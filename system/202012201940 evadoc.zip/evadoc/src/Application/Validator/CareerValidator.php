<?php
namespace App\Validator;
use Rakit\Validation\Validator;

class CareerValidator{
    private Validator $validator;

    public function __construct(Validator $validator) {
        $this->validator = $validator;
    }

    public function validateSaveCareer(array $data): array {
        $validationRules = [
            'clave'          =>  'required|alpha_dash|between:13,13',
            'nombre'         =>  'required|alpha|alpha_spaces',
            'nombre_corto'   =>  'required|alpha|between:2,5',
        ];
    
        $errorMessages = [
            'clave:required'         => 'La clave es obligatoria',
            'clave:alpha_dash'       => 'La clave no es válida',
            'clave:between'          => 'La clave debe tener 13 caracteres',
            'nombre:required'        => 'El nombre es obligatorio',
            'nombre:alpha'           => 'El nombre no es válido',
            'nombre:alpha_espaces'   => 'El nombre no es válido',
            'nombre_corto:required'  => 'El nombre es obligatorio',
            'nombre_corto:alpha'     => 'El nombre no es válido',
            'nombre_corto:between'   => 'El nombre debe tener entre 2 y 5 caracteres',
        ];
    
        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data);
    }

    public function validateFindCareer(array $data): array {
        $validationRules = [
            'nombre'          =>  'required|alpha|alpha_spaces',
        ];
    
        $errorMessages = [
            'nombre:required'        => 'El nombre es obligatorio',
            'nombre:alpha'           => 'El nombre no es válido',
            'nombre:alpha_espaces'   => 'El nombre no es válido',
        ];
    
        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data);
    }
}