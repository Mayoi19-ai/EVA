<?php
namespace App\Validator;

use Rakit\Validation\Validator;

class CustomValidator {

    protected Validator $validator;
    protected array $valiationRules;
    protected array $errorMessages;

    public function __construct(Validator $validator, array $validationRules, array $errorMessages) {
        $this->validator = $validator;
        $this->validationRules = $validationRules;
        $this->errorMessages = $errorMessages;
    }

    public function validate(array $data): array {
        $validation = $this->validator->make($data, $this->validationRules, $this->errorMessages);
        $validation->validate();

        if ($validation->fails()) {
            $errors        = $validation->errors();
            $errorMessages = $errors->firstOfAll();
            // Array holding all the results (valid data and errors)
            $resultData = [$errorMessages, 
            'flag' => false];
            return $resultData;
        } else {
            $validData = $validation->getValidData();
            $resultData = [$validData, 
            'flag' => true];
            return $resultData;
        }
    }
}