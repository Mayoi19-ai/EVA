<?php
namespace App\Validator;
use Rakit\Validation\Validator;

class CampusValidator{
    private Validator $validator;

    public function __construct(Validator $validator) {
        $this->validator = $validator;
    }

    public function validateSaveCampus(array $data): array {
        $validationRules = [
            'nombre'          =>  'required|alpha|alpha_spaces',
        ];
    
        $errorMessages = [
            'nombre:required'     => 'El nombre es obligatorio',
            'nombre:alpha'        => 'El nombre no es válido',
            'nombre:alpha_spaces' => 'El nombre no acepta caracteres especiales',
        ];
    
        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data);
    }
}