<?php
namespace App\Controller\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use App\Validator\SchoolSubjectValidator;
use Ujpef\LatteView;
use Slim\Exception\HttpForbiddenException;
use App\Infrastructure\CrudSystem\SchoolSubjectInfrastructure as Infrastructure;
use App\Infrastructure\CrudSystem\CareerInfrastructure as Career;
use App\Infrastructure\CrudSystem\LessonInfrastructure as Lesson;

class SchoolSubjectController{
    private Container $container;
    private Infrastructure $infrastructure;
    private Career $career;
    private Lesson $lesson;
    
    public function __construct(Container $container, Infrastructure $infrastructure, Career $career, Lesson $lesson){
        $this->container = $container;
        $this->infrastructure = $infrastructure;
        $this->career = $career;
        $this->lesson = $lesson;
    }

    public function saveForm(Request $request, Response $response){
        $careerData = $this->career->readAuxiliary();
        $lessonData = $this->lesson->readAll();

        return $this->container->get(LatteView::class)->render($response, 
        'Materia/schoolsubject.latte',[
            'careers' => $careerData,
            'lessons' => $lessonData
        ]);
    }

    public function register(Request $request, Response $response, array $args){
        $resultData = [];
        
        $data = (array)$request->getParsedBody();
        $this->infrastructure->create($data);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Materia/schoolsubjectValidation.latte',
            ['validacion_exitosa' => $validationResult] + $resultData
        );
    }

    public function searchByCareer(Request $request, Response $response){
        $resultData = [];
        $name = $_GET['nombre'];
        $data = $this->infrastructure->readByCareer($name);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Materia/schoolsubjectValidation.latte',[
                'subject_search' => $name,
                'careers' => $data]
        );
    }

    public function searchByLesson(Request $request, Response $response){
        $resultData = [];
        $name = $_GET['nombre'];
        $data = $this->infrastructure->readByLesson($name);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Materia/schoolsubjectValidation.latte',[
                'subject_search' => $name,
                'lessons' => $data]
        );
    }

    public function show(Request $request, Response $response){
        $data = $this->infrastructure->readAll();

        return $this->container->get(LatteView::class)->render(
            $response, 
            'PruebasGera/prueba.latte', [
                'all_subjects_information' => $data
            ]);
    }

    public function updateForm(Request $request, Response $response){
        $data = $request->getParsedBody();
        $careerData = $this->career->readAll();
        $lessonData = $this->lesson->readAll();

        return $this->container->get(LatteView::class)->render($response, 
        'Materia/schoolsubject.latte',[
            'subject_information' => $data,
            'careers' => $careerData,
            'lessons' => $lessonData
        ]);
    }

    public function update(Request $request, Response $response, array $args){
        $resultData = [];
        
        $data = (array)$request->getParsedBody();
        $this->infrastructure->update($data);
        return $this->container->get(LatteView::class)->render(
            $response,
            'Materia/schoolsubjectValidation.latte',
            ['validacion_exitosa' => $validationResult] + $resultData
        );
    }

    public function delete(Request $request, Response $response){
        $this->infrastructure->delete($_GET['id_carrera'], $_GET['clave_asignatura']);
        return $response;
    }
}