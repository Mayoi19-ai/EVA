<?php
namespace App\Controller\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use App\Validator\ModalityValidator as Validator;
use Ujpef\LatteView;
use Slim\Exception\HttpForbiddenException;
use App\Infrastructure\CrudSystem\ModalityInfrastructure as Infrastructure;

class ModalityController{
    private Container $container;
    private Infrastructure $infrastructure;
    private Validator $validator;
    
    public function __construct(Container $container, Infrastructure $infrastructure, Validator $validator){
        $this->container = $container;
        $this->infrastructure = $infrastructure;
        $this->validator = $validator;
    }

    public function saveForm(Request $request, Response $response){
        return $this->container->get(LatteView::class)->render($response, 
            'Modalidad/modality.latte');
    }

    public function register(Request $request, Response $response, array $args){
        $data = $request->getParsedBody();
        $this->infrastructure->create($data);
        $validationResult = $this->validator->validateSaveModality($data);

        if($validationResult['flag']) {
            echo 'true';
        } else {
            echo 'false';
        }
        
        return $this->container->get(LatteView::class)->render(
            $response,
            'Modalidad/modalityValidation.latte',
            ['validacion_exitosa' => $validationResult]
        );
    }

    public function show(Request $request, Response $response, array $args){
        $data = $this->infrastructure->readAll();

        return $this->container->get(LatteView::class)->render(
            $response,
            'Maestros/teacherTable.latte', [
                'all_modalities_information' => $data
            ]
        );
    }
    
    public function update(Request $request, Response $response, array $args){
        
        $data = $request->getParsedBody();
        $validationResult = $this->validator->validateSaveModality($data);

        if($validationResult['flag']) {
            echo 'true';
        } else {
            echo 'false';
        }
        
        $this->infrastructure->update($data);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Modalidad/modalityValidation.latte',
            ['validacion_exitosa' => $validationResult]
        );
    }

    public function delete(Request $request, Response $response, array $args){
        $this->infrastructure->delete($args['id']);
        return $response;
    }
}
