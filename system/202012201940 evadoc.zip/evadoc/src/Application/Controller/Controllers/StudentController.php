<?php
namespace App\Controller\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use App\Validator\StudentValidator;
use Ujpef\LatteView;
use Slim\Exception\HttpForbiddenException;
use App\Infrastructure\CrudSystem\StudentInfrastructure as Infrastructure;

class StudentController{
    private Container $container;
    private Infrastructure $infrastructure;
    
    public function __construct(Container $container, Infrastructure $infrastructure){
        $this->container = $container;
        $this->infrastructure = $infrastructure;
    }

    public function saveForm(Request $request, Response $response){
        return $this->container->get(LatteView::class)->render($response, 
            'Alumnos/student.latte');
    }

    public function register(Request $request, Response $response, array $args){
        $resultData = [];
        
        $data = (array)$request->getParsedBody();
        $this->infrastructure->create($data);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Alumnos/validationstudent.latte',
            ['validacion_exitosa' => $validationResult] + $resultData
        );
    }

    public function search(Request $request, Response $response){
        $resultData = [];
        $control = $_GET['control'];

        $data = $this->infrastructure->read($control);
        return $this->container->get(LatteView::class)->render(
            $response,
            'Alumnos/validationstudent.latte', [
                'student_information' => $data,
                'student_control' => $control
            ]);
    }
    
    public function show(Request $request, Response $response, array $args){
        $data = $this->infrastructure->readAll();
        return $this->container->get(LatteView::class)->render(
            $response,
            'Alumnos/studentTable.latte', [
                'students_information' => $data  
            ]);
    }

    public function updateForm(Request $request, Response $response){
        $data = $request->getParsedBody();
        return $this->container->get(LatteView::class)->render($response, 
            'Alumnos/student.latte', [
                'student_information' => $data
            ]);
    }

    public function update(Request $request, Response $response, array $args){
        $resultData = [];
        
        $data = (array)$request->getParsedBody();
        $this->infrastructure->update($data);
        return $this->container->get(LatteView::class)->render(
            $response,
            'Alumnos/validationstudent.latte',
            ['validacion_exitosa' => $validationResult] + $resultData
        );
    }

    public function delete(Request $request, Response $response){
        $this->infrastructure->delete($_GET['control']);
        return $response;
    }
}