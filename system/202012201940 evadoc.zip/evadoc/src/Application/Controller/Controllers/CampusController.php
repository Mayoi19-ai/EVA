<?php
namespace App\Controller\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use Ujpef\LatteView;
use Slim\Exception\HttpForbiddenException;
use App\Validator\CampusValidator as Validator;
use App\Infrastructure\CrudSystem\CampusInfrastructure as Infrastructure;

class CampusController{
    private Container $container;
    private Validator $validator;
    private Infrastructure $infrastructure;

    public function __construct(Container $container, Validator $validator, Infrastructure $infrastructure){
        $this->container = $container;
        $this->validator = $validator;
        $this->infrastructure = $infrastructure;
    }

    public function saveForm(Request $request, Response $response, array $args){
        return $this->container->get(LatteView::class)->render($response, 'Campus/campusform.latte'
        );
    }

    public function register(Request $request, Response $response, array $args){
        $resultData = [];
        
        $data = (array)$request->getParsedBody();
        //$validationResult =  $this->validator->validateSaveCampus($data, $resultData);
        $this->infrastructure->create($data);
        return $this->container->get(LatteView::class)->render(
            $response,
            'Campus/campusvalidation.latte',
            ['validacion_exitosa' => $validationResult, 'result' => $resultData]
        );
    }

    public function show(Request $request, Response $response){
        $data = $this->infrastructure->readAll();
        
        return $this->container->get(LatteView::class)->render(
            $response,
            'Campus/campusTable.latte',
            ['all_campuses_information' => $data]
        );
    }

    public function update(Request $request, Response $response){
        $resultData = [];
        $data = (array)$request->getParsedBody();

        $this->infrastructure->update($data);
        return $this->container->get(LatteView::class)->render(
            $response,
            'Campus/campusform.latte',
        );
    }

    public function updateForm(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        return $this->container->get(LatteView::class)->render(
            $response,
            'Campus/updatecampus.latte',
            ['campus_data' => $data]
        );
    }

    public function delete(Request $request, Response $response){
        $this->infrastructure->delete($_GET['id']);
        return $response;
    }
}