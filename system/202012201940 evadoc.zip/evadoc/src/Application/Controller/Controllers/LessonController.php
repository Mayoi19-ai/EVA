<?php
namespace App\Controller\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use App\Validator\LessonValidator as Validator;
use Ujpef\LatteView;
use Slim\Exception\HttpForbiddenException;
use App\Infrastructure\CrudSystem\LessonInfrastructure as Infrastructure;

class LessonController{
    private Container $container;
    private Infrastructure $infrastructure;
    private Validator $validator;
    
    public function __construct(Container $container, Infrastructure $infrastructure, Validator $validator){
        $this->container = $container;
        $this->infrastructure = $infrastructure;
        $this->validator = $validator;
    }

    public function saveForm(Request $request, Response $response){
        return $this->container->get(LatteView::class)->render($response, 'Asignatura/lesson.latte');
    }

    public function register(Request $request, Response $response){
        $resultData = [];
        
        $data = (array)$request->getParsedBody();
        $this->infrastructure->create($data);
    
        return $this->container->get(LatteView::class)->render(
            $response,
            'Asignatura/lessonvalidation.latte',
            ['validacion_exitosa' => $validationResult] + $resultData
        );
    }

    public function search(Request $request, Response $response){
        $resultData = [];

        $data = $this->infrastructure->read($_GET['nombre']);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Asignatura/lessonSearch.latte',
            ['all_lessons_information' => $data,
            'lesson_name' => $name]
        );
    }

    public function show(Request $request, Response $response, array $args){
        $data = $this->infrastructure->readAll();

        return $this->container->get(LatteView::class)->render(
            $response,
            'Asignatura/lessonTable.latte', [
                'all_lessons_information' => $data]);
    }

    public function updateForm(Request $request, Response $response){
        $data = $request->getParsedBody();
        return $this->container->get(LatteView::class)->render($response, 
            'Asignatura/lessonUpdate.latte', [
                'lesson_information' => $data
            ]);
    }

    public function update(Request $request, Response $response){
        $resultData = [];
        
        $data = (array)$request->getParsedBody();
        $this->infrastructure->update($data);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Asignatura/lessonvalidation.latte',
            ['validacion_exitosa' => $validationResult] + $resultData
        );
    }

    public function delete(Request $request, Response $response){
        $this->infrastructure->delete($_GET['clave']);
        return $response;
    }
}