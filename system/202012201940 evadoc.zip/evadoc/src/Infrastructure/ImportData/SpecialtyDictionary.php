<?php
namespace App\Infrastructure\ImportData;

use Port\Spreadsheet\SpreadsheetReader;
use Medoo\Medoo;

class SpecialtyDictionary {
    private Medoo $db;

    public function __construct(Medoo $db) {
        $this->db = $db;
    }

    public function loadSpecialtyDictionary(string $xlsxFileDictionarySpecialty) {
        $sql = <<<'EOD'
        INSERT IGNORE INTO diccionario_especialidad 
            (cve, id_carrera, id_modalidad, id_campus) 
            values (:cve, :id_carrera, :id_modalidad, :id_campus);
        EOD;

        $file = new \SplFileObject($xlsxFileDictionarySpecialty);
        $specialties = new SpreadsheetReader($file);
        $i = 2; // Rows to ignore.
        foreach ($specialties as $record) {
            if($i++ > 3) {

                $sth = $this->db->pdo->prepare($sql);
                $sth->bindParam(':cve', $record[0]);
                $sth->bindParam(':id_carrera', $record[1]);
                $sth->bindParam(':id_modalidad', $record[2]);
                $sth->bindParam(':id_campus', $record[3]);
                $sth->execute();
            }
        }
    }
}