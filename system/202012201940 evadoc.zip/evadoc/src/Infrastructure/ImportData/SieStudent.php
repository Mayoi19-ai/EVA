<?php
namespace App\Infrastructure\ImportData;

use org\majkel\dbase\Table;
use Medoo\Medoo;

class SieStudent {
    private Medoo $db;

    public function __construct(Medoo $db) {
        $this->db = $db;
    }

    public function loadSieStudent (string $dbfFileStudent) {
        $sql = <<<'EOP'
        DROP TABLE IF EXISTS `temp_dalu`;
        CREATE TEMPORARY TABLE IF NOT EXISTS `temp_dalu` (
            `ctr` CHAR(8) NOT NULL,
            `nom` VARCHAR(250) NOT NULL,
            `esp` INT(10) NOT NULL,
            `sem` TINYINT(12) UNSIGNED NOT NULL,
            PRIMARY KEY (`ctr`));
        EOP;

        $this->db->query($sql);

        $file = Table::fromFile($dbfFileStudent);

        foreach ($file as $record) {
            $this->db->insert("temp_dalu", [
                "ctr" => $record['ALU_CTR'],
                "nom" => utf8_encode($record['ALU_NIN']),
                "esp" => $record['ALU_ESP'],
                "sem" => $record['ALU_SEM']
            ]);
        }
    }
}