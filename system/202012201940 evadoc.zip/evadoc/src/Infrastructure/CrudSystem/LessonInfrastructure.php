<?php
namespace App\Infrastructure\CrudSystem;

use Medoo\Medoo;

class LessonInfrastructure{
    private Medoo $db;

    public function __construct(Medoo $db) {
        $this->db = $db;
    }

    public function create(array $data): ?array
    {
        $sql = $this->db->insert('asignatura',[
            'clave' => strtoupper($lessonData['clave']), 
            'nombre'=> strtoupper($lessonData['nombre'])
        ]);
        return $sql;
    }

    public function readAll(): ?array
    {
        $sql = $this->db->select('asignatura',[
           'clave', 
            'nombre']
        );
        return $sql;
    }

    public function read(string $name)
    {
        $sql = $this->db->select('asignatura', [
            'clave', 
            'nombre'],[
                'nombre[~]' => strtoupper($name)
            ]);

        return $sql;
    }

    public function update(array $data): ?array
    {
        $sql = $this->db->update('asignatura', [
            'clave'  => strtoupper($data['clave']), 
            'nombre' => strtoupper($data['nombre'])], [
                'clave' => strtoupper($data['clave_antigua'])
            ]);

        return $sql;
    }
    
    public function delete(string $code): ?array
    {
        $sql = $this->db->delete('asignatura', [
            'clave' => $code
        ]);
        
        return $sql;
    }
}