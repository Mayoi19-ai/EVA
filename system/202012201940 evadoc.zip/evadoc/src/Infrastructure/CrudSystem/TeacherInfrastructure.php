<?php
namespace App\Infrastructure\CrudSystem;

use Medoo\Medoo;

class TeacherInfrastructure{
    private Medoo $db;

    public function __construct(Medoo $db) {
        $this->db = $db;
    }

    public function create(array $data): ?array
    {
        $sql = $this->db->insert('docente',[
            'folio' => $data['folio'], 
            'nombre' => strtoupper($data['nombre']),
            'clave_departamento' => $data['clave_departamento']
            ]);
        return $sql;
    }

    public function readAll(): ?array
    {
        $sql = <<<'EOP'
        SELECT docente.folio AS 'folio', 
        docente.nombre AS 'nombre',
        departamento.clave AS 'clave_departamento',
        departamento.nombre  AS 'departamento'
        FROM 
        docente,
        departamento 
        where docente.clave_departamento =  departamento.clave;
        EOP;
        $sth = $this->db->pdo->prepare($sql);
        $sth->execute();
        $records = $sth->fetchAll();
        return $records;
    }

    public function read(string $name): ?array
    {
        $sql = <<<'EOP'
        SELECT docente.folio AS 'folio', 
        docente.nombre AS 'nombre',
        departamento.clave AS 'clave_departamento',
        departamento.nombre  AS 'departamento'
        FROM 
        docente,
        departamento 
        where docente.clave_departamento = departamento.clave
        AND docente.nombre LIKE '%' :nombre '%';
        EOP;
        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':nombre', strtoupper($name));
        $sth->execute();
        $records = $sth->fetchAll();
        return $records;
    }

    public function readByDepartment(string $name): ?array
    {
        $sql = <<<'EOP'
        SELECT docente.folio AS 'folio', 
        docente.nombre AS 'nombre',
        departamento.clave AS 'clave_departamento',
        departamento.nombre  AS 'departamento'
        FROM 
        docente,
        departamento 
        where docente.clave_departamento = departamento.clave
        AND departamento.nombre LIKE '%' :nombre '%';
        EOP;
        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':nombre', strtoupper($name));
        $sth->execute();
        $records = $sth->fetchAll();
        return $records;
    }

    public function update(array $data): ?array
    {
        $sql = $this->db->update('docente', [
            'folio' => $data['folio'], 
            'nombre' => strtoupper($data['nombre']),
            'clave_departamento' => $data['clave_departamento']], [
                'folio' => $data['folio_antiguo']
                ]);

        return $sql;
    }
    
    public function delete(string $code): ?array
    {
        $sql = $this->db->delete('docente', [
            'folio' => $code]
        );
        return $sql;
    }
}