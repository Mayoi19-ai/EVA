<?php
namespace App\Infrastructure\CrudSystem;

use Medoo\Medoo;

class SchoolSubjectInfrastructure{
    private Medoo $db;

    public function __construct(Medoo $db) {
        $this->db = $db;
    }

    public function insertSubject(array $data): ?array
    {
        $sql = $this->db->insert('materia',[
            'id_carrera' => $data['id_carrera'], 
            'clave_asignatura' => $data['clave_asignatura']
            ]);

        return $sql;
    }

    public function readAll(): ?array
    {
        $sql = <<<'EOP'
        SELECT carrera.nombre AS 'carrera', 
        carrera.id AS 'id_carrera',
        asignatura.nombre AS 'asignatura',
        asignatura.clave AS 'clave_asignatura'
        FROM 
        carrera, 
        asignatura, 
        materia
        WHERE 
        materia.id_carrera = carrera.id
        AND
        materia.clave_asignatura = asignatura.clave
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->execute();
        $records = $sth->fetchAll();
        return $records;
    }

    public function readByCareer(string $name): ?array
    {
        $sql = <<<'EOP'
        SELECT carrera.nombre AS 'carrera', 
        carrera.id AS 'id_carrera',
        asignatura.nombre AS 'asignatura',
        asignatura.clave AS 'clave_asignatura'
        FROM 
        carrera, 
        asignatura, 
        materia
        WHERE 
        materia.id_carrera = carrera.id
        AND
        materia.clave_asignatura = asignatura.clave
        AND 
        carrera.nombre LIKE '%' :nombre '%';
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':nombre', $name);
        $sth->execute();
        $records = $sth->fetchAll();
        return $records;
    }

    public function readByLesson(string $name): ?array
    {
        $sql = <<<'EOP'
        SELECT carrera.nombre AS 'carrera', 
        carrera.id AS 'id_carrera',
        asignatura.nombre AS 'asignatura',
        asignatura.clave AS 'clave_asignatura'
        FROM 
        carrera, 
        asignatura, 
        materia
        WHERE 
        materia.id_carrera = carrera.id
        AND
        materia.clave_asignatura = asignatura.clave
        AND 
        asignatura.nombre LIKE '%' :nombre '%';
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':nombre', $name);
        $sth->execute();
        $records = $sth->fetchAll();
        return $records;
    }

    public function updateSubject(array $data): ?array
    {
        $sql = $this->db->update('materia',[
            'id_carrera' => $data['id_carrera'], 
            'clave_asignatura' => $data['clave_asignatura']],[
                'AND' => [
                'id_carrera' => $data['id_carrera_antiguo'], 
                'clave_asignatura' => $data['clave_asignatura_antiguo']
                ]
            ]);

        return $sql;
    }
    
    public function delete(int $careerId, string $lessonCode): ?array
    {
        $data = $this->db->delete('materia', [
            'AND' => [
            'id_carrera' => $careerId,
            'clave_asignatura' => $lessonCode
            ]
        ]);
        
        return $data;
    }
}