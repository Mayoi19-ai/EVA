<?php
namespace App\Infrastructure\CrudSystem;

use Medoo\Medoo;

class StudentInfrastructure{
    private Medoo $db;

    public function __construct(Medoo $db) {
        $this->db = $db;
    }

    public function create(array $data): ?array
    {
        $sql = $this->db->insert('alumno',[
            'control' => strtoupper($data['control']), 
            'nombre' => strtoupper($data['nombre']),
            'contrasenia' => $data['control']
            ]);

        return $sql;
    }

    public function readAll(): ?array
    {
        $sql = $this->db->select('alumno',[
            'control',
            'nombre']
        );

        return $data;
    }

    public function read(string $control): ?array
    {
        $sql = $this->db->select('alumno',[
            'nombre',
            'control'], [
                'control' => strtoupper($control)]
            );

        return $sql;
    }

    public function update(array $data): ?array
    {
        $sql = $this->db->update('alumno',[
            'control' => strtoupper($data['control']), 
            'nombre' => strtoupper($data['nombre']),
            'contrasenia' => strtoupper($data['control'])], [
                'control' => strtoupper($data['control_antiguo'])
                ]);

        return $sql;
    }

    public function updatePassword(array $data): ?array
    {
        $sql = $this->db->update('alumno',[
            'contrasenia' => $data['contrasenia']], [
                'control' => strtoupper($data['control'])
                ]);

        return $sql;
    }
    
    public function delete(string $control): ?array
    {
        $sql = $this->db->delete('alumno', [
                'control' => $control
                ]);

        return $sql;
    }
}