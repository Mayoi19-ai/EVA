<?php
namespace App\Infrastructure\CrudSystem;

use Medoo\Medoo;

class CareerInfrastructure{
    private Medoo $db;

    public function __construct(Medoo $db) {
        $this->db = $db;
    }

    public function create(array $data): ?array
    {
        $sql = $this->db->insert('carrera',[
            'id' => $data['id'],
            'clave' => strtoupper($data['clave']), 
            'nombre' => strtoupper($data['nombre']),
            'nombre_corto' => strtoupper($data['nombre_corto'])
        ]);
        return $sql;
    }

    public function readAll(): ?array
    {
        $sql = $this->db->select('carrera', [
            'id', 
            'clave',
            'nombre',
            'nombre_corto']);
        return $sql;
    }

    public function readAuxiliary(): ?array
    {
        $sql = $this->db->select('carrera', [
            'id',
            'nombre'
        ]);

        return $sql;   
    }

    public function update(array $data): ?array
    {
        $sql = $this->db->update('carrera', [
            'clave'  => strtoupper($data['clave']),
            'nombre' => strtoupper($data['nombre']),
            'nombre_corto' => strtoupper($data['nombre_corto'])], [
            'id' => $data['id']
            ]);

        return $sql;
    }
    
    public function delete(int $id): ?array
    {   
        $sql = $this->db->delete('carrera', [
            'id' => $id
        ]);
        return $sql;
    }
}