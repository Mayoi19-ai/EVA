<?php
namespace App\Infrastructure\CrudSystem;

use Medoo\Medoo;

class CourseInfrastructure{
    private Medoo $db;

    public function __construct(Medoo $db) {
        $this->db = $db;
    }

    public function create(array $data): ?array
    {
        $data = $this->db->insert('curso',[
            'nombre_grupo' => $data['grupo'],
            'id_periodo' => $data['id_periodo'],
            'id_carrera' => $data['id_carrera'],
            'clave_asignatura' => $data['clave_asignatura'],
            'folio_docente' => $data['folio_docente']
            ]);

        return $data;
    }

    public function readAll(int $periodId): ?array
    {
        $sql = <<<'EOP'
        SELECT curso.id AS 'id_curso',
        curso.nombre_grupo AS 'grupo',
        carrera.nombre AS 'carrera',
        curso.id_carrera AS 'id_carrera',
        asignatura.nombre AS 'asignatura',
        curso.clave_asignatura AS 'clave_asignatura',
        docente.nombre AS 'docente',
        curso.folio_docente AS 'folio_docente'
        FROM 
        curso,
        asignatura,
        carrera, 
        docente
        WHERE 
        curso.id_carrera = carrera.id
        AND 
        curso.clave_asignatura = asignatura.clave
        AND 
        curso.folio_docente = docente.folio
        AND
        curso.id_periodo = :id_periodo;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':id_periodo', $periodId);
        $sth->execute();
        $records = $sth->fetchAll();
        return $records;
    }

    public function readBygroup(string $group, int $periodId): ?array
    {
        $sql = <<<'EOP'
        SELECT curso.id AS 'id_curso',
        curso.nombre_grupo AS 'grupo',
        carrera.nombre AS 'carrera',
        curso.id_carrera AS 'id_carrera',
        asignatura.nombre AS 'asignatura',
        curso.clave_asignatura AS 'clave_asignatura',
        docente.nombre AS 'docente',
        curso.folio_docente AS 'folio_docente'
        FROM 
        curso,
        asignatura,
        carrera, 
        docente
        WHERE 
        curso.id_carrera = carrera.id
        AND 
        curso.clave_asignatura = asignatura.clave
        AND 
        curso.folio_docente = docente.folio
        AND
        curso.id_periodo = :id_periodo
        AND 
        curso.nombre_grupo LIKE '%' :grupo '%';
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':id_periodo', $periodId);
        $sth->bindParam(':grupo', $group);
        $sth->execute();
        $records = $sth->fetchAll();
        return $records;
    }

    public function readByLesson(string $lesson, int $periodId): ?array
    {
        $sql = <<<'EOP'
        SELECT curso.id AS 'id_curso',
        curso.nombre_grupo AS 'grupo',
        carrera.nombre AS 'carrera',
        curso.id_carrera AS 'id_carrera',
        asignatura.nombre AS 'asignatura',
        curso.clave_asignatura AS 'clave_asignatura',
        docente.nombre AS 'docente',
        curso.folio_docente AS 'folio_docente'
        FROM 
        curso,
        asignatura,
        carrera, 
        docente
        WHERE 
        curso.id_carrera = carrera.id
        AND 
        curso.clave_asignatura = asignatura.clave
        AND 
        curso.folio_docente = docente.folio
        AND
        curso.id_periodo = :id_periodo
        AND 
        asignatura.nombre LIKE '%' :asignatura '%';
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':id_periodo', $periodId);
        $sth->bindParam(':asignatura', $lesson);
        $sth->execute();
        $records = $sth->fetchAll();
        return $records;
    }

    public function update(array $data): ?array
    {
        $data = $this->db->update('curso',[
            'nombre_grupo' => $data['grupo'], 
            'id_carrera' => $data['id_carrera'],
            'clave_asignatura' => $data['clave_asignatura'],
            'folio_docente' => $data['folio_docente']], [
                'curso.id' => $data['id_curso']
            ]);

        return $data;
    }
    
    public function deleteCourse(int $code, int $periodId): ?array
    {
        $data = $this->db->delete('curso', [
            'AND' => [
                'curso.id' => $code,
                'id_periodo' => $periodId
            ]
        ]);
        
        return $data;
    }
}