function validateSaveCampus(formulario) {
    if(formulario.so.value.length<1){
        alert('Seleccione un Sistema Operativo.');
        return false;
    }  
}
