<?php
// source: Curso/courseTable.latte

use Latte\Runtime as LR;

class Templateb16fb7885e extends Latte\Runtime\Template
{
	public $blocks = [
		'content' => 'blockContent',
	];

	public $blockTypes = [
		'content' => 'html',
	];


	function main()
	{
		extract($this->params);
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('content', get_defined_vars());
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['courseShow'])) trigger_error('Variable $courseShow overwritten in foreach on line 28');
		
	}


	function blockContent($_args)
	{
		extract($_args);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 7 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
</head>

<body>
 
 

<table name="showAllCourses" method="get" >
<tr>
<th>Clave de curso</th>
<th>Grupo</th>
<th>Periodo</th>
<th>Carrera</th>
<th>Asignatura</th>
<th>Docente</th>

</tr>

<?php
		$iterations = 0;
		foreach ($all_courses_information as $courseShow) {
?>
<tr>

    <td><?php echo LR\Filters::escapeHtmlText($courseShow['Curso id']) /* line 31 */ ?> </td>
    <td><?php echo LR\Filters::escapeHtmlText($courseShow['Grupo']) /* line 32 */ ?> </td>
    <td><?php echo LR\Filters::escapeHtmlText($courseShow['Periodo']) /* line 33 */ ?> </td>
    <td><?php echo LR\Filters::escapeHtmlText($courseShow['Carrera']) /* line 34 */ ?> </td>
     <td><?php echo LR\Filters::escapeHtmlText($courseShow['Asignatura']) /* line 35 */ ?> </td>
      <td><?php echo LR\Filters::escapeHtmlText($courseShow['Docente']) /* line 36 */ ?> </td>

    
    <td>
<form action="<?php
			echo $router->relativeUrlFor("courseUpdateForm");
?>" method="post">
            <input type="hidden" name="id" value="<?php echo LR\Filters::escapeHtmlAttr($campusShow['id']) /* line 41 */ ?>">
            <input type="hidden" name="nombre" value="<?php echo LR\Filters::escapeHtmlAttr($campusShow['nombre']) /* line 42 */ ?>">
<input type="submit" class="btn btn-primary btn-sm" value='Editar'>
</form>
</td>
    </td>

</tr>
<?php
			$iterations++;
		}
?>

</body>
</html>
<?php
	}

}
