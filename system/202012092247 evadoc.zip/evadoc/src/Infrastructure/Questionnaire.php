<?php
namespace App\Infrastructure;

use Medoo\Medoo;

class Questionnaire {
    private Medoo $db;

    public function __construct(Medoo $db) {
        $this->db = $db;
    }

    public function get(): array {
        $stm = $this->db->select(
            "cuestionario", [
                "id", "pregunta"], [
                    
                ]);
            
        return $stm;
    }
}