<?php
namespace App\Validator;
use Rakit\Validation\Validator;

class PeriodValidator{
    private Validator $validator;

    public function __construct(Validator $validator) {
        $this->validator = $validator;
    }

    public function validateSavePeriod(array $data, array &$resultData): bool {
        $validationRules = [
            'name'          =>  'required|uppercase',
            'begin'         =>  'required|date:Y-m-d',
            'complete'      =>  'date:Y-m-d',
        ];

        $errorMessages = [
            'name:required'     => 'El nombre es obligatorio',
            'name:uppercase'    => 'El nombre debe estar en mayúsculas',
            'begin:required'    => 'La fecha de inicio es obligatoria',
            'begin:date'        => 'El formato de fecha inicio no es válido',
            'complete:date'     => 'El formato de fecha fin no es válido',
        ];

        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data, $resultData);
    }

    public function validateFindPeriod(array $data, array &$resultData): bool {
        $validationRules = [
            'name'          =>  'required|alpha_dash|uppercase',
        ];

        $errorMessages = [
            'name:required'     => 'El nombre es obligatorio',
            'name:uppercase'    => 'El nombre debe estar en mayúsculas',
        ];
    }
}