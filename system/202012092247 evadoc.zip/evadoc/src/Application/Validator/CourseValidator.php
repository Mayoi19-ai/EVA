<?php
namespace App\Validator;
use Rakit\Validation\Validator;

class CourseValidator{
    private Validator $validator;

    public function __construct(Validator $validator) {
        $this->validator = $validator;
    }

    public function validateSaveCourse(array $data, array &$resultData): bool {
        $validationRules = [
            'groupName'     =>  'required|alpha_num|uppercase|between:4,4',
            'codePeriod'    =>  'required|numeric|digits_between:1,10',
            'codeCareer'    =>  'required|alpha_dash|uppercase|between:13,13',
            'codeLesson'    =>  'required|alpha_dash|uppercase|between:8,8',
            'teacherFolio'  =>  'required|numeric|digits_between:1,3',
        ];

        $errorMessages = [
            'codePeriod:required'          => 'La clave del periodo es obligatoria',
            'codePeriod:numeric'           => 'La clave del periodo es numerica',
            'codePeriod:digits_between'    => 'La clave del periodo debe tener entre 1 a 10 caracteres',
            'codeCareer:required'          => 'La clave es obligatoria',
            'codeCareer:uppercase'         => 'La clave de la crrera debe estar en mayúsculas',
            'codeCareer:between'           => 'La clave de carrera debe tener 13 caracteres',
            'codeCareer:alpha_dash'        => 'La clave de carrera no permite espacios o caracteres especiales',
            'codeLesson:required'          => 'La clave de asignatura es obligatoria',
            'codeLesson:alpha_dash'        => 'La clave de asignatura no acepta espacios o caracteres especiales',
            'codeLesson:uppercase'         => 'La clave de asignatura debe de estar en mayúsculas',
            'codeLesson:between'           => 'La clave de asignatura debe tener 8 caracteres',
            'teacherFolio:required'        => 'El folio del docente es requerido',
            'teacherFolio:digits_between'  => 'El folio del docente debe tener tres digitos',
            'teacherFolio:numeric'         => 'El folio del docente solo acepta números',
        ];

        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data, $resultData);
    }
}