<?php

namespace App\Infrastructure\ImportData;

use App\Infrastructure\CrudSystem\InscriptionInfrastructure;
use Medoo\Medoo;


class Inscriptions {
    private Medoo $db;
    private InscriptionInfrastructure $inscriptionInfrastructure;

    public function __construct(Medoo $db, InscriptionInfrastructure $inscriptionInfrastructure){
        $this->db = $db;
        $this->inscriptionInfrastructure = $inscriptionInfrastructure;
    }

    public function inscriptions (int $period): ?array
    {
        $inscriptions = $this->importInscriptions((int) $period);

        if (array_key_exists('error', $this->inscriptionInfrastructure->readAll((int) $period))) {
            $result = ['flag' => true, 
            'error' => 'Error al importar Registros en Inscripción'];
            return $result;
        }
        
        return null;
    }

    private function importInscriptions(int $period)
    {
        $sql = <<<'EOP'
        DROP TABLE IF EXISTS `temp_inscripcion`;
        CREATE TEMPORARY TABLE `temp_inscripcion`(
        `ctr_alumno` CHAR(10) NOT NULL,
        `grupo` CHAR(6) NOT NULL,
        `id_periodo` INT(10) NOT NULL,
        `id_carrera` INT(10) NOT NULL, 
        `clave_asginatura` CHAR(10) NOT NULL,
        `folio_docente` INT(10) NOT NULL,
        UNIQUE INDEX `inscription_UNIQUE` USING BTREE (`ctr_alumno`, 
        `grupo`, `id_periodo`, `id_carrera`, `clave_asginatura`, `folio_docente`));

        INSERT IGNORE INTO temp_inscripcion 
        SELECT temp_dlis.ctr, temp_grupo.nombre, :id_periodo, diccionario_especialidad.id_carrera, temp_dret2.clave_asignatura, temp_dgau.cat
        FROM temp_grupo
        INNER JOIN 
        temp_dlis
        ON temp_grupo.cve = temp_dlis.gpo
        INNER JOIN 
        temp_dgau
        ON temp_dlis.gpo = temp_dgau.gpo AND temp_dlis.mat = temp_dgau.mat
        INNER JOIN 
        temp_dcat
        ON temp_dcat.cve =  temp_dgau.cat
        INNER JOIN
        temp_dret
        ON temp_dgau.mat = temp_dret.cve
        INNER JOIN 
        temp_dret2
        ON temp_dret.cve = temp_dret2.mat
        INNER JOIN 
        diccionario_especialidad
        ON temp_dret2.esp =  diccionario_especialidad.cve;

        INSERT INTO inscripcion (id_curso, alumno_control, activar)
        SELECT curso.id, temp_inscripcion.ctr_alumno, 1 FROM curso
        INNER JOIN 
        temp_inscripcion
        ON curso.nombre_grupo = temp_inscripcion.grupo 
        AND 
        curso.id_periodo = temp_inscripcion.id_periodo
        AND 
        curso.id_carrera = temp_inscripcion.id_carrera
        AND 
        curso.clave_asignatura = temp_inscripcion.clave_asginatura
        AND 
        curso.folio_docente = temp_inscripcion.folio_docente;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':id_periodo', $period);
        $sth->execute();
    }
}