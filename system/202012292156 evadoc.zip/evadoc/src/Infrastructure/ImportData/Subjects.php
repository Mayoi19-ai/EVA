<?php

namespace App\Infrastructure\ImportData;

use Medoo\Medoo;

class Subjects {
    private Medoo $db;
    public function __construct(Medoo $db){
        $this->db = $db;
    }

    public function subjects()
    {
        $sql = <<<'EOP'
        INSERT IGNORE INTO materia 
        SELECT carrera.id, temp_dret2.clave_asignatura 
        FROM carrera
        INNER JOIN diccionario_especialidad 
        ON carrera.id = diccionario_especialidad.id_carrera 
        INNER JOIN temp_dret2 
        ON diccionario_especialidad.cve = temp_dret2.esp;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->execute();
    }
}