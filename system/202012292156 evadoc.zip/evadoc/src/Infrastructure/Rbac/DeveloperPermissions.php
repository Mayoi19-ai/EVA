<?php
namespace App\Infrastructure\Rbac;

use Medoo\Medoo;
use App\Infrastructure\Exceptions\CustomException as Exception;

class DeveloperPermissions {
    private Medoo $db;
    private Exception $exception;
    
    public function __construct(Medoo $db, Exception $exception) {
        $this->db = $db;
        $this->exception = $exception;
    }

    public function create(array $data): array
    {
        $this->db->pdo->beginTransaction();
        $this->db->insert('permisos',[
            'categoria' => $data['categoria'],
            'nombre' => $data['nombre'], 
            'enlace' => $data['enlace']
        ]);

        $result = $this->exception->saveError((array) $this->db->error());
        return $result;
    }

    public function readAll(): array
    {
        $sql = $this->db->select('permisos',[
            'id',
            'categoria',
            'nombre',
            'enlace'
        ]);

        $result = $this->exception->readError((array) $this->db->error(), (array) $sql);
        return $result;
    }

    public function update(array $data): array
    {
        $this->db->pdo->beginTransaction();
        $this->db->update('permisos',[
            'categoria' => $data['categoria'],
            'nombre' => $data['nombre'],
            'enlace' => $data['enlace']], [
                'id' => $data['id']
        ]);

        $result = $this->exception->saveError((array) $this->db->error());
        return $result;
    }

    public function delete(int $id): array
    {
        $this->db->pdo->beginTransaction();
        $this->db->delete('permisos', [
                'id' => $id
        ]);
        
        $result = $this->exception->deleteError((array) $this->db->error());
        return $result;
    }
}