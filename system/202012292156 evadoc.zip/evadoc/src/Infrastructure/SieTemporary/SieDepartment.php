<?php

namespace App\Infrastructure\SieTemporary;

use org\majkel\dbase\Table;
use Medoo\Medoo;

class SieDepartment {
    private Medoo $db;

    public function __construct(Medoo $db) {
        $this->db = $db;
    }

    public function loadSieDepartment (string $dbfFileDepartment): ?array
    {
        $create = $this->createSieDepartment((string) $dbfFileDepartment);
        if(!empty($create[1])){
            $result = ['flag' => true, 
                        'error' => 'No se pudo crear estructura Departamento SIE'];
            return $result;
        }

        return null;
    }

    public function createSieDepartment (string $dbfFileDepartment): array 
    {
        $sql = <<<'EOP'
        DROP TABLE IF EXISTS `temp_ddep`;
        CREATE TEMPORARY TABLE IF NOT EXISTS `temp_ddep` (
            `cve` INT(3) UNSIGNED NOT NULL,
            `nom` VARCHAR(250) NOT NULL,
            `nco` VARCHAR(50) NOT NULL,
            PRIMARY KEY (`cve`));
        EOP;

        $this->db->query($sql);

        $file = Table::fromFile($dbfFileDepartment);

        foreach ($file as $record) {
            $this->db->insert("temp_ddep", [
                "cve" => $record['DEP_CVE'],
                "nom" => utf8_encode($record['DEP_NOM']),
                "nco" => utf8_encode($record['DEP_NCO'])
            ]);
        }
        return $this->db->error();
    }
}