<?php
namespace App\Controller\Presentation;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use Evadoc\Infrastructure\Teacher;
use Evadoc\Infrastructure;
use Medoo\Medoo;

class presentationController{

    private Container $container;

    public function __construct(Container $container) {
        $this->container = $container;
    }

    public function index(Request $request, Response $response) {
        $response->getBody()->write('Hola mundo feliz!');
        return $response;
    }

    public function testdb(Request $request, Response $response, $args) {
/*        $medoo = $this->container->get(Medoo::class);
        $teacher1 = new Teacher($medoo);
*/
        $teacher1 = $this->container->get(Teacher::class);
        $campus = $teacher1->get($args['id']);
        if(empty( $campus )) {
            $response->getBody()->write("No se encontró el campus.");
        }

        print_r( $campus );

        //----


        return $response;
    }
}