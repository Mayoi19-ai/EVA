<?php
namespace App\Controller\Access;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use Ujpef\LatteView;
use App\Infrastructure\Rbac\Permission as Infrastructure;

class PermissionController {
    private Container $container;
    private Infrastructure $infrastructure;

    public function __construct(Container $container, Infrastructure $infrastructure){
        $this->container = $container;
        $this->infrastructure = $infrastructure;
    }

    public function show(Request $request, Response $response){
        $sthResult = $this->infrastructure->readAll();
        
        return $this->container->get(LatteView::class)->render(
            $response,
            'Campus/campusTable.latte',
            ['query' => $sthResult
        ]);
    }

    public function showByCategory(Request $request, Response $response){
        $sthResult = $this->infrastructure->readByCategory($_GET['categoria']);
        return $this->container->get(LatteView::class)->render(
            $response,
            'Inscripcion/inscriptionValidation.latte', [
                'query' => $sthResult,
            ]);
    }
}