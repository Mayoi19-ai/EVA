<?php
namespace App\Controller\Access;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use Ujpef\LatteView;
use App\Validator\RolePermissionsValidator as Validator;
use App\Validator\RoleValidator as RoleVal;
use App\Infrastructure\Rbac\RolePermissions as Infrastructure;
use App\Infrastructure\Rbac\Role as RoleInfra;
use App\Infrastructure\Rbac\Permission as PermissionInfra;

class RolePermissionsController{
    private Container $container;
    private Validator $validator;
    private RoleVal $roleVal;
    private Infrastructure $infrastructure;
    private RoleInfra $roleInfra;
    private PermissionInfra $permissionInfra;

    public function __construct(Container $container, Validator $validator,Infrastructure $infrastructure, RoleVal $roleVal, RoleInfra $roleInfra, PermissionInfra $permissionInfra){
        $this->container = $container;
        $this->validator = $validator;
        $this->infrastructure = $infrastructure;
        $this->roleVal = $roleVal;
        $this->roleInfra = $roleInfra;
        $this->permissionInfra = $permissionInfra;
    }

    public function saveForm(Request $request, Response $response){
        $roleData = $this->roleInfra->showAll();
        $permissionData = $this->permissionInfra->showAll();
        return $this->container->get(LatteView::class)->render(
            $response, 
            'Campus/campusForm.latte', [
                'roles' => $roleData,
                'permissions' => $permissionData
            ]
        );
    }

    public function register(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $validationResult = $this->validator->validateSaveRolePermissions($data);

        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->create((array) $data);
        } else {
            $sthResult = ['consulta' => false];
        }
        return $this->container->get(LatteView::class)->render(
            $response,
            'Campus/campusValidation.latte',[
                'validation' => $validationResult, 
                'query' => $sthResult
            ]);
    }

    public function show(Request $request, Response $response){
        $sthResult = $this->infrastructure->readAll();
        
        return $this->container->get(LatteView::class)->render(
            $response,
            'Campus/campusTable.latte',
            ['query' => $sthResult
        ]);
    }

    public function showByRole(Request $request, Response $response){
        $sthResult = $this->infrastructure->groupByRole($_GET['id_roles']);
        return $this->container->get(LatteView::class)->render(
            $response,
            'Inscripcion/inscriptionValidation.latte', [
                'query' => $sthResult,
            ]);
    }

    public function update(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $validationResult = $this->validator->validateSaveRolePermissions((array) $data);
        
        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->update((array) $data);
        } else {
            $sthResult = ['consulta' => false];
        }

        $this->infrastructure->update($data);
        return $this->container->get(LatteView::class)->render(
            $response,
            'Campus/campusValidation.latte', [
                'validation' => $validationResult,
                'query' => $sthResult
            ]);
    }

    public function updateForm(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $roleData = $this->roleInfra->showAll();
        $permissionData = $this->permissionInfra->showAll();

        return $this->container->get(LatteView::class)->render(
            $response,
            'Campus/updateCampus.latte', [
                'data' => $data,
                'roles' => $roleData,
                'permissions' => $permissionData
            ]);
    }

    public function delete(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $sthResult = $this->infrastructure->delete((array) $data);
        return $this->container->get(LatteView::class)->render(
            $response,
            'Modalidad/modalityValidation.latte', [
                'query' => $sthResult
            ]);
    }
}