<?php
namespace App\Validator;
use Rakit\Validation\Validator;

class InscriptionValidator{
    private Validator $validator;

    public function __construct(Validator $validator) {
        $this->validator = $validator;
    }

    public function validateSaveInscription(array $data): array {
        $validationRules = [
            'id_curso'         =>  'required|numeric|digits_between:1,10',
            'control'          =>  'required|alpha_dash|between:8,8',
            'activar'          =>  'required|numeric|digits_between:1,1'
        ];

        $errorMessages = [
            'id_curso:required'      => 'La clave del curso es obligatoria',
            'id_curso:numeric'       => 'La clave del curso solo acepta números',
            'id_curso:between'       => 'La clave del curso debe tener entre 1 y 10 caracteres',
            'control:required'       => 'El número de control es obligatorio',
            'control:alpha_dash'     => 'El número de control no es válido',
            'control:between'        => 'El número de control debe tener 8 caracteres',
            'control:required'       => 'El número de control es obligatorio',
            'activar:required'       => 'El campo activar es obligatorio',
            'activar:numeric'        => 'El campo activar solo acepta números',
            'activar:digits_between' => 'El campo activar debe tener 1 caracter'
        ];

        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data);
    }

    public function validateUpdateInscriptionByCareer(array $data): array {
        $validationRules = [
            'id_periodo'    =>  'required|numeric|digits_between:1,10',
            'id_carrera'    =>  'required|numeric|digits_between:1,10',
            'activar'       =>  'required|numeric|digits_between:1,1'
        ];

        $errorMessages = [
            'id_periodo:required'          => 'La clave del periodo es obligatoria',
            'id_periodo:numeric'           => 'La clave del periodo es numerica',
            'id_periodo:digits_between'    => 'La clave del periodo debe tener entre 1 a 10 caracteres',
            'id_carrera:required'          => 'La clave es obligatoria',
            'id_carrera:numeric'           => 'La clave de carrera es numerica',
            'id_carrera:between'           => 'La clave de carrera debe tener entre 1 a 10 caracteres',
            'activar:required'             => 'El campo activar es obligatorio',
            'activar:numeric'              => 'El campo activar solo acepta números',
            'activar:digits_between'       => 'El campo activar debe tener 1 caracter'
        ];

        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data);
    }

    public function validateUpdateInscriptionByGroup(array $data): array {
        $validationRules = [
            'id_periodo'    =>  'required|numeric|digits_between:1,10',
            'grupo'         =>  'required|alpha_dash|between:5,5',
            'activar'       =>  'required|numeric|digits_between:1,1'
        ];

        $errorMessages = [
            'id_periodo:required'          => 'La clave del periodo es obligatoria',
            'id_periodo:numeric'           => 'La clave del periodo es numerica',
            'id_periodo:digits_between'    => 'La clave del periodo debe tener entre 1 a 10 caracteres',
            'grupo:required'               => 'El grupo es obligatorio',
            'grupo:alpha_dash'             => 'El grupo no acepta espacios ni caracteres especiales',
            'grupo:between'                => 'El grupo debe tener 5 caracteres',
            'activar:required'             => 'El campo activar es obligatorio',
            'activar:numeric'              => 'El campo activar solo acepta números',
            'activar:digits_between'       => 'El campo activar debe tener 1 caracter'
        ];

        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data);
    }
}