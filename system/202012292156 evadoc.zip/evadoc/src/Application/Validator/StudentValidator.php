<?php
namespace App\Validator;
use Rakit\Validation\Validator;

class StudentValidator{
    private Validator $validator;

    public function __construct(Validator $validator){
        $this->validator = $validator;
    }

    public function validateSaveStudent(array $data): array {
        $validationRules = [
            'control'        =>  'required|alpha_dash|between:8,8',
            'nombre'         =>  'required|alpha_spaces',
            'contrasenia'    =>  'required|same:control',
        ];

        $errorMessages = [
            'control:required'      => 'El número de control es obligatorio',
            'control:alpha_dash'    => 'El número de control no es válido',
            'control:between'       => 'El número de control debe tener 8 caracteres',
            'control:required'      => 'El número de control es obligatorio',
            'nombre:required'       => 'El nombre es obligatorio',
            'nombre:alpha_spaces'   => 'El nombre no es válido',
            'contrasenia:required'  => 'La clave de acceso es obligatoria',
            'contrasenia:same'      => 'La clave de acceso debe ser igual al número de control',
        ];

        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data);
    }

    public function validateFindStudent(array $data): array {
        $validationRules = [
            'control'        =>  'required|alpha_dash|between:8,8',
        ];

        $errorMessages = [
            'control:required'    => 'El número de control es obligatorio',
            'control:alpha_dash'  => 'El número de control no es válido',
            'control:between'     => 'El número de control debe tener 8 caracteres',
            'control:required'    => 'El número de control es obligatorio',
        ];

        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data);
    }

    public function validateUpdatePassword(array $data): array {
        $validationRules = [
            'contrasenia'       =>  'required|between:8,12',
            'contrasenia_same'  =>  'required|same:contrasenia',
        ];

        $errorMessages = [
            'contrasenia:required'       => 'La clave de acceso es obligatoria',
            'contrasenia:between'        => 'La clave de acceso debe tener de 8 a 12 caracteres',
            'contrasenia_same:required'  => 'La verificación de clave de acceso es obligatoria',
            'contrasenia_same:same'      => 'La clave de acceso no coincide',
        ];

        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data);
    }
}