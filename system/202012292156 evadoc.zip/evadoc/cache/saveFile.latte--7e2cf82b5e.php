<?php
// source: Archivos/saveFile.latte

use Latte\Runtime as LR;

class Template7e2cf82b5e extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		$target_path = "archivos/";
		$target_path = $target_path . basename( $_FILES['uploadedfile']['name']);
		if(move_uploaded_file($_FILES['uploadedfile']['tmp_name'], $target_path)) {
			echo "El archivo ".  basename( $_FILES['uploadedfile']['name']).
			" ha sido subido";
		}
		else{
			echo "Ha ocurrido un error, trate de nuevo!";
		};
		return get_defined_vars();
	}

}
