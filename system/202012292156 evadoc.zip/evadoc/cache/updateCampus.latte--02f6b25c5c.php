<?php
// source: Campus/updateCampus.latte

use Latte\Runtime as LR;

class Template02f6b25c5c extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		/* line 1 */
		$this->createTemplate('@layout-navbar.latte', $this->params, "include")->renderToContentType('html');
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 7 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>

</head>
<body>
<form name="updateCampus" method="post" action="<?php
		echo $router->relativeUrlFor("campusUpdate");
?>">
<ul>
<li>
<div class="container section">
    <label><input type="hidden" id="id" name="id" value="<?php echo LR\Filters::escapeHtmlAttr($data['id']) /* line 18 */ ?>" class="validate"></label>
  </li>
  <li>
    <label for="name">Nombre:</label>
    <input type="text" id="nombre" name="nombre" value="<?php echo LR\Filters::escapeHtmlAttr($data['nombre']) /* line 22 */ ?>" class="validate">
  </li>
 </ul>
<input type="submit" value="Registrar" name="registrar">
</form>




    <footer class="copyright"> 
        <p>Todos los derechos reservados, Gerardo y Raul 2020</p>
    </footer>
</body>
</html><?php
		return get_defined_vars();
	}

}
