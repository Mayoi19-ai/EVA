<?php
// source: PruebasGera/prueba.latte

use Latte\Runtime as LR;

class Template9a2f4835c8 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		return get_defined_vars();
	}

}
