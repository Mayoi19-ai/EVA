<?php
// source: Docente/teacherValidation.latte

use Latte\Runtime as LR;

class Template19615f0a98 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		return get_defined_vars();
	}

}
