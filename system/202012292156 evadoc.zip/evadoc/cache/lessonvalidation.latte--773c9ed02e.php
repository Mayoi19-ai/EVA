<?php
// source: Asignatura/lessonvalidation.latte

use Latte\Runtime as LR;

class Template773c9ed02e extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		return get_defined_vars();
	}

}
