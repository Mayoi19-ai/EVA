<?php
// source: Menu\@principalMenu.latte

use Latte\Runtime as LR;

class Templatea7d3aaf43f extends Latte\Runtime\Template
{
	public $blocks = [
		'content' => 'blockContent',
	];

	public $blockTypes = [
		'content' => 'html',
	];


	function main()
	{
		extract($this->params);
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('content', get_defined_vars());
		return get_defined_vars();
	}


	function blockContent($_args)
	{
		extract($_args);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 6 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
     
</head>
<body>
<nav class="blue-grey lighten-3">  
  <ul id="slide-out" class="sidenav">
    <li><div class="user-view">
      <div class="background">
      </div>
    <img src="\materialize\Recursos\itshlogo.png">
    </div>
    </li>
<!--Menu desplegable-->
    <li><a href="showAllStudents">Alumnos</a></li>
    <li><div class="divider"></div></li>
    <li><a href="#!">Asignatura</a></li>
    <li><div class="divider"></div></li>
    <li><a link rel="showAllCampuses">Campus</a></li>
    <li><div class="divider"></div></li>
    <li><a href="showAllStudents">Carera</a></li>
    <li><div class="divider"></div></li>
    <li><a href="#!">Curso</a></li>
    <li><div class="divider"></div></li>
    <li><a link rel="showAllCampuses">Departamento</a></li>
    <li><div class="divider"></div></li>
    <li><a href="showAllStudents">Docente</a></li>
    <li><div class="divider"></div></li>
    <li><a href="#!">Evaluacion</a></li>
    <li><div class="divider"></div></li>
    <li><a link rel="showAllCampuses">grupo</a></li>
    <li><div class="divider"></div></li>
    <li><a href="showAllStudents">Inscripcion</a></li>
    <li><div class="divider"></div></li>
    <li><a href="#!">Materia</a></li>
    <li><div class="divider"></div></li>
    <li><a link rel="showAllCampuses">Modalidad</a></li>
    <li><div class="divider"></div></li>
    <li><a link rel="showAllCampuses">Periodo</a></li>
    <li><div class="divider"></div></li>
  </ul>
  <a data-target="slide-out" class="sidenav-trigger"><i class="material-icons">menu</i></a>
          <!--Opction menu -->
          <ul class="right hide-on-med-and-down">
      <li><a class="dropdown-trigger" href="#!" data-target="dropdown1">Opciones<i class="material-icons right">arrow_drop_down</i></a></li>
      <ul id='dropdown1' class='dropdown-content'>
        <li><a href="#!">Ususario</a></li>
        <li><a href="#!">Cerrar sesion</a></li>
        <li><a href="#!">Contacto</a></li>
      </ul>
    </ul>
    <a href="#" data-target="slide-out" class="sidenav-trigger"><i class="material-icons">menu</i></a>
                   
  </nav>
    
    

    <a href="#" data-target="slide-out" class="sidenav-trigger"><i class="material-icons">menu</i></a>

<!--Fin menu desplegable -->
        
    <footer class="copyright"> 
    <script>
      M.AutoInit();
      </script>
        <p>Todos los derechos reservados, Gerardo y Raul 2020</p>
    </footer>
</body>
</html>
<?php
	}

}
