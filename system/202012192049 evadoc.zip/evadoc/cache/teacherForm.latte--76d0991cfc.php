<?php
// source: Docente/teacherForm.latte

use Latte\Runtime as LR;

class Template76d0991cfc extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 5 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
      
</head>
<body>
<form name="teacherSaveForm" method="post" action="<?php
		echo $router->relativeUrlFor("teacherRegister");
?>">

  <!-- Datos del formulario -->
<div class="container section">
  Folio <input type="text" name="folio">
  Nombre docente <input type="text" name="nombre">
    <select name="clave_departamento">
      <option value="" name="clave_departamento">Selecciona un departamento</option>
<?php
		$iterations = 0;
		foreach ($all_departments_information as $option) {
			?>      <option  value="<?php echo LR\Filters::escapeHtmlAttr($option['clave']) /* line 21 */ ?>" ><?php
			echo LR\Filters::escapeHtmlText($option['nombre']) /* line 21 */ ?></option>
<?php
			$iterations++;
		}
?>
    </select>
  

        
  <!-- Botón de envío de formulario -->
  
  <input type="submit" value="Enviar formulario">
</div>
</form>
 

    <footer class="copyright"> 
        <p>Todos los derechos reservados, Gerardo y Raul 2020</p>
        
        
    </footer>
</body>
 <script>M.AutoInit();</script>
</html><?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['option'])) trigger_error('Variable $option overwritten in foreach on line 20');
		
	}

}
