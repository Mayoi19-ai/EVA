<?php
// source: Campus/campusTable.latte

use Latte\Runtime as LR;

class Templateec46562748 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 6 */ ?></title>
</head>
<table name="showCampus" method="get">

<ul>
<?php
		$iterations = 0;
		foreach ($all_campuses_information as $campuse) {
			?>	<td><?php echo LR\Filters::escapeHtmlText($campuse['nombre']) /* line 12 */ ?></td>
  <td><?php echo LR\Filters::escapeHtmlText($campuse['pruebas']) /* line 13 */ ?></td>
  <td width='150'></td> 
<?php
			$iterations++;
		}
?>
</ul>

   
</div> 
</body> 

</html> <?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['campuse'])) trigger_error('Variable $campuse overwritten in foreach on line 11');
		
	}

}
