<?php
namespace App\Controller\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use App\Validator\DepartmentValidator as Validator;
use Ujpef\LatteView;
use Slim\Exception\HttpForbiddenException;
use App\Infrastructure\CrudSystem\DepartmentInfrastructure as Infrastructure;

class DepartmentController{
    private Container $container;
    private Validator $validator;
    private Infrastructure $infrastructure;
    
    public function __construct(Container $container, Validator $validator, Infrastructure $infrastructure){
        $this->container = $container;
        $this->validator = $validator;
        $this->infrastructure = $infrastructure;
    }

    public function saveForm(Request $request, Response $response, array $args){
        return $this->container->get(LatteView::class)->render($response, 
        'Departamento/departmentForm.latte');
    }

    public function register(Request $request, Response $response){
        $resultData = [];
        
        $data = (array)$request->getParsedBody();
        $this->infrastructure->create($data);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Departamento/validationdepartment.latte',
            ['validacion_exitosa' => $validationResult] + $resultData
        );
    }

    public function search(Request $request, Response $response){
        $resultData = [];
        $data = $this->infrastructure->read($_GET['nombre']);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Departamento/departmentSearch.latte',[
                'all_deparments_information' => $data,
                'department_name' => $name
            ]
        );
    }

    public function show(Request $request, Response $response){
        $data = $this->infrastructure->readAll();

        return $this->container->get(LatteView::class)->render(
            $response,
            'Departamento/departmentTable.latte',[
                'all_departments_information' => $data
            ]
        );
    }

    public function updateForm(Request $request, Response $response){
        $data = $request->getParsedBody();

        return $this->container->get(LatteView::class)->render($response, 
        'Departamento/departmentUpdate.latte', [
            'department_information' => $data
        ]);
    }

    public function update(Request $request, Response $response){
        $resultData = [];
        $data = $request->getParsedBody();
        $this->infrastructure->update($data);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Departamento/departmentValidation.latte',
            ['validacion_exitosa' => $validationResult] + $resultData
        );
    }

    public function delete(Request $request, Response $response, array $args){
        $this->infrastructure->delete($_GET['clave']);
        return $response;
    }
}