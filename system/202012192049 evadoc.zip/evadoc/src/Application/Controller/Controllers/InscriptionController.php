<?php
namespace App\Controller\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use App\Validator\InscriptionValidator;
use Ujpef\LatteView;
use Slim\Exception\HttpForbiddenException;
use App\Infrastructure\CrudSystem\InscriptionInfrastructure as Infrastructure;
use App\Infrastructure\CrudSystem\CourseInfrastructure as Course;

class InscriptionController{
    private Container $container;
    private Infrastructure $infrastructure;
    private Course $course;
    
    public function __construct(Container $container, Infrastructure $infrastructure, Course $course){
        $this->container = $container;
        $this->infrastructure = $infrastructure;
        $this->course = $course;
    }

    public function saveForm(Request $request, Response $response, array $args){
        
        return $this->container->get(LatteView::class)->render($response, 'Inscripcion/inscription.latte');
    }

    public function register(Request $request, Response $response, array $args){
        $resultData = [];
        
        $data = (array)$request->getParsedBody();
        $inscriptionVal = $this->container->get(InscriptionValidator::class);
        
        $validationResult = $inscriptionVal->validateSaveInscription($data, $resultData);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Inscripcion/inscriptionValidation.latte',
            ['validacion_exitosa' => $validationResult] + $resultData
        );
    }

    public function show(Request $request, Response $response, array $args){
        $data = $this->infrastructure->readAll();
        return $this->container->get(LatteView::class)->render(
            $response,
            'Inscripcion/inscriptionTable.latte'
        );
    }

    public function searchByStudent(Request $request, Response $response, array $args){
        $resultData = [];
        
        $data = array("courseCode" => $args['codeCourse']);
        
        $inscriptionVal = $this->container->get(InscriptionValidator::class);
        
        $validationResult = $inscriptionVal->ValidateSearch($data, $resultData);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Inscripcion/inscriptionValidation.latte',
            ['validacion_exitosa' => $validationResult] + $resultData
        );
    }

    public function update(Request $request, Response $response, array $args){
        $resultData = [];
        
        $data = (array)$request->getParsedBody();
        $inscriptionVal = $this->container->get(InscriptionValidator::class);
        
        $validationResult = $inscriptionVal->ValidateUpdate($data, $resultData);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Inscripcion/inscriptionValidation.latte',
            ['validacion_exitosa' => $validationResult] + $resultData
        );
    }

    public function delete(Request $request, Response $response, array $args){
        $code = $args['courseCode'];
        $response->getBody()->write("$code");
        return $response;
    }
}