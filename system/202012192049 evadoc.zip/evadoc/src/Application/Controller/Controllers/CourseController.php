<?php
namespace App\Controller\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use App\Validator\CourseValidator as Validator;
use Ujpef\LatteView;
use Slim\Exception\HttpForbiddenException;
use App\Infrastructure\CrudSystem\CourseInfrastructure as Infrastructure;
use App\Infrastructure\CrudSystem\GroupInfrastructure as Group;
use App\Infrastructure\CrudSystem\SchoolSubjectInfrastructure as Subject;

class CourseController {
    private Container $container;
    private Validator $validator;
    private Infrastructure $infrastructure;
    private Group $group;
    private Subject $subject;
    
    public function __construct(Container $container, Validator $validator, Infrastructure $infrastructure, Group $group, Subject $subject){
        $this->container = $container;
        $this->validator = $validator;
        $this->infrastructure = $infrastructure;
        $this->group = $group;
        $this->subject = $subject;
    }

    public function saveForm(Request $request, Response $response){
        $groupData = $this->group->readAuxiliary($_GET['id_periodo']);
        $subjectData = $this->subject->readAll();

        return $this->container->get(LatteView::class)->render($response, 'Curso/course.latte', [
            'groups' => $groupData,
            'subjects' => $groupData
        ]);
    }

    public function register(Request $request, Response $response){
        $data = $request->getParsedBody();
        $this->infrastructure->create($data);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Curso/courseValidation.latte',
            ['validacion_exitosa' => $validationResult] + $resultData
        );
    }

    public function searchByGroup(Request $request, Response $response){
        $resultData = [];
        $group = $_GET['grupo'];
        $this->infrastructure->readByGroup($group, $_GET['id_periodo']);
        return $this->container->get(LatteView::class)->render(
            $response,
            'Curso/courseValidation.latte',
            ['validacion_exitosa' => $validationResult] + $resultData
        );
    }

    public function searchByLesson(Request $request, Response $response){
        $resultData = [];
        $lesson = $_GET['clave_asignatura'];
        $this->infrastructure->readByLesson($lesson, $_GET['id_periodo']);
        return $this->container->get(LatteView::class)->render(
            $response,
            'Curso/courseValidation.latte',
            ['validacion_exitosa' => $validationResult] + $resultData
        );
    }

    public function show(Request $request, Response $response){
        $data = $this->infrastructure-> readAll($_GET['id_periodo']);
        return $this->container->get(LatteView::class)->render(
            $response,
            'Curso/courseTable.latte',
            ['all_courses_information' => $data]
        );
    }

    public function updateForm(Request $request, Response $response){
        $data = $request->getParsedBody();
        $groupData = $this->group->readAuxiliary($_GET['id_periodo']);
        $subjectData = $this->subject->readAll();
        return $this->container->get(LatteView::class)->render($response, 'Curso/course.latte', [
            'course_information' => $data,
            'groups' => $groupData,
            'subjects' => $groupData
        ]);
    }

    public function update(Request $request, Response $response){
        $resultData = [];
        $data = $request->getParsedBody();
        $this->infrastructure->update($data);
        return $this->container->get(LatteView::class)->render(
            $response,
            'Curso/courseValidation.latte',
            ['validacion_exitosa' => $validationResult] + $resultData
        );
    }

    public function delete(Request $request, Response $response){
        $code = $_GET['id_curso'];
        $periodId = $_GET['id_periodo'];
        $this->infrastructure->delete($code, $periodId);
        return $response;
    }

    /*public function containerData(Request $request, Response $response) {
        $data = (array)$request->getParsedBody();
        return $this->container->get(LatteView::class)->render(
            $response,
            'Curso/updatecourse.latte',
            ['course_data' => $data]
        );
    }*/
}