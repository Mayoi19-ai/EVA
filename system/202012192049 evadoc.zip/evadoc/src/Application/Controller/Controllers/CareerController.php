<?php
namespace App\Controller\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use App\Validator\CareerValidator as Validator;
use Ujpef\LatteView;
use Slim\Exception\HttpForbiddenException;
use App\Infrastructure\CrudSystem\CareerInfrastructure as Infrastructure;

class CareerController{
    private Container $container;
    private Infrastructure $infrastructure;
    private Validator $validator;

    public function __construct(Container $container, Infrastructure $infrastructure, Validator $validator){
        $this->container = $container;
        $this->infrastructure = $infrastructure;
        $this->validator = $validator;
    }

    public function saveForm(Request $request, Response $response){
        return $this->container->get(LatteView::class)->render($response, 'Carrera/career.latte');
    }

    public function register(Request $request, Response $response){
        $resultData = [];
        
        $data = (array)$request->getParsedBody();
        //$validationResult = $this->validator->validateSaveCareer($data, $resultData);
        $this->infrastructure->create($data);
        
        return $this->container->get(LatteView::class)->render(
            $response,
            'Carrera/careerValidation.latte',
            ['validacion_exitosa' => $validationResult] + $resultData
        );
    }

    public function show(Request $request, Response $response, array $args){
        $data = $this->infrastructure->readAll();

        return $this->container->get(LatteView::class)->render(
            $response,
            'Carrera/careerTable.latte',
            ['all_careers_information' => $data]
        );
    }
    
    public function updateForm(Request $request, Response $response, array $args){
        $data = $request->getParsedBody();
        return $this->container->get(LatteView::class)->render($response, 
            'Carrera/careerUpdate.latte',[
            'career_information' => $data]);
    }

    public function update(Request $request, Response $response, array $args){
        $resultData = [];
        
        $data = (array)$request->getParsedBody();
        $this->infrastructure->update($data);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Carrera/careerValidation.latte',
            ['validacion_exitosa' => $validationResult] + $resultData
        );
    }

    public function delete(Request $request, Response $response){
        $this->infrastructure->delete($_GET['id']);
        return $response;
    }
}