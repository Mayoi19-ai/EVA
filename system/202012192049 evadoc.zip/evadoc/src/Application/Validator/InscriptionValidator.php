<?php
namespace App\Validator;
use Rakit\Validation\Validator;

class InscriptionValidator{
    private Validator $validator;

    public function __construct(Validator $validator) {
        $this->validator = $validator;
    }

    public function validateSaveInscription(array $data, array &$resultData): bool {
        $validationRules = [
            'courseCode'         =>  'required|numeric|digits_between:1,10',
            'studentControl'     =>  'required|alpha_num|uppercase|between:8,8',
        ];

        $errorMessages = [
            'courseCode:required'       => 'La clave del curso es obligatoria',
            'courseCode:numeric'        => 'La clave del curso solo acepta números',
            'courseCode:between'        => 'La clave del curso debe tener entre 1 y 10 caracteres',
            'studentControl:required'   => 'El número de control es obligatorio',
            'studentControl:alpha_num'  => 'El número de control no es válido',
            'studentControl:uppercase'  => 'El número de control debe estar en mayúsculas',
            'studentControl:between'    => 'El número de control debe tener 8 caracteres',
        ];

        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data, $resultData);
    }

    public function validateFindInscription(array $data, array &$resultData): bool {
        $validationRules = [
            'courseCode'         =>  'required|numeric|digits_between:1,10',
        ];

        $errorMessages = [
            'courseCode:required'       => 'La clave del curso es obligatoria',
            'courseCode:numeric'        => 'La clave del curso solo acepta números',
            'courseCode:between'        => 'La clave del curso debe tener entre 1 y 10 caracteres',          
        ];

        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data, $resultData);
    }
}