<?php
namespace App\Infrastructure\CrudSystem;

use Medoo\Medoo;

class EmptyData {
    protected Medoo $db;
    
    public function __construct(Medoo $db){
        $this->db = $db;
    }

    public function emptyData(array &$data): array
    {
        if(!$data){
            //$data = array( array("noFound" => "No hay registros"));
            $dbError = $this->db->error();
            if(empty($dbError)){
                $data = array( array("noFound" => "No hay registros"));
            } else {
                $data = $dbError;
            }
        }
        return $data;
    }
}