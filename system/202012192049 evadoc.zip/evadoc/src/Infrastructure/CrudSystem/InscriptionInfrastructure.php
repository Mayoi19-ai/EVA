<?php
namespace App\Infrastructure\CrudSystem;

use Medoo\Medoo;

class InscriptionInfrastructure{
    private Medoo $db;

    public function __construct(Medoo $db) {
        $this->db = $db;
    }

    public function insertInscription(array $inscriptionData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $inscription = $databaseInfra['inscription'];

        $data = $this->db->insert($inscription['table'],[
            $inscription['courseId'] => $courseId, 
            $inscription['studentCode'] => $studentCode]
        );

        return $data;
    }

    public function readAll(): ?array
    {
        $data = $this->db->select($inscription['table'],[
            $inscription['courseId'], 
            $inscription['studentCode']]
        );

        return $data;
    }

    public function selectOneInscription(array $inscriptionData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $inscription = $databaseInfra['inscription'];

        $data = $this->db->select($inscription['table'], [
            $inscription['courseId'], 
            $inscription['studentCode']], [
                $inscription['studentCode'] => $studentCode]
            );

        return $data;
    }

    public function updateInscription(array $inscriptionData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $inscription = $databaseInfra['inscription'];

        $data = $this->db->update($inscription['table'], [
            $inscription['courseId'], 
            $inscription['studentCode']], [
                "AND" => [
                    $inscription['studentCode'] => $studentCode,
                    $inscription['courseId'] => $courseId]]
            );

        return $data;
    }
    
    public function deleteInscription(array $inscriptionData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $inscription = $databaseInfra['inscription'];

        $data = $this->db->delete($inscription['table'], [
            "AND" => [
                $inscription['studentCode'] => $studentCode,
                $inscription['courseId'] => $courseId]]
        );
        
        return $data;
    }
}