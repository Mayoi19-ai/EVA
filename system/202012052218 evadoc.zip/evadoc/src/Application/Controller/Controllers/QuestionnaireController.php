<?php
 namespace App\Controller\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use Slim\Exception\HttpForbiddenException;
use Ujpef\LatteView;
use App\Infrastructure\Questionnaire;

class QuestionnaireController {
    private Container $container;
    private Questionnaire $questionnaire;
    
    public function __construct(Container $container, Questionnaire $questionnaire) {
        $this->container = $container;
        $this->questionnaire = $questionnaire;
    }

    public function getAll(Request $request, Response $response): Response {
        $data = $this->questionnaire->get();
       // echo('<pre>');
        //var_dump($data);
        //echo('<pre>');
        $latte = $this->container->get(LatteView::class)->render(
            $response,
            'Preguntas/question.latte',
            ['data' => $data]
        );
        return $latte;
    }
}