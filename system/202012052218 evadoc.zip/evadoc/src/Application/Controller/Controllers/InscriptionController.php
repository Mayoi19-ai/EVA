<?php
namespace App\Controller\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use App\Validator\InscriptionValidator;
use Ujpef\LatteView;
use Slim\Exception\HttpForbiddenException;
use App\Database\InscriptionInfrastructure;

class InscriptionController{
    private $container;
    
    public function __construct(Container $container){
        $this->container = $container;
    }

    public function saveForm(Request $request, Response $response, array $args){
        // Simula que la lógica de negocios valida el id
        $id = (int) $args['id'];
        if($id > 5) {
            throw new HttpForbiddenException($request);
        }
        return $this->container->get(LatteView::class)->render($response, 'Inscripcion/inscription.latte', [
            'id' => $id,
        ]);
    }

    public function register(Request $request, Response $response, array $args){
        $resultData = [];
        
        $data = (array)$request->getParsedBody();
        $inscriptionVal = $this->container->get(InscriptionValidator::class);
        
        $validationResult = $inscriptionVal->validateSaveInscription($data, $resultData);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Inscripcion/inscriptionValidation.latte',
            ['validacion_exitosa' => $validationResult] + $resultData
        );
    }

    public function searchForm(Request $request, Response $response, array $args){
        // Simula que la lógica de negocios valida el id
        $id = (int) $args['id'];
        if($id > 5) {
            throw new HttpForbiddenException($request);
        }
        return $this->container->get(LatteView::class)->render($response, 'Inscripcion/inscription.latte', [
            'id' => $id,
        ]);
    }

    public function search(Request $request, Response $response, array $args){
        $resultData = [];
        
        $data = array("courseCode" => $args['codeCourse']);
        
        $inscriptionVal = $this->container->get(InscriptionValidator::class);
        
        $validationResult = $inscriptionVal->ValidateSearch($data, $resultData);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Inscripcion/inscriptionValidation.latte',
            ['validacion_exitosa' => $validationResult] + $resultData
        );
    }

    public function show(Request $request, Response $response, array $args){
        $teacherInfraestructure = $this->container->get(TeacherInfrastructure::class);
        $dataTeacher = $teacherInfraestructure->selectDataTeacher();

        if(empty( $dataTeacher )) {
            $response->getBody()->write("No hay docentes registrados");
        }
        return $this->container->get(LatteView::class)->render(
            $response,
            'Inscripcion/inscriptionTable.latte'
        );
    }

    public function update(Request $request, Response $response, array $args){
        $resultData = [];
        
        $data = (array)$request->getParsedBody();
        $inscriptionVal = $this->container->get(InscriptionValidator::class);
        
        $validationResult = $inscriptionVal->ValidateUpdate($data, $resultData);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Inscripcion/inscriptionValidation.latte',
            ['validacion_exitosa' => $validationResult] + $resultData
        );
    }

    public function delete(Request $request, Response $response, array $args){
        $code = $args['courseCode'];
        $response->getBody()->write("$code");
        return $response;
    }
}