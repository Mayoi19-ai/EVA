<?php
namespace App\Validator;
use Rakit\Validation\Validator;

class LessonValidator{
    private Validator $validator;

    public function __construct(Validator $validator) {
        $this->validator = $validator;
    }

    public function validateSaveLesson(array $data, array &$resultData): bool {
        $validationRules = [
            'code'          =>  'required|alpha_dash|uppercase|between:8,8',
            'name'          =>  'required|alpha_spaces|uppercase',
        ];

        $errorMessages = [
            'code:required'     => 'La clave es obligatoria',
            'code:alpha_dash'   => 'La clave no acepta espacios o caracteres especiales',
            'code:uppercase'    => 'La clave debe de estar en mayúsculas',
            'code:between'      => 'La clave debe tener 8 caracteres',
            'name:requied'      => 'El nombre es obligatorio',
            'name:alpha_spaces' => 'El nombre no es válido',
            'name:uppercase'    => 'El nombre debe de estar en mayúsculas',            
        ];

        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data, $resultData);
    }

    public function validateFindLesson(array $data, array &$resultData): bool {
        $validationRules = [
            'code'          =>  'required|alpha_dash|uppercase|between:8,8',
        ];

        $errorMessages = [
            'code:required'     => 'La clave es obligatoria',
            'code:alpha_dash'   => 'La clave no acepta espacios o caracteres especiales',
            'code:uppercase'    => 'La clave debe de estar en mayúsculas',
            'code:between'      => 'La clave debe tener 8 caracteres',
        ];

        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data, $resultData);
    }
}