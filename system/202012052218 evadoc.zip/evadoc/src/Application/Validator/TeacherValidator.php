<?php
namespace App\Validator;
use Rakit\Validation\Validator;

class TeacherValidator {
    private Validator $validator;

    public function __construct(Validator $validator) {
        $this->validator = $validator;
    }

    public function validateSaveTeacher(array $data, array &$resultData): array {
        $validationRules = [
            'folio'             =>  'required|numeric|digits_between:1,3',
            'name'              =>  'required|alpha_spaces|uppercase',
            'codeDepartment'    =>  'required|digits_between:1,3',
        ];

        $errorMessages = [
            'folio:required'                =>  'El folio es obligatorio',
            'folio:digits_between'          =>  'El folio debe tener tres digitos',
            'folio:numeric'                 =>  'El folio solo acepta números',
            'name:required'                 =>  'El nombre es obligatorio',
            'name:alpha_spaces'             =>  'El nombre no es válido',
            'name:uppercase'                =>  'El nombre debe estar en mayúsculas',
            'codeDepartment:required'       =>  'El departamento es obligatorio',
            'codeDepartment:digits_between' =>  'La clave del departamento debe tener tres digitos',
        ];

        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data, $resultData);
    }

    public function validateFindTeacher(array $data, array &$resultData): array {
        $validationRules = [
            'folio'         =>  'required|numeric|digits_between:1,3',
        ];

        $errorMessages = [
            'folio:required'            =>  'El folio es obligatorio',
            'folio:digits_between'      =>  'El folio solo acepta tres digitos',
            'folio:numeric'             =>  'El folio solo acepta números',
        ];

        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data, $resultData);
    }
}
