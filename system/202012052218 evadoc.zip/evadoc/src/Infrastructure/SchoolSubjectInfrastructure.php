<?php
namespace App\Infrastructure;

use Medoo\Medoo;
use Psr\Container\ContainerInterface;

class SchoolSubjectInfrastructure{
    private Medoo $db;
    private ContainerInterface $container;

    public function __construct(Medoo $db, ContainerInterface $container) {
        $this->db = $db;
        $this->container = $container;
    }

    public function insertSubject(array $subjectData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $subject = $databaseInfra['schoolSubject'];

        $data = $this->db->insert($subject['table'],[
            $subject['careerId'] => $careerId, 
            $subject['lessonCode'] => $lessonCode]
        );

        return $data;
    }

    public function selectShowAllSubjects(): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $subject = $databaseInfra['schoolSubject'];

        $data = $this->db->select($subject['table'],[
            $subject['careerId'],
            $subject['lessonCode']]
        );

        return $data;
    }

    public function selectOneSubject(array $subjectData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $subject = $databaseInfra['schoolSubject'];

        $data = $this->db->select($subject['table'],[
            $subject['careerId'],
            $subject['lessonCode']], [
                $subject['careerId'] => $careerId]
            );

        return $data;
    }

    public function updateSubject(array $subjectData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $subject = $databaseInfra['schoolSubject'];

        $data = $this->db->update($subject['table'],[
            $subject['careerId'] => $careerId, 
            $subject['lessonCode'] => $lessonCode],[
                $subject['careerId'] => $careerId]
            );

        return $data;
    }
    
    public function deleteSubject(array $subjectData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $subject = $databaseInfra['schoolSubject'];

        $data = $this->db->delete($subject['table'], [
            "AND" => [
                $subject['careerId'] => $careerId,
                $subject['lessonCode'] => $lessonCode,
            ]]
        );
        
        return $data;
    }
}