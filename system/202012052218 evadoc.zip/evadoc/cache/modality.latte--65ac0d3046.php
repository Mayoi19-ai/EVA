<?php
// source: Modalidad/modality.latte

use Latte\Runtime as LR;

class Template65ac0d3046 extends Latte\Runtime\Template
{
	public $blocks = [
		'content' => 'blockContent',
	];

	public $blockTypes = [
		'content' => 'html',
	];


	function main()
	{
		extract($this->params);
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('content', get_defined_vars());
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		$this->parentName = 'modalityform.latte';
		
	}


	function blockContent($_args)
	{
?><p>Este es el saludo probiene de modality.latte.</p>
<?php
	}

}
