<?php
// source: Menu/principalMenu.latte

use Latte\Runtime as LR;

class Template1b81eca377 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		$this->parentName = '@principalMenu.latte';
		
	}

}
