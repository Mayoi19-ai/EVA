<?php
// source: Preguntas/question.latte

use Latte\Runtime as LR;

class Templateaa3ef40812 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		$this->parentName = '@question.latte';
		
	}

}
