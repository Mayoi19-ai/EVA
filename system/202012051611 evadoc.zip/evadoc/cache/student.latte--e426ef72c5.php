<?php
// source: Alumnos/student.latte

use Latte\Runtime as LR;

class Templatee426ef72c5 extends Latte\Runtime\Template
{
	public $blocks = [
		'content' => 'blockContent',
	];

	public $blockTypes = [
		'content' => 'html',
	];


	function main()
	{
		extract($this->params);
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('content', get_defined_vars());
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		$this->parentName = 'studentform.latte';
		
	}


	function blockContent($_args)
	{
?><p>Este es el saludo probiene de Student.latte.</p>
<?php
	}

}
