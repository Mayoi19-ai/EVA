<?php

namespace App\Infrastructure;

use org\majkel\dbase\Table;
use Port\Spreadsheet\SpreadsheetReader;
use Medoo\Medoo;

class DbfImport {
    private Medoo $medoo;

    public function __construct(Medoo $medoo) {
        $this->medoo = $medoo;
    }
    
   public function imports() {
        
        $file = new \SplFileObject(__DIR__.'/../../public/dbfFiles/test_qw.xlsx');
        $reader = new SpreadsheetReader($file);

        $despPath = Table::fromFile(__DIR__.'/../../public/dbfFiles/desp.DBF');
        $ddepPath = Table::fromFile(__DIR__.'/../../public/dbfFiles/ddep.DBF');
        $dretPath = Table::fromFile(__DIR__.'/../../public/dbfFiles/dret.DBF');
        $dcatPath = Table::fromFile(__DIR__.'/../../public/dbfFiles/dcat.DBF');
        $daluPath = Table::fromFile(__DIR__.'/../../public/dbfFiles/dalu.DBF');
        $dgauPath = Table::fromFile(__DIR__.'/../../public/dbfFiles/dgau.DBF');
        $dlisPath = Table::fromFile(__DIR__.'/../../public/dbfFiles/dlis.DBF');

        foreach ($reader as $record) {
            
            $career = $record[0];
            $mySistem = $record[1];
            $sie = $record[2];

            echo "<br>";
            echo "$career, $mySistem, $sie";
            echo "<br>";
        }

        foreach ($despPath as $record) {
            $esp_cve = $record['ESP_CVE'];
            $esp_nco = $record['ESP_NCO'];

            echo "<br>";
            echo "$esp_cve, $esp_nco";
            echo "<br>";
        }

        foreach ($ddepPath as $record) {
            $dep_cve = $record['DEP_CVE'];
            $dep_nco = $record['DEP_NCO'];

            echo "<br>";
            echo "$dep_cve, $dep_nco";
            echo "<br>";
        }

        foreach ($dretPath as $record) {
            $ret_cve = $record['RET_CVE'];
            $ret_nco = $record['RET_NCO'];

            echo "<br>";
            echo "$ret_cve, $ret_nco";
            echo "<br>";
        }

        foreach ($dcatPath as $record) {
            $cat_cve = $record['CAT_CVE'];
            $cat_dep = $record['CAT_DEP'];
            $cat_nom = $record['CAT_NOM'];

            echo "<br>";
            echo "$cat_cve, $cat_dep, $cat_nom";
            echo "<br>";
        }

        foreach ($daluPath as $record) {
            $alu_ctr = $record['ALU_CTR'];
            $alu_nin = $record['ALU_NIN'];
            $alu_esp = $record['ALU_ESP'];
            $alu_sem = $record['ALU_SEM'];

            echo "<br>";
            echo "$alu_ctr, $alu_nin, $alu_esp, $alu_sem";
            echo "<br>";
        }

        foreach ($dgauPath as $record) {
            $gpo_mat = $record['GPO_MAT'];
            $gpo_gpo = $record['GPO_GPO'];
            $gpo_cat = $record['GPO_CAT'];

            echo "<br>";
            echo "$gpo_mat, $gpo_gpo, $gpo_cat";
            echo "<br>";
        }

        foreach ($dlisPath as $record) {
            $lis_ctr = $record['LIS_CTR'];
            $lis_mat = $record['LIS_MAT'];
            $lis_gpo = $record['LIS_GPO'];
            
            echo "<br>";
            echo "$lis_ctr, $lis_mat, $lis_gpo";
            echo "<br>";
        }
    }
}
