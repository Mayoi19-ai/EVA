<?php
namespace App\Controller\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use App\Validator\LessonValidator;
use Ujpef\LatteView;
use Slim\Exception\HttpForbiddenException;
use App\Database\LessonInfrastructure;

class LessonController{
    private $container;
    
    public function __construct(Container $container){
        $this->container = $container;
    }

    public function saveForm(Request $request, Response $response, array $args){
        // Simula que la lógica de negocios valida el id
        $id = (int) $args['id'];
        if($id > 5) {
            throw new HttpForbiddenException($request);
        }
        return $this->container->get(LatteView::class)->render($response, 'Asignatura/lesson.latte', [
            'id' => $id,
        ]);
    }

    public function register(Request $request, Response $response, array $args){
        $resultData = [];
        
        $data = (array)$request->getParsedBody();
        $lessonVal = $this->container->get(LessonValidator::class);
        
        $validationResult = $lessonVal->validateSaveLesson($data, $resultData);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Asignatura/lessonvalidation.latte',
            ['validacion_exitosa' => $validationResult] + $resultData
        );
    }

    public function searchForm(Request $request, Response $response, array $args){
        // Simula que la lógica de negocios valida el id
        $id = (int) $args['id'];
        if($id > 5) {
            throw new HttpForbiddenException($request);
        }
        return $this->container->get(LatteView::class)->render($response, 'Asignatura/lesson.latte', [
            'id' => $id,
        ]);
    }

    public function search(Request $request, Response $response, array $args){
        $resultData = [];
        
        $data = array("code" => $args['code']);
        
        $lessonVal = $this->container->get(LessonValidator::class);
        
        $validationResult = $lessonVal->ValidateSearch($data, $resultData);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Asignatura/lessonvalidation.latte',
            ['validacion_exitosa' => $validationResult] + $resultData
        );
    }

    public function show(Request $request, Response $response, array $args){
        $teacherInfraestructure = $this->container->get(TeacherInfrastructure::class);
        $dataTeacher = $teacherInfraestructure->selectDataTeacher();

        if(empty( $dataTeacher )) {
            $response->getBody()->write("No hay docentes registrados");
        }
        return $this->container->get(LatteView::class)->render(
            $response,
            'Asignatura/lessonTable.latte'
        );
    }
    
    public function update(Request $request, Response $response, array $args){
        $resultData = [];
        
        $data = (array)$request->getParsedBody();
        $lessonVal = $this->container->get(LessonValidator::class);
        
        $validationResult = $lessonVal->ValidateUpdate($data, $resultData);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Asignatura/lessonvalidation.latte',
            ['validacion_exitosa' => $validationResult] + $resultData
        );
    }

    public function delete(Request $request, Response $response, array $args){
        $code = $args['code'];
        $response->getBody()->write("$code");
        return $response;
    }
}