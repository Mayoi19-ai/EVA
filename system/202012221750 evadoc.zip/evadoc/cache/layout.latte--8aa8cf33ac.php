<?php
// source: Archivos/layout.latte

use Latte\Runtime as LR;

class Template8aa8cf33ac extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		$this->parentName = '@layout.latte';
		
	}

}
