<?php
// source: Asignatura/lessonTable.latte

use Latte\Runtime as LR;

class Template5c94dd159e extends Latte\Runtime\Template
{
	public $blocks = [
		'content' => 'blockContent',
	];

	public $blockTypes = [
		'content' => 'html',
	];


	function main()
	{
		extract($this->params);
		/* line 1 */
		$this->createTemplate('@layout-navbar.latte', $this->params, "include")->renderToContentType('html');
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('content', get_defined_vars());
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['lessonShow'])) trigger_error('Variable $lessonShow overwritten in foreach on line 35');
		
	}


	function blockContent($_args)
	{
		extract($_args);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 8 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <link type="text/css" rel="stylesheet" href="/materialize/css/style.css"  media="screen,projection">
</head>

<body>
<div class="MiTabla">
<div class="row">
<div class="input-field col s6">
<form action="<?php
		echo $router->relativeUrlFor("lessonSearch");
?>" method="get"> <!-- buscar -->
         <input type="text" name="nombre">
    <input type="submit" class="btn btn-primary btn-sm" value='Buscar'>
    </form>
    </div>
    </div>
<table name="showAllLessons" method="get" class="bordered striped hoverable centered responsive-table"> <!-- nombre de tabla-->
<thead>
<tr>
<th>Clave de la asignatura</th>
<th>Nombre</th>
<th></th>
<th></th>
</tr>
</thead>
<tbody>
<?php
		$iterations = 0;
		foreach ($all_lessons_information as $lessonShow) {
?>
<tr>
    <td><?php echo LR\Filters::escapeHtmlText($lessonShow['clave']) /* line 37 */ ?> </td>
    <td><?php echo LR\Filters::escapeHtmlText($lessonShow['nombre']) /* line 38 */ ?> </td>
    <td>
<form action="<?php
			echo $router->relativeUrlFor("lessonUpdateForm");
?>" method="post">
            <input type="hidden" name="clave" value="<?php echo LR\Filters::escapeHtmlAttr($lessonShow['clave']) /* line 41 */ ?>">
             <input type="hidden" name="nombre" value="<?php echo LR\Filters::escapeHtmlAttr($lessonShow['nombre']) /* line 42 */ ?>">
<input type="submit" class="btn btn-primary btn-sm" value='Editar'>
</form>
</td>
   <td>
    <form action="<?php
			echo $router->relativeUrlFor("lessonDelete");
?>" method="get">
            <input type="hidden" name="clave" value="<?php echo LR\Filters::escapeHtmlAttr($lessonShow['clave']) /* line 48 */ ?>">
    <input type="submit"  style="background-color: #f44336" class="btn btn-primary btn-sm " value='Eliminar'>
    </form>
   </td>
</tr>
<?php
			$iterations++;
		}
?>
</tbody>
</table>
<div class="fixed-action-btn">
<a href="save-form" style="background-color: #4caf50" class="btn-floating btn-large  "><i class="material-icons">add</i></a>
</div>
</div>
</body>
</html>
<?php
	}

}
