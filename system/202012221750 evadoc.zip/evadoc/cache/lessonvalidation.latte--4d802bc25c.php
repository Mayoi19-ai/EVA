<?php
// source: Asignatura/lessonvalidation.latte

use Latte\Runtime as LR;

class Template4d802bc25c extends Latte\Runtime\Template
{
	public $blocks = [
		'content' => 'blockContent',
	];

	public $blockTypes = [
		'content' => 'html',
	];


	function main()
	{
		extract($this->params);
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('content', get_defined_vars());
		return get_defined_vars();
	}


	function blockContent($_args)
	{
		extract($_args);
		?>¿Fué la validación exitosa? <?php echo LR\Filters::escapeHtmlText($validacion_exitosa) /* line 2 */ ?>


<br>
<table>
    <tbody>
        <tr>
            <td>Nombre:</td>
            <td><?php echo LR\Filters::escapeHtmlText($result['name']) /* line 9 */ ?></td>
        </tr>
    </tbody>
</table>}
<pre> <?php echo LR\Filters::escapeHtmlText(var_dump($result)) /* line 13 */ ?> </pre>
<?php
	}

}
