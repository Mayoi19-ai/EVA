<?php
namespace App\Controller\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use App\Validator\SchoolSubjectValidator as Validator;
use Ujpef\LatteView;
use App\Infrastructure\CrudSystem\SchoolSubjectInfrastructure as Infrastructure;
use App\Infrastructure\CrudSystem\CareerInfrastructure as CareerInfra;
use App\Infrastructure\CrudSystem\LessonInfrastructure as LessonInfra;
use App\Validator\LessonValidator as LessonVal;

class SchoolSubjectController{
    private Container $container;
    private Infrastructure $infrastructure;
    private CareerInfra $careerInfra;
    private LessonInfra $lessonInfra;
    private Validator $validator;
    private LessonVal $lessonVal;

    public function __construct(Container $container, Infrastructure $infrastructure, CareerInfra $careerInfra, LessonInfra $lessonInfra, Validator $validator, LessonVal $lessonVal){
        $this->container = $container;
        $this->infrastructure = $infrastructure;
        $this->careerInfra = $careerInfra;
        $this->lessonInfra = $lessonInfra;
        $this->validator = $validator;
        $this->lessonVal = $lessonVal;
    }

    public function saveForm(Request $request, Response $response){
        $careerData = $this->careerInfra->readAuxiliary();
        $lessonData = $this->lessonInfra->readAll();

        return $this->container->get(LatteView::class)->render($response, 
        'Materia/schoolsubject.latte',[
            'careers' => $careerData,
            'lessons' => $lessonData
        ]);
    }

    public function register(Request $request, Response $response){
        $data = $request->getParsedBody();
        $validationResult = $this->validator->validateSaveSubject((array) $data);

        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->create((array) $data);
        } else {
            $sthResult = ['consulta' => false];
        }

        return $this->container->get(LatteView::class)->render(
            $response,
            'Materia/schoolsubjectValidation.latte', [
                'validation' => $validationResult, 
                'query' => $sthResult
            ]);
    }

    public function orderByCareer(Request $request, Response $response){
        $sthResult = $this->infrastructure->orderByCareer((int) $_GET['careerId']);
        return $this->container->get(LatteView::class)->render(
            $response,
            'Materia/schoolsubjectValidation.latte', [
                'query' => $sthResult
            ]);
    }

    public function searchByLesson(Request $request, Response $response){
        $validationResult = $this->lessonVal->validateFindLesson((array) $_GET);

        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->readByLesson((string) $_GET['asignatura']);
        } else {
            $sthResult = ['consulta' => false];
        }

        return $this->container->get(LatteView::class)->render(
            $response,
            'Materia/schoolsubjectValidation.latte', [
                'query' => $sthResult,
                'lesson_name' => $_GET['nombre']
            ]);
    }

    public function show(Request $request, Response $response){
        $sthResult = $this->infrastructure->readAll();

        return $this->container->get(LatteView::class)->render(
            $response, 
            'PruebasGera/prueba.latte', [
                'query' => $sthResult
            ]);
    }

    public function updateForm(Request $request, Response $response){
        $data = $request->getParsedBody();
        $careerData = $this->careerInfra->readAll();
        $lessonData = $this->lessonInfra->readAll();

        return $this->container->get(LatteView::class)->render($response, 
        'Materia/schoolsubject.latte',[
            'subject_information' => $data,
            'careers' => $careerData,
            'lessons' => $lessonData
        ]);
    }

    public function update(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $validationResult = $this->validator->validateSaveSubject((array) $data);

        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->update((array) $data);
        } else {
            $sthResult = ['consulta' => false];
        }

        return $this->container->get(LatteView::class)->render(
            $response,
            'Materia/schoolsubjectValidation.latte', [
                'validation' => $validationResult, 
                'query' => $sthResult,
            ]);
    }

    public function delete(Request $request, Response $response){
        $sthResult = $this->infrastructure->delete((int) $_GET['id_carrera'],(string) $_GET['clave_asignatura']);
        return $response;

        return $this->container->get(LatteView::class)->render(
            $response,
            'Modalidad/modalityValidation.latte', [
                'query' => $sthResult
            ]);
    }
}