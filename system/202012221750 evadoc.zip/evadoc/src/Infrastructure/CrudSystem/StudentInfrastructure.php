<?php
namespace App\Infrastructure\CrudSystem;

use Medoo\Medoo;
use App\Infrastructure\CrudSystem\CustomException as Exception;

class StudentInfrastructure{
    private Medoo $db;
    private Exception $exception;

    public function __construct(Medoo $db, Exception $exception) {
        $this->db = $db;
        $this->exception = $exception;
    }

    public function create(array $data): ?array
    {
        $this->db->pdo->beginTransaction();
        $this->db->insert('alumno',[
            'control' => strtoupper($data['control']), 
            'nombre' => strtoupper($data['nombre']),
            'contrasenia' => $data['control']
        ]);

        $result = $this->exception->saveError((array) $this->db->error());
        return $result;
    }

    public function readAll(): ?array
    {
        $sql = $this->db->select('alumno',[
            'control',
            'nombre']
        );

        $result = $this->exception->readError((array) $this->db->error(), (array) $sql);
        return $result;
    }

    public function read(string $control): ?array
    {
        $sql = $this->db->select('alumno',[
            'nombre',
            'control'], [
                'control' => strtoupper($control)
        ]);

        $result = $this->exception->readError((array) $this->db->error(), (array) $sql);
        return $result;
    }

    public function update(array $data): ?array
    {
        $this->db->pdo->beginTransaction();
        $this->db->update('alumno',[
            'control' => strtoupper($data['control']), 
            'nombre' => strtoupper($data['nombre']),
            'contrasenia' => strtoupper($data['control'])], [
                'control' => strtoupper($data['control_antiguo'])
        ]);

        $result = $this->exception->saveError((array) $this->db->error());
        return $result;
    }

    public function updatePassword(array $data): ?array
    {
        $this->db->update('alumno',[
            'contrasenia' => $data['contrasenia']], [
                'control' => strtoupper($data['control'])
                ]);

        return $nothing;
    }
    
    public function delete(string $control): ?array
    {
        $this->db->pdo->beginTransaction();
        $this->db->delete('alumno', [
                'control' => $control
        ]);
        
        $result = $this->exception->deleteError((array) $this->db->error());
        return $result;
    }
}