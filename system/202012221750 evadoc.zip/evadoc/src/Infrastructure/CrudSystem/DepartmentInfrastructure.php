<?php
namespace App\Infrastructure\CrudSystem;

use Medoo\Medoo;
use App\Infrastructure\CrudSystem\CustomException as Exception;

class DepartmentInfrastructure{
    private Medoo $db;
    private Exception $exception;

    public function __construct(Medoo $db, Exception $exception) {
        $this->db = $db;
        $this->exception = $exception;
    }

    public function create(array $data): ?array
    {
        $this->db->pdo->beginTransaction();
        $this->db->insert('departamento',[
            'clave' => $data['clave'], 
            'nombre' => strtoupper($data['nombre'])
        ]);
        
        $result = $this->exception->saveError((array) $this->db->error());
        return $result;
    }

    public function readAll(): ?array
    {
        $sql = $this->db->select('departamento',[
            'clave',
            'nombre'
        ]);
        
        $result = $this->exception->readError((array) $this->db->error(), (array) $sql);
        return $result;
    }

    public function read(string $name): ?array
    {
        $sql = $this->db->select('departamento',[
            'clave', 
            'nombre'], [
                'nombre[~]' => strtoupper($name)
        ]);

        $result = $this->exception->readError((array) $this->db->error(), (array) $sql);
        return $result;
    }

    public function update(array $data): ?array
    {
        $this->db->pdo->beginTransaction();
        $this->db->update('departamento',[
            'clave' => $data['clave'], 
            'nombre' => strtoupper($data['nombre'])], [
                'clave' => $data['clave_antigua']
        ]);

        $result = $this->exception->saveError((array) $this->db->error());
        return $result;
    }
    
    public function delete(int $code): ?array
    {
        $this->db->pdo->beginTransaction();
        $this->db->delete('departamento', [
            'clave' => $code
        ]);
        
        $result = $this->exception->deleteError((array) $this->db->error());
        return $result;
    }
}