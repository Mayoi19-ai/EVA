<?php declare(strict_types=1);

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Log\LoggerInterface;
use Slim\App;
use Ujpef\LatteView;
use Slim\Routing\RouteCollectorProxy;

//use App\Controller\Presentation\presentationController;
//use App\Controller\Saludos;

use App\Controller\Controllers\MenuController;
use App\Controller\Controllers\TeacherController;
use App\Controller\Controllers\CampusController;
use App\Controller\Controllers\ModalityController;
use App\Controller\Controllers\PeriodController;
use App\Controller\Controllers\CareerController;
use App\Controller\Controllers\LessonController;
use App\Controller\Controllers\DepartmentController;
use App\Controller\Controllers\StudentController;
use App\Controller\Controllers\InscriptionController;
use App\Controller\Controllers\SchoolSubjectController;
use App\Controller\Controllers\CourseController;
use App\Controller\Controllers\GroupController;
use App\Controller\Controllers\QuestionnaireController;
use App\Controller\Controllers\ImportDbfDataController;

return function(App $app): void
{
    $app->get('/test/{id:\\d+}', ImportDbfDataController::class . ':importAll')->setName('test');
    $app->group('/panel', function (RouteCollectorProxy $group) {
        
        $group->get('/questionnaire/{id}', QuestionnaireController::class . ':getAll')->setName('getQuestionnaire');

        $group->get('/menu/{id}', MenuController::class . ':menu')->setName('menuAdmin');

        $group->group('/teacher', function (RouteCollectorProxy $group) {
            $group->get('/save-form/{id:\\d+}', TeacherController::class . ':saveForm')->setName('teacherSaveForm');
            $group->post('/register/{id:\\d+}', TeacherController::class . ':register')->setName('teacherRegister');

            $group->get('/search-form/{folio:\\d+}', TeacherController::class . ':searchForm')->setName('teacherSearchForm');
            $group->get('/search/{folio:\\d+}', TeacherController::class . ':search')->setName('teacherSearch');

            $group->get('/show/{folio:\\d+}', TeacherController::class . ':show')->setName('showAllTeachers');
            $group->post('/update/{id:\\d+}', TeacherController::class . ':update')->setName('teacherUpdate');
            $group->get('/delete/{folio:\\d+}', TeacherController::class . ':delete')->setName('teacherDelete');
        });

        $group->group('/campus', function (RouteCollectorProxy $group) {
            $group->get('/save-form/{id:\\d+}', CampusController::class . ':saveForm')->setName('campusSaveForm');
            $group->post('/register/{id:\\d+}', CampusController::class . ':register')->setName('campusRegister');

            $group->get('/search-form/{id:\\d+}', CampusController::class . ':searchForm')->setName('campusSearchForm');
            $group->get('/search/{id:\\d+}', CampusController::class . ':search')->setName('campusSearch');

            $group->get('/show/{folio:\\d+}', CampusController::class . ':show')->setName('showAllCampuses');
            $group->post('/update/{id:\\d+}', CampusController::class . ':update')->setName('campusUpdate');
            $group->get('/delete/{id:\\d+}', CampusController::class . 'delete')->setName('campusDelete');
        });

        $group->group('/modality', function (RouteCollectorProxy $group) {
            $group->get('/save-form/{id:\\d+}', ModalityController::class . ':saveForm')->setName('modalitySaveForm');
            $group->post('/register/{id:\\d+}', ModalityController::class . ':register')->setName('modalityRegister');

            $group->get('/search-form/{id}', ModalityController::class . ':searchForm')->setName('modalitySearchForm');
            $group->get('/search/{id}', ModalityController::class . ':search')->setName('modalitySearch');

            $group->get('/show/{id}', ModalityController::class . ':show')->setName('showAllModalities');
            $group->post('/update/{id}', ModalityController::class . ':update')->setName('modalityUpdate');
            $group->get('/delete/{id:\\d+}', ModalityController::class . ':delete')->setName('modalityDelete');
        });

        $group->group('/period', function (RouteCollectorProxy $group) {
            $group->get('/save-form/{id:\\d+}', PeriodController::class . ':saveForm')->setName('periodSaveForm');
            $group->post('/register/{id}', PeriodController::class . ':register')->setName('periodRegister');

            $group->get('/search-form/{name}', PeriodController::class . ':searchForm')->setName('periodSearchForm');
            $group->get('/search/{name}', PeriodController::class . ':search')->setName('periodSearch');

            $group->get('/show/{id}', PeriodController::class . ':show')->setName('showAllPeriods');
            $group->post('/update/{id}', PeriodController::class . ':update')->setName('periodUpdate');
            $group->get('/delete/{id:\\d+}', PeriodController::class . ':delete')->setName('periodDelete');
        });

        $group->group('/career', function (RouteCollectorProxy $group) {
            $group->get('/save-form/{id:\\d+}', CareerController::class . ':saveForm')->setName('careerSaveForm');
            $group->post('/register/{id}', CareerController::class . ':register')->setName('careerRegister');

            $group->get('/search-form/{id:\\d+}', CareerController::class . ':searchForm')->setName('careerSearchForm');
            $group->get('/search/{id}', CareerController::class . ':search')->setName('careerSearch');

            $group->get('/show/{id:\\d+}', CareerController::class . ':show')->setName('showAllCareers');
            $group->post('/update/{id}', CareerController::class . ':update')->setName('careerUpdate');
            $group->get('/delete/{id:\\d+}', CareerController::class . ':delete')->setName('careerDelete');
        });

        $group->group('/lesson', function (RouteCollectorProxy $group) {
            $group->get('/save-form/{id:\\d+}', LessonController::class . ':saveForm')->setName('lessonSaveForm');
            $group->post('/register/{id}', LessonController::class . ':register')->setName('lessonRegister');

            $group->get('/search-form/{id:\\d+}', LessonController::class . ':searchForm')->setName('lessonSearchForm');
            $group->get('/search/{code}', LessonController::class . ':search')->setName('lessonSearch');

            $group->get('/show/{id:\\d+}', LessonController::class . ':show')->setName('showAllLessons');
            $group->post('/update/{id}', LessonController::class . ':update')->setName('lessonUpdate');
            $group->get('/delete/{id:\\d+}', LessonController::class . ':delete')->setName('lessonDelete');
        });

        $group->group('/department', function (RouteCollectorProxy $group) {
            $group->get('/save-form/{id:\\d+}',  DepartmentController::class . ':saveForm')->setName('departmentSaveForm');
            $group->post('/register/{id}', DepartmentController::class . ':register')->setName('departmentRegister');

            $group->get('/search-form/{id:\\d+}',  DepartmentController::class . ':searchForm')->setName('departmentSearchForm');
            $group->get('/search/{code}',  DepartmentController::class . ':search')->setName('departmentSearch');

            $group->get('/show/{id:\\d+}',  DepartmentController::class . ':show')->setName('showAllDepartments');
            $group->get('/update/{id}',  DepartmentController::class . ':update')->setName('departmentUpdate');
            $group->get('/delete/{id:\\d+}', DepartmentController::class . ':delete')->setName('departmentDelete');
        });

        $group->group('/student', function (RouteCollectorProxy $group) {
            $group->get('/save-form/{id:\\d+}',  StudentController::class . ':saveForm')->setName('studentSaveForm');
            $group->post('/register/{id}', StudentController::class . ':register')->setName('studentRegister');
            
            $group->get('/search-form/{id:\\d+}',  StudentController::class . ':searchForm')->setName('studentSearchForm');
            $group->get('/search/{id}', StudentController::class . ':search')->setName('studentSearch');

            $group->get('/show/{id:\\d+}',  StudentController::class . ':show')->setName('showAllStudents');
            $group->get('/update/{id}', StudentController::class . ':update')->setName('studentUpdate');
            $group->get('/delete/{id:\\d+}', StudentController::class . ':delete')->setName('studentDelete');
        });

        $group->group('/inscription', function (RouteCollectorProxy $group) {
            $group->get('/save-form/{id:\\d+}', InscriptionController::class . ':saveForm')->setName('inscriptionSaveForm');
            $group->post('/register/{id}', InscriptionController::class . ':register')->setName('inscriptionRegister');

            $group->get('/search-form/{id:\\d+}', InscriptionController::class . ':searchForm')->setName('inscriptionSearchForm');
            $group->get('/search/{courseCode}', InscriptionController::class . ':search')->setName('inscriptionSearch');

            $group->get('/show/{id:\\d+}', InscriptionController::class . ':show')->setName('showAllInscriptions');
            $group->get('/update/{id}', InscriptionController::class . ':update')->setName('inscriptionUpdate');
            $group->get('/delete/{courseCode:\\d+}', InscriptionController::class . ':delete')->setName('inscriptionDelete');
        });

        $group->group('/subject', function (RouteCollectorProxy $group) {
            $group->get('/save-form/{id:\\d+}', SchoolSubjectController::class . ':saveForm')->setName('subjectSaveForm');
            $group->post('/register/{id}', SchoolSubjectController::class . ':register')->setName('subjectRegister');

            $group->get('/search-form/{id:\\d+}', SchoolSubjectController::class . ':searchForm')->setName('subjectSearchForm');
            $group->get('/search/{codeCareer}', SchoolSubjectController::class . ':search')->setName('subjectSearch');

            $group->get('/show/{id:\\d+}', SchoolSubjectController::class . ':show')->setName('showAllSubjects');
            $group->post('/update/{id}', SchoolSubjectController::class . ':update')->setName('subjectUpdate');
            $group->get('/delete/{id:\\d+}', SchoolSubjectController::class . ':delete')->setName('subjectDelete');
        });

        $group->group('/course', function (RouteCollectorProxy $group) {
            $group->get('/save-form/{id:\\d+}', CourseController::class . ':saveForm')->setName('courseSaveForm');
            $group->post('/register/{id}', CourseController::class . ':register')->setName('courseRegister');

            $group->get('/search-form/{id:\\d+}', CourseController::class . ':searchForm')->setName('courseSearchForm');
            $group->get('/search/{courseCode}', CourseController::class . ':search')->setName('courseSearch');

            $group->get('/show/{id:\\d+}', CourseController::class . ':show')->setName('showAllCourses');
            $group->post('/update/{id}', CourseController::class . ':update')->setName('courseUpdate');
            $group->get('/delete/{id:\\d+}', CourseController::class . ':delete')->setName('courseDelete');
        });

        $group->group('/group', function (RouteCollectorProxy $group) {
            $group->get('/save-form/{id:\\d+}', GroupController::class . ':saveForm')->setName('groupSaveForm');
            $group->post('/register/{id}', GroupController::class . ':register')->setName('groupRegister');
            
            $group->get('/search-form/{id:\\d+}', GroupController::class . ':searchForm')->setName('groupSearchForm');
            $group->get('/search/{courseCode}', GroupController::class . ':search')->setName('groupSearch');

            $group->get('/show/{id:\\d+}', GroupController::class . ':show')->setName('showAllGroups');
            $group->post('/update/{id}', GroupController::class . ':update')->setName('groupUpdate');
            $group->get('/delete/{id:\\d+}', GroupController::class . ':delete')->setName('groupDelete');

        
        });

    });
};
           //Menu
        //$group->group('/menu', function (RouteCollectorProxy $group) {
        //    $group->get('/show/{id}', MenuController::class . ':form')->setName('menuTest');
        //});
    
    //$app->get('/', presentationController::class . ':index')->setName('presentation');
    /*$app->get('/', function(Request $request, Response $response) {
        $response->getBody()->write('¡Hola mundo feliz!');
        return $response;
    })->setName('index');

    $app->get('/teacher/{name}', add::class . ':register')->setName('docenteAdd');

    $app->get('/test/{id}', presentationController::class . ':testdb')->setName('test');

    /*$app->get('/hello/{name}', function(Request $request, Response $response, $name) {
        $logger = $this->get(LoggerInterface::class);
        $logger->debug('Obteniendo datos desde los sensores remotos.');
        $logger->warning('Los datos están incompletos.');

        return $this->get(LatteView::class)->render($response, 'index.latte', [
            'variable' => 123,
            'name'     => $name
        ]);
    })->setName('sayhello');*/
