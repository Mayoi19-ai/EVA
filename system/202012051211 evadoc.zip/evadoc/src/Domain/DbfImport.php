<?php

namespace App\Domain;

use org\majkel\dbase\Table;

class DbfImport {

    public function imports() {
        $despPath = Table::fromFile(__DIR__.'/../../public/dbfFiles/desp.DBF');
        $ddepPath = Table::fromFile(__DIR__.'/../../public/dbfFiles/ddep.DBF');
        $dretPath = Table::fromFile(__DIR__.'/../../public/dbfFiles/dret.DBF');
        $dcatPath = Table::fromFile(__DIR__.'/../../public/dbfFiles/dcat.DBF');
        $daluPath = Table::fromFile(__DIR__.'/../../public/dbfFiles/dalu.DBF');
        $dgauPath = Table::fromFile(__DIR__.'/../../public/dbfFiles/dgau.DBF');
        $dlisPath = Table::fromFile(__DIR__.'/../../public/dbfFiles/dlis.DBF');

        $desp = [];
        $ddep = [];
        $dret = [];
        $dcat = [];
        $dalu = [];
        $dgau = [];
        $dlis = [];

        foreach ($despPath as $record) {
            array_push($desp, $record['ESP_CVE']);
            array_push($desp, $record['ESP_NCO']);
        }

        foreach ($ddepPath as $record) {
            array_push($ddep, $record['DEP_CVE']);
            array_push($ddep, $record['DEP_NCO']);
        }

        foreach ($dretPath as $record) {
            array_push($dret, $record['RET_CVE']);
            array_push($dret, $record['RET_NCO']);
        }

        foreach ($dcatPath as $record) {
            array_push($dcat, $record['CAT_CVE']);
            array_push($dcat, $record['CAT_DEP']);
            array_push($dcat, $record['CAT_NOM']);
        }

        foreach ($daluPath as $record) {
            array_push($dalu, $record['ALU_CTR']);
            array_push($dalu, $record['ALU_NIN']);
            array_push($dalu, $record['ALU_ESP']);
            array_push($dalu, $record['ALU_SEM']);
        }

        foreach ($dgauPath as $record) {
            array_push($dgau, $record['GPO_MAT']);
            array_push($dgau, $record['GPO_GPO']);
            array_push($dgau, $record['GPO_CAT']);
        }

        foreach ($dlisPath as $record) {
            array_push($dlis, $record['LIS_CTR']);
            array_push($dlis, $record['LIS_MAT']);
            array_push($dlis, $record['LIS_GPO']);
        }
        //array_push($mat, $ddep);
        //array_push($mat, $test);
        //$array = array_combine($name, $mat);

        //print_r($array['test']);


        //print_r($mat['1']);
        /*foreach ($dbf as $record) {
           foreach ($record as $info => $valor) {
               echo "<p> $valor </p>";
           }
        }*/

        /*echo "<br>";
            print_r($record['DEP_CVE']);
            echo "<br>";
            print_r($record['DEP_NOM']);
            echo "<br>";*/
    }
}