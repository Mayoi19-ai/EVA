<?php
namespace App\Validator;
use Rakit\Validation\Validator;

class GroupValidator{
    private Validator $validator;

    public function __construct(Validator $validator) {
        $this->validator = $validator;
    }

    public function validateSaveGroup(array $data, array &$resultData): bool {
        $validationRules = [
            'name'          =>  'required|alpha_num|uppercase|between:4,4',
            'codePeriod'    =>  'required|numeric|digits_between:1,10',
            'codeCareer'    =>  'required|alpha_dash|uppercase|between:13,13',
            'codeModality'  =>  'required|numeric|digits_between:1,10',
            'codeCampus'    =>  'required|numeric|digits_between:1,10',
        ];

        $errorMessages = [
            'name:required'                => 'El nombre es obligatorio',
            'name:alpha_num'               => 'El nombre no acepta espacios ni caracteres especiales',
            'name:uppercase'               => 'El nombre debe de estar en mayúsculas',
            'name:between'                 => 'El nombre debe tener 4 caracteres',
            'codePeriod:required'          => 'La clave del periodo es obligatoria',
            'codePeriod:numeric'           => 'La clave del periodo es numerica',
            'codePeriod:digits_between'    => 'La clave del periodo debe tener entre 1 a 10 caracteres',
            'codeCareer:required'          => 'La clave es obligatoria',
            'codeCareer:uppercase'         => 'La clave de la crrera debe estar en mayúsculas',
            'codeCareer:between'           => 'La clave de carrera debe tener 13 caracteres',
            'codeCareer:alpha_dash'        => 'La clave de carrera no permite espacios o caracteres especiales',
            'codeModality:required'        => 'La clave de modalidad es obligatoria',
            'codeModality:numeric'         => 'La clave de modalidad solo acepta números',
            'codeModality:digits_between'  => 'La clave de modadalidad debe tener entre 1 a 10 caracteres',
            'codeCampus:required'          => 'La clave de campus es obligatoria',
            'codeCampus:numeric'           => 'La clave de campus solo acepta números',
            'codeCampus:digits_between'    => 'La clave de campus debe tener entre 1 a 10 caracteres',
        ];

        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data, $resultData);
    }
}