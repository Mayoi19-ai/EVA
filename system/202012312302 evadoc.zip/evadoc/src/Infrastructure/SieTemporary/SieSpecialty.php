<?php
namespace App\Infrastructure\SieTemporary;

use org\majkel\dbase\Table;
use Medoo\Medoo;

class SieSpecialty {
    private Medoo $db;

    public function __construct(Medoo $db) {
        $this->db = $db;
    }

    public function loadSieSpecialty (string $dbfFileSpecialty): ?array
    {
        $create = $this->createSieSpecialty((string) $dbfFileSpecialty);
        if(!empty($create[1])){
            $result = ['flag' => true, 
                        'error' => 'No se pudo crear estructura Carrera SIE'];
            return $result;
        }

        return null;
    }

    public function createSieSpecialty(string $dbfFileSpecialty): array
    {
        $sql = <<<'EOP'
            DROP TABLE IF EXISTS `temp_desp`;
            CREATE TEMPORARY TABLE IF NOT EXISTS `temp_desp` (
                `cve` INT(3) UNSIGNED NOT NULL,
                `nom` VARCHAR(250) NOT NULL,
                `nco` VARCHAR(45) NOT NULL,
            PRIMARY KEY (`cve`));
          EOP;

        $this->db->query($sql);

        $file = Table::fromFile($dbfFileSpecialty);
        
        foreach ($file as $record) {
            $this->db->insert("temp_desp", [
                "cve" => $record['ESP_CVE'], 
                "nom" => utf8_encode($record['ESP_NOM']),
                "nco" => $record['ESP_NCO']
            ]);
        }

        return $this->db->error();
    }
}