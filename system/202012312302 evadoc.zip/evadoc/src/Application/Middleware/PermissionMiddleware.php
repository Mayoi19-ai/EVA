<?php declare(strict_types=1);
namespace App\Middleware;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Server\MiddlewareInterface as Middleware;
use Psr\Http\Server\RequestHandlerInterface as RequestHandler;
use Slim\Routing\RouteContext;
use Psr\Http\Message\ResponseFactoryInterface as Factory;
use App\Infrastructure\Login\Login as Infrastructure;
use App\SessionLife;

class PermissionMiddleware implements Middleware
{
    private Factory $responseFactory;
    private Infrastructure $infrastructure;
    private SessionLife $sessionLife;

    public function __construct(Factory $responseFactory, Infrastructure $infrastructure, SessionLife $sessionLife)
    {
        $this->responseFactory = $responseFactory;
        $this->infrastructure = $infrastructure;
        $this->sessionLife = $sessionLife;
    }

    public function process(Request $request, RequestHandler $handler): Response
    {
        $routeContext = RouteContext::fromRequest($request);
        $route = $routeContext->getRoute();

        if (session_status() !== PHP_SESSION_ACTIVE) {
            $routeParser = RouteContext::fromRequest($request)->getRouteParser();
            $url = $routeParser->urlFor('getQuestionnaire');
        
            $response = $this->responseFactory->createResponse();
            $response = $response->withStatus(302)->withHeader('Location', $url);
            return $response;
        }

        $session = $request->getAttribute('session');
        
        if(empty($session['registered'])){
            $routeParser = RouteContext::fromRequest($request)->getRouteParser();
            $url = $routeParser->urlFor('getQuestionnaire');
        
            $response = $this->responseFactory->createResponse();
            $response = $response->withStatus(302)->withHeader('Location', $url);
            return $response;
        }

        if(preg_match("/^\d{3}[zZ]{1}\d{4}$/", $session['nombre'])) {
            //check if the student is logged in
            $find = $this->infrastructure->studentLogged((string) $session['id']);

            if(empty($find)){
                $routeParser = RouteContext::fromRequest($request)->getRouteParser();
                $url = $routeParser->urlFor('getQuestionnaire');
        
                $response = $this->responseFactory->createResponse();
                $response = $response->withStatus(302)->withHeader('Location', $url);
                return $response;

            } else {

                if($find['control'] == $session['control'] && $find['ip'] == $session['ip'] && $find['navegador'] == $session['userAgent']) {
                    $name = $route->getName();
                    $permissions = $this->infrastructure->searchPermission((string) $name);

                    if(empty($permissions)) {
                        if(empty($this->sessionLife->sessionRenewStudent($session))) {
                            $routeParser = RouteContext::fromRequest($request)->getRouteParser();
                            $url = $routeParser->urlFor('getQuestionnaire');
        
                            $response = $this->responseFactory->createResponse();
                            $response = $response->withStatus(302)->withHeader('Location', $url);
                            return $response;
                        }

                        return $handler->handle($request);
                     
                    } else {
                        $routeParser = RouteContext::fromRequest($request)->getRouteParser();
                        $url = $routeParser->urlFor('getQuestionnaire');
                
                        $response = $this->responseFactory->createResponse();
                        $response = $response->withStatus(302)->withHeader('Location', $url);
                        return $response;
                    }

                } else {
                    $routeParser = RouteContext::fromRequest($request)->getRouteParser();
                    $url = $routeParser->urlFor('getQuestionnaire');
                
                    $response = $this->responseFactory->createResponse();
                    $response = $response->withStatus(302)->withHeader('Location', $url);
                    return $response;
                }
            }
        } else {
            //check if the user is logged in
            $find = $this->infrastructure->studentLogged((string) $session['id']);

            if(empty($find)){
                $routeParser = RouteContext::fromRequest($request)->getRouteParser();
                $url = $routeParser->urlFor('getQuestionnaire');
        
                $response = $this->responseFactory->createResponse();
                $response = $response->withStatus(302)->withHeader('Location', $url);
                return $response;

            } else {

                if($find['id_usuario'] == $session['usuario'] && $find['ip'] == $session['ip'] && $find['navegador'] == $session['userAgent']) {
                    $name = $route->getName();
                    $permissions = $this->infrastructure->searchUserPermission((string) $name, (int) $session['usuario']);

                    if(!empty($permissions)) {
                        if(empty($this->sessionLife->sessionRenewUser($session))) {
                            
                            $routeParser = RouteContext::fromRequest($request)->getRouteParser();
                            $url = $routeParser->urlFor('getQuestionnaire');
        
                            $response = $this->responseFactory->createResponse();
                            $response = $response->withStatus(302)->withHeader('Location', $url);
                            return $response;
                        }
                        return $handler->handle($request);
                     
                    } else {
                        $routeParser = RouteContext::fromRequest($request)->getRouteParser();
                        $url = $routeParser->urlFor('getQuestionnaire');
                
                        $response = $this->responseFactory->createResponse();
                        $response = $response->withStatus(302)->withHeader('Location', $url);
                        return $response;
                    }

                } else {
                    $routeParser = RouteContext::fromRequest($request)->getRouteParser();
                    $url = $routeParser->urlFor('getQuestionnaire');
                
                    $response = $this->responseFactory->createResponse();
                    $response = $response->withStatus(302)->withHeader('Location', $url);
                    return $response;
                }
            }
        }
    }
}