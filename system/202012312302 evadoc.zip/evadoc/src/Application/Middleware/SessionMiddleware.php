<?php declare(strict_types=1);
namespace App\Middleware;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Server\MiddlewareInterface as Middleware;
use Psr\Http\Server\RequestHandlerInterface as RequestHandler;
use Slim\Routing\RouteContext;
use Psr\Http\Message\ResponseFactoryInterface as Factory;
use App\Validator\LoginValidator as Validator;
use App\Infrastructure\Login\Login as Infrastructure;

class SessionMiddleware implements Middleware
{
    private Factory $responseFactory;
    private Validator $validator;
    private Infrastructure $infrastructure;

    public function __construct(Factory $responseFactory, Validator $validator, Infrastructure $infrastructure)
    {
        $this->responseFactory = $responseFactory;
        $this->validator = $validator;
        $this->infrastructure = $infrastructure;
    }

    public function process(Request $request, RequestHandler $handler): Response
    {
        //$data = $request->getParsedBody();
        $data = ['nombre' => '163Z0204',
                  'contrasenia' => '163Z0204'];

        if(preg_match("/^\d{3}[zZ]{1}\d{4}$/", $data['nombre'])) {
            //student session
            $student = $this->student($data);

            if(empty($student)) {
                $routeParser = RouteContext::fromRequest($request)->getRouteParser();
                $url = $routeParser->urlFor('getQuestionnaire');
                
                $response = $this->responseFactory->createResponse();
                $response = $response->withStatus(302)->withHeader('Location', $url);
                return $response;

            } else {
                if(password_verify($data['contrasenia'], $student['contrasenia'])) {
                    session_name('eva');
                    session_start();
                    //session_regenerate_id();
                    $_SESSION['id'] = uniqid(bin2hex(random_bytes(5)), true);
                    $_SESSION['registered'] = true;
                    $_SESSION['control'] = $data['nombre'];
                    $_SESSION['ip'] = $this->getRealIP();
                    $_SESSION['userAgent'] = $_SERVER['HTTP_USER_AGENT'];
                    $_SESSION['lastActivity'] = time();
                    
                    $save = $this->infrastructure->saveStudent($_SESSION);
                    if (!empty($save)) {
                        $request = $request->withAttribute('session', $_SESSION);
                        return $handler->handle($request);
                    } else {
                        $routeParser = RouteContext::fromRequest($request)->getRouteParser();
                        $url = $routeParser->urlFor('getQuestionnaire');
        
                        $response = $this->responseFactory->createResponse();
                        $response = $response->withStatus(302)->withHeader('Location', $url);
                        return $response;
                    }

                } else {
                    $routeParser = RouteContext::fromRequest($request)->getRouteParser();
                    $url = $routeParser->urlFor('getQuestionnaire');
                
                    $response = $this->responseFactory->createResponse();
                    $response = $response->withStatus(302)->withHeader('Location', $url);
                    return $response;
                }
            }

        } else {
            //user session
            $user = $this->user($data);

            if(empty($user)) {
                $routeParser = RouteContext::fromRequest($request)->getRouteParser();
                $url = $routeParser->urlFor('getQuestionnaire');
                    
                $response = $this->responseFactory->createResponse();
                $response = $response->withStatus(302)->withHeader('Location', $url);
                return $response;

            } else {
                if(password_verify($data['contrasenia'], $user['contrasenia'])) {
                    session_name('eva');
                    session_start();
                    //session_regenerate_id();
                    $_SESSION['id'] = uniqid(bin2hex(random_bytes(5)), true);
                    $_SESSION['registered'] = true;
                    $_SESSION['usuario'] = $data['id'];
                    $_SESSION['ip'] = $this->getRealIP();
                    $_SESSION['userAgent'] = $_SERVER['HTTP_USER_AGENT'];
                    $_SESSION['lastActivity'] = time();
                    $request = $request->withAttribute('session', $_SESSION);
                    
                    $save = $this->infrastructure->saveUser($_SESSION);
                    if (!empty($save)) {
                        $request = $request->withAttribute('session', $_SESSION);
                        return $handler->handle($request);
                    } else {
                        $routeParser = RouteContext::fromRequest($request)->getRouteParser();
                        $url = $routeParser->urlFor('getQuestionnaire');
        
                        $response = $this->responseFactory->createResponse();
                        $response = $response->withStatus(302)->withHeader('Location', $url);
                        return $response;
                    }

                } else {
                    $routeParser = RouteContext::fromRequest($request)->getRouteParser();
                    $url = $routeParser->urlFor('getQuestionnaire');
                
                    $response = $this->responseFactory->createResponse();
                    $response = $response->withStatus(302)->withHeader('Location', $url);
                    return $response;
                }
            }
        }
    }

    private function student(array $data): ?array
    {
        $validationResult = $this->validator->studentValidator((array) $data);

        if(!empty($validationResult['flag'])) {
            return $this->infrastructure->findStudent((array) $data);        
        }

        return null;
    }

    private function user(array $data): ?array
    {
        $validationResult = $this->validator->userValidator((array) $data);

        if(!empty($validationResult['flag'])) {
            return $this->infrastructure->findUser((array) $data);
        }

        return null;
    }

    private function getRealIP() {
        if (!empty($_SERVER['HTTP_CLIENT_IP']))
            return $_SERVER['HTTP_CLIENT_IP'];
           
        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))
            return $_SERVER['HTTP_X_FORWARDED_FOR'];
       
        return $_SERVER['REMOTE_ADDR'];
    }
}