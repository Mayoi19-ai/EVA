<?php
namespace App\Controller\Student;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use Ujpef\LatteView;
use App\Validator\StudentValidator as Validator;
use App\Infrastructure\CrudSystem\StudentInfrastructure as Infrastructure;
use App\Infrastructure\CrudSystem\PeriodInfrastructure as PeriodInfra;
use App\Infrastructure\Student\Courses as CoursesInfra;

class StudentCoursesController{
    private Container $container;
    private Validator $validator;
    private Infrastructure $infrastructure;
    private PeriodInfra $periodInfra;
    private CoursesInfra $coursesInfra;

    public function __construct(Container $container, Validator $validator, Infrastructure $infrastructure, PeriodInfra $periodInfra, CoursesInfra $coursesInfra){
        $this->container = $container;
        $this->validator = $validator;
        $this->infrastructure = $infrastructure;
        $this->periodInfra = $periodInfra;
        $this->coursesInfra = $coursesInfra;
    }

    public function menu (Request $request, Response $response) {
        $student = $request->getParsedBody();
        $periodData = $this->periodInfra->readActivedPeriod();
        $studentData = $this->infrastructure->read((string) $student['control']);

        return $this->container->get(LatteView::class)->render(
            $response, 
            'Campus/campusForm.latte', [
                'student_information' => $data
            ]);
    }

    public function showCourses (Request $request, Response $response) {
        $this->coursesInfra->readAll($_GET);
        return $this->container->get(LatteView::class)->render(
            $response,
            'Campus/campusTable.latte',
            ['query' => $sthResult
        ]);
    }

    public function updateForm (Request $request, Response $response) {

        return $this->container->get(LatteView::class)->render($response, 
            'Alumno/studentUpdate.latte');
    }

    public function update(Request $request, Response $response) {
        $data = $request->getParsedBody();
        $validationResult = $this->validator->validateUpdatePassword((array) $data);
        
        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->updatePassword((array) $data);
        } else {
            $sthResult = ['consulta' => false];
        }

        return $this->container->get(LatteView::class)->render(
            $response,
            'Alumno/studentValidation.latte', [
                'validation' => $validationResult, 
                'query' => $sthResult
            ]);
    }

    public function createCode (Request $request, Response $response) {
        return $this->container->get(LatteView::class)->render(
            $response,
            'Alumno/studentValidation.latte', [
                'validation' => $validationResult, 
                'query' => $sthResult
            ]);   
    }

    public function showQuiz (Request $request, Response $response) {
        return $this->container->get(LatteView::class)->render(
            $response,
            'Campus/campusTable.latte',
            ['course' => $_GET['id']
        ]);
    }

    public function saveQuiz (Request $request, Response $response) {
        //$this->coursesInfra->readAll($_GET['id']);
        return $this->container->get(LatteView::class)->render(
            $response,
            'Campus/campusTable.latte',
            );
    }

    
}