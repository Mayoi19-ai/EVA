<?php
// source: Docente/teacherUpdate.latte

use Latte\Runtime as LR;

class Templatea7dff85ea6 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		/* line 1 */
		$this->createTemplate('@layout-navbar.latte', $this->params, "include")->renderToContentType('html');
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 7 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>

</head>
<body>
<div class="container section">
<form name="teacherUpdateForm" method="post" action="<?php
		echo $router->relativeUrlFor("teacherUpdate");
?>">
<ul>
<li>
    <label><input type="hidden" id="folio_antiguo" name="folio_antiguo" value="<?php echo LR\Filters::escapeHtmlAttr($teacher_information['folio']) /* line 18 */ ?>" class="validate"></label>
  </li>
  <li>
    <label for="folio">Folio docente:</label>
    <label><input id="folio" name="folio" value="<?php echo LR\Filters::escapeHtmlAttr($teacher_information['folio']) /* line 22 */ ?>" class="validate"></label>
  </li>
  <li>
    <label for="clave">Nombre:</label>
    <label><input type="text" id="nombre" name="nombre" value="<?php echo LR\Filters::escapeHtmlAttr($teacher_information['nombre']) /* line 26 */ ?>" class="validate"></label>
  </li>
  <li>
    <label for="clave">Departamento:</label>
      <select name="clave_departamento">
      <option value="<?php echo LR\Filters::escapeHtmlAttr($teacher_information['clave_departamento']) /* line 31 */ ?>" name="clave_departamento"><?php
		echo LR\Filters::escapeHtmlText($teacher_information['nombre_departamento']) /* line 31 */ ?></option>
<?php
		$iterations = 0;
		foreach ($departments as $option) {
			?>      <option  value="<?php echo LR\Filters::escapeHtmlAttr($option['clave']) /* line 33 */ ?>" ><?php
			echo LR\Filters::escapeHtmlText($option['nombre']) /* line 33 */ ?></option>
<?php
			$iterations++;
		}
?>
    </select>
  </li>
 </ul>
<input type="submit" value="Registrar" name="registrar">
</div>
</form>




    <footer class="copyright"> 
        <p>Todos los derechos reservados, Gerardo y Raul 2020</p>
    </footer>
</body>
<script>M.AutoInit();</script>
</html><?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['option'])) trigger_error('Variable $option overwritten in foreach on line 32');
		
	}

}
