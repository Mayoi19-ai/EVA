<?php
// source: Docente/teacherTable.latte

use Latte\Runtime as LR;

class Template1f657a137b extends Latte\Runtime\Template
{
	public $blocks = [
		'content' => 'blockContent',
	];

	public $blockTypes = [
		'content' => 'html',
	];


	function main()
	{
		extract($this->params);
		/* line 1 */
		$this->createTemplate('@layout-navbar.latte', $this->params, "include")->renderToContentType('html');
?>

<?php
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('content', get_defined_vars());
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['teacherShow'])) trigger_error('Variable $teacherShow overwritten in foreach on line 37');
		
	}


	function blockContent($_args)
	{
		extract($_args);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 9 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
 <link type="text/css" rel="stylesheet" href="/materialize/css/style.css"  media="screen,projection">
</head>

<body>
 <div class="MiTabla">
 <div class="row">
<div class="input-field col s6">
<form action="<?php
		echo $router->relativeUrlFor("teacherSearch");
?>" method="get"> <!-- buscar -->
         <input type="text" name="nombre">
    <input type="submit" class="btn btn-primary btn-sm" value='Buscar'>
    </form>
    </div>
    </div>
<table name="showAllTeacher" method="get" class="bordered striped hoverable centered responsive-table"> <!-- nombre de tabla-->
<thead>
<tr>
<th>Folio de docente</th>
<th>Nombre de docente</th>
<th>Nombre de departamento</th>
<th></th>
<th></th>
</tr>
</thead>
<tbody>
<?php
		$iterations = 0;
		foreach ($query as $teacherShow) {
?>
<tr>
    <td><?php echo LR\Filters::escapeHtmlText($teacherShow['folio']) /* line 39 */ ?> </td>
    <td><?php echo LR\Filters::escapeHtmlText($teacherShow['nombre']) /* line 40 */ ?> </td>
    <td><?php echo LR\Filters::escapeHtmlText($teacherShow['departamento']) /* line 41 */ ?> </td>
    <td>
<form action="<?php
			echo $router->relativeUrlFor("teacherUpdateForm");
?>" method="post">
            <input type="hidden" name="folio" value="<?php echo LR\Filters::escapeHtmlAttr($teacherShow['folio']) /* line 44 */ ?>">
             <input type="hidden" name="nombre" value="<?php echo LR\Filters::escapeHtmlAttr($teacherShow['nombre']) /* line 45 */ ?>">
              <input type="hidden" name="clave_departamento" value="<?php echo LR\Filters::escapeHtmlAttr($teacherShow['clave']) /* line 46 */ ?>">
              <input type="hidden" name="nombre_departamento" value="<?php echo LR\Filters::escapeHtmlAttr($teacherShow['departamento']) /* line 47 */ ?>">
<input type="submit" class="btn btn-primary btn-sm" value='Editar'>
</form>
</td>
   <td>
    <form action="<?php
			echo $router->relativeUrlFor("teacherDelete");
?>" method="get">
            <input type="hidden" name="folio" value="<?php echo LR\Filters::escapeHtmlAttr($teacherShow['folio']) /* line 53 */ ?>">
    <input type="submit" style="background-color: #f44336" class="btn btn-primary btn-sm #f44336" value='Eliminar'>
    </form>
   </td>

</tr>
<?php
			$iterations++;
		}
?>
</tbody>
</table>
<div class="fixed-action-btn">
<a href="save-form" style="background-color: #4caf50" class="btn-floating btn-large #4caf50" ><i class="material-icons">add</i></a>
</div>
</div>
</body>
</html>
<?php
	}

}
