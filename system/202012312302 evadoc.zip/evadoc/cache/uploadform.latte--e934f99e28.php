<?php
// source: Archivos\uploadform.latte

use Latte\Runtime as LR;

class Templatee934f99e28 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 5 */ ?></title>
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
        <link type="text/css" rel="stylesheet" href="/materialize/css/style.css"  media="screen,projection">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
        <script> M.AutoInit(); </script> 

        

</head>
<body>


<form action="<?php
		echo $router->relativeUrlFor("menuAdmin");
?>" method="post" enctype="multipart/form-data">
<input type="file" name="archivo">
<br><br>
<input type="submit">



</body>
</html><?php
		return get_defined_vars();
	}

}
