<?php
namespace App\Validator;
use Rakit\Validation\Validator;

class CampusValidator{
    private Validator $validator;

    public function __construct(Validator $validator) {
        $this->validator = $validator;
    }

    public function validateSaveCampus(array $data, array &$resultData): array {
        $validationRules = [
            'name'          =>  'required|alpha|alpha_spaces|uppercase',
        ];
    
        $errorMessages = [
            'name:required'     => 'El nombre es obligatorio',
            'name:alpha'        => 'El nombre no válido',
            //'name:uppercase'    => 'El nombre debe de estar en mayúsculas',
            //'name:alpha_spaces' => 'El nombre no acepta caracteres especiales',
        ];
    
        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data, $resultData);
    }
}