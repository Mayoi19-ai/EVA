<?php
namespace App\Controller\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use Ujpef\LatteView;
use Slim\Exception\HttpForbiddenException;
use Medoo\medoo;
use App\Validator\CampusValidator as Validator;
use App\Database\CampusInfrastructure;

class CampusController{
    private $container;
    private $medoo;
    private $validator;

    public function __construct(Container $container, Medoo $medoo, Validator $validator){
        $this->container = $container;
        $this->medoo = $medoo;
        $this->validator = $validator;
    }

    public function saveForm(Request $request, Response $response, array $args){
        // Simula que la lógica de negocios valida el id
        $id = (int) $args['id'];
        if($id > 5) {
            throw new HttpForbiddenException($request);
        }
        return $this->container->get(LatteView::class)->render($response, 'Campus/campus.latte', [
            'id' => $id,
        ]);
    }

    public function register(Request $request, Response $response, array $args){
        $resultData = [];
        
        $data = (array)$request->getParsedBody();
        $validationResult =  $this->validator->validateSaveCampus($data, $resultData);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Campus/campusvalidation.latte',
            ['validacion_exitosa' => $validationResult, 'result' => $resultData]
        );
    }

    public function searchForm(Request $request, Response $response, array $args){
        // Simula que la lógica de negocios valida el id
        $id = (int) $args['id'];
        if($id > 5) {
            throw new HttpForbiddenException($request);
        }
        return $this->container->get(LatteView::class)->render($response, 'Campus/campus.latte', [
            'id' => $id,
        ]);
    }

    public function search(Request $request, Response $response, array $args){
        $resultData = [];
        
        $data = array("name" => $args['name']);
        
        $campusVal = $this->container->get(CampusValidator::class);
        
        $validationResult = $campusVal->ValidateSearch($data, $resultData);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Campus/campusvalidation.latte',
            ['validacion_exitosa' => $validationResult] + $resultData
        );
    }

    public function show(Request $request, Response $response, array $args){
        $campusInfrastructure = $this->container->get(CampusInfrastructure::class);
        $dataCampuses = $campusInfrastructure->selectShowAllCampuses();
        
        return $this->container->get(LatteView::class)->render(
            $response,
            'Campus/campusTable.latte',
            ['all_campuses_information' => $dataCampuses]
        );
    }

    public function update(Request $request, Response $response, array $args){
        $resultData = [];
        
        $data = (array)$request->getParsedBody();
        $campusVal = $this->container->get(CampusValidator::class);
        
        $validationResult = $campusVal->ValidateUpdate($data, $resultData);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Campus/campusvalidation.latte',
            ['validacion_exitosa' => $validationResult] + $resultData
        );
    }

    public function delete(Request $request, Response $response, array $args){
        $code = $args['code'];
        $response->getBody()->write("$code");
        return $response;
    }
}