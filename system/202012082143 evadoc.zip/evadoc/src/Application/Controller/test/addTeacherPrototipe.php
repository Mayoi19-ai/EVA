<?php
namespace App\Controller\Teacher;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use Ujpef\LatteView;

class addTeacher{
    private Container $container;
    private string $mensaje = 'Hola mundo feliz!';

    public function __construct(Container $container){
        $this->container = $container; 
    }

    public function register(Request $request, Response $response, array $params){
        return $this->container->get(LatteView::class)->render($response, 'saludar.latte', [
            'variable' => 123,
            'name'     => $params['name'],
        ]);
    }
}