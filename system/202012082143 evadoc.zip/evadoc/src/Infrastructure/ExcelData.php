<?php
namespace App\Infrastructure;

use Port\Spreadsheet\SpreadsheetReader;
use Medoo\Medoo;

class ExcelData {
    private Medoo $db;

    public function __construct(Medoo $db) {
        $this->db = $db;
    }

    public function import() {
        $file = new \SplFileObject(__DIR__.'/../../public/dbfFiles/dret3.xlsx');
        $groups = new SpreadsheetReader($file);

        foreach ($groups as $record) {

            $sie = $record[0];
            $noSie = $record[1];
            echo "<br>";
            echo "$sie, $noSie";
            echo "<br>";

            $this->db->insert("nosie", [
                "clave" => $sie, 
                "nombre" => $noSie
            ]);
        }
    }
}