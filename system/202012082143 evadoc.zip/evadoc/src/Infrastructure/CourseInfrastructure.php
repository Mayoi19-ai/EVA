<?php
namespace App\Infrastructure;

use Medoo\Medoo;
use Psr\Container\ContainerInterface;

class CourseInfrastructure{
    private Medoo $db;
    private ContainerInterface $container;

    public function __construct(Medoo $db, ContainerInterface $container) {
        $this->db = $db;
        $this->container = $container;
    }

    public function insertCourse(array $courseData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $course = $databaseInfra['course'];

        $data = $this->db->insert($course['table'],[
            $course['groupName'] => $groupName, 
            $course['periodId'] => $periodId, 
            $course['careerId'] => $careerId, 
            $course['lessonCode'] => $lessonCode, 
            $course['teacherCode'] => $teacherCode]
        );

        return $data;
    }

    public function selectShowAllCourses(): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $course = $databaseInfra['course'];

        $data = $this->db->select($course['table'],[
            $course['groupName'], 
            $course['periodId'], 
            $course['careerId'], 
            $course['lessonCode'], 
            $course['teacherCode']]
        );

        return $data;
    }

    public function selectOneCourse(array $courseData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $course = $databaseInfra['course'];

        $data = $this->db->select($course['table'],[
            $course['groupName'], 
            $course['periodId'], 
            $course['careerId'], 
            $course['lessonCode'], 
            $course['teacherCode']], [
                $course['teacherCode'] => $teacherCode]
            );

        return $data;
    }

    public function updateCourse(array $courseData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $course = $databaseInfra['course'];

        $data = $this->db->update($course['table'],[
            $course['groupName'] => $groupName, 
            $course['periodId'] => $periodId, 
            $course['careerId'] => $careerId, 
            $course['lessonCode'] => $lessonCode, 
            $course['teacherCode'] => $teacherCode], [
                $course['id'] => $courseId]
            );

        return $data;
    }
    
    public function deleteCourse(array $courseData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $course = $databaseInfra['course'];

        $data = $this->db->delete($course['table'], [
            $course['id'] => $courseId]
        );
        
        return $data;
    }
}