<?php
namespace App\Infrastructure;

use Medoo\Medoo;
use Psr\Container\ContainerInterface;

class InscriptionInfrastructure{
    private Medoo $db;
    private ContainerInterface $container;

    public function __construct(Medoo $db, ContainerInterface $container) {
        $this->db = $db;
        $this->container = $container;
    }

    public function insertInscription(array $inscriptionData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $inscription = $databaseInfra['inscription'];

        $data = $this->db->insert($inscription['table'],[
            $inscription['courseId'] => $courseId, 
            $inscription['studentCode'] => $studentCode]
        );

        return $data;
    }

    public function selectShowAllInscriptions(): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $inscription = $databaseInfra['inscription'];

        $data = $this->db->select($inscription['table'],[
            $inscription['courseId'], 
            $inscription['studentCode']]
        );

        return $data;
    }

    public function selectOneInscription(array $inscriptionData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $inscription = $databaseInfra['inscription'];

        $data = $this->db->select($inscription['table'], [
            $inscription['courseId'], 
            $inscription['studentCode']], [
                $inscription['studentCode'] => $studentCode]
            );

        return $data;
    }

    public function updateInscription(array $inscriptionData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $inscription = $databaseInfra['inscription'];

        $data = $this->db->update($inscription['table'], [
            $inscription['courseId'], 
            $inscription['studentCode']], [
                "AND" => [
                    $inscription['studentCode'] => $studentCode,
                    $inscription['courseId'] => $courseId]]
            );

        return $data;
    }
    
    public function deleteInscription(array $inscriptionData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $inscription = $databaseInfra['inscription'];

        $data = $this->db->delete($inscription['table'], [
            "AND" => [
                $inscription['studentCode'] => $studentCode,
                $inscription['courseId'] => $courseId]]
        );
        
        return $data;
    }
}