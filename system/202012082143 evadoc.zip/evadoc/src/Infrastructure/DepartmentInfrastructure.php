<?php
namespace App\Infrastructure;

use Medoo\Medoo;
use Psr\Container\ContainerInterface;

class DepartmentInfrastructure{
    private Medoo $db;
    private ContainerInterface $container;

    public function __construct(Medoo $db, ContainerInterface $container) {
        $this->db = $db;
        $this->container = $container;
    }

    public function insertDepartment(array $departmentData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $department = $databaseInfra['department'];

        $data = $this->db->insert($department['table'],[
            $department['code'] => $code, 
            $department['name'] => $name]
        );
        
        return $data;
    }

    public function selectShowAllDepartments(): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $department = $databaseInfra['department'];

        $data = $this->db->select($department['table'],[
            $department['code'], 
            $department['name']]
        );

        return $data;
    }

    public function selectOneDepartment(array $departmentData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $department = $databaseInfra['department'];

        $data = $this->db->select($department['table'],[
            $department['code'], 
            $department['name']], [
                $department['name'] => $name]
            );

        return $data;
    }

    public function updateDepartment(array $departmentData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $department = $databaseInfra['department'];

        $data = $this->db->update($department['table'],[
            $department['code'] => $code, 
            $department['name'] => $name], [
                $department['code'] => $code]
        );

        return $data;
    }
    
    public function deleteDepartment(array $departmentData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $department = $databaseInfra['department'];

        $data = $this->db->delete($department['table'], [
            $department['code'] => $code]
        );
        
        return $data;
    }
}