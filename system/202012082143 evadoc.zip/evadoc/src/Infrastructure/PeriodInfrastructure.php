<?php
namespace App\Infrastructure;

use Medoo\Medoo;
use Psr\Container\ContainerInterface;

class PeriodInfrastructure{
    private Medoo $db;
    private ContainerInterface $container;

    public function __construct(Medoo $db, ContainerInterface $container) {
        $this->db = $db;
        $this->container = $container;
    }

    public function insertPeriod(array $periodData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $period = $databaseInfra['period'];

        $data = $this->db->insert($period['table'],[
            $period['name'] => $periodName, 
            $period['start'] => $periodStart, 
            $period['finish'] => $periodFinish]
        );

        return $data;
    }

    public function selectShowAllPeriods(): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $period = $databaseInfra['period'];

        $data = $this->db->select($period['table'],[
            $period['name'],
            $period['start'],
            $period['finish']]
        );

        return $data;
    }

    public function selectOnePeriod(array $periodData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $period = $databaseInfra['period'];

        $data = $this->db->select($period['table'],[
            $period['name'],
            $period['start'],
            $period['finish']], [
                $period['name'] => $periodName]
            );

        return $data;
    }

    public function updatePeriod(array $periodData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $period = $databaseInfra['period'];

        $data = $this->db->update($period['table'],[
            $period['name'] => $periodName, 
            $period['start'] => $periodStart, 
            $period['finish'] => $periodFinish],[
                $period['id'] => $periodId]
            );

        return $data;
    }
    
    public function deletePeriod(array $periodData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $period = $databaseInfra['period'];

        $data = $this->db->delete($period['table'], [
            $period['id'] => $periodId]
        );
        
        return $data;
    }
}