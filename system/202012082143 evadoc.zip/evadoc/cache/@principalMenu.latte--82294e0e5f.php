<?php
// source: Menu\@principalMenu.latte

use Latte\Runtime as LR;

class Template82294e0e5f extends Latte\Runtime\Template
{
	public $blocks = [
		'content' => 'blockContent',
	];

	public $blockTypes = [
		'content' => 'html',
	];


	function main()
	{
		extract($this->params);
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('content', get_defined_vars());
		return get_defined_vars();
	}


	function blockContent($_args)
	{
		extract($_args);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 6 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
     
</head>
<body>
<nav>  
  <ul id="slide-out" class="sidenav">
    <li><div class="user-view">
      <div class="background">
      </div>
    <img src="\materialize\Recursos\itshlogo.png">
    </div></li>
<!--Menu desplegable-->
        <ul class="collapsible collapsible-accordion">
          <li>
            <a class="collapsible-header">Alumno</a>
            <div class="collapsible-body">
              <ul>
                <li><a href="/panel/student/show/1">Buscar</a></li>
                <li><a href="/panel/student/save-form/1">Registrar</a></li>
                <li><a href="#!">Eliminar</a></li>
              </ul>
            </div>
           </li>
         <li> 
        </ul>
       </li>
     </ul>

          <!--Opction menu -->
          <ul class="right hide-on-med-and-down">
      <li><a href="#!">First Sidebar Link</a></li>
      <li><a href="#!">Second Sidebar Link</a></li>
      <li><a class="dropdown-trigger" href="#!" data-target="dropdown1">Dropdown<i class="material-icons right">arrow_drop_down</i></a></li>
      <ul id='dropdown1' class='dropdown-content'>
        <li><a href="#!">First</a></li>
        <li><a href="#!">Second</a></li>
        <li><a href="#!">Third</a></li>
        <li><a href="#!">Fourth</a></li>
      </ul>
    </ul>
    <a href="#" data-target="slide-out" class="sidenav-trigger"><i class="material-icons">menu</i></a>
          
            
  </nav>
    
    

    <a href="#" data-target="slide-out" class="sidenav-trigger"><i class="material-icons">menu</i></a>

<!--Fin menu desplegable -->
        
    <footer class="copyright"> 
    <script>
      M.AutoInit();
      </script>
        <p>Todos los derechos reservados, Gerardo y Raul 2020</p>
    </footer>
</body>
</html>
<?php
	}

}
