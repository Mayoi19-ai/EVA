<?php
// source: Asignatura/lesson.latte

use Latte\Runtime as LR;

class Template860c207470 extends Latte\Runtime\Template
{
	public $blocks = [
		'content' => 'blockContent',
	];

	public $blockTypes = [
		'content' => 'html',
	];


	function main()
	{
		extract($this->params);
?>

<?php
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('content', get_defined_vars());
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		$this->parentName = 'lessonform.latte';
		
	}


	function blockContent($_args)
	{
?><p>Este es el saludo probiene de lesson.latte.</p>
<?php
	}

}
