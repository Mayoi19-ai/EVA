<?php declare(strict_types=1);

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Log\LoggerInterface;
use Slim\App;
use Ujpef\LatteView;
use Slim\Routing\RouteCollectorProxy;

//use App\Controller\Presentation\presentationController;
//use App\Controller\Saludos;

use App\Controller\Controllers\MenuController;
use App\Controller\Controllers\TeacherController;
use App\Controller\Controllers\CampusController;
use App\Controller\Controllers\ModalityController;
use App\Controller\Controllers\PeriodController;
use App\Controller\Controllers\CareerController;
use App\Controller\Controllers\LessonController;
use App\Controller\Controllers\DepartmentController;
use App\Controller\Controllers\StudentController;
use App\Controller\Controllers\InscriptionController;
use App\Controller\Controllers\SchoolSubjectController;
use App\Controller\Controllers\CourseController;
use App\Controller\Controllers\GroupController;
use App\Controller\Controllers\QuestionnaireController;
use App\Controller\Controllers\ImportDbfDataController;
use App\Controller\Controllers\PruebaController;
use App\Controller\Access\UserController;
use App\Controller\Access\RoleController;
use App\Controller\Access\UserRolesController;
use App\Controller\Access\RolePermissionsController;

return function(App $app): void
{
    $app->get('/test', ImportDbfDataController::class . ':importAll')->setName('test');
    $app->group('/panel', function (RouteCollectorProxy $group) {
        
        $group->get('/questionnaire', QuestionnaireController::class . ':getAll')->setName('getQuestionnaire');

        $group->get('/menu', MenuController::class . ':menu')->setName('menuAdmin');
        $group->get('/prueba', PruebaController::class . ':prueba')->setName('PruebasGera');

        $group->group('/teacher', function (RouteCollectorProxy $group) {
            $group->get('/save-form', TeacherController::class . ':saveForm')->setName('teacherSaveForm');
            $group->post('/register', TeacherController::class . ':register')->setName('teacherRegister');

            $group->get('/search', TeacherController::class . ':search')->setName('teacherSearch');
            $group->get('/order-department', TeacherController::class . ':orderByDepartment')->setName('teacherOrderByDepartment');

            $group->get('/show', TeacherController::class . ':show')->setName('showAllTeachers');
            $group->post('/update-form', TeacherController::class . ':updateForm')->setName('teacherUpdateForm');
            $group->post('/update', TeacherController::class . ':update')->setName('teacherUpdate');
            $group->get('/delete', TeacherController::class . ':delete')->setName('teacherDelete');
        });

        $group->group('/campus', function (RouteCollectorProxy $group) {
            $group->get('/save-form', CampusController::class . ':saveForm')->setName('campusSaveForm');
            $group->post('/register', CampusController::class . ':register')->setName('campusRegister');

            $group->get('/show', CampusController::class . ':show')->setName('showAllCampuses');
            $group->post('/update-form', CampusController::class . ':updateForm')->setName('campusUpdateForm');
            $group->post('/update', CampusController::class . ':update')->setName('campusUpdate');
            $group->get('/delete', CampusController::class . ':delete')->setName('campusDelete');
        });

        $group->group('/modality', function (RouteCollectorProxy $group) {
            $group->get('/save-form', ModalityController::class . ':saveForm')->setName('modalitySaveForm');
            $group->post('/register', ModalityController::class . ':register')->setName('modalityRegister');

            $group->get('/show', ModalityController::class . ':show')->setName('showAllModalities');
            $group->post('/update', ModalityController::class . ':update')->setName('modalityUpdate');
            $group->get('/delete', ModalityController::class . ':delete')->setName('modalityDelete');
        });

        $group->group('/period', function (RouteCollectorProxy $group) {
            $group->get('/save-form', PeriodController::class . ':saveForm')->setName('periodSaveForm');
            $group->post('/register', PeriodController::class . ':register')->setName('periodRegister');

            $group->get('/show', PeriodController::class . ':show')->setName('showAllPeriods');
            $group->post('/update-form', PeriodController::class . ':updateForm')->setName('periodUpdateForm');
            $group->post('/update', PeriodController::class . ':update')->setName('periodUpdate');
            $group->get('/delete', PeriodController::class . ':delete')->setName('periodDelete');
        });

        $group->group('/career', function (RouteCollectorProxy $group) {
            $group->get('/save-form', CareerController::class . ':saveForm')->setName('careerSaveForm');
            $group->post('/register', CareerController::class . ':register')->setName('careerRegister');

            $group->get('/show', CareerController::class . ':show')->setName('showAllCareers');
            $group->post('/update-form', CareerController::class . ':updateForm')->setName('careerUpdateForm');
            $group->post('/update', CareerController::class . ':update')->setName('careerUpdate');
            $group->get('/delete', CareerController::class . ':delete')->setName('careerDelete');
        });

        $group->group('/lesson', function (RouteCollectorProxy $group) {
            $group->get('/save-form', LessonController::class . ':saveForm')->setName('lessonSaveForm');
            $group->post('/register', LessonController::class . ':register')->setName('lessonRegister');

            $group->get('/search', LessonController::class . ':search')->setName('lessonSearch');

            $group->get('/show', LessonController::class . ':show')->setName('showAllLessons');
            $group->post('/update-form', LessonController::class . ':updateForm')->setName('lessonUpdateForm');
            $group->post('/update', LessonController::class . ':update')->setName('lessonUpdate');
            $group->get('/delete', LessonController::class . ':delete')->setName('lessonDelete');
        });

        $group->group('/department', function (RouteCollectorProxy $group) {
            $group->get('/save-form',  DepartmentController::class . ':saveForm')->setName('departmentSaveForm');
            $group->post('/register', DepartmentController::class . ':register')->setName('departmentRegister');

            $group->get('/show',  DepartmentController::class . ':show')->setName('showAllDepartments');
            $group->post('/update-form',  DepartmentController::class . ':updateForm')->setName('departmentUpdateForm');
            $group->post('/update',  DepartmentController::class . ':update')->setName('departmentUpdate');
            $group->get('/delete', DepartmentController::class . ':delete')->setName('departmentDelete');
        });

        $group->group('/student', function (RouteCollectorProxy $group) {
            $group->get('/save-form',  StudentController::class . ':saveForm')->setName('studentSaveForm');
            $group->post('/register', StudentController::class . ':register')->setName('studentRegister');
            
            $group->get('/search', StudentController::class . ':search')->setName('studentSearch');

            $group->get('/show',  StudentController::class . ':show')->setName('showAllStudents');
            
            $group->post('/update-form',  StudentController::class . ':updateForm')->setName('studentUpdateForm');
            $group->post('/update', StudentController::class . ':update')->setName('studentUpdate');
            $group->get('/delete', StudentController::class . ':delete')->setName('studentDelete');
        });

        $group->group('/inscriptions', function (RouteCollectorProxy $group) {
            $group->get('/save-form', InscriptionController::class . ':saveForm')->setName('inscriptionSaveForm');
            $group->post('/register', InscriptionController::class . ':register')->setName('inscriptionRegister');

            $group->get('/search-student', CourseController::class . ':searchByStudent')->setName('inscriptionSearchByStudent');

            $group->get('/show-career', InscriptionController::class . ':showByCareer')->setName('showAInscriptionsByCareer');
            $group->get('/update-career', InscriptionController::class . ':updateByCareer')->setName('inscriptionUpdateByCareer');

            $group->get('/show-group', InscriptionController::class . ':showByGroup')->setName('showAInscriptionsByGroup');
            $group->get('/update-group', InscriptionController::class . ':updateByGroup')->setName('inscriptionUpdateByGroup');
            
            $group->get('/show', InscriptionController::class . ':show')->setName('showAllInscriptions');
            $group->post('/update-form', InscriptionController::class . ':updateForm')->setName('inscriptionUpdateForm');
            $group->get('/update', InscriptionController::class . ':update')->setName('inscriptionUpdate');
            $group->get('/delete', InscriptionController::class . ':delete')->setName('inscriptionDelete');
        });

        
        $group->group('/subject', function (RouteCollectorProxy $group) {
            $group->get('/save-form', SchoolSubjectController::class . ':saveForm')->setName('subjectSaveForm');
            $group->post('/register', SchoolSubjectController::class . ':register')->setName('subjectRegister');

            $group->get('/order-career', SchoolSubjectController::class . ':orderByCareer')->setName('subjectOrderByCareer');
            $group->get('/search-lesson', SchoolSubjectController::class . ':searchByLesson')->setName('subjectSearchByLesson');

            $group->get('/show', SchoolSubjectController::class . ':show')->setName('showAllSubjects');
            $group->post('/update-form', SchoolSubjectController::class . ':updateForm')->setName('updateForm');
            $group->post('/update', SchoolSubjectController::class . ':update')->setName('subjectUpdate');
            $group->get('/delete', SchoolSubjectController::class . ':delete')->setName('subjectDelete');
        });

        $group->group('/course', function (RouteCollectorProxy $group) {
            $group->get('/save-form', CourseController::class . ':saveForm')->setName('courseSaveForm');
            $group->post('/register', CourseController::class . ':register')->setName('courseRegister');

            $group->get('/search-group', CourseController::class . ':searchByGroup')->setName('courseSearchByGroup');
            $group->get('/search-lesson', CourseController::class . ':searchByLesson')->setName('courseSearchByLesson');

            $group->get('/show', CourseController::class . ':show')->setName('showAllCourses');
            $group->post('/update-form', CourseController::class . ':updateForm')->setName('courseUpdateForm');
            $group->post('/update', CourseController::class . ':update')->setName('courseUpdate');
            $group->post('/delete', CourseController::class . ':delete')->setName('courseDelete');
        });

        $group->group('/group', function (RouteCollectorProxy $group) {
            $group->get('/save-form', GroupController::class . ':saveForm')->setName('groupSaveForm');
            $group->post('/register', GroupController::class . ':register')->setName('groupRegister');
            
            $group->get('/search', GroupController::class . ':search')->setName('groupSearch');

            $group->get('/show', GroupController::class . ':show')->setName('showAllGroups');
            $group->post('/update-form', GroupController::class . ':updateForm')->setName('groupUpdateForm');
            $group->post('/update', GroupController::class . ':update')->setName('groupUpdate');
            $group->get('/delete', GroupController::class . ':delete')->setName('groupDelete');
        });

        $group->group('/user', function (RouteCollectorProxy $group) {
            $group->get('/save-form', UserController::class . ':saveForm')->setName('userSaveForm');
            $group->post('/register', UserController::class . ':register')->setName('userRegister');

            $group->get('/show', UserController::class . ':show')->setName('showAllUsers');
            $group->post('/update-form', UserController::class . ':updateForm')->setName('userUpdateForm');
            $group->post('/update', UserController::class . ':update')->setName('userUpdate');
            $group->get('/delete', UserController::class . ':delete')->setName('userDelete');
        });

        $group->group('/role', function (RouteCollectorProxy $group) {
            $group->get('/save-form', RoleController::class . ':saveForm')->setName('roleSaveForm');
            $group->post('/register', RoleController::class . ':register')->setName('roleRegister');

            $group->get('/show', RoleController::class . ':show')->setName('showAllroles');
            $group->post('/update-form', RoleController::class . ':updateForm')->setName('roleUpdateForm');
            $group->post('/update', RoleController::class . ':update')->setName('roleUpdate');
            $group->get('/delete', RoleController::class . ':delete')->setName('roleDelete');
        });

        $group->group('/user-roles', function (RouteCollectorProxy $group) {
            $group->get('/save-form', UserRolesController::class . ':saveForm')->setName('userRolesSaveForm');
            $group->post('/register', UserRolesController::class . ':register')->setName('userRolesRegister');

            $group->get('/search-user', UserRolesController::class . ':searchByUser')->setName('userRolesSearchByUser');

            $group->get('/show', UserRolesController::class . ':show')->setName('showAllUserRoles');
            $group->post('/update-form', UserRolesController::class . ':updateForm')->setName('userRolesUpdateForm');
            $group->post('/update', UserRolesController::class . ':update')->setName('userRolesUpdate');
            $group->get('/delete', UserRolesController::class . ':delete')->setName('userRolesDelete');
        });

        $group->group('/role-permissions', function (RouteCollectorProxy $group) {
            $group->get('/save-form', RolePermissionsController::class . ':saveForm')->setName('rolePermissionsSaveForm');
            $group->post('/register', RolePermissionsController::class . ':register')->setName('rolePermissionsRegister');

            $group->get('/search-role', RolePermissionsController::class . ':showByRole')->setName('rolePermissionsSearchByUser');

            $group->get('/show', RolePermissionsController::class . ':show')->setName('showAllRolePermissions');
            $group->post('/update-form', RolePermissionsController::class . ':updateForm')->setName('rolePermissionsUpdateForm');
            $group->post('/update', RolePermissionsController::class . ':update')->setName('rolePermissionsUpdate');
            $group->get('/delete', RolePermissionsController::class . ':delete')->setName('rolePermissionsDelete');
        });
    });
};