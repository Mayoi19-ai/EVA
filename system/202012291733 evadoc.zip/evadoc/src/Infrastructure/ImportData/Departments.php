<?php

namespace App\Infrastructure\ImportData;

use Medoo\Medoo;

class Departments {
    private Medoo $db;
    public function __construct(Medoo $db){
        $this->db = $db;
    }

    public function departments()
    {
        $sql = <<<'EOP'
        INSERT IGNORE INTO departamento
        SELECT temp_ddep.cve, temp_ddep.nom 
        FROM temp_ddep;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->execute();
    }
}