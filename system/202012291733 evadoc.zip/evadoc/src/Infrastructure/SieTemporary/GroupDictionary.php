<?php
namespace App\Infrastructure\SieTemporary;

use Port\Spreadsheet\SpreadsheetReader;
use Medoo\Medoo;

class GroupDictionary {
    private Medoo $db;

    public function __construct(Medoo $db) {
        $this->db = $db;
    }

    public function loadGroupDictionary (string $xlsxFileGroup): ?array
    {
        $create = $this->createDictionary((string) $xlsxFileGroup);
        if(!empty($create[1])){
            $result = ['flag' => true, 
                        'error' => 'No se pudo crear diccionario Grupo'];
            return $result;
        }

        return null;
    }

    private function createDictionary(string $xlsxFileGroup): array 
    {
        $sql = <<<'EOD'
            DROP TABLE IF EXISTS `temp_grupo`;
            CREATE TEMPORARY TABLE IF NOT EXISTS `temp_grupo` (
                `cve`    CHAR(6) NOT NULL,
                `nombre` CHAR(6) NOT NULL,
                PRIMARY KEY (`cve`),
                UNIQUE INDEX `nombre_cve_UNIQUE` (`cve` ASC, `nombre` ASC)
            );
            EOD;
        
        $this->db->query($sql);

        $file = new \SplFileObject($xlsxFileGroup);
        $groups = new SpreadsheetReader($file);
        $i = 2; // Rows to ignore.
        foreach ($groups as $record) {
            if($i++ > 3) {
                $this->db->insert("temp_grupo", [
                    "cve"    => $record[1], 
                    "nombre" => $record[0],
                ]);
            }
        }
        return $this->db->error();
    }
}