<?php
namespace App\Validator;
use Rakit\Validation\Validator;

class RoleValidator{
    private Validator $validator;

    public function __construct(Validator $validator) {
        $this->validator = $validator;
    }

    public function validateSaveRole(array $data): array {
        $validationRules = [
            'nombre'           =>  'required|alpha_spaces|between:9,240',
        ];

        $errorMessages = [
            'nombre:required'            => 'El nombre es obligatorio',
            'nombre:alpha_spaces'        => 'El nombre no acepta números ni caracteres especiales',
            'nombre:between'             => 'El nombre debe tener al menos 9 caracteres',
        ];

        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data);
    }
}