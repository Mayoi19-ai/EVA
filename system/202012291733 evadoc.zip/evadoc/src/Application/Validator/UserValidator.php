<?php
namespace App\Validator;
use Rakit\Validation\Validator;

class UserValidator{
    private Validator $validator;

    public function __construct(Validator $validator) {
        $this->validator = $validator;
    }

    public function validateSaveUser(array $data): array {
        $validationRules = [
            'nombre'           =>  'required|alpha_spaces|between:9,240',
            'contrasenia'      =>  'required|between:8,12',
            'contrasenia_same' =>  'required|same:contrasenia',
        ];

        $errorMessages = [
            'nombre:required'            => 'El nombre es obligatorio',
            'nombre:alpha_spaces'        => 'El nombre no acepta números ni caracteres especiales',
            'nombre:between'             => 'El nombre debe tener al menos 9 caracteres',
            'contrasenia:required'       => 'La clave de acceso es obligatoria',
            'contrasenia:between'        => 'La clave de acceso debe tener de 8 a 12 caracteres',
            'contrasenia_same:required'  => 'La verificación de clave de acceso es obligatoria',
            'contrasenia_same:between'   => 'La clave de acceso no coincide',
        ];

        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data);
    }

    public function validateFindUser(array $data): array {
        $validationRules = [
            'nombre'           =>  'required|alpha_spaces|between:3,240',
        ];

        $errorMessages = [
            'nombre:required'            => 'El nombre es obligatorio',
            'nombre:alpha_spaces'        => 'El nombre no acepta números ni caracteres especiales',
            'nombre:between'             => 'El nombre debe tener al menos 3 caracteres',
        ];

        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data);
    }
}