<?php
// source: Carrera/careerTable.latte

use Latte\Runtime as LR;

class Template5a5f82e976 extends Latte\Runtime\Template
{
	public $blocks = [
		'content' => 'blockContent',
	];

	public $blockTypes = [
		'content' => 'html',
	];


	function main()
	{
		extract($this->params);
		/* line 1 */
		$this->createTemplate('@layout-navbar.latte', $this->params, "include")->renderToContentType('html');
?>

<?php
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('content', get_defined_vars());
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['careerShow'])) trigger_error('Variable $careerShow overwritten in foreach on line 30');
		
	}


	function blockContent($_args)
	{
		extract($_args);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 9 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
        <link type="text/css" rel="stylesheet" href="/materialize/css/style.css"  media="screen,projection">

</head>

<body>
<div class="MiTabla">
<table name="showAllPeriods" method="get" class="bordered striped hoverable centered responsive-table">
<thead>
<tr>
<th>Clave de carrera</th>
<th>Nombre</th>
<th>Nombre corto</th>
<th></th>
<th></th>
</tr>
</thead>
<tbody>
<?php
		$iterations = 0;
		foreach ($all_careers_information as $careerShow) {
?>
<tr>
    <td><?php echo LR\Filters::escapeHtmlText($careerShow['clave']) /* line 32 */ ?> </td>
    <td><?php echo LR\Filters::escapeHtmlText($careerShow['nombre']) /* line 33 */ ?> </td>
    <td><?php echo LR\Filters::escapeHtmlText($careerShow['nombre_corto']) /* line 34 */ ?> </td>
    <td>
<form action="<?php
			echo $router->relativeUrlFor("careerUpdateForm");
?>" method="post">
            <input type="hidden" name="id" value="<?php echo LR\Filters::escapeHtmlAttr($careerShow['id']) /* line 37 */ ?>">
             <input type="hidden" name="clave" value="<?php echo LR\Filters::escapeHtmlAttr($careerShow['clave']) /* line 38 */ ?>">
            <input type="hidden" name="nombre" value="<?php echo LR\Filters::escapeHtmlAttr($careerShow['nombre']) /* line 39 */ ?>">
            <input type="hidden" name="nombre_corto" value="<?php echo LR\Filters::escapeHtmlAttr($careerShow['nombre_corto']) /* line 40 */ ?>">
<input type="submit" class="btn btn-primary btn-sm #f44336" value='Editar'>
</form>
</td>
   <td>
    <form action="<?php
			echo $router->relativeUrlFor("careerDelete");
?>" method="get">
            <input type="hidden" name="id" value="<?php echo LR\Filters::escapeHtmlAttr($careerShow['id']) /* line 46 */ ?>">
    <input type="submit" style="background-color: #f44336" class="btn btn-primary btn-sm" value='Eliminar'>
    </form>
   </td>

</tr>
<?php
			$iterations++;
		}
?>
</tbody>
</table>
<div class="fixed-action-btn">
<a href="save-form" style="background-color: #4caf50" class="btn-floating btn-large #4caf50" ><i class="material-icons">add</i></a>
</div>
</div>
</body>
</html>
<?php
	}

}
