<?php
// source: Campus/campusform.latte

use Latte\Runtime as LR;

class Template0725c86829 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 6 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
       <link type="text/css" rel="stylesheet" href="/materialize/css/style.css"  media="screen,projection">
</head>
<body>
  

<div>
  <form name="campusSaveForm" method="post" action="<?php
		echo $router->relativeUrlFor("campusRegister");
?>"> 
  
  <!-- Datos del formulario -->

  <div class="container section">
         <label for="name">Nombre:</label>
    <input type="text" id="nombre" name="nombre" class="validate">
  <!-- Botón de envío de formulario -->
  
  <input type="submit" class="btn btn-primary btn-sm" value="Enviar formulario">

</form>
 </div>

    <footer class="copyright"> 
        <p>Todos los derechos reservados, Gerardo y Raul 2020</p>
        
        
    </footer>
</body>
</html><?php
		return get_defined_vars();
	}

}
