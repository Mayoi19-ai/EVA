<?php
// source: Archivos/uploadfiles.latte

use Latte\Runtime as LR;

class Templateb2e2b73f59 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>

<?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		$this->parentName = 'uploadform.latte';
		
	}

}
