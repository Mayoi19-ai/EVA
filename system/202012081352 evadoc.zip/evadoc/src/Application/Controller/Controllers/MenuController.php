<?php
namespace App\Controller\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use Ujpef\LatteView;
use Slim\Exception\HttpForbiddenException;

class MenuController{
    private Container $container;
    public function __construct(Container $container){
        $this->container = $container;
    }

    public function menu(Request $request, Response $response, array $args){
        // Simula que la lógica de negocios valida el id
        $id = (int) $args['id'];
        if($id > 5) {
            throw new HttpForbiddenException($request);
        }

        $latte = $this->container->get(LatteView::class)->render($response, 'Menu/principalMenu.latte', [
            'id' => $id,
        ]);

        return  $latte;
    }
}