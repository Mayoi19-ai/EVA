<?php
namespace App\Validator;
use Rakit\Validation\Validator;

class CareerValidator{
    private Validator $validator;

    public function __construct(Validator $validator) {
        $this->validator = $validator;
    }

    public function validateSaveCareer(array $data, array &$resultData): bool {
        $validationRules = [
            'code'          =>  'required|alpha_dash|uppercase|between:13,13',
            'name'          =>  'required|alpha|alpha_spaces',
            'shortName'     =>  'required|alpha|between:5,5',
        ];
    
        $errorMessages = [
            'code:required'       => 'La clave es obligatoria',
            'code:uppercase'      => 'La clave debe estar en mayúsculas',
            'code:between'        => 'La clave debe tener 13 caracteres',
            'name:required'       => 'El nombre es obligatorio',
            'name:alpha'          => 'El nombre no es válido',
            'shortName:required'  => 'El nombre es obligatorio',
            'shortName:alpha'     => 'El nombre no es válido',
            'shortName:between'   => 'El nombre debe tener 5 caracteres',
        ];
    
        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data, $resultData);
    }

    public function validateFindCareer(array $data, array &$resultData): bool {
        $validationRules = [
            'code'          =>  'required|alpha_dash|uppercase|between:13,13',
        ];
    
        $errorMessages = [
            'code:required'       => 'La clave es obligatoria',
            'code:uppercase'      => 'La clave debe estar en mayúsculas',
            'code:between'        => 'La clave debe tener 13 caracteres',
        ];
    
        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data, $resultData);
    }
}