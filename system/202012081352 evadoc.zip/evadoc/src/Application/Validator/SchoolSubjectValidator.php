<?php
namespace App\Validator;
use Rakit\Validation\Validator;

class SchoolSubjectValidator{
    private Validator $validator;

    public function __construct(Validator $validator) {
        $this->validator = $validator;
    }

    public function validateSaveSubject(array $data, array &$resultData): bool {
        $validatorRules = [
            'codeCareer'          =>  'required|alpha_dash|uppercase|between:13,13',
            'codeLesson'          =>  'required|alpha_dash|uppercase|between:8,8',
        ];

        $errorMessages = [
            'codeCareer:required'      => 'La clave de carrera es obligatoria',
            'codeCareer:uppercase'     => 'La clave de carrera debe estar con números y letras en mayúsculas',
            'codeCareer:between'       => 'La clave de carrera debe tener 13 caracteres',
            'codeLesson:required'      => 'La clave de asignatura es obligatoria',
            'codeLesson:alpha_dash'    => 'La clave de asignatura no acepta espacios o caracteres especiales',
            'codeLesson:uppercase'     => 'La clave de asignatura debe de estar en mayúsculas',
            'codeLesson:between'       => 'La clave de asignatura debe tener 8 caracteres',
        ];

        $validator = new CustomValidator($this->validator, $validatorRules, $errorMessages);
        return $validator->validate($data, $resultData);
    }

    public function validateFindSubject(array $data, array &$resultData): bool {
        $validatorRules = [
            'codeCareer'          =>  'required|alpha_dash|uppercase|between:13,13',
        ];

        $errorMessages = [
            'codeCareer:required'      => 'La clave de carrera es obligatoria',
            'codeCareer:uppercase'     => 'La clave de carrera debe estar con números y letras en mayúsculas',
            'codeCareer:between'       => 'La clave de carrera debe tener 13 caracteres',
        ];

        $validator = new CustomValidator($this->validator, $validatorRules, $errorMessages);
        return $validator->validate($data, $resultData);
    }
}