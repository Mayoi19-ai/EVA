<?php declare(strict_types=1);

use DI\ContainerBuilder;

return function(ContainerBuilder $containerBuilder): void
{
    $containerBuilder->addDefinitions([
        'databaseTables'    =>  [
            'student'   =>  [
                'table'         =>  'alumno',
                'code'          =>  'control',
                'name'          =>  'nombre',
                'password'      =>  'contrasenia',
            ],
            'lesson'        =>  [
                'table'         =>  'asignatura',
                'lessonCode'    =>  'clave',
                'lessonName'    =>  'nombre',
            ],
            'campus'            =>  [
                'table'         =>  'campus',
                'id'            =>  'id',
                'name'          =>  'nombre',
                'test'          =>  'pruebas',   
            ],
            'career'        =>  [
                'table'         =>  'carrera',
                'id'            =>  'id',
                'code'          =>  'clave',
                'name'          =>  'nombre',
                'shortName'     =>  'nombre_corto',
            ],
            'course'        =>  [
                'table'         =>  'curso',
                'id'            =>  'id',
                'groupName'     =>  'nombre_grupo',
                'periodId'      =>  'id_periodo',
                'careerId'      =>  'id_carrera',
                'lessonCode'    =>  'clave_asignatura',
                'teacherCode'   =>  'folio_docente',
            ],
            'department'    =>  [
                'table'         =>  'departamento',
                'code'          =>  'clave',
                'name'          =>  'nombre',
            ],
            'teacher'       =>  [
                'table'         =>  'docente',
                'code'          =>  'folio',
                'name'          =>  'nombre',
                'departmentCode'    =>  'clave_departamento',
            ],
            'evaluate'      =>  [
                'id'            =>  'id',
            ],
            'group'         =>  [
                'name'          =>  'nombre',
                'periodId'      =>  'id_periodo',
                'careerId'      =>  'id_carrera',
                'modalityId'    =>  'id_modalidad',
                'campusId'      =>  'id_campus',
            ],
            'inscription'   =>  [
                'id'            =>  'id',
                'courseId'      =>  'id_curso',
                'studentCode'   => 'alumno_control',
            ],
            'schoolSubject' =>  [
                'careerId'      =>  'id_carrera',
                'lessonCode'    =>  'clave_asignature',
            ],
            'modality'      =>  [
                'id'            =>  'id',
                'name'          =>  'nombre',
            ],
            'period'        =>  [
                'id'            =>  'id',
                'name'          =>  'nombre',
                'start'         =>  'inicia',
                'finish'        =>  'termina',
            ],
        ],
    ]);
};