<?php

namespace App\Infrastructure;

use org\majkel\dbase\Table;
use Port\Spreadsheet\SpreadsheetReader;
use Medoo\Medoo;

class DbfImport {
    private Medoo $db;

    public function __construct(Medoo $db) {
        $this->db = $db;
    }
    
    
    public function loadAssignmentsDictionary(string $dbfFileName) {

        $records = Table::fromFile($dbfFileName);
        foreach ($records as $record) {
            $hypen = substr($record['SIEVISUAL'], 6, 1);
            if($hypen === '-') {
                $row = [
                    'id_carrera'       => (int)substr($record['SIEVISUAL'], 0, 2),
                    'clave_asignatura' => substr($record['SIEVISUAL'], 3, 8),
                ];
    
                $a = $record['SIEDOS'];
    
                printf("ID Carrera: %s, Clave asignatura: '%s'<br>\n", $row['id_carrera'], $row['clave_asignatura']);
            }
        }

    }
    
    
    public function loadGroupsDictionary(string $xslxFilename) {
        $sql = <<<'EOD'
            DROP TABLE IF EXISTS `temp_grupo`;
            CREATE TEMPORARY TABLE `temp_grupo` (
                `cve`    CHAR(6) CHARACTER SET 'utf8mb4' NOT NULL,
                `nombre` CHAR(6) CHARACTER SET 'utf8mb4' NOT NULL,
                PRIMARY KEY (`cve`),
                UNIQUE INDEX `nombre_cve_UNIQUE` (`cve` ASC, `nombre` ASC)
            );
            EOD;
        
        $this->db->query($sql);
        
        $file = new \SplFileObject($xslxFilename);
        $groups = new SpreadsheetReader($file);
        $i = 2; // Rows to ignore.
        foreach ($groups as $record) {
            if($i++ > 0) {
                $this->db->insert("temp_grupo", [
                    "cve"    => $record[0], 
                    "nombre" => $record[1],
                ]);
            }
        }
    }

    public function importData () {

        $dbfFileName = __DIR__ . '/../../public/dbfFiles/dret2.DBF';
        $this->loadAssignmentsDictionary($dbfFileName);



        die();

            $this->db->query("CREATE TEMPORARY TABLE IF NOT EXISTS `desp` (
              `cve` INT(3) UNSIGNED NOT NULL,
              `nom` VARCHAR(250) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_spanish_ci' NOT NULL,
              `nco` VARCHAR(45) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_spanish_ci' NOT NULL,
              PRIMARY KEY (`cve`))
            ENGINE = InnoDB
            DEFAULT CHARACTER SET = utf8mb4
            COLLATE = utf8mb4_spanish_ci;");

            $despPath = Table::fromFile(__DIR__.'/../../public/dbfFiles/desp.DBF');

            foreach ($despPath as $record) {
                $esp_cve = $record['ESP_CVE'];
                $esp_nom = $record['ESP_NOM'];
                $esp_nco = $record['ESP_NCO'];
    
                $this->db->insert("desp", [
                    "cve" => $esp_cve, 
                    "nom" => $esp_nom,
                    "nco" => $esp_nom
                ]);
            }

            $this->db->query("CREATE TEMPORARY TABLE IF NOT EXISTS `ddep` (
                `cve` INT(3) UNSIGNED NOT NULL,
                `nom` VARCHAR(250) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_spanish_ci' NOT NULL,
                `nco` VARCHAR(50) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_spanish_ci' NOT NULL,
                PRIMARY KEY (`cve`))
              ENGINE = InnoDB
              DEFAULT CHARACTER SET = utf8mb4
              COLLATE = utf8mb4_spanish_ci;");

            $ddepPath = Table::fromFile(__DIR__.'/../../public/dbfFiles/ddep.DBF');

            foreach ($ddepPath as $record) {
                $dep_cve = $record['DEP_CVE'];
                $dep_nom = $record['DEP_NOM'];
                $dep_nco = $record['DEP_NCO'];

                $this->db->insert("ddep", [
                    "cve" => $dep_cve, 
                    "nom" => $dep_nom,
                    "nco" => $dep_nco
                ]);
            }

            $this->db->query("CREATE TEMPORARY TABLE IF NOT EXISTS `dret` (
                `cve` CHAR(4) NOT NULL,
                `nom` VARCHAR(250) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_spanish_ci' NOT NULL,
                `nco` VARCHAR(50) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_spanish_ci' NOT NULL,
                PRIMARY KEY (`cve`))
              ENGINE = InnoDB
              DEFAULT CHARACTER SET = utf8mb4
              COLLATE = utf8mb4_spanish_ci;");

            $dretPath = Table::fromFile(__DIR__.'/../../public/dbfFiles/dret.DBF');

            foreach ($dretPath as $record) {
                $ret_cve = $record['RET_CVE'];
                $ret_nom = $record['RET_NOM'];
                $ret_nco = $record['RET_NCO'];

                $this->db->insert("dret", [
                    "cve" => $ret_cve, 
                    "nom" => $ret_nom,
                    "nco" => $ret_nco
                ]);
            }

            $xlsxFileName = __DIR__.'/../../public/dbfFiles/grupos.xlsx';
            $this->loadGroupsDictionary($xlsxFileName);
    }
}

        //$dretPath = Table::fromFile(__DIR__.'/../../public/dbfFiles/dret.DBF');
        //$dcatPath = Table::fromFile(__DIR__.'/../../public/dbfFiles/dcat.DBF');
        //$daluPath = Table::fromFile(__DIR__.'/../../public/dbfFiles/dalu.DBF');
        //$dgauPath = Table::fromFile(__DIR__.'/../../public/dbfFiles/dgau.DBF');
        //$dlisPath = Table::fromFile(__DIR__.'/../../public/dbfFiles/dlis.DBF');