<?php
namespace App\Infrastructure;

use Medoo\Medoo;

class TamporaryTables {
    private Medoo $db;

    public function __construct(Medoo $db) {
        $this->db = $db;
    }

    public function desp() {
        $this->db->query("CREATE TEMPORARY TABLE IF NOT EXISTS `test_temporal`.`desp` (
          `cve` INT(3) UNSIGNED NOT NULL,
          `nom` VARCHAR(250) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_spanish_ci' NOT NULL,
          `nco` VARCHAR(45) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_spanish_ci' NOT NULL,
          PRIMARY KEY (`cve`))
        ENGINE = InnoDB
        DEFAULT CHARACTER SET = utf8mb4
        COLLATE = utf8mb4_spanish_ci;");
    }

    public function ddep() {
        $this->db->query("CREATE TEMPORARY TABLE IF NOT EXISTS `test_temporal`.`ddep` (
          `cve` INT(3) UNSIGNED NOT NULL,
          `nom` VARCHAR(250) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_spanish_ci' NOT NULL,
          `nco` VARCHAR(50) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_spanish_ci' NOT NULL,
          PRIMARY KEY (`cve`))
        ENGINE = InnoDB
        DEFAULT CHARACTER SET = utf8mb4
        COLLATE = utf8mb4_spanish_ci;");
    }

    public function dret () {
        $this->db->query("CREATE TEMPORARY TABLE IF NOT EXISTS `test_temporal`.`dret` (
          `cve` CHAR(4) NOT NULL,
          `nom` VARCHAR(250) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_spanish_ci' NOT NULL,
          `nco` VARCHAR(50) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_spanish_ci' NOT NULL,
          PRIMARY KEY (`cve`))
        ENGINE = InnoDB
        DEFAULT CHARACTER SET = utf8mb4
        COLLATE = utf8mb4_spanish_ci;
        ");
    }

    public function grop () {
        $this->db->query("CREATE TEMPORARY TABLE IF NOT EXISTS `test_temporal`.`grup` (
          `cve` CHAR(4) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_spanish_ci' NOT NULL,
          `nombre` CHAR(5) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_spanish_ci' NOT NULL,
          PRIMARY KEY (`cve`),
          UNIQUE INDEX `nombre_UNIQUE` (`nombre` ASC),
          UNIQUE INDEX `cve_UNIQUE` (`cve` ASC))
        ENGINE = InnoDB;");
    }

    public function dcat () {
        $this->db->query("CREATE TEMPORARY TABLE IF NOT EXISTS `test_temporal`.`dret` (
          `cve` CHAR(4) NOT NULL,
          `nom` VARCHAR(250) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_spanish_ci' NOT NULL,
          `nco` VARCHAR(50) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_spanish_ci' NOT NULL,
          PRIMARY KEY (`cve`))
        ENGINE = InnoDB
        DEFAULT CHARACTER SET = utf8mb4
        COLLATE = utf8mb4_spanish_ci;");
    }

    public function dalu () {
        $this->db->query("CREATE TEMPORARY TABLE IF NOT EXISTS `test_temporal`.`dalu` (
          `ctr` CHAR(8) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_spanish_ci' NOT NULL,
          `nom` VARCHAR(250) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_spanish_ci' NOT NULL,
          `esp` INT(10) NOT NULL,
          `sem` TINYINT(12) UNSIGNED NOT NULL,
          PRIMARY KEY (`ctr`))
        ENGINE = InnoDB
        DEFAULT CHARACTER SET = utf8mb4
        COLLATE = utf8mb4_spanish_ci;");
    }

    public function dgau () {
        $this->db->query("CREATE TEMPORARY TABLE IF NOT EXISTS `test_temporal`.`dgau` (
          `gpo` CHAR(4) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_spanish_ci' NOT NULL,
          `cat` INT(3) NOT NULL,
          `mat` CHAR(4) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_spanish_ci' NOT NULL,
          UNIQUE INDEX `gpo_UNIQUE` USING BTREE (`gpo`, `mat`),
          INDEX `FK_dgau_grupo_idx` (`gpo` ASC))
        ENGINE = InnoDB
        DEFAULT CHARACTER SET = utf8mb4
        COLLATE = utf8mb4_spanish_ci;");
    }

    public function dlis () {
        $this->db->query("CREATE TEMPORARY TABLE IF NOT EXISTS `test_temporal`.`dlis` (
          `ctr` CHAR(8) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_spanish_ci' NOT NULL,
          `gpo` CHAR(4) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_spanish_ci' NOT NULL,
          `mat` CHAR(4) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_spanish_ci' NOT NULL)
        ENGINE = InnoDB
        DEFAULT CHARACTER SET = utf8mb4
        COLLATE = utf8mb4_spanish_ci;");
    }
}