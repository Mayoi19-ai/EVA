<?php declare(strict_types=1);
require __DIR__ . '/../vendor/autoload.php';

use DI\ContainerBuilder;
use Psr\Log\LoggerInterface;
use Slim\App;
use Slim\Factory\AppFactory;

// Instantiate PHP-DI ContainerBuilder
$containerBuilder = new ContainerBuilder();

// Set up settings
$settings = require __DIR__ . '/../config/settings.php';
$settings($containerBuilder);

// Set up dependencies
$dependencies = require __DIR__ . '/../config/dependencies.php';
$dependencies($containerBuilder);

// Build PHP-DI Container instance
$container = $containerBuilder->build();

// Load template engine
//$container->get('\Template');

// Instantiate the app
AppFactory::setContainer($container);
$app = AppFactory::create();
$app->setBasePath($container->get('settings')['basePath']);
$container->set(App::class, $app);

// Register middleware
$middleware = require __DIR__ . '/../config/middleware.php';
$middleware($app);

// Register routes
$routes = require __DIR__ . '/../config/routes.php';
$routes($app);

// Add Routing Middleware
$app->addRoutingMiddleware();

// Add Error Middleware
$errorSettings = $container->get('settings')['error'];
$app->addErrorMiddleware(
    $errorSettings['displayDetails'],
    $errorSettings['log'],
    $errorSettings['logDetails'],
    $container->get(LoggerInterface::class)
);

// Run App
$app->run();
