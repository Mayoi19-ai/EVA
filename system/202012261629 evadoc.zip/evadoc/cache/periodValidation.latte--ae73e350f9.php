<?php
// source: Periodo/periodValidation.latte

use Latte\Runtime as LR;

class Templateae73e350f9 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		return get_defined_vars();
	}

}
