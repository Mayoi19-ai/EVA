<?php
// source: Archivos/prueba.php

use Latte\Runtime as LR;

class Templated8d4bb0c70 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		
		
		$nombres=$_FILES['archivo']['name'];
		$guardado=$_FILES['archivos']['tmp_name'];

		if(!file_exists('archivos')){
			mkdir('archivos',0777,true);
			if(file_exists('archivos')){
				if(move_uploaded_file($guardado, 'Archivos/' .$nombre)){
					echo "Archivo guardado con exito";
				}else{
					echo "Archivo no se pudo guardar";

				}
			}
		}else{
			if(move_uploaded_file($guardado, 'Archivos/' .$nombre)){
				echo "Archivo guardado con exito";

			}else{
				echo "Archivo no se pudo guardar";
			}
		}
		return get_defined_vars();
	}

}
