<?php
// source: Alumno/studentValidation.latte

use Latte\Runtime as LR;

class Template99b046382d extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		return get_defined_vars();
	}

}
