<?php
// source: Alumnos\studentform.latte

use Latte\Runtime as LR;

class Template0700ff5b33 extends Latte\Runtime\Template
{
	public $blocks = [
		'content' => 'blockContent',
	];

	public $blockTypes = [
		'content' => 'html',
	];


	function main()
	{
		extract($this->params);
		?><<?php
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('content', get_defined_vars());
		?>  <?php
		return get_defined_vars();
	}


	function blockContent($_args)
	{
		extract($_args);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 6 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
</head>
<body>
  
  <form name="studentSaveForm" method="post" action="<?php
		echo $router->relativeUrlFor("studentRegister", ['id' => $id]);
?>">
  <!-- Datos del formulario -->
<div class="container setcion">
<div class="row">
    <form class="col s12">
      <div class="row">
        <div class="input-field col s6">
          <input  id="control" type="text" class="validate">
          <label for="first_name">Numero de control</label>
        </div>
        <div class="input-field col s6">
          <input id="name" type="text" class="validate">
          <label for="last_name">Nombre</label>
        </div>
      </div>
      <div class="row">
        <div class="input-field col s12">
          <input  id="password" type="text" class="validate">
          <label for="disabled">Contraseña</label>
        </div>
      </div>
  </div>
  

  <!-- Botón de envío de formulario -->
  
  <input type="submit" value="Enviar formulario">
</form>
</div>
 

    <footer class="copyright"> 
        <p>Todos los derechos reservados, Gerardo y Raul 2020</p>
    </footer>
</body>
</html>
<?php
	}

}
