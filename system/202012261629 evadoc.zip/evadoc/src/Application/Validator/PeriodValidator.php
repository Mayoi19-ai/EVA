<?php
namespace App\Validator;
use Rakit\Validation\Validator;

class PeriodValidator{
    private Validator $validator;

    public function __construct(Validator $validator) {
        $this->validator = $validator;
    }

    public function validateSavePeriod(array $data): array {
        $validationRules = [
            'nombre'           =>  'required',
            'inicia'           =>  'required|date:Y-m-d',
            'termina'          =>  'date:Y-m-d',
        ];

        $errorMessages = [
            'nombre:required'    => 'El nombre es obligatorio',
            'inicia:required'    => 'La fecha de inicio es obligatoria',
            'inicia:date'        => 'El formato de fecha inicio no es válido',
            'termina:date'       => 'El formato de fecha fin no es válido',
        ];

        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data);
    }
}