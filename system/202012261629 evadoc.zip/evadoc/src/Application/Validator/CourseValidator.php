<?php
namespace App\Validator;
use Rakit\Validation\Validator;

class CourseValidator{
    private Validator $validator;

    public function __construct(Validator $validator) {
        $this->validator = $validator;
    }

    public function validateSaveCourse(array $data): bool {
        $validationRules = [
            'grupo'               =>  'required|alpha_dash|between:4,4',
            'id_periodo'          =>  'required|numeric|digits_between:1,10',
            'id_carrera'          =>  'required|numeric|digits_between:1,10',
            'clave_asignatura'    =>  'required|alpha_dash|between:8,8',
            'folio_docente'       =>  'required|numeric|digits_between:1,3',
        ];

        $errorMessages = [
            'nombre:required'              => 'El nombre es obligatorio',
            'nombre:alpha_dash'            => 'El nombre no acepta espacios ni caracteres especiales',
            'nombre:between'               => 'El nombre debe tener 5 caracteres',
            'id_periodo:required'          => 'La clave del periodo es obligatoria',
            'id_periodo:numeric'           => 'La clave del periodo es numerica',
            'id_periodo:digits_between'    => 'La clave del periodo debe tener entre 1 a 10 caracteres',
            'id_carrera:required'          => 'La clave es obligatoria',
            'id_carrera:numeric'           => 'La clave de carrera es numerica',
            'id_carrera:between'           => 'La clave de carrera debe tener entre 1 a 10 caracteres',
            'clave_asignatura:required'    => 'La clave de asignatura es obligatoria',
            'clave_asignatura:alpha_dash'  => 'La clave de asignatura no acepta espacios o caracteres especiales',
            'clave_asignatura:between'     => 'La clave de asignatura debe tener 8 caracteres',
            'folio_docente:required'       =>  'El folio del docente es obligatorio',
            'folio_docente:digits_between' =>  'El folio del docente debe tener 1 a 3 digitos',
            'folio_docente:numeric'        =>  'El folio del docente solo acepta números',
        ];

        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data);
    }
}