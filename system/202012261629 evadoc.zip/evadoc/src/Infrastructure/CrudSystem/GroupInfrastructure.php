<?php
namespace App\Infrastructure\CrudSystem;

use Medoo\Medoo;
use App\Infrastructure\CrudSystem\CustomException as Exception;

class GroupInfrastructure{
    private Medoo $db;
    private Exception $exception;

    public function __construct(Medoo $db, Exception $exception) {
        $this->db = $db;
        $this->exception = $exception;
    }

    public function create(array $data): array
    {
        $this->db->pdo->beginTransaction();
        $this->db->insert('grupo', [
            'nombre' => strtoupper($data['grupo']),
            'id_periodo' => $data['id_periodo'],
            'id_carrera' => $data['id_carrera'],
            'id_modalidad' => $data['id_modalidad'],
            'id_campus' => $data['id_campus']
        ]);

        $result = $this->exception->saveError((array) $this->db->error());
        return $result;
    }

    public function readAll(int $periodId): array
    {
        $sql = <<<'EOP'
        SELECT grupo.nombre AS 'grupo',
        carrera.nombre_corto AS 'carrera',
        grupo.id_carrera AS 'id_carrera',
        modalidad.nombre AS 'modalidad',    
        grupo.id_modalidad AS 'id_modalidad',
        campus.nombre AS 'campus',
        grupo.id_campus AS 'id_campus'
        FROM 
        grupo,
        carrera,
        modalidad,
        campus
        WHERE
        grupo.id_carrera = carrera.id 
        AND 
        grupo.id_modalidad = modalidad.id
        AND 
        grupo.id_periodo = :id_periodo
        AND 
        grupo.id_campus = campus.id;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':id_periodo', $periodId);
        $sth->execute();
        $records = $sth->fetchAll();
        
        $result = $this->exception->readError((array) $this->db->error(), (array) $records);
        return $result;
    }

    public function readAuxiliary(int $periodId): array
    {
        $sql = <<<'EOP'
        SELECT grupo.nombre AS 'grupo',
        carrera.nombre_corto AS 'carrera',
        grupo.id_carrera AS 'id_carrera'
        FROM 
        grupo,
        carrera
        WHERE
        grupo.id_carrera = carrera.id 
        AND 
        grupo.id_modalidad = modalidad.id
        AND 
        grupo.id_periodo = :id_periodo
        AND 
        grupo.id_campus = campus.id;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':id_periodo', $periodId);
        $sth->execute();
        $records = $sth->fetchAll();
        
        $result = $this->exception->readError((array) $this->db->error(), (array) $records);
        return $result;
    }

    public function read(int $periodId, string $group): array
    {
        $sql = <<<'EOP'
        SELECT grupo.nombre AS 'grupo',
        carrera.nombre_corto AS 'carrera',
        grupo.id_carrera AS 'id_carrera',
        modalidad.nombre AS 'modalidad',    
        grupo.id_modalidad AS 'id_modalidad',
        campus.nombre AS 'campus',
        grupo.id_campus AS 'id_campus'
        FROM 
        grupo,
        carrera,
        modalidad,
        campus
        WHERE
        grupo.id_carrera = carrera.id 
        AND 
        grupo.id_modalidad = modalidad.id
        AND 
        grupo.id_campus = campus.id
        AND 
        grupo.id_periodo = :id_periodo
        AND 
        grupo.nombre LIKE '%' :grupo '%';
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':id_periodo', $periodId);
        $sth->bindParam(':grupo', strtoupper($group));
        $sth->execute();
        $records = $sth->fetchAll();

        $result = $this->exception->readError((array) $this->db->error(), (array) $records);
        return $result;
    }

    public function update(array $data): array
    {
        $this->db->pdo->beginTransaction();
        $this->db->update('grupo', [
            'nombre' => strtoupper($data['nombre']),
            'id_carrera' => $data['id_carrera'],
            'id_modalidad' => $data['id_modalidad'],
            'id_campus' => $data['id_campus']], [
                'AND' => [
                    'nombre' => $data['nombre_antiguo'],
                    'id_periodo' => $data['id_periodo'],
                    'id_carrera' => $data['id_carrera_antiguo'],
                    'id_modalidad' => $data['id_modalidad_antiguo'],
                    'id_campus' => $data['id_campus_antiguo']
                ]
        ]);
            
        $result = $this->exception->saveError((array) $this->db->error());
        return $result;
    }
    
    public function delete(array $data): array
    {
        $this->db->pdo->beginTransaction();
        $this->db->delete('grupo', [
            'AND' => [
                'nombre' => $data['nombre'],
                'id_periodo' => $data['id_periodo'],
                'id_carrera' => $data['id_carrera'],
                'id_modalidad' => $data['id_modalidad'],
                'id_campus' => $data['id_campus']
            ]
        ]);

        $result = $this->exception->deleteError((array) $this->db->error());
        return $result;
    }
}