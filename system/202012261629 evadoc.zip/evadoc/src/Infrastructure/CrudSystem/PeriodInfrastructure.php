<?php
namespace App\Infrastructure\CrudSystem;

use Medoo\Medoo;
use App\Infrastructure\CrudSystem\CustomException as Exception;

class PeriodInfrastructure{
    private Medoo $db;
    private Exception $exception;

    public function __construct(Medoo $db, Exception $exception) {
        $this->db = $db;
        $this->exception = $exception;
    }

    public function create(array $data): array
    {
        $this->db->pdo->beginTransaction();
        $this->db->insert('periodo',[
            'nombre' => strtoupper($data['nombre']), 
            'inicia' => $data['inicia'], 
            'termina' => $data['termina']
        ]);
        
        $result = $this->exception->saveError((array) $this->db->error());
        return $result;
    }

    public function readAll(): array
    {
        $sql = $this->db->select('periodo',[
            'id',
            'nombre',
            'inicia',
            'termina'
        ]);
        
        $result = $this->exception->readError((array) $this->db->error(), (array) $sql);
        return $result;
    }

    //in reparation
    public function readActivedPeriod(): array
    {
        $sql = $this->sb->select('periodo', [
            'id'], [
                'activo' => 1
        ]);

        return $sql;
    }

    public function update(array $data): array
    {
        $this->db->pdo->beginTransaction();

        $this->db->update('periodo',[
            'nombre'  => strtoupper($data['nombre']), 
            'inicia'  => $data['inicia'], 
            'termina' => $data['termina']], [
            'id'      => $data['id']
        ]);

        $result = $this->exception->saveError((array) $this->db->error());
        return $result;
    }
    
    public function delete(int $id): array
    {
        $this->db->pdo->beginTransaction();
        $this->db->delete('periodo', [
            'id' => $id
        ]);
        
        $result = $this->exception->deleteError((array) $this->db->error());
        return $result;
    }
}