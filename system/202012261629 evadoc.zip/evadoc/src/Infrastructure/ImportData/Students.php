<?php

namespace App\Infrastructure\ImportData;

use Medoo\Medoo;

class Students {
    private Medoo $db;
    public function __construct(Medoo $db){
        $this->db = $db;
    }

    public function students ()
    {
        //Execution time 5min
        set_time_limit(300);

        $students = $this->db->select('temp_dalu', [
            'temp_dalu.ctr', 
            'temp_dalu.nom'
        ]);

        $sql = <<<'EOP'
        INSERT IGNORE INTO alumno (control, nombre, contrasenia)
        VALUES (:control, :nombre, :contrasenia);
        EOP;

        foreach ($students as $record) {
            $password = password_hash($record['ctr'], PASSWORD_BCRYPT);
            $sth = $this->db->pdo->prepare($sql);
            $sth->bindParam(':control', $record['ctr']);
            $sth->bindParam(':nombre', $record['nom']);
            $sth->bindParam(':contrasenia', $password);
            $sth->execute();
        }
    }
}