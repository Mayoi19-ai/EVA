<?php
// source: PruebasGera/prueba.latte

use Latte\Runtime as LR;

class Template7c6ff2bee4 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		return get_defined_vars();
	}

}
