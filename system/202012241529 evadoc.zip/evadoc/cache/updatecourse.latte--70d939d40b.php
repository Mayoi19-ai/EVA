<?php
// source: Curso/updatecourse.latte

use Latte\Runtime as LR;

class Template70d939d40b extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 5 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
       <script>  $id = $_POST['id']; $nombre = $_POST['nombre'];  </script>
<?php
		$id = $campus_data['id'];
?>
       
</head>
<body>
<form name="updateCampus" method="post" action="<?php
		echo $router->relativeUrlFor("campusUpdate", ['id' => $id]);
?>">
<ul>
<li>
    <label><input type="hidden" id="Curso id" name="Curso id" value="<?php echo LR\Filters::escapeHtmlAttr($campus_data['Curso id']) /* line 17 */ ?>" class="validate"></label>
  </li>
  <li>
    <label for="name">Grupo:</label>
    <input type="text" id="Grupo" name="Grupo" value="<?php echo LR\Filters::escapeHtmlAttr($courseShow['Grupo']) /* line 21 */ ?>" class="validate">
<select>
      <option id="Grupo" name="Grupo" value="<?php echo LR\Filters::escapeHtmlAttr($courseShow['Grupo']) /* line 23 */ ?>" class="validate"></option>
<?php
		$iterations = 0;
		foreach ($course_data as $grupoOption) {
			?>      <option value="<?php echo LR\Filters::escapeHtmlAttr($grupoOption['Grupo']) /* line 25 */ ?>">Option 1</option>
      
<?php
			$iterations++;
		}
?>
    </select>

  </li>
 </ul>
<input type="submit" value="Registrar" name="registrar">
</form>




    <footer class="copyright"> 
        <p>Todos los derechos reservados, Gerardo y Raul 2020</p>
    </footer>
</body>
</html><?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['grupoOption'])) trigger_error('Variable $grupoOption overwritten in foreach on line 24');
		
	}

}
