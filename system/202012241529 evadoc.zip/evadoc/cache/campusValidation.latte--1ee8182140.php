<?php
// source: Campus/campusValidation.latte

use Latte\Runtime as LR;

class Template1ee8182140 extends Latte\Runtime\Template
{
	public $blocks = [
		'content' => 'blockContent',
	];

	public $blockTypes = [
		'content' => 'html',
	];


	function main()
	{
		extract($this->params);
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('content', get_defined_vars());
		return get_defined_vars();
	}


	function blockContent($_args)
	{
		extract($_args);
		?>¿Fué la validación exitosa? <?php echo LR\Filters::escapeHtmlText($validation?'Si':'No') /* line 2 */ ?>

<br>


<table>
    <tbody>
        <tr>
            <td>ID:</td>
            <td><?php echo LR\Filters::escapeHtmlText($id) /* line 10 */ ?></td>
        </tr>
        <tr>
           
             <td>Nombre:</td>
            <td><?php echo LR\Filters::escapeHtmlText($nombre) /* line 15 */ ?></td>
        </tr>
    </tbody>
</table>
<?php
	}

}
