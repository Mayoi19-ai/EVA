<?php declare(strict_types=1);
namespace App\Middleware;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Server\MiddlewareInterface as Middleware;
use Psr\Http\Server\RequestHandlerInterface as RequestHandler;
use Slim\Routing\RouteContext;
use Psr\Http\Message\ResponseFactoryInterface;

class SessionMiddleware implements Middleware
{
    private $responseFactory;

    public function __construct(ResponseFactoryInterface $responseFactory)
    {
        $this->responseFactory = $responseFactory;
    }

    public function process(Request $request, RequestHandler $handler): Response
    {
        $routeContext = RouteContext::fromRequest($request);
        $route = $routeContext->getRoute();
        // return NotFound for non existent route
        //if (empty($route)) {
        //}

        $name = $route->getName();
        $groups = $route->getGroups();
        $methods = $route->getMethods();
        $arguments = $route->getArguments();
        /*if(isset($_SERVER['HTTP_AUTHORIZATION'])) {
            session_start();
            $request = $request->withAttribute('session', $_SESSION);
        }*/

        $routeParser = RouteContext::fromRequest($request)->getRouteParser();
        $ur = $routeParser->urlFor('test');
        //print_r($ur);
        //echo('<br>');
        //print_r("Hello world"."  ".$name);
        //return $handler->handle($request);


        $response = $this->responseFactory->createResponse();
        $response = $response->withStatus(302)->withHeader('Location', $ur);
        return $response;
    }

}