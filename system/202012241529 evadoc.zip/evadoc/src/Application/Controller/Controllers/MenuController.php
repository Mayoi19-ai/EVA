<?php
namespace App\Controller\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use Ujpef\LatteView;
use Slim\Exception\HttpForbiddenException;
use App\Domain\DbfImport;

class MenuController{
    private Container $container;

    public function __construct(Container $container){
        $this->container = $container;
    }

    public function menu(Request $request, Response $response, array $args){
        return $this->container->get(LatteView::class)->render($response, 'Menu/layout.latte', [
        ]);
    }
}