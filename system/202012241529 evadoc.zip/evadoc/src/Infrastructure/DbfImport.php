<?php
namespace App\Infrastructure;
use App\Infrastructure\importData\GroupDictionary as Group;
use App\Infrastructure\importData\SieCourse as Course;
use App\Infrastructure\importData\SieDepartment as Department;
use App\Infrastructure\importData\SieInscription as Inscription;
use App\Infrastructure\importData\SieSpecialty as Specialty;
use App\Infrastructure\importData\SieStudent as Student;
use App\Infrastructure\importData\SieSubject as Subject;
use App\Infrastructure\importData\SieTeacher as Teacher;
use App\Infrastructure\importData\SpecialtyDictionary;
use App\Infrastructure\importData\SubjectDictionary;
use App\Infrastructure\importData\SqlQueries;

class DbfImport {
    private Group $group;
    private Course $course;
    private Department $department;
    private Inscription $inscription;
    private Specialty $specialty;
    private Student $student;
    private Subject $subject;
    private Teacher $teacher;
    private SpecialtyDictionary $specialtyDictionary;
    private SubjectDictionary $subjecDictionary;
    private SqlQueries $sqlQueries;

    public function __construct(Group $group, Course $course, Department $department, Inscription $inscription, Specialty $specialty, Student $student, Subject $subject, Teacher $teacher,  SpecialtyDictionary $specialtyDictionary, SubjectDictionary $subjecDictionary, SqlQueries $sqlQueries) {
        $this->group = $group;
        $this->course = $course;
        $this->department = $department;
        $this->inscription = $inscription;
        $this->specialty = $specialty;
        $this->student = $student;
        $this->subject = $subject;
        $this->teacher = $teacher;
        $this->specialtyDictionary = $specialtyDictionary;
        $this->subjecDictionary = $subjecDictionary;
        $this->sqlQueries = $sqlQueries;
    }

    public function importData () {
        
        $xlsxFileGroup = __DIR__.'/../../public/dbfFiles/Grupos.xlsx';
        $this->group->loadGroupDictionary($xlsxFileGroup);

        $dbfFileDictionarySubject = __DIR__ . '/../../public/dbfFiles/dret2.DBF';
        $this->subjecDictionary->loadSubjectDictionary($dbfFileDictionarySubject);

        $dbfFileSpecialty = __DIR__.'/../../public/dbfFiles/desp.DBF';
        $this->specialty->loadSieSpecialty($dbfFileSpecialty);

        $dbfFileDepartment = __DIR__.'/../../public/dbfFiles/ddep.DBF';
        $this->department->loadSieDepartment($dbfFileDepartment);

        $dbfFileSubject = __DIR__.'/../../public/dbfFiles/dret.DBF';
        $this->subject->loadSieSubject($dbfFileSubject);

        $dbfFileTeacher = __DIR__.'/../../public/dbfFiles/dcat.DBF';
        $this->teacher->loadSieTeacher($dbfFileTeacher);

        $dbfFileStudent = __DIR__.'/../../public/dbfFiles/dalu.DBF';
        $this->student->loadSieStudent($dbfFileStudent);

        $dbfFileCourse = __DIR__.'/../../public/dbfFiles/dgau.DBF';
        $this->course->loadSieCourse($dbfFileCourse);

        $dbfFileInscription = __DIR__.'/../../public/dbfFiles/dlis.DBF';
        $this->inscription->loadSieInscription($dbfFileInscription);

        $xlsxFileDictionarySpecialty =__DIR__.'/../../public/dbfFiles/DiccionarioEspecialidad.xlsx';
        $this->specialtyDictionary->loadSpecialtyDictionary($xlsxFileDictionarySpecialty);

        $this->sqlQueries->queries();
    }
}