<?php
namespace App\Infrastructure\ImportData;

use org\majkel\dbase\Table;
use Medoo\Medoo;

class SieInscription {
    private Medoo $db;

    public function __construct(Medoo $db) {
        $this->db = $db;
    }

    public function loadSieInscription(string $dbfFileInscription) {
        $sql = <<<'EOP'
        DROP TABLE IF EXISTS `temp_dlis`;
        CREATE TEMPORARY TABLE IF NOT EXISTS `temp_dlis` (
            `ctr` CHAR(10) NOT NULL,
            `gpo` CHAR(6) NOT NULL,
            `mat` CHAR(4) NOT NULL,
            UNIQUE INDEX `dlis_Unique` USING BTREE (`ctr`,`gpo`,`mat`));
        EOP;

        $this->db->query($sql);
        $file = Table::fromFile($dbfFileInscription);

        foreach ($file as $record) {
            $this->db->insert("temp_dlis", [
                "ctr" => $record['LIS_CTR'],
                "gpo" => $record['LIS_GPO'],
                "mat" => $record['LIS_MAT']
            ]);
        }
    }
}