<?php
namespace App\Infrastructure\ImportData;

use org\majkel\dbase\Table;
use Medoo\Medoo;

class SubjectDictionary {
    private Medoo $db;

    public function __construct(Medoo $db) {
        $this->db = $db;
    }
    
    public function loadSubjectDictionary(string $dbfFileDictionarySubject) {
        $sql = <<<'EOD'
        DROP TABLE IF EXISTS `temp_dret2`;
        CREATE TEMPORARY TABLE IF NOT EXISTS `temp_dret2` (
            `mat` CHAR(6) NOT NULL,
            `esp` INT(10) UNSIGNED NOT NULL,
            `clave_asignatura` CHAR(11) NOT NULL,
            UNIQUE INDEX `mat_UNIQUE` (`mat` ASC, `esp` ASC, `clave_asignatura` ASC));
        EOD;

        $this->db->query($sql);

        $records = Table::fromFile($dbfFileDictionarySubject);
        foreach ($records as $record) {
            $hypen = substr($record['SIEVISUAL'], 6, 1);
            if($hypen === '-') {
                $row = [
                    'id_carrera'       => (int)substr($record['SIEVISUAL'], 0, 2),
                    'clave_asignatura' => substr($record['SIEVISUAL'], 3, 8),
                ];

                $this->db->insert("temp_dret2", [
                    "mat"    => $record['SIEDOS'], 
                    "esp"    => $row['id_carrera'],
                    "clave_asignatura" => $row['clave_asignatura']
                ]);
            }
        }
    }
}