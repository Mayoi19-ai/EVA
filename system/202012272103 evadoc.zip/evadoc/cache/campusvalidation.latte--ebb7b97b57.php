<?php
// source: Campus/campusvalidation.latte

use Latte\Runtime as LR;

class Templateebb7b97b57 extends Latte\Runtime\Template
{
	public $blocks = [
		'content' => 'blockContent',
	];

	public $blockTypes = [
		'content' => 'html',
	];


	function main()
	{
		extract($this->params);
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('content', get_defined_vars());
		return get_defined_vars();
	}


	function blockContent($_args)
	{
		extract($_args);
		?>¿Fué la validación exitosa? <?php echo LR\Filters::escapeHtmlText($campus_data) /* line 2 */ ?>


<br>
<table>
    <tbody>
        <tr>
            <td>Nombre:</td>
            <td><?php echo LR\Filters::escapeHtmlText($result['name']) /* line 9 */ ?></td>
        </tr>
    </tbody>
</table>}
<pre> <?php echo LR\Filters::escapeHtmlText(var_dump($result)) /* line 13 */ ?> </pre>
<?php
	}

}
