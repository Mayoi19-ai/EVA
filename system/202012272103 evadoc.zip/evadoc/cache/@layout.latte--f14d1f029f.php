<?php
// source: Archivos\@layout.latte

use Latte\Runtime as LR;

class Templatef14d1f029f extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>




</head>
<body>
<h1>Subir archivo facultad</h1>
<form enctype="multipart/form-data"  action="<?php
		echo $router->relativeUrlFor("menuAdmin");
?>" method="POST">
<input name="uploadedfile" type="file">
<input type="submit" value="Subir archivo">

</body>
</html><?php
		return get_defined_vars();
	}

}
