<?php
// source: Carrera\careerform.latte

use Latte\Runtime as LR;

class Templatef86b48db4f extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		/* line 1 */
		$this->createTemplate('@layout-navbar.latte', $this->params, "include")->renderToContentType('html');
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 7 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
</head>
<body>
<form name="careerSaveForm" method="post" action="<?php
		echo $router->relativeUrlFor("careerRegister");
?>">
  <!-- Datos del formulario -->
<div class="container setcion">
  Identificador <input type="text" name="id">
  Clave de la carrera <input type="text" name="clave">
  Nombre <input type="text" name="nombre">
  Nombre corto <input type="text" name="nombre_corto">
  <!-- Botón de envío de formulario -->
  
  <input type="submit" value="Enviar formulario">
</div>
</form>
 

    <footer class="copyright"> 
        <p>Todos los derechos reservados, Gerardo y Raul 2020</p>
        
        
    </footer>
</body>
</html><?php
		return get_defined_vars();
	}

}
