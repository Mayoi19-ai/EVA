<?php
// source: Campus/campusTable.latte

use Latte\Runtime as LR;

class Templateee2d146580 extends Latte\Runtime\Template
{
	public $blocks = [
		'content' => 'blockContent',
	];

	public $blockTypes = [
		'content' => 'html',
	];


	function main()
	{
		extract($this->params);
		/* line 1 */
		$this->createTemplate('@layout-navbar.latte', $this->params, "include")->renderToContentType('html');
?>

<?php
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('content', get_defined_vars());
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['campusShow'])) trigger_error('Variable $campusShow overwritten in foreach on line 28');
		
	}


	function blockContent($_args)
	{
		extract($_args);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 9 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
        <link type="text/css" rel="stylesheet" href="/materialize/css/style.css"  media="screen,projection">
</head>

<body>
<div class="MiTabla" class="container setcion responsive-table" >
<table name="showAllCampuses" method="get" class="bordered striped hoverable centered responsive-table">
<thead>
<tr>
<th>Codigo</th>
<th>Campus</th>
<th></th>
<th></th>
</tr>
</thead>
<tbody>
<?php
		$iterations = 0;
		foreach ($query as $campusShow) {
?>
<tr>
    <td><?php echo LR\Filters::escapeHtmlText($campusShow['id']) /* line 30 */ ?> </td>
    <td><?php echo LR\Filters::escapeHtmlText($campusShow['nombre']) /* line 31 */ ?> </td>
    <td>
<form action="<?php
			echo $router->relativeUrlFor("campusUpdateForm");
?>" method="post">
            <input type="hidden" name="id" value="<?php echo LR\Filters::escapeHtmlAttr($campusShow['id']) /* line 34 */ ?>">
            <input type="hidden" name="nombre" value="<?php echo LR\Filters::escapeHtmlAttr($campusShow['nombre']) /* line 35 */ ?>">
<input type="submit" class="btn btn-primary btn-sm" value='Editar'>
</form>
</td>
<td>
    <form action="<?php
			echo $router->relativeUrlFor("campusDelete");
?>" method="get">
            <input type="hidden" name="id" value="<?php echo LR\Filters::escapeHtmlAttr($campusShow['id']) /* line 41 */ ?>">
    <input type="submit" style="background-color: #f44336" class="btn btn-primary btn-sm #f44336" value='Eliminar'>
    </form>
</td>

</tr>
<?php
			$iterations++;
		}
?>
</tbody>
<div class="fixed-action-btn">
<a href="save-form" style="background-color: #4caf50" class="btn-floating btn-large " ><i class="material-icons">add</i></a>
</table>
</div>
</body>
</html>
<?php
	}

}
