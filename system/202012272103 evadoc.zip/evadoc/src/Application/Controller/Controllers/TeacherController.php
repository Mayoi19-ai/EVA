<?php
namespace App\Controller\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use App\Validator\TeacherValidator as Validator;
use Ujpef\LatteView;
use App\Infrastructure\CrudSystem\TeacherInfrastructure as Infrastructure;
use App\Infrastructure\CrudSystem\DepartmentInfrastructure as DepartmentInfra;

class TeacherController{
    private Container $container;
    private Validator $validator;
    private Infrastructure $infrastructure;
    private DepartmentInfra $departmentInfra;
    
    public function __construct(Container $container, Validator $validator, Infrastructure $infrastructure, DepartmentInfra $departmentInfra){
        $this->container = $container;
        $this->validator = $validator;
        $this->infrastructure = $infrastructure;
        $this->departmentInfra = $departmentInfra;
    }

    public function saveForm(Request $request, Response $response){
        $departmentData = $this->departmentInfra->readAll();

        return $this->container->get(LatteView::class)->render($response,
         'Docente/teacherForm.latte', [
             'departments' => $departmentData
         ]);
    }

    public function register(Request $request, Response $response){
        $data = $request->getParsedBody();
        $validationResult = $this->validator->validateSaveTeacher((array) $data);
        
        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->create((array) $data);
        } else {
            $sthResult = ['consulta' => false];
        }

        return $this->container->get(LatteView::class)->render(
            $response,
            'Docente/teacherValidation.latte', [
                'validation' => $validationResult, 
                'query' => $sthResult
            ]);
    }

    public function search(Request $request, Response $response){
        $validationResult = $this->validator->validateFindTeacher((array) $_GET);
        
        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->read((string) $_GET['nombre']);
        } else {
            $sthResult = ['consulta' => false];
        }

        return $this->container->get(LatteView::class)->render(
            $response,
            'Docente/teacherSearch.latte', [
                'query' => $sthResult,
                'teacher_name' => $_GET['nombre']
            ]);
    }

    public function show(Request $request, Response $response){
        $sthResult = $this->infrastructure->readAll();

        return $this->container->get(LatteView::class)->render(
            $response,
            'Docente/teacherTable.latte', [
                'query' => $sthResult
            ]);
    }

    public function orderByDepartment(Request $request, Response $response){
        $sthResult = $this->infrastructure->orderByDepartment((int) $_GET['clave_departamento']);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Docente/teacherTable.latte', [
                'query' => $sthResult,
                'department_information' => $_GET['clave_departamento']
            ]);
    }

    public function updateForm(Request $request, Response $response){
        $data = $request->getParsedBody();
        $departmentData = $this->departmentInfra->readAll();
        return $this->container->get(LatteView::class)->render($response,
         'Docente/teacherUpdate.latte', [
             'teacher_information' => $data,
             'departments' => $departmentData
         ]);
    }

    public function update(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $validationResult = $this->validator->validateSaveTeacher((array) $data);

        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->update((array) $data);
        } else {
            $sthResult = ['consulta' => false];
        }

        return $this->container->get(LatteView::class)->render(
            $response,
            'Docente/teacherValidation.latte', [
                'validation' => $validationResult, 
                'query' => $sthResult,
            ]);
    }

    public function delete(Request $request, Response $response){
        $sthResult = $this->infrastructure->delete((int) $_GET['folio']);
        
        return $this->container->get(LatteView::class)->render(
            $response,
            'Docente/teacherValidation.latte', [
                'query' => $sthResult
            ]);
    }
}