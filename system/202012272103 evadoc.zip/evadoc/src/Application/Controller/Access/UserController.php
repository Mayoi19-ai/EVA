<?php
namespace App\Controller\Access;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use Ujpef\LatteView;
use App\Validator\CampusValidator as Validator;
use App\Infrastructure\CrudSystem\CampusInfrastructure as Infrastructure;

class CampusController{
    private Container $container;
    private Validator $validator;
    private Infrastructure $infrastructure;

    public function __construct(Container $container, Validator $validator, Infrastructure $infrastructure){
        $this->container = $container;
        $this->validator = $validator;
        $this->infrastructure = $infrastructure;
    }

    public function saveForm(Request $request, Response $response){
        return $this->container->get(LatteView::class)->render($response, 'Campus/campusForm.latte'
        );
    }

    public function register(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $validationResult = $this->validator->validateSaveCampus($data);

        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->create((array) $data);
        } else {
            $sthResult = ['consulta' => false];
        }
        return $this->container->get(LatteView::class)->render(
            $response,
            'Campus/campusValidation.latte',[
                'validation' => $validationResult, 
                'query' => $sthResult
            ]);
    }

    public function show(Request $request, Response $response){
        $sthResult = $this->infrastructure->readAll();
        
        return $this->container->get(LatteView::class)->render(
            $response,
            'Campus/campusTable.latte',
            ['query' => $sthResult
        ]);
    }

    public function update(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $validationResult = $this->validator->validateSaveCampus((array) $data);
        
        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->update((array) $data);
        } else {
            $sthResult = ['consulta' => false];
        }

        $this->infrastructure->update($data);
        return $this->container->get(LatteView::class)->render(
            $response,
            'Campus/campusValidation.latte', [
                'validation' => $validationResult,
                'query' => $sthResult
            ]);
    }

    public function updateForm(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        return $this->container->get(LatteView::class)->render(
            $response,
            'Campus/updateCampus.latte',
            ['data' => $data]
        );
    }

    public function delete(Request $request, Response $response){
        $sthResult = $this->infrastructure->delete((int)$_GET['id']);
        return $this->container->get(LatteView::class)->render(
            $response,
            'Modalidad/modalityValidation.latte', [
                'query' => $sthResult
            ]);
    }
}