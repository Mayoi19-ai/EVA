<?php

namespace App\Infrastructure\ImportData;
use App\Infrastructure\ImportData\Courses;
use App\Infrastructure\ImportData\Departments;
use App\Infrastructure\ImportData\Groups;
use App\Infrastructure\ImportData\Inscriptions;
use App\Infrastructure\ImportData\Lessons;
use App\Infrastructure\ImportData\Students;
use App\Infrastructure\ImportData\Subjects;
use App\Infrastructure\ImportData\Teachers;

use Medoo\Medoo;

class Queries {
    private Courses $courses;
    private Departments $departments;
    private Groups $groups;
    private Inscriptions $inscriptions;
    private Lessons $lessons;
    private Students $students;
    private Subjects $subjects;
    private Teachers $teachers;

    public function __construct(Courses $courses, Departments $departments, Groups $groups, Inscriptions $inscriptions, Lessons $lessons, Students $students, Subjects $subjects, Teachers $teachers){
        $this->courses = $courses;
        $this->departments = $departments;
        $this->groups = $groups;
        $this->inscriptions = $inscriptions;
        $this->lessons = $lessons;
        $this->students = $students;
        $this->subjects = $subjects;
        $this->teachers = $teachers;
    }

    public function queries (int $period): ?array
    {
        //in lesson the transaction begins
        $lessonsResult = $this->lessons->lessons();

        $departmentsResult = $this->departments->departments();

        $teachersResult = $this->teachers->teachers();

        $subjectsResult = $this->subjects->subjects();

        $groupsResult = $this->groups->groups((int) $period);

        if(!empty($groupsResult)) {
            //the transaction not ok finish here
            $this->db->pdo->rollBack();
            return $groupsResult;
        }

        $coursesResult = $this->courses->courses((int) $period);

        if(!empty($coursesResult)) {
            //the transaction not ok finish here
            $this->db->pdo->rollBack();
            return $coursesResult;
        }

        $studentsResult = $this->students->students();

        $inscriptionsResult = $this->inscriptions->inscriptions((int) $period);

        if(!empty($inscriptionsResult)) {
            //the transaction not ok finish here
            $this->db->pdo->rollBack();
            return $inscriptionsResult;
        }
        //the transaction ok finish here
        $this->db->pdo->commit();

        return null;
    }
}