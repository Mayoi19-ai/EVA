<?php
namespace App\Infrastructure\Rbac;

use Medoo\Medoo;
use App\Infrastructure\Exceptions\CustomException as Exception;

class UserRoles {
    private Medoo $db;
    private Exception $exception;
    
    public function __construct(Medoo $db, Exception $exception) {
        $this->db = $db;
        $this->exception = $exception;
    }

    public function create(array $data): array
    {
        $this->db->pdo->beginTransaction();
        $this->db->insert('roles_usuario',[
            'id_usuario' => $data['id_usuario'],
            'id_roles' => $data['id_roles']
        ]);

        $result = $this->exception->saveError((array) $this->db->error());
        return $result;
    }

    public function readAll(): array
    {
        $sql = <<<'EOP'
        SELECT
        usuario.id as 'id_usuario',
        usuario.nombre as 'usuario',
        roles.id as 'id_roles',
        roles.nombre as 'rol'
        FROM 
        usuario,
        roles,
        roles_usuario
        WHERE 
        roles_usuario.id_roles = roles.id
        AND
        roles_usuario.id_usuario = usuario.id;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->execute();
        $records = $sth->fetchAll();
        
        $result = $this->exception->readError((array) $this->db->error(), (array) $records);
        return $result;
    }

    public function readByUser(string $user): array
    {
        $sql = <<<'EOP'
        SELECT
        usuario.id as 'id_usuario',
        usuario.nombre as 'usuario',
        roles.id as 'id_roles',
        roles.nombre as 'rol'
        FROM 
        usuario,
        roles,
        roles_usuario
        WHERE 
        roles_usuario.id_roles = roles.id
        AND
        roles_usuario.id_usuario = usuario.id
        AND 
        usuario.nombre LIKE '%' :usuario '%';
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':usuario', $user);
        $sth->execute();
        $records = $sth->fetchAll();
        
        $result = $this->exception->readError((array) $this->db->error(), (array) $records);
        return $result;
    }

    public function update(array $data): array
    {
        $this->db->pdo->beginTransaction();
        $this->db->update('roles_usuario',[
            'id_usuario' => $data['id_usuario'],
            'id_roles' => $data['id_roles']], [
                'AND' => [
                    'id_usuario' => $data['id_usuario_antiguo'],
                    'id_roles' => $data['id_roles_antiguo']
                ]
            ]);

        $result = $this->exception->saveError((array) $this->db->error());
        return $result;
    }

    public function delete(array $data): array
    {
        $this->db->pdo->beginTransaction();
        $this->db->delete('roles_usuario', [
            'AND' => [
                'id_usuario' => $data['id_usuario'],
                'id_roles' => $data['id_roles']
            ]
        ]);
        
        $result = $this->exception->deleteError((array) $this->db->error());
        return $result;
    }
}