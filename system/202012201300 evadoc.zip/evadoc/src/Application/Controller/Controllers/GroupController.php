<?php
namespace App\Controller\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use App\Validator\GroupValidator;
use Ujpef\LatteView;
use Slim\Exception\HttpForbiddenException;
use App\Infrastructure\CrudSystem\GroupInfrastructure as Infrastructure;
use App\Infrastructure\CrudSystem\CareerInfrastructure as Career;
use App\Infrastructure\CrudSystem\ModalityInfrastructure as Modality;
use App\Infrastructure\CrudSystem\CampusInfrastructure as Campus;

class GroupController{
    private Container $container;
    private Infrastructure $infrastructure;
    private Career $career;
    private Modality $modality;
    private Campus $campus;

    public function __construct(Container $container, Infrastructure $infrastructure, Career $career, Modality $modality, Campus $campus ){
        $this->container = $container;
        $this->infrastructure = $infrastructure;
        $this->career = $career;
        $this->modality = $modality;
        $this->campus = $campus;
    }

    public function saveForm(Request $request, Response $response){
        $careerData = $this->career->readAuxiliary();
        $modalityData = $this->modality->readAll();
        $campusData = $this->campus->readAll();

        return $this->container->get(LatteView::class)->render($response, 
        'Grupo/group.latte', [
            'all_careers_information' => $careerData,
            'all_modalities_information' => $modalityData,
            'all_campus_information' => $campusData
        ]);
    }

    public function register(Request $request, Response $response, array $args){
        $resultData = [];
        
        $data = $request->getParsedBody();
        $this->infrastructure->create($data);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Grupo/groupvalidation.latte'
        );
    }

    public function search(Request $request, Response $response, array $args){
        $resultData = [];
        $name = $_GET['grupo'];
        $data = $this->infrastructure->read($_GET['id_periodo'], $name);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Maestros/validationteacher.latte', [
                'group_search' => $name,
                'groups' => $data
            ]);
    }

    public function show(Request $request, Response $response){
        $data = $this->infrastructure->readAll($_GET['id_periodo']);
        return $this->container->get(LatteView::class)->render(
            $response,
            'Grupo/groupTable.latte', [
                'all_groups_information' => $data
            ]);
    }

    public function updateForm(Request $request, Response $response){
        $data = $request->getParsedBody();
        $careerData = $this->career->readAuxiliary();
        $modalityData = $this->modality->readAll();
        $campusData = $this->campus->readAll();

        return $this->container->get(LatteView::class)->render($response, 
        'Grupo/group.latte', [
            'all_careers_information' => $careerData,
            'all_modalities_information' => $modalityData,
            'all_campus_information' => $campusData,
            'group_information' => $data
        ]);
    }

    public function update(Request $request, Response $response, array $args){
        $resultData = [];
        
        $data = $request->getParsedBody();
        $this->infrastructure->update($data);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Maestros/validationteacher.latte');
    }

    public function delete(Request $request, Response $response){
        $data = $request->getParsedBody();
        $this->infrastructure->delete($data);
        return $response;
    }
}