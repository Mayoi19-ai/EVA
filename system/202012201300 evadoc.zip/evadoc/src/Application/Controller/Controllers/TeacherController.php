<?php
namespace App\Controller\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use App\Validator\TeacherValidator as Validator;
use Ujpef\LatteView;
use Slim\Exception\HttpForbiddenException;
use Medoo\Medoo;
use App\Infrastructure\CrudSystem\TeacherInfrastructure as Infrastructure;
use App\Infrastructure\CrudSystem\DepartmentInfrastructure as Department;

class TeacherController{
    private Container $container;
    private Validator $validator;
    private Infrastructure $infrastructure;
    private Department $department;
    
    public function __construct(Container $container, Validator $validator, Infrastructure $infrastructure, Department $department){
        $this->container = $container;
        $this->validator = $validator;
        $this->infrastructure = $infrastructure;
        $this->department = $department;
    }

    public function saveForm(Request $request, Response $response){
        $departmentData = $this->department->readAll();

        return $this->container->get(LatteView::class)->render($response,
         'Docente/teacherForm.latte', [
             'departments' => $departmentData
         ]);
    }

    public function register(Request $request, Response $response){
        $resultData = [];
        $data = $request->getParsedBody();
        $this->infrastructure->create($data);
        
        return $this->container->get(LatteView::class)->render(
            $response,
            'Maestros/validationteacher.latte',
            ['validacion_exitosa' => $validationResult] + $resultData
        );
    }

    public function search(Request $request, Response $response){
        $resultData = [];
        $name = $_GET['nombre'];
        $data = $this->infrastructure->read($name);
        return $this->container->get(LatteView::class)->render(
            $response,
            'Docente/teacherSearch.latte', [
                'teacher_information' => $data,
                'teacher_name' => $name]
        );
    }

    public function show(Request $request, Response $response){
        $data = $this->infrastructure->readAll();

        return $this->container->get(LatteView::class)->render(
            $response,
            'Docente/teacherTable.latte', [
                'all_teachers_information' => $data
                ]);
    }

    public function updateForm(Request $request, Response $response){
        $data = $request->getParsedBody();
        $departmentData = $this->department->readAll();
        return $this->container->get(LatteView::class)->render($response,
         'Docente/teacherUpdate.latte', [
             'teacher_information' => $data,
             'departments' => $departmentData
         ]);
    }

    public function update(Request $request, Response $response){
        $resultData = [];
        $data = (array)$request->getParsedBody();
        $this->infrastructure->update($data);
        return $this->container->get(LatteView::class)->render(
            $response,
            'Maestros/validationteacher.latte',
            ['validacion_exitosa' => $validationResult] + $resultData
        );
    }

    public function delete(Request $request, Response $response){
        $this->infrastructure->delete($_GET['folio']);
        return $response;
    }
}

/*
   public function form(Request $request, Response $response, array $args){
        // Simula que la lógica de negocios valida el id
        $id = (int) $args['id'];
        if($id > 5) {
            throw new HttpForbiddenException($request);
        }
        return $this->container->get(LatteView::class)->render($response, 'Maestros/teacher.latte', [
            'id' => $id,
        ]);
    }

 */