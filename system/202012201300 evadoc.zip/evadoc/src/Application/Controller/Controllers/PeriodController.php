<?php
namespace App\Controller\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use App\Validator\PeriodValidator as Validator;
use Ujpef\LatteView;
use Slim\Exception\HttpForbiddenException;
use App\Infrastructure\CrudSystem\PeriodInfrastructure as Infrastructure;

class PeriodController{
    private Container $container;
    private Validator $validator;
    private Infrastructure $infrastructure;
    
    public function __construct(Container $container, Validator $validator, Infrastructure $infrastructure){
        $this->container = $container;
        $this->validator = $validator;
        $this->infrastructure = $infrastructure;
    }

    public function saveForm(Request $request, Response $response, array $args){
        return $this->container->get(LatteView::class)->render($response, 'Periodo/periodForm.latte');
    }

    public function register(Request $request, Response $response, array $args){
        $resultData = [];
    
        $data = (array)$request->getParsedBody();

        $this->infrastructure->create($data);
        return $this->container->get(LatteView::class)->render(
            $response,
            'Periodo/periodValidation.latte',
            ['validacion_exitosa' => $validationResult] + $resultData
        );
    }

    public function show(Request $request, Response $response){
        $data = $this->infrastructure->readAll();

        return $this->container->get(LatteView::class)->render(
            $response,
            'Periodo/periodTable.latte', [
                'all_period_information' => $data
            ]
        );
    }
    
    public function updateForm(Request $request, Response $response, array $args){
        $data = (array)$request->getParsedBody();
        return $this->container->get(LatteView::class)->render($response, 
        'Periodo/periodUpdate.latte', [
            'period_data' => $data
        ]);
    }

    public function update(Request $request, Response $response){
        $resultData = [];
        
        $data = (array)$request->getParsedBody();
        
        $this->infrastructure->update($data);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Periodo/periodValidation.latte',
            ['validacion_exitosa' => $validationResult] + $resultData
        );
    }

    public function delete(Request $request, Response $response){
        $this->infrastructure->delete($_GET['id']);
        return $response;
    }
}