<?php
namespace App\Controller\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use App\Validator\InscriptionValidator;
use Ujpef\LatteView;
use Slim\Exception\HttpForbiddenException;
use App\Infrastructure\CrudSystem\InscriptionInfrastructure as Infrastructure;
use App\Infrastructure\CrudSystem\CourseInfrastructure as Course;
use App\Infrastructure\CrudSystem\StudentInfrastructure as Student;

class InscriptionController{
    private Container $container;
    private Infrastructure $infrastructure;
    private Course $course;
    private Student $student;
    
    public function __construct(Container $container, Infrastructure $infrastructure, Course $course, Student $student){
        $this->container = $container;
        $this->infrastructure = $infrastructure;
        $this->course = $course;
        $this->student = $student;
    }

    public function saveForm(Request $request, Response $response, array $args){
        $courseData = $this->course->readAll();
        $studentData = $this->student->readAll();

        return $this->container->get(LatteView::class)->render($response, 
            'Inscripcion/inscription.latte', [
                'courses' => $courseData,
                'students' => $studentData
            ]);
    }

    public function register(Request $request, Response $response){
        $resultData = [];
        
        $data = (array)$request->getParsedBody();
        $this->infrastructure->update($data);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Inscripcion/inscriptionValidation.latte',
            ['validacion_exitosa' => $validationResult] + $resultData
        );
    }

    public function show(Request $request, Response $response, array $args){
        $data = $this->infrastructure->readAll($_GET['id_periodo']);
        return $this->container->get(LatteView::class)->render(
            $response,
            'Inscripcion/inscriptionTable.latte', [
                'all_inscriptions_information' => $data
            ]);
    }

    public function searchByStudent(Request $request, Response $response){
        $resultData = [];
        $control = $_GET['control'];
        $data = $this->infrastructure->readByStudent($control, $_GET['id_period']);
        return $this->container->get(LatteView::class)->render(
            $response,
            'Inscripcion/inscriptionValidation.latte',
            ['inscription_information' => $data]
        );
    }

    public function update(Request $request, Response $response, array $args){
        $resultData = [];
        
        $data = (array)$request->getParsedBody();
        $this->infrastructure->update($data);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Inscripcion/inscriptionValidation.latte',
            ['validacion_exitosa' => $validationResult] + $resultData
        );
    }

    public function delete(Request $request, Response $response){
        $this->infrastructure->delete($_GET['id']);
    }
}