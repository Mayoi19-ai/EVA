<?php
namespace App\Validator;
use Rakit\Validation\Validator;

class CampusValidator{
    private Validator $validator;

    public function __construct(Validator $validator) {
        $this->validator = $validator;
    }

    public function validateSaveCampus(array $data, array &$resultData): array {
        $validationRules = [
            'nombre'          =>  'required|alpha|alpha_spaces|uppercase',
        ];
    
        $errorMessages = [
            'nombre:required'     => 'El nombre es obligatorio',
            'nombre:alpha'        => 'El nombre no válido',
            'nombre:uppercase'    => 'El nombre debe de estar en mayúsculas',
            'nombre:alpha_spaces' => 'El nombre no acepta caracteres especiales',
        ];
    
        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data, $resultData);
    }
}