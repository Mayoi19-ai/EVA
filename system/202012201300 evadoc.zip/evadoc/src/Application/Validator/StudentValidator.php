<?php
namespace App\Validator;
use Rakit\Validation\Validator;

class StudentValidator{
    private Validator $validator;

    public function __construct(Validator $validator){
        $this->validator = $validator;
    }

    public function validateSaveStudent(array $data, array &$resultData): bool {
        $validationRules = [
            'control'     =>  'required|alpha_num|uppercase|between:8,8',
            'name'        =>  'required|alpha_spaces|uppercase',
            'password'    =>  'required|between:10,20',
        ];

        $errorMessages = [
            'control:required'    => 'El número de control es obligatorio',
            'control:alpha_num'   => 'El número de control no es válido',
            'control:uppercase'   => 'El número de control debe estar en mayúsculas',
            'control:between'     => 'El número de control debe tener 8 caracteres',
            'control:required'    => 'El número de control es obligatorio',
            'name:required'       => 'El nombre es obligatorio',
            'name:alpha_spaces'   => 'El nombre no es válido',
            'name:uppercase'      => 'El nombre debe estar en mayúsculas',
            'password:required'   => 'La clave de acceso es obligatoria',
            'password:between'    => 'La clave de acceso debe tener de 10 a 20 caracteres',
        ];
    }

    public function validateFindStudent(array $data, array &$resultData): bool {
        $validationRules = [
            'control'     =>  'required|alpha_num|uppercase|between:8,8',
        ];

        $errorMessages = [
            'control:required'    => 'El número de control es obligatorio',
            'control:alpha_num'   => 'El número de control no es válido',
            'control:uppercase'   => 'El número de control debe estar en mayúsculas',
            'control:between'     => 'El número de control debe tener 8 caracteres',
            'control:required'    => 'El número de control es obligatorio',
        ];
    }
}