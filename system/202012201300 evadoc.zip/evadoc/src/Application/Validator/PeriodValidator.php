<?php
namespace App\Validator;
use Rakit\Validation\Validator;

class PeriodValidator{
    private Validator $validator;

    public function __construct(Validator $validator) {
        $this->validator = $validator;
    }

    public function validateSavePeriod(array $data, array &$resultData): bool {
        $validationRules = [
            'nombre'           =>  'required|uppercase',
            'inicia'           =>  'required|date:Y-m-d',
            'termina'          =>  'date:Y-m-d',
        ];

        $errorMessages = [
            'nombre:required'    => 'El nombre es obligatorio',
            'nombre:uppercase'   => 'El nombre debe estar en mayúsculas',
            'inicia:required'    => 'La fecha de inicio es obligatoria',
            'inicia:date'        => 'El formato de fecha inicio no es válido',
            'termina:date'       => 'El formato de fecha fin no es válido',
        ];

        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data, $resultData);
    }

    public function validateFindPeriod(array $data, array &$resultData): bool {
        $validationRules = [
            'nombre'          =>  'required|alpha_dash|uppercase',
        ];

        $errorMessages = [
            'nombre:required'     => 'El nombre es obligatorio',
            'nombre:uppercase'    => 'El nombre debe estar en mayúsculas',
        ];
    }
}