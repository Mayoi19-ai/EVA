<?php
namespace App\Infrastructure\CrudSystem;

use Medoo\Medoo;

class InscriptionInfrastructure{
    private Medoo $db;

    public function __construct(Medoo $db) {
        $this->db = $db;
    }

    public function create(array $data): ?array
    {
        $data = $this->db->insert('inscripcion',[
            'id_curso' => $data['id_curso'], 
            'alumno_control' => $data['control']
        ]);

        return $data;
    }

    public function readAll(int $periodId): ?array
    {
        $sql = <<<'EOP'
        SELECT 
        inscripcion.id AS 'id',
        inscripcion.alumno_control AS 'control',
        alumno.nombre AS 'alumno',
        curso.id AS 'id_curso',
        curso.nombre_grupo AS 'grupo',
        carrera.nombre AS 'carrera',
        curso.id_carrera AS 'id_carrera',
        asignatura.nombre AS 'asignatura',
        curso.clave_asignatura AS 'clave_asignatura',
        docente.nombre AS 'docente',
        curso.folio_docente AS 'folio_docente'
        FROM 
        inscripcion,
        alumno,
        curso,
        asignatura,
        carrera, 
        docente
        WHERE inscripcion.alumno_control = alumno.control
        AND inscripcion.id_curso = curso.id
        AND curso.id_carrera = carrera.id
        AND curso.clave_asignatura = asignatura.clave
        AND curso.folio_docente = docente.folio 
        AND curso.id_periodo = :id_periodo;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':id_periodo', $periodId);
        $sth->execute();
        $records = $sth->fetchAll();
        return $records;
    }

    public function readByStudent(string $control, int $periodId): ?array
    {
        $sql = <<<'EOP'
        SELECT 
        inscripcion.id AS 'id',
        inscripcion.alumno_control AS 'control',
        alumno.nombre AS 'alumno',
        curso.id AS 'id_curso',
        curso.nombre_grupo AS 'grupo',
        carrera.nombre AS 'carrera',
        curso.id_carrera AS 'id_carrera',
        asignatura.nombre AS 'asignatura',
        curso.clave_asignatura AS 'clave_asignatura',
        docente.nombre AS 'docente',
        curso.folio_docente AS 'folio_docente'
        FROM 
        inscripcion,
        alumno,
        curso,
        asignatura,
        carrera, 
        docente
        WHERE inscripcion.alumno_control = alumno.control
        AND inscripcion.id_curso = curso.id
        AND curso.id_carrera = carrera.id
        AND curso.clave_asignatura = asignatura.clave
        AND curso.folio_docente = docente.folio
        AND curso.id_periodo = :id_periodo
        AND inscripcion.alumno_control LIKE '%' :control '%';
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':id_periodo', $periodId);
        $sth->bindParam(':control', $name);
        $sth->execute();
        $records = $sth->fetchAll();
        return $records;
    }

    public function update(array $data): ?array
    {
        $sql = $this->db->update('inscripcion', [
            'id_curso' => $data['id_curso'], 
            'alumno_control' => $data['control']], [
                'id' => $data['id']
            ]);

        return $sql;
    }
    
    public function delete(int $id): ?array
    {
        $sql = $this->db->delete('inscripcion', [
            'id' => $id]
        );
        
        return $sql;
    }
}