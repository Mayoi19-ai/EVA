<?php
namespace App\Infrastructure\CrudSystem;

use Medoo\Medoo;
use Psr\Container\ContainerInterface;

class DepartmentInfrastructure{
    private Medoo $db;

    public function __construct(Medoo $db) {
        $this->db = $db;
    }

    public function create(array $data): ?array
    {
        $sql = $this->db->insert('departamento',[
            'clave' => $data['clave'], 
            'nombre' => $data['nombre']
            ]);
        
        return $sql;
    }

    public function readAll(): ?array
    {
        $sql = $this->db->select('departamento',[
            'clave',
            'nombre'
        ]);
        return $sql;
    }

    public function read(string $name): ?array
    {
        $sql = $this->db->select('departamento',[
            'clave', 
            'nombre'], [
                'nombre[~]' => $name
                ]);

        return $sql;
    }

    public function update(array $data): ?array
    {
        $sql = $this->db->update('departamento',[
            'clave' => $data['clave'], 
            'nombre' => $data['nombre']], [
                'clave' => $data['clave_antigua']
                ]);

        return $sql;
    }
    
    public function delete(int $code): ?array
    {
        $sql = $this->db->delete('departamento', [
            'clave' => $code
            ]);
        return $sql;
    }
}