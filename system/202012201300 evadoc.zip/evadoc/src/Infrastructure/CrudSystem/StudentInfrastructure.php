<?php
namespace App\Infrastructure\CrudSystem;

use Medoo\Medoo;

class StudentInfrastructure{
    private Medoo $db;

    public function __construct(Medoo $db) {
        $this->db = $db;
    }

    public function create(array $data): ?array
    {
        $sql = $this->db->insert('alumno',[
            'control' => $data['control'], 
            'nombre' => $data['nombre'],
            'contrasenia' => $data['contrasenia']
            ]);

        return $sql;
    }

    public function readAll(): ?array
    {
        $sql = $this->db->select('alumno',[
            'control',
            'nombre']
        );

        return $data;
    }

    public function read(string $control): ?array
    {
        $sql = $this->db->select('alumno',[
            'nombre',
            'control'], [
                'control' => $control]
            );

        return $sql;
    }

    public function update(array $data): ?array
    {
        $sql = $this->db->update('alumno',[
            'control' => $data['control'], 
            'nombre' => $data['nombre'],
            'contrasenia' => $data['contrasenia']], [
                'control' => $data['control_antiguo']
                ]);

        return $sql;
    }
    
    public function delete(string $control): ?array
    {
        $sql = $this->db->delete('alumno', [
                'control' => $control
                ]);

        return $sql;
    }
}