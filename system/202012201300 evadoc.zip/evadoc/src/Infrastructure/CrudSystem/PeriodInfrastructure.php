<?php
namespace App\Infrastructure\CrudSystem;

use Medoo\Medoo;

class PeriodInfrastructure{
    private Medoo $db;

    public function __construct(Medoo $db) {
        $this->db = $db;
    }

    public function create(array $data): ?array
    {
        $sql = $this->db->insert('periodo',[
            'nombre' => $data['nombre'], 
            'inicia' => $data['inicia'], 
            'termina' => $data['termina']]
        );
        return $sql;
    }

    public function readAll(): ?array
    {
        $sql = $this->db->select('periodo',[
            'id',
            'nombre',
            'inicia',
            'termina']
        );
        return $sql;
    }

    public function readActivedPeriod(): ?array
    {
        $sql = $this->sb->select('periodo', [
            'id'], [
                'activo' => 1
            ]);

        return $sql;
    }

    public function update(array $data): ?array
    {
        $sql = $this->db->update('periodo',[
            'nombre'  => $data['nombre'], 
            'inicia'  => $data['inicia'], 
            'termina' => $data['termina']], [
            'id'      => $data['id']]
            );

        return $sql;
    }
    
    public function delete(int $id): ?array
    {
        $sql = $this->db->delete('periodo', [
            'id' => $id]
        );
        
        return $sql;
    }
}