<?php
// source: Departamento/departmentForm.latte

use Latte\Runtime as LR;

class Template3d2a6e3062 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 5 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
</head>
<body>
<form name="departmentSaveForm" method="post" action="<?php
		echo $router->relativeUrlFor("departmentRegister");
?>">
  <!-- Datos del formulario -->
  <div class="container section">
  Codigo <input type="text" name="clave">
  Nombre <input type="text" name="nombre">
 
  <!-- Botón de envío de formulario -->
  
  <input type="submit" value="Enviar formulario">
</div>
</form>

 

    <footer class="copyright"> 
        <p>Todos los derechos reservados, Gerardo y Raul 2020</p>
        
        
    </footer>
</body>
</html><?php
		return get_defined_vars();
	}

}
