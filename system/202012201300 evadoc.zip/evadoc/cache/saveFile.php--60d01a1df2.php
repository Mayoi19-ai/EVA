<?php
// source: Archivos/saveFile.php

use Latte\Runtime as LR;

class Template60d01a1df2 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		
		$archivo = (isset($_FILES['archivo'])) ? $_FILES['archivo'] : null;
		if ($archivo) {
			$ruta_destino_archivo = "Archivos/<?php echo LR\Filters::escapeHtmlText($archivo['name']) /* line 4 */ ?>";
				$archivo_ok = move_uploaded_file($archivo['tmp_name'], $ruta_destino_archivo);
			}

			return get_defined_vars();
		}

	}
	