<?php
// source: Preguntas/question.latte

use Latte\Runtime as LR;

class Template0cb0c55215 extends Latte\Runtime\Template
{
	public $blocks = [
		'title' => 'blockTitle',
		'footer' => 'blockFooter',
	];

	public $blockTypes = [
		'title' => 'html',
		'footer' => 'html',
	];


	function main()
	{
		extract($this->params);
?>
<!doctype html>
<html lang="en">
<head>
	<title><?php
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('title', get_defined_vars());
?></title>
	<link rel="stylesheet" href="style.css">
</head>
<body>
	<div id="content">
		{'../header.latte'}
     
	</div>
    <div id="content">
		{'@question.latte'}
        
	</div>
	<div id="footer">
		<?php
		$this->renderBlock('footer', get_defined_vars());
?>
	</div>
</body>
</html><?php
		return get_defined_vars();
	}


	function blockTitle($_args)
	{
		
	}


	function blockFooter($_args)
	{
		?>&copy; Copyright 2008<?php
	}

}
