<?php
// source: Carrera/careerUpdate.latte

use Latte\Runtime as LR;

class Template689bce15a6 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 5 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>

</head>
<body>
<div class="container setcion">
<form name="careerUpdateForm" method="post" action="<?php
		echo $router->relativeUrlFor("careerUpdate");
?>">
<ul>
<li>
    <label><input type="hidden" id="id" name="id" value="<?php echo LR\Filters::escapeHtmlAttr($career_information['id']) /* line 16 */ ?>" class="validate"></label>
  </li>
<li>
    <label for="clave">Clave:</label>
    <label><input type="text" id="clave" name="clave" value="<?php echo LR\Filters::escapeHtmlAttr($career_information['clave']) /* line 20 */ ?>" class="validate"></label>
  </li>
  <li>
    <label for="nombre">Nombre:</label>
    <input type="text" id="nombre" name="nombre" value="<?php echo LR\Filters::escapeHtmlAttr($career_information['nombre']) /* line 24 */ ?>" class="validate"></label>
  </li>
  <li>
    <label for="nombre_corto">Nombre corto:</label>
    <input type="text" id="nombre_corto" name="nombre_corto" value="<?php echo LR\Filters::escapeHtmlAttr($career_information['nombre_corto']) /* line 28 */ ?>" class="validate"></label>
  </li>
 </ul>
<input type="submit" value="Registrar" name="registrar">
</form>




    <footer class="copyright"> 
        <p>Todos los derechos reservados, Gerardo y Raul 2020</p>
    </footer>
</body>
</html><?php
		return get_defined_vars();
	}

}
