<?php
// source: Campus/campus.latte

use Latte\Runtime as LR;

class Template681903d8da extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		?><<?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		$this->parentName = 'campusTable.latte';
		
	}

}
