<?php declare(strict_types=1);

return [
    'campus' =>  [
        'name'   =>  'campus',
        'id'     =>  'id',
        'fields' => [
            'name' => 'nombre',
        ]
    ],
];