<?php declare(strict_types=1);

use DI\ContainerBuilder;
use Psr\Log\LogLevel;

return function(ContainerBuilder $containerBuilder): void
{
    
    $containerBuilder->addDefinitions([
        'settings' => [
            'basePath'           => '/evadoc/public',
            'error'              => [
                'displayDetails' => true,
                'log'            => true,
                'logDetails'     => false,
            ],
            'logger'             => [
                'name'  => 'EvaDoc',
                'path'  => __DIR__ . '/../logs/app.log',
                'level' => LogLevel::DEBUG,
            ],
            'view' => [
                'path'   => __DIR__ . '/../src/Templates',
                'cache'  => __DIR__ . '/../cache',
                'params' => [
                    'title'     => 'ITSH - Evaluación Docente',
                    'copyright' => 'Gerardo & Raul',
                ],
            ],
            'database' => [
                'type'      => 'mysql',
                'name'      => 'proyecto',
                'server'    => 'localhost',
                'username'  => 'root',
                'password'  => '',
                'charset'   => 'utf8mb4',
                'collation' => 'utf8mb4_spanish_ci',
                'port'      => 3306,
                'prefix'    => '',
                'basePath'  => '//localhost/',
            ],
            'database/tables' => require(__DIR__ . '/settingsDatabase.php'),
        ],
    ]);
};