<?php
// source: Campus/campusTable.latte

use Latte\Runtime as LR;

class Templateee2d146580 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 6 */ ?></title>
</head>
<table name="showAllCampuses" method="get">

<div>
<!--<?php
		if ((empty($selectShowAllCampuses))) {
?>

<p>El campus esta vacio</p>
<?php
		}
		else {
			?><p n:inner-foreach = "$selectShowAllCampuses as $campuse"><?php echo LR\Filters::escapeHtmlComment($campuse['nombre']) /* line 14 */ ?> </p>
<?php
		}
?> -->

   
</div> 
</body> 

</html> <?php
		return get_defined_vars();
	}

}
