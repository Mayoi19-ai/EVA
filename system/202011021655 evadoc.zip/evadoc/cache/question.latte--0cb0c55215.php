<?php
// source: Preguntas/question.latte

use Latte\Runtime as LR;

class Template0cb0c55215 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		$this->parentName = '@question.latte';
		
	}

}
