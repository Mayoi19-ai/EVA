<?php
// source: Preguntas\@question.latte

use Latte\Runtime as LR;

class Template08d5120404 extends Latte\Runtime\Template
{
	public $blocks = [
		'content' => 'blockContent',
	];

	public $blockTypes = [
		'content' => 'html',
	];


	function main()
	{
		extract($this->params);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 5 */ ?></title>
</head>
<body>
    <h1><?php echo LR\Filters::escapeHtmlText($title) /* line 8 */ ?></h1>
<?php
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('content', get_defined_vars());
?>




    <footer class="copyright"> 
        <p>Todos los derechos reservados, Gerardo y Raul 2020</p>
    </footer>
</body>
</html><?php
		return get_defined_vars();
	}


	function blockContent($_args)
	{
?>     
     <div class="wrapper_row js_complete_quizz_question_wrapper" style="">
  <div class="row js_error_placement_parent step_22">
    <div class="m_header_step" data-step="22">
      <h1 class="js_error_placement quizz_question ">¿Cómo clasificamos los siguientes atributos?</h1>
    </div>
    <div class="form_fields matrix_content matrix_single">
      <ul class="cols-5">
        <li class="question_row header"><span class="question" style="max-width: calc( (100% / (5 + 1) ) - 1em);"></span><span class="answer" style="max-width: calc( (100% / (5 + 1) ) - 1em);">Muy por debajo del promedio</span><span class="answer" style="max-width: calc( (100% / (5 + 1) ) - 1em);">Por debajo del promedio</span><span class="answer" style="max-width: calc( (100% / (5 + 1) ) - 1em);">Promedio</span><span class="answer" style="max-width: calc( (100% / (5 + 1) ) - 1em);">Por encima del promedio</span><span class="answer" style="max-width: calc( (100% / (5 + 1) ) - 1em);">Muy por encima del promedio</span></li>
        <li class="question_row"><span class="question" style="max-width: calc( (100% / (5 + 1) ) - 1em);">Experiencia de servicio al cliente</span><span class="answer" style="max-width: calc( (100% / (5 + 1) ) - 1em);"><input class="js_quizz_radio_button" data-next="1" data-adds-extra-text="0" type="radio" value="103622" name="participation[promo_response_attributes][response_36203_matrix_question_20]" id="participation_promo_response_attributes_response_36203_matrix_question_20_103622"></span><span class="answer" style="max-width: calc( (100% / (5 + 1) ) - 1em);"><input class="js_quizz_radio_button" data-next="1" data-adds-extra-text="0" type="radio" value="103623" name="participation[promo_response_attributes][response_36203_matrix_question_20]" id="participation_promo_response_attributes_response_36203_matrix_question_20_103623"></span><span class="answer" style="max-width: calc( (100% / (5 + 1) ) - 1em);"><input class="js_quizz_radio_button" data-next="1" data-adds-extra-text="0" type="radio" value="103624" name="participation[promo_response_attributes][response_36203_matrix_question_20]" id="participation_promo_response_attributes_response_36203_matrix_question_20_103624"></span><span class="answer" style="max-width: calc( (100% / (5 + 1) ) - 1em);"><input class="js_quizz_radio_button" data-next="1" data-adds-extra-text="0" type="radio" value="103625" name="participation[promo_response_attributes][response_36203_matrix_question_20]" id="participation_promo_response_attributes_response_36203_matrix_question_20_103625"></span><span class="answer" style="max-width: calc( (100% / (5 + 1) ) - 1em);"><input class="js_quizz_radio_button" data-next="1" data-adds-extra-text="0" type="radio" value="103626" name="participation[promo_response_attributes][response_36203_matrix_question_20]" id="participation_promo_response_attributes_response_36203_matrix_question_20_103626"></span></li>
        <li class="question_row"><span class="question" style="max-width: calc( (100% / (5 + 1) ) - 1em);">La entrega a tiempo de servicio</span><span class="answer" style="max-width: calc( (100% / (5 + 1) ) - 1em);"><input class="js_quizz_radio_button" data-next="1" data-adds-extra-text="0" type="radio" value="103622" name="participation[promo_response_attributes][response_36203_matrix_question_21]" id="participation_promo_response_attributes_response_36203_matrix_question_21_103622"></span><span class="answer" style="max-width: calc( (100% / (5 + 1) ) - 1em);"><input class="js_quizz_radio_button" data-next="1" data-adds-extra-text="0" type="radio" value="103623" name="participation[promo_response_attributes][response_36203_matrix_question_21]" id="participation_promo_response_attributes_response_36203_matrix_question_21_103623"></span><span class="answer" style="max-width: calc( (100% / (5 + 1) ) - 1em);"><input class="js_quizz_radio_button" data-next="1" data-adds-extra-text="0" type="radio" value="103624" name="participation[promo_response_attributes][response_36203_matrix_question_21]" id="participation_promo_response_attributes_response_36203_matrix_question_21_103624"></span><span class="answer" style="max-width: calc( (100% / (5 + 1) ) - 1em);"><input class="js_quizz_radio_button" data-next="1" data-adds-extra-text="0" type="radio" value="103625" name="participation[promo_response_attributes][response_36203_matrix_question_21]" id="participation_promo_response_attributes_response_36203_matrix_question_21_103625"></span><span class="answer" style="max-width: calc( (100% / (5 + 1) ) - 1em);"><input class="js_quizz_radio_button" data-next="1" data-adds-extra-text="0" type="radio" value="103626" name="participation[promo_response_attributes][response_36203_matrix_question_21]" id="participation_promo_response_attributes_response_36203_matrix_question_21_103626"></span></li>
        <li class="question_row"><span class="question" style="max-width: calc( (100% / (5 + 1) ) - 1em);">Profesionalismo</span><span class="answer" style="max-width: calc( (100% / (5 + 1) ) - 1em);"><input class="js_quizz_radio_button" data-next="1" data-adds-extra-text="0" type="radio" value="103622" name="participation[promo_response_attributes][response_36203_matrix_question_22]" id="participation_promo_response_attributes_response_36203_matrix_question_22_103622"></span><span class="answer" style="max-width: calc( (100% / (5 + 1) ) - 1em);"><input class="js_quizz_radio_button" data-next="1" data-adds-extra-text="0" type="radio" value="103623" name="participation[promo_response_attributes][response_36203_matrix_question_22]" id="participation_promo_response_attributes_response_36203_matrix_question_22_103623"></span><span class="answer" style="max-width: calc( (100% / (5 + 1) ) - 1em);"><input class="js_quizz_radio_button" data-next="1" data-adds-extra-text="0" type="radio" value="103624" name="participation[promo_response_attributes][response_36203_matrix_question_22]" id="participation_promo_response_attributes_response_36203_matrix_question_22_103624"></span><span class="answer" style="max-width: calc( (100% / (5 + 1) ) - 1em);"><input class="js_quizz_radio_button" data-next="1" data-adds-extra-text="0" type="radio" value="103625" name="participation[promo_response_attributes][response_36203_matrix_question_22]" id="participation_promo_response_attributes_response_36203_matrix_question_22_103625"></span><span class="answer" style="max-width: calc( (100% / (5 + 1) ) - 1em);"><input class="js_quizz_radio_button" data-next="1" data-adds-extra-text="0" type="radio" value="103626" name="participation[promo_response_attributes][response_36203_matrix_question_22]" id="participation_promo_response_attributes_response_36203_matrix_question_22_103626"></span></li>
        <li class="question_row"><span class="question" style="max-width: calc( (100% / (5 + 1) ) - 1em);">La experiencia de compra</span><span class="answer" style="max-width: calc( (100% / (5 + 1) ) - 1em);"><input class="js_quizz_radio_button" data-next="1" data-adds-extra-text="0" type="radio" value="103622" name="participation[promo_response_attributes][response_36203_matrix_question_23]" id="participation_promo_response_attributes_response_36203_matrix_question_23_103622"></span><span class="answer" style="max-width: calc( (100% / (5 + 1) ) - 1em);"><input class="js_quizz_radio_button" data-next="1" data-adds-extra-text="0" type="radio" value="103623" name="participation[promo_response_attributes][response_36203_matrix_question_23]" id="participation_promo_response_attributes_response_36203_matrix_question_23_103623"></span><span class="answer" style="max-width: calc( (100% / (5 + 1) ) - 1em);"><input class="js_quizz_radio_button" data-next="1" data-adds-extra-text="0" type="radio" value="103624" name="participation[promo_response_attributes][response_36203_matrix_question_23]" id="participation_promo_response_attributes_response_36203_matrix_question_23_103624"></span><span class="answer" style="max-width: calc( (100% / (5 + 1) ) - 1em);"><input class="js_quizz_radio_button" data-next="1" data-adds-extra-text="0" type="radio" value="103625" name="participation[promo_response_attributes][response_36203_matrix_question_23]" id="participation_promo_response_attributes_response_36203_matrix_question_23_103625"></span><span class="answer" style="max-width: calc( (100% / (5 + 1) ) - 1em);"><input class="js_quizz_radio_button" data-next="1" data-adds-extra-text="0" type="radio" value="103626" name="participation[promo_response_attributes][response_36203_matrix_question_23]" id="participation_promo_response_attributes_response_36203_matrix_question_23_103626"></span></li>
        <li class="question_row"><span class="question" style="max-width: calc( (100% / (5 + 1) ) - 1em);">Calidad del servicio</span><span class="answer" style="max-width: calc( (100% / (5 + 1) ) - 1em);"><input class="js_quizz_radio_button" data-next="1" data-adds-extra-text="0" type="radio" value="103622" name="participation[promo_response_attributes][response_36203_matrix_question_24]" id="participation_promo_response_attributes_response_36203_matrix_question_24_103622"></span><span class="answer" style="max-width: calc( (100% / (5 + 1) ) - 1em);"><input class="js_quizz_radio_button" data-next="1" data-adds-extra-text="0" type="radio" value="103623" name="participation[promo_response_attributes][response_36203_matrix_question_24]" id="participation_promo_response_attributes_response_36203_matrix_question_24_103623"></span><span class="answer" style="max-width: calc( (100% / (5 + 1) ) - 1em);"><input class="js_quizz_radio_button" data-next="1" data-adds-extra-text="0" type="radio" value="103624" name="participation[promo_response_attributes][response_36203_matrix_question_24]" id="participation_promo_response_attributes_response_36203_matrix_question_24_103624"></span><span class="answer" style="max-width: calc( (100% / (5 + 1) ) - 1em);"><input class="js_quizz_radio_button" data-next="1" data-adds-extra-text="0" type="radio" value="103625" name="participation[promo_response_attributes][response_36203_matrix_question_24]" id="participation_promo_response_attributes_response_36203_matrix_question_24_103625"></span><span class="answer" style="max-width: calc( (100% / (5 + 1) ) - 1em);"><input class="js_quizz_radio_button" data-next="1" data-adds-extra-text="0" type="radio" value="103626" name="participation[promo_response_attributes][response_36203_matrix_question_24]" id="participation_promo_response_attributes_response_36203_matrix_question_24_103626"></span></li>
        <li class="question_row"><span class="question" style="max-width: calc( (100% / (5 + 1) ) - 1em);">Comprensión de las necesidades de los clientes</span><span class="answer" style="max-width: calc( (100% / (5 + 1) ) - 1em);"><input class="js_quizz_radio_button" data-next="1" data-adds-extra-text="0" type="radio" value="103622" name="participation[promo_response_attributes][response_36203_matrix_question_25]" id="participation_promo_response_attributes_response_36203_matrix_question_25_103622"></span><span class="answer" style="max-width: calc( (100% / (5 + 1) ) - 1em);"><input class="js_quizz_radio_button" data-next="1" data-adds-extra-text="0" type="radio" value="103623" name="participation[promo_response_attributes][response_36203_matrix_question_25]" id="participation_promo_response_attributes_response_36203_matrix_question_25_103623"></span><span class="answer" style="max-width: calc( (100% / (5 + 1) ) - 1em);"><input class="js_quizz_radio_button" data-next="1" data-adds-extra-text="0" type="radio" value="103624" name="participation[promo_response_attributes][response_36203_matrix_question_25]" id="participation_promo_response_attributes_response_36203_matrix_question_25_103624"></span><span class="answer" style="max-width: calc( (100% / (5 + 1) ) - 1em);"><input class="js_quizz_radio_button" data-next="1" data-adds-extra-text="0" type="radio" value="103625" name="participation[promo_response_attributes][response_36203_matrix_question_25]" id="participation_promo_response_attributes_response_36203_matrix_question_25_103625"></span><span class="answer" style="max-width: calc( (100% / (5 + 1) ) - 1em);"><input class="js_quizz_radio_button" data-next="1" data-adds-extra-text="0" type="radio" value="103626" name="participation[promo_response_attributes][response_36203_matrix_question_25]" id="participation_promo_response_attributes_response_36203_matrix_question_25_103626"></span></li>
      </ul>
    </div>
  </div>
  <!-- - class=row -->
</div>


<?php
	}

}
