<?php
namespace App\Controller\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use App\Validator\CampusValidator;
use Ujpef\LatteView;
use Slim\Exception\HttpForbiddenException;
//use App\Database\CampusInfrastructure;
use App\Infrastructure\Database\CampusInfrastructure;

class CampusController{
    private $container;
    private CampusInfrastructure $infrastructure;
    
    public function __construct(CampusInfrastructure $infrastructure, Container $container){
        $this->infrastructure = $infrastructure;
        $this->container = $container;
    }

    public function get(Request $request, Response $response, array $args): Response
    {
        $response->getBody()->write($this->infrastructure->get($args['id'])['nombre']);
        return $response;
    }

    public function getAll(Request $request, Response $response): Response
    {
        var_dump($this->infrastructure->selectAll());
        return $response;
    }
/*
    public function saveForm(Request $request, Response $response, array $args){
        // Simula que la lógica de negocios valida el id
        $id = (int) $args['id'];
        if($id > 5) {
            throw new HttpForbiddenException($request);
        }
        return $this->container->get(LatteView::class)->render($response, 'Campus/campus.latte', [
            'id' => $id,
        ]);
    }

    public function register(Request $request, Response $response, array $args){
        $resultData = [];
        
        $data = (array)$request->getParsedBody();
        $campusVal = $this->container->get(CampusValidator::class);
        
        $validationResult = $campusVal->validateSaveCampus($data, $resultData);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Campus/campusvalidation.latte',
            ['validacion_exitosa' => $validationResult, 'result' => $resultData]
        );
    }

    public function searchForm(Request $request, Response $response, array $args){
        // Simula que la lógica de negocios valida el id
        $id = (int) $args['id'];
        if($id > 5) {
            throw new HttpForbiddenException($request);
        }
        return $this->container->get(LatteView::class)->render($response, 'Campus/campus.latte', [
            'id' => $id,
        ]);
    }

    public function search(Request $request, Response $response, array $args){
        $resultData = [];
        
        $data = array("name" => $args['name']);
        
        $campusVal = $this->container->get(CampusValidator::class);
        
        $validationResult = $campusVal->ValidateSearch($data, $resultData);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Campus/campusvalidation.latte',
            ['validacion_exitosa' => $validationResult] + $resultData
        );
    }

    public function show(Request $request, Response $response, array $args){
        $campusInfrastructure = $this->container->get(CampusInfrastructure::class);
        $dataCampuses = $campusInfrastructure->selectShowAllCampuses();
        
        return $this->container->get(LatteView::class)->render(
            $response,
            'Campus/campusTable.latte',
            ['all_campuses_information' => $dataCampuses]
        );
    }

    public function update(Request $request, Response $response, array $args){
        $resultData = [];
        
        $data = (array)$request->getParsedBody();
        $campusVal = $this->container->get(CampusValidator::class);
        
        $validationResult = $campusVal->ValidateUpdate($data, $resultData);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Campus/campusvalidation.latte',
            ['validacion_exitosa' => $validationResult] + $resultData
        );
    }

    public function delete(Request $request, Response $response, array $args){
        $code = $args['code'];
        $response->getBody()->write("$code");
        return $response;
    }
*/
}