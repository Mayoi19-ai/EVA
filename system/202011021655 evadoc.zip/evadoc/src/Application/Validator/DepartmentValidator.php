<?php
namespace App\Validator;
use Rakit\Validation\Validator;

class DepartmentValidator{
    private Validator $validator;

    public function __construct(Validator $validator) {
        $this->validator = $validator;
    }

    public function validateSaveDepartment(array $data, array &$resultData): bool {
        $validationRules = [
            'code'          =>  'required|numeric|digits_between:3,3',
            'name'          =>  'required|alpha_spaces|uppercase',
        ];

        $errorMessages = [
            'code:required'       => 'La clave es obligatoria',
            'code:numeric'        => 'La clave solo acepta números',
            'code:digits_between' => 'La clave debe tener 3 digitos',
            'name:required'       => 'El nombre es obligatorio',
            'name:alpha_spaces'   => 'El nombre no es válido',
            'name:uppercase'      => 'El nombre debe de estar en mayúsculas',
        ];

        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data, $resultData);
    }

    public function validateFindDepartment(array $data, array &$resultData): bool {
        $validationRules = [
            'code'          =>  'required|numeric|digits_between:3,3',
        ];

        $errorMessages = [
            'code:required'       => 'La clave es obligatoria',
            'code:numeric'        => 'La clave solo acepta números',
            'code:digits_between' => 'La clave debe tener 3 digitos',
        ];

        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data, $resultData);
    }
}