<?php
namespace App\Temporary;

use Medoo\Medoo;

class SIETables {
    private Medoo $db;

    public function __construct(Medoo $db) {
        $this->db = $db;
    }

    public function createDdep(array $ddepData) {
        $ddep = 'CREATE TEMPORARY TABLE IF NOT EXISTS ddep (
                    cve INT(3) UNSIGNED NOT NULL,
                    nom VARCHAR(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
                    nco VARCHAR(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
                    PRIMARY KEY (cve))
                ENGINE = InnoDB
                DEFAULT CHARACTER SET = utf8mb4;';

        $sth = $this->db->pdo->exec($ddep);

        foreach ($ddepData as $row){
            $cve = $row['DEP_CVE'];
            $nom = $row['DEP_NOM'];
            $nco = $row['DEP_NCO'];

            $register = $this->db->pdo->prepare("INSERT INTO ddep (cve, nom, nco) VALUES (:cve, :nom, :nco);");
            $register->bindParam(':cve', $cve);
            $register->bindParam(':nom', $nom;
            $register->bindParam(':nco', $nco);
        }
    }

    public function createDesp(array $despData) {
        $desp = 'CREATE TABLE IF NOT EXISTS desp (
                    id INT(10) UNSIGNED NOT NULL,
                    nom VARCHAR(250) NOT NULL,
                    nco VARCHAR(45) NOT NULL,
                    PRIMARY KEY (id))
                ENGINE = InnoDB
                AUTO_INCREMENT = 19
                DEFAULT CHARACTER SET = utf8mb4;';
        
        $sth = $this->db->pdo->exec($desp);

        foreach ($despData as $row){
            $id = $row['ESP']
            $nom = $row['ESP_NOM'];
            $nco = $row['ESP_NCO'];

            $register = $this->db->pdo->prepare("INSERT INTO desp (id, nom, nco) VALUES (:id, :nom, :nco);");
            $register->bindParam(':id', $id);
            $register->bindParam(':nom', $nom);
            $register->bindParam(':nco', $nco);
        }
    }

    public function createDret(array $dretData) {
        $dret = 'CREATE TEMPORARY TABLE IF NOT EXISTS dret (
                    cve CHAR(4) CHARACTER SET utf8mb4 COLLATE 
                    utf8mb4_spanish_ci NOT NULL,
                    nom VARCHAR(250) NOT NULL,
                    nco VARCHAR(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
                    PRIMARY KEY (cve))
                ENGINE = InnoDB
                DEFAULT CHARACTER SET = utf8mb4;';

        $sth = $this->db->pdo->exec($dret);

        foreach ($dretData as $row){
            $cve = $row['RET_CVE'];
            $nom = $row['RET_NOM'];
            $nco = $row['RET_NCO'];

            $register = $this->db->pdo->prepare("INSERT INTO dret (cve, nom, nco) VALUES (:cve, :nom, :nco);");
            $register->bindParam(':cve', $cve);
            $register->bindParam(':nom', $nom);
            $register->bindParam('nco', $nco);
        }
    }

    public function createGpo(array $gpoData) {
        $gpo = 'CREATE TEMPORARY TABLE IF NOT EXISTS grupo (
                    cve CHAR(4) CHARACTER SET utf8mb4 COLLATE 
                    utf8mb4_spanish_ci NOT NULL,
                    nombre CHAR(5) NOT NULL,
                    PRIMARY KEY (cve))
                    ENGINE = InnoDB;';

        $sth = $this->db->pdo->exec($gpo);

        foreach ($dretData as $row){
            $cve = $row['cve'];
            $nombre = $row['nombre'];

            $register = $this->db->pdo->prepare("INSERT INTO grupo (cve, nombre) VALUES (:cve, :nombre);");
            $register->bindParam(':cve', $cve);
            $register->bindParam(':nombre', $nombre);
        }
    }

    public function createDalu(array $daluData) {
        $dalu = 'CREATE TABLE IF NOT EXISTS dalu (
                    ctr CHAR(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
                    nom VARCHAR(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
                    esp INT(10) UNSIGNED NOT NULL,
                    sem TINYINT(12) UNSIGNED NOT NULL,
                PRIMARY KEY (ctr),
                INDEX FK_dalu_especialidad (esp ASC) VISIBLE,
                CONSTRAINT FK_dalu_especialidad
                    FOREIGN KEY (esp)
                    REFERENCES desp (id))
                ENGINE = InnoDB
                DEFAULT CHARACTER SET = utf8mb4;';

        $sth = $this->db->pdo->exec($dalu);

        foreach($daluData as $row){
            $ctr = $row['ALU_CTR'];
            $nom = $row['ALU_NOM'];
            $esp = $row['ALU_ESP'];
            $sem = $row['ALU_SEM'];

            $register = $this->db->pdo->prepare("INSERT INTO dalu (ctr, nom, esp, sem) VALUES (:ctr, :nom, :esp, :sem);");
            $register->bindParam(':ctr', $ctr);
            $register->bindParam(':nom', $nom);
            $register->bindParam(':esp', $esp);
            $register->bindParam(':sem', $sem);
        }
    }

    public function createDcat(array $dcatData) {
        $dcat = 'CREATE TEMPORARY TABLE IF NOT EXISTS dcat (
                    cve INT(3) UNSIGNED NOT NULL,
                    dep INT(3) UNSIGNED NOT NULL,
                    nom VARCHAR(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
                    PRIMARY KEY (cve),
                    INDEX FK_dcat_ddep (dep ASC),
                    CONSTRAINT FK_dcat_ddep
                        FOREIGN KEY (dep)
                        REFERENCES ddep (cve))
                ENGINE = InnoDB
                DEFAULT CHARACTER SET = utf8mb4;';

        $sth = $this->db->pdo->exec($dcat);

        foreach($dcatData as $row){
            $cve = $row['CAT_CVE'];
            $dep = $row['CAT_DEP'];
            $nom = $row['CAT_NOM'];

            $register = $this->db->pdo->prepare("INSERT INTO dcat (cve, dep, nom) VALUES (:cve, :dep, :nom);");
            $register->bindParam(':cve', $cve);
            $register->bindParam(':dep', $dep);
            $register->bindParam(':nom', $nom);
        }
    }

    public function createDgau(array $dgauData) {
        $dgau = 'CREATE TEMPORARY TABLE IF NOT EXISTS dgau (
                    gpo CHAR(4) CHARACTER SET utf8mb4 COLLATE 
                    utf8mb4_spanish_ci NOT NULL,
                    cat INT(3) UNSIGNED NOT NULL,
                    mat CHAR(4) CHARACTER SET utf8mb4 COLLATE 
                    utf8mb4_spanish_ci NOT NULL,
                    INDEX FK_dgau_dcat (cat ASC),
                    INDEX FK_dgau_grupo_idx (gpo ASC),
                    INDEX FK_dgau_dret_idx (mat ASC),
                    CONSTRAINT FK_dgau_dcat
                        FOREIGN KEY (cat)
                        REFERENCES dcat (cve),
                    CONSTRAINT FK_dgau_grupo
                        FOREIGN KEY (gpo)
                        REFERENCES grupo (cve)
                        ON DELETE NO ACTION
                        ON UPDATE NO ACTION,
                    CONSTRAINT FK_dgau_dret
                        FOREIGN KEY (mat)
                        REFERENCES dret (cve)
                        ON DELETE NO ACTION
                        ON UPDATE NO ACTION)
                ENGINE = InnoDB
                DEFAULT CHARACTER SET = utf8mb4;';

        $sth = $this->db->pdo->exec($dgau);

        foreach($dgauData as $row){
            $gpo = $row['GPO_GPO'];
            $cat = $row['GPO_CAT'];
            $mat = $row['GPO_MAT'];

            $register = $this->db->pdo->prepare("INSERT INTO dgau (gpo, cat, mat) VALUES (:gpo, :cat, :mat);");
            $register->bindParam(':gpo', $gpo);
            $register->bindParam(':cat', $cat);
            $register->bindParam(':mat', $mat);
        }
    }

    public function createDlis(array $dlisData) {
        $dlis = 'CREATE TEMPORARY TABLE IF NOT EXISTS dlis (
                    ctr CHAR(8) CHARACTER SET utf8mb4 COLLATE 
                    utf8mb4_spanish_ci NOT NULL,
                    gpo CHAR(4) CHARACTER SET utf8mb4 COLLATE 
                    utf8mb4_spanish_ci NOT NULL,
                    mat CHAR(4) CHARACTER SET utf8mb4 COLLATE 
                    utf8mb4_spanish_ci NOT NULL,
                    INDEX FK_dlis_dalu (ctr ASC),
                    INDEX FK_dlis_dgau_idx (gpo ASC, mat ASC),
                    CONSTRAINT FK_dlis_dalu
                        FOREIGN KEY (ctr)
                        REFERENCES dalu (ctr),
                    CONSTRAINT FK_dlis_dgau
                        FOREIGN KEY (gpo , mat)
                        REFERENCES dgau (gpo , mat)
                        ON DELETE NO ACTION
                        ON UPDATE NO ACTION)
                ENGINE = InnoDB
                DEFAULT CHARACTER SET = utf8mb4;';
        
        $sth = $this->db->pdo->exec($dlis);

        foreach($dlisData as $row){
            $ctr = $row['LIS_CTR'];
            $gpo = $row['LIS_GPO'];
            $mat = $row['LIS_MAT'];

            $register = $this->db->pdo->prepare("INSERT INTO grupo (ctr, gpo, mat) VALUES (:ctr, :gpo, :mat);");
            $register->bindParam(':ctr', $ctr);
            $register->bindParam(':gpo', $gpo);
            $register->bindParam(':mat', $mat);
        }
    }
}