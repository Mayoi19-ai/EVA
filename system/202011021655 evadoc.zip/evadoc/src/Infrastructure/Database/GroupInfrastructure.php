<?php
namespace App\Database;

use Medoo\Medoo;
use Psr\Container\ContainerInterface;

class GroupInfrastructure{
    private Medoo $db;
    private ContainerInterface $container;

    public function __construct(Medoo $db, ContainerInterface $container) {
        $this->db = $db;
        $this->container = $container;
    }

    public function insertGroup(array $groupData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $group = $databaseInfra['group'];

        $data = $this->db->insert($group['table'], [
            $group['name'] => $name, 
            $group['periodId'] => $periodId, 
            $group['careerId'] => $careerId, 
            $group['modalityId'] => $modalityId, 
            $group['campusId'] => $campusId]
        );

        return $data;
    }

    public function selectShowAllGroups(): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $group = $databaseInfra['group'];

        $data = $this->db->select($group['table'], [
            $group['name'], 
            $group['periodId'], 
            $group['careerId'], 
            $group['modalityId'], 
            $group['campusId']]
        );

        return $data;
    }

    public function selectOneGroup(array $groupData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $group = $databaseInfra['group'];

        $data = $this->db->select($group['table'], [
            $group['name'], 
            $group['periodId'], 
            $group['careerId'], 
            $group['modalityId'], 
            $group['campusId']], [
                $group['name'] => $name]
            );

        return $data;
    }

    public function updateGroup(array $groupData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $group = $databaseInfra['group'];

        $data = $this->db->update($group['table'], [
            $group['name'] => $name, 
            $group['periodId'] => $periodId, 
            $group['careerId'] => $careerId, 
            $group['modalityId'] => $modalityId, 
            $group['campusId'] => $campusId], [
                $group['name'] => $name]
            );
            
        return $data;
    }
    
    public function deleteGroup(array $groupData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $group = $databaseInfra['group'];

        $data = $this->db->delete($group['table'], [
            "AND" => [
                $group['name'] => $name, 
                $group['periodId'] => $periodId]]
            );
            
        return $data;
    }
}