<?php
namespace App\Infrastructure\Database;

use Medoo\Medoo;
use Psr\Container\ContainerInterface;
use App\Infrastructure\Database\DatabaseTrait;


class CampusInfrastructure {
    use DatabaseTrait;

    private Medoo $db;
    private array $tables;
    private ContainerInterface $container;

    public function __construct(Medoo $db, ContainerInterface $container) {
        $this->db = $db;
        $this->tables = $container->get('settings')['database/tables'];
        $this->container = $container;
    }

    public function get(int $id): array {
        $table = $this->translateTable('campus');
        $where = array_combine($table['id'], [$id]);

        return $this->db->get($table['name'], $table['fields'], $where);
    }

    public function selectAll(): array {
        $table = $this->translateTable('campus');
        return $this->db->select($table['name'], $table['fields'], []);
    }

    public function insert(array $data): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $campus = $databaseInfra['campus'];

        $data = $this->db->insert($campus['table'],[
            $campus['name'] => $campusName]
        );

        return $data;
    }

    public function selectShowAllCampuses(): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $campus = $databaseInfra['campus'];

        $data = $this->db->select($campus['table'], [
            $campus['name']]
        );

        $emptyData = new EmptyData($this->db);
        return $emptyData->emptyData($data);
        //$emptyData = new EmptyData();
        //return $emptyData->emptyData($this->db, $data);
        //return $data;
    }

    public function selectOneCampus(array $campusData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $campus = $databaseInfra['campus'];

        $data = $this->db->select($campus['table'], [
            $campus['name']], [
                $campus['name'] => $campusName]
            );

        return $data;
    }

    public function updateCampus(array $campusData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $campus = $databaseInfra['campus'];

        $data = $this->db->update($campus['table'], [
            $campus['name'] => $campusName], [
                $campus['id'] => $campusId]
            );

        return $data;
    }
    
    public function deleteCampus(array $campusData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $campus = $databaseInfra['campus'];
        
        $data = $this->db->delete($campus['table'], [
            $campus['id'] => $campusId]
        );
        
        return $data;
    }
}