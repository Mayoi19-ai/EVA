<?php
namespace App\Database;

use Medoo\Medoo;
use Psr\Container\ContainerInterface;

class ModalityInfrastructure{
    private Medoo $db;
    private ContainerInterface $container;

    public function __construct(Medoo $db, ContainerInterface $container) {
        $this->db = $db;
        $this->container = $container;
    }

    public function insertModality(array $modalityData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $modality = $databaseInfra['modality'];

        $data = $this->db->insert($modality['table'],[
            $modality['name'] => $modalityName]
        );

        return $data;
    }

    public function selectShowAllModalities(): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $modality = $databaseInfra['modality'];

        $data = $this->db->select($modality['table'],[
            $modality['name'] => $modalityName]
        );

        return $data;
    }

    public function selectOneModality(array $modalityData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $modality = $databaseInfra['modality'];

        $data = $this->db->select($modality['table'], [
            $modality['name'] => $modalityName], [
                $modality['name'] => $modalityName]
            );

        return $data;
    }

    public function updateModality(array $modalityData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $modality = $databaseInfra['modality'];

        $data = $this->db->update($modality['table'], [
            $modality['name'] => $modalityName], [
                $modality['id'] => $modalityId]
            );

        return $data;
    }
    
    public function deleteModality(array $modalityData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $modality = $databaseInfra['modality'];

        $data = $this->db->delete($modality['table'], [
            $modality['id'] => $modalityId]
        );
        
        return $data;
    }
}