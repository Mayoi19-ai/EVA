<?php
namespace App\Database;

use Medoo\Medoo;

class EmptyData {
    protected Medoo $db;
    public function __construct(Medoo $db){
        $this->db = $db;
    }

    public function emptyData(array &$data): array
    {
        if(empty($data)){
            $data = array( array("noFound" => "No hay registros"));

        }elseif(empty($this->db->error())){
            $data = $this->db->error();
        }
        print_r($data);
        return $data;
    }
}

  /*public function emptyData(array &$data): array
    {
        if(empty($data)){
            //$data = array( array("noFound" => "No hay registros"));
            $dbError = $this->db->error();
            if(empty($dbError)){
                $data = array( array("noFound" => "No hay registros"));
            } else {
                $data = $dbError;
            }
        }
        print_r($data);
        return $data;
    }*/