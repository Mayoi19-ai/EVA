<?php
namespace App\Infrastructure\Database;

trait DatabaseTrait {

    public function translateTable (string $name): array
    {
        $table = $this->tables['campus'];
        $name = $table['name'];
        $id = is_array($table['id']) ? $table['id'] : [$table['id']];
        $fields = array_merge($id, array_values($table['fields']));
        return ['name' => $name, 'id' => $id, 'fields' => $fields];
    }

}