<?php
namespace App\Database;

use Medoo\Medoo;
use Psr\Container\ContainerInterface;

class TeacherInfrastructure{
    private Medoo $db;
    private ContainerInterface $container;

    public function __construct(Medoo $db, ContainerInterface $container) {
        $this->db = $db;
        $this->container = $container;
    }

    public function insertTeacher(array $teacherData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $teacher = $databaseInfra['teacher'];

        $data = $this->db->insert($teacher['table'],[
            $teacher['code'] => $teacherCode, 
            $teacher['name'] => $teacherName, 
            $teacher['departmentCode'] => $departmentCode]
        );

        return $data;
    }

    public function selectShowAllTeachers(): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $teacher = $databaseInfra['teacher'];

        $data = $this->db->select($teacher['table'],[
            $teacher['code'], 
            $teacher['name'], 
            $teacher['departmentCode']]
        );

        return $data;
    }

    public function selectOneTeacher(array $teacherData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $teacher = $databaseInfra['teacher'];

        $data = $this->db->select($teacher['table'], [
            $teacher['code'], 
            $teacher['name'], 
            $teacher['departmentCode']], [
                $teacher['name'] => $teacherName]
            );

        return $data;
    }

    public function updateTeacher(array $teacherData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $teacher = $databaseInfra['teacher'];

        $data = $this->db->update($teacher['table'], [
            $teacher['code'], 
            $teacher['name'], 
            $teacher['departmentCode']], [
                $teacher['code'] => $teacherCode]
            );

        return $data;
    }
    
    public function deleteTeacher(array $teacherData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $teacher = $databaseInfra['teacher'];

        $data = $this->db->delete($teacher['table'], [
            $teacher['code'] => $teacherCode]
        );
        
        return $data;
    }
}