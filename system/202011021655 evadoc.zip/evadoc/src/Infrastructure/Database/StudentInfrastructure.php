<?php
namespace App\Database;

use Medoo\Medoo;
use Psr\Container\ContainerInterface;

class StudentInfrastructure{
    private Medoo $db;
    private ContainerInterface $container;

    public function __construct(Medoo $db, ContainerInterface $container) {
        $this->db = $db;
        $this->container = $container;
    }

    public function insertStudent(array $studentData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $student = $databaseInfra['student'];

        $data = $this->db->insert($student['table'],[
            $student['code'] => $studentCode, 
            $student['name'] => $studentName,
            $student['password'] => $studentPassword]
        );

        return $data;
    }

    public function selectShowAllStudents(): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $student = $databaseInfra['student'];

        $data = $this->db->select($student['table'],[
            $student['code'],
            $student['name']]
        );

        return $data;
    }

    public function selectOneStudent(array $studentData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $student = $databaseInfra['student'];

        $data = $this->db->select($student['table'],[
            $student['code'],
            $student['name']], [
                $student['code'] => $studentCode]
            );

        return $data;
    }

    public function updateStudent(array $studentData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $student = $databaseInfra['student'];

        $data = $this->db->update($student['table'],[
            $student['code'] => $studentCode, 
            $student['name'] => $studentName],[
                $student['code'] => $studentCode]
            );

        return $data;
    }
    
    public function deleteStudent(array $studentData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $student = $databaseInfra['student'];

        $data = $this->db->delete($student['table'], [
                $student['code'] => $studentCode]
        );
        
        return $data;
    }
}