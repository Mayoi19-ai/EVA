<?php
// source: Menus/principalmenu.latte

use Latte\Runtime as LR;

class Templatea8f7f115fc extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 5 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
     
</head>
<body>
<nav>  
  <ul id="slide-out" class="sidenav">
    <li><div class="user-view">
      <div class="background">
      </div>
    <img src="\materialize\Recursos\itshlogo.png">
    </div></li>
<!--Menu desplegable-->
        <ul class="collapsible collapsible-accordion">
          <li>
            <a class="collapsible-header">Alumno</a>
            <div class="collapsible-body">
              <ul>
                <li><a href="/panel/student/show/1">Buscar</a></li>
                <li><a href="/panel/student/save-form/1">Registrar</a></li>
                <li><a href="#!">Eliminar</a></li>
              </ul>
            </div>
          </li>
          <li>
            <a class="collapsible-header">Docente</a>
            <div class="collapsible-body">
              <ul>
                <li><a href="/panel/teacher/show/1">Buscar</a></li>
                <li><a href="/panel/teacher/save-form/1">Registrar</a></li>
                <li><a href="#!">Eliminar</a></li>
              </ul>
            </div>
          </li>
          <li>
            <a class="collapsible-header">Materia</a>
            <div class="collapsible-body">
              <ul>
                <li><a href="/panel/subject/show/1">Buscar</a></li>
                <li><a href="/panel/subject/save-form/1">Registrar</a></li>
                <li><a href="#!">Eliminar</a></li>
              </ul>
            </div>
          </li>
          <li>
            <a class="collapsible-header">Grupo</a>
            <div class="collapsible-body">
              <ul>
                <li><a href="/panel/group/show/1">Buscar</a></li>
                <li><a href="/panel/group/save-form/1">Registrar</a></li>
                <li><a href="#!">Eliminar</a></li>
              </ul>
            </div>
          </li>
          <li>
            <a class="collapsible-header">Curso</a>
            <div class="collapsible-body">
              <ul>
                <li><a href="/panel/course/show/1">Buscar</a></li>
                <li><a href="/panel/course/save-form/1">Registrar</a></li>
                <li><a href="#!">Eliminar</a></li>
              </ul>
            </div>
          </li>
          <li>
            <a class="collapsible-header">Inscripcion</a>
            <div class="collapsible-body">
              <ul>
                <li><a href="/panel/inscription/show/1">Buscar</a></li>
                <li><a href="/panel/inscription/save-form/1">Registrar</a></li>
                <li><a href="#!">Eliminar</a></li>
              </ul>
            </div>
          </li>
          <li>
            <a class="collapsible-header">Campus</a>
            <div class="collapsible-body">
              <ul>
                <li><a href="/panel/campus/show/1">Buscar</a></li>
                <li><a href="/panel/campus/save-form/1">Registrar</a></li>
                <li><a href="#!">Eliminar</a></li>
              </ul>
            </div>
          </li> <!-- aqui -->
           <li>
            <a class="collapsible-header">Modalidad</a>
            <div class="collapsible-body">
              <ul>
                <li><a href="/panel/modality/show/1">Buscar</a></li>
                <li><a href="/panel/modality/save-form/1">Registrar</a></li>
                <li><a href="#!">Eliminar</a></li>
              </ul>
            </div>
          </li> <!-- aqui -->
           <li>
            <a class="collapsible-header">Periodo</a>
            <div class="collapsible-body">
              <ul>
                <li><a href="/panel/period/show/1">Buscar</a></li>
                <li><a href="/panel/period/save-form/1">Registrar</a></li>
                <li><a href="#!">Eliminar</a></li>
              </ul>
            </div>
          </li> <!-- aqui -->
           <li>
            <a class="collapsible-header">Carrera</a>
            <div class="collapsible-body">
              <ul>
                <li><a href="/panel/career/show/1">Buscar</a></li>
                <li><a href="/panel/career/save-form/1">Registrar</a></li>
                <li><a href="#!">Eliminar</a></li>
              </ul>
            </div>
          </li> <!-- aqui -->
           <li>
            <a class="collapsible-header">Asignatura</a>
            <div class="collapsible-body">
              <ul>
                <li><a href="/panel/lesson/show/1">Buscar</a></li>
                <li><a href="/panel/lesson/save-form/1">Registrar</a></li>
                <li><a href="#!">Eliminar</a></li>
              </ul>
            </div>
          </li> <!-- aqui -->
           <li>
            <a class="collapsible-header">Departamento</a>
            <div class="collapsible-body">
              <ul>
                <li><a href="/panel/department/show/1">Buscar</a></li>
                <li><a href="/panel/department/save-form/1">Registrar</a></li>
                <li><a href="#!">Eliminar</a></li>
              </ul>
            </div>
          </li> <!-- aqui -->
        </ul>
      </li>
    </ul>
  </nav>
    
    

    <a href="#" data-target="slide-out" class="sidenav-trigger"><i class="material-icons">menu</i></a>

<!--Fin menu desplegable -->
        
    <footer class="copyright"> 
    <script>
      M.AutoInit();
      </script>
        <p>Todos los derechos reservados, Gerardo y Raul 2020</p>
    </footer>
</body>
</html><?php
		return get_defined_vars();
	}

}
