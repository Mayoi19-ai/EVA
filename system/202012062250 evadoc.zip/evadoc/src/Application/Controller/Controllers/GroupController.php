<?php
namespace App\Controller\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use App\Validator\GroupValidator;
use Ujpef\LatteView;
use Slim\Exception\HttpForbiddenException;
use App\Database\GroupInfrastructure;

class GroupController{
    private $container;
    
    public function __construct(Container $container){
        $this->container = $container;
    }

    public function saveForm(Request $request, Response $response, array $args){
        // Simula que la lógica de negocios valida el id
        $id = (int) $args['id'];
        if($id > 5) {
            throw new HttpForbiddenException($request);
        }
        return $this->container->get(LatteView::class)->render($response, 'Grupo/group.latte', [
            'id' => $id,
        ]);
    }

    public function register(Request $request, Response $response, array $args){
        $resultData = [];
        
        $data = (array)$request->getParsedBody();
        $courseVal = $this->container->get(GroupValidator::class);
        
        $validationResult = $courseVal->validateSaveGroup($data, $resultData);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Grupo/groupvalidation.latte',
            ['validacion_exitosa' => $validationResult] + $resultData
        );
    }

    public function searchForm(Request $request, Response $response, array $args){
        // Simula que la lógica de negocios valida el id
        $id = (int) $args['id'];
        if($id > 5) {
            throw new HttpForbiddenException($request);
        }
        return $this->container->get(LatteView::class)->render($response, 'Grupo/group.latte', [
            'id' => $id,
        ]);
    }

    public function search(Request $request, Response $response, array $args){
        $resultData = [];
        
        $data = array("folio" => $args['folio']);
        
        $teacherVal = $this->container->get(TeacherValidator::class);
        
        $validationResult = $teacherVal->ValidateSearch($data, $resultData);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Maestros/validationteacher.latte',
            ['validacion_exitosa' => $validationResult] + $resultData
        );
    }

    public function show(Request $request, Response $response, array $args){
        $teacherInfraestructure = $this->container->get(TeacherInfrastructure::class);
        $dataTeacher = $teacherInfraestructure->selectDataTeacher();

        if(empty( $dataTeacher )) {
            $response->getBody()->write("No hay docentes registrados");
        }
        return $this->container->get(LatteView::class)->render(
            $response,
            'Grupo/groupTable.latte'
        );
    }

    public function update(Request $request, Response $response, array $args){
        $resultData = [];
        
        $data = (array)$request->getParsedBody();
        $teacherVal = $this->container->get(TeacherValidator::class);
        
        $validationResult = $teacherVal->ValidateUpdate($data, $resultData);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Maestros/validationteacher.latte',
            ['validacion_exitosa' => $validationResult] + $resultData
        );
    }

    public function delete(Request $request, Response $response, array $args){
        $name = $args['folio'];
        $response->getBody()->write("$name");
        return $response;
    }
}