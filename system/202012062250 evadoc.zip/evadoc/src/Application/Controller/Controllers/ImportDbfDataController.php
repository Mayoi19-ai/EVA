<?php
namespace App\Controller\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Slim\Exception\HttpForbiddenException;
use App\Infrastructure\TamporaryTables;
//use App\Infrastructure\DbfImport;
use App\Infrastructure\ExcelData;

class ImportDbfDataController {
    private ExcelData $import;
    private TamporaryTables $temporary;

    public function __construct(ExcelData $import, TamporaryTables $temporary) {
        $this->import = $import;
        $this->temporary = $temporary;
    }

    public function importAll(Request $request, Response $response, array $args){
        // Simula que la lógica de negocios valida el id
        $id = (int) $args['id'];
        if($id > 5) {
            throw new HttpForbiddenException($request);
        }
        $this->import->import();
        return $response;
    }
}