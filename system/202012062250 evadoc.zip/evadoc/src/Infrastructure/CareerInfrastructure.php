<?php
namespace App\Infrastructure;

use Medoo\Medoo;
use Psr\Container\ContainerInterface;

class CareerInfrastructure{
    private Medoo $db;
    private ContainerInterface $container;

    public function __construct(Medoo $db, ContainerInterface $container) {
        $this->db = $db;
        $this->container = $container;
    }

    public function insertCareer(array $careerData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $career = $databaseInfra['career'];

        $data = $this->db->insert($career['table'],[
            $career['code'] => $careerCode,
            $career['name'] => $careerName, 
            $career['shortName'] => $careerShortName]
        );

        return $data;
    }

    public function selectShowAllCareer(): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $career = $databaseInfra['career'];

        $data = $this->db->select($career['table'], [
            $career['code'], 
            $career['name'], 
            $career['shortName']]
        );

        return $data;
    }

    public function selectOneCareer(array $careerData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $career = $databaseInfra['career'];

        $data = $this->db->select($career['table'], [
            $career['code'], 
            $career['name'], 
            $career['shortName']], [
                $career['shortName'] => $careerShortName]
            );

        return $data;
    }

    public function updateCareer(array $careerData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $career = $databaseInfra['career'];

        $data = $this->db->update($career['table'], [
            $career['code'], 
            $career['name'], 
            $career['shortName']], [
                $career['id'] => $careerId]
            );

        return $data;
    }
    
    public function deleteCareer(array $careerData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $career = $databaseInfra['career'];
        
        $data = $this->db->delete($career['table'], [
            $career['id'] => $careerId]
        );
        
        return $data;
    }
}