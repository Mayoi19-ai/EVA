<?php
namespace App\Infrastructure;

use Medoo\Medoo;

class TamporaryTables {
    private Medoo $db;

    public function __construct(Medoo $db) {
        $this->db = $db;
    }

    public function desp() {
        $this->db->query("CREATE TEMPORARY TABLE IF NOT EXISTS `desp` (
            `cve` int(3) unsigned NOT NULL,
            `nom` varchar(250) COLLATE utf8mb4_spanish_ci NOT NULL,
            `nco` varchar(45) COLLATE utf8mb4_spanish_ci NOT NULL,
            PRIMARY KEY (`cve`)
          ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;");
    }

    public function ddep() {
        $this->db->query("CREATE TEMPORARY TABLE IF NOT EXISTS `ddep` (
            `cve` int(3) unsigned NOT NULL,
            `nom` varchar(250) COLLATE utf8mb4_spanish_ci NOT NULL,
            `nco` varchar(50) COLLATE utf8mb4_spanish_ci NOT NULL,
            PRIMARY KEY (`cve`)
          ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;");
    }

    public function dret () {
        $this->db->query("CREATE TEMPORARY TABLE IF NOT EXISTS `dret` (
            `cve` char(4) COLLATE utf8mb4_spanish_ci NOT NULL,
            `nom` varchar(250) COLLATE utf8mb4_spanish_ci NOT NULL,
            `nco` varchar(50) COLLATE utf8mb4_spanish_ci NOT NULL,
            PRIMARY KEY (`cve`)
          ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;");
    }

    public function grop () {
        $this->db->query("CREATE TEMPORARY TABLE IF NOT EXISTS `grop` (
            `cve` CHAR(4) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_spanish_ci' NOT NULL,
            `nombre` CHAR(5) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_spanish_ci' NOT NULL,
            `carrera` CHAR(13) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_spanish_ci' NOT NULL,
            PRIMARY KEY (`cve`),
            UNIQUE INDEX `nombre_UNIQUE` (`nombre` ASC),
            UNIQUE INDEX `carrera_UNIQUE` (`carrera` ASC),
            UNIQUE INDEX `cve_UNIQUE` (`cve` ASC))
          ENGINE = INNODB;");
    }

    public function dcat () {
        $this->db->query("CREATE TEMPORARY TABLE IF NOT EXISTS `dcat` (
            `cve` INT(3) UNSIGNED NOT NULL,
            `dep` INT(3) UNSIGNED NOT NULL,
            `nom` VARCHAR(250) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_spanish_ci' NOT NULL,
            PRIMARY KEY (`cve`),
            INDEX `FK_dcat_ddep` (`dep` ASC),
            CONSTRAINT `FK_dcat_ddep`
              FOREIGN KEY (`dep`)
              REFERENCES `ddep` (`cve`))
          ENGINE = InnoDB
          DEFAULT CHARACTER SET = utf8mb4
          COLLATE = UTF8MB4_SPANISH_CI;");
    }

    public function dalu () {
        $this->db->query("CREATE TEMPORARY TABLE IF NOT EXISTS `dalu` (
            `ctr` CHAR(8) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_spanish_ci' NOT NULL,
            `nom` VARCHAR(250) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_spanish_ci' NOT NULL,
            `esp` INT(3) UNSIGNED NOT NULL,
            `sem` TINYINT(12) UNSIGNED NOT NULL,
            PRIMARY KEY (`ctr`),
            INDEX `FK_dalu_especialidad` (`esp` ASC),
            CONSTRAINT `FK_dalu_especialidad`
              FOREIGN KEY (`esp`)
              REFERENCES `desp` (`cve`))
          ENGINE = InnoDB
          DEFAULT CHARACTER SET = utf8mb4
          COLLATE = utf8mb4_spanish_ci;");
    }

    public function dgau () {
        $this->db->query("CREATE TEMPORARY TABLE IF NOT EXISTS `dgau` (
            `gpo` CHAR(4) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_spanish_ci' NOT NULL,
            `cat` INT(3) UNSIGNED NOT NULL,
            `mat` CHAR(4) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_spanish_ci' NOT NULL,
            UNIQUE INDEX `gpo_UNIQUE` USING BTREE (`gpo`, `cat`, `mat`),
            INDEX `FK_dgau_dcat` (`cat` ASC),
            INDEX `FK_dgau_grupo_idx` (`gpo` ASC),
            INDEX `FK_dgau_dret_idx` (`mat` ASC),
            CONSTRAINT `FK_dgau_dcat`
              FOREIGN KEY (`cat`)
              REFERENCES `dcat` (`cve`),
            CONSTRAINT `FK_dgau_dret`
              FOREIGN KEY (`mat`)
              REFERENCES `dret` (`cve`)
              ON DELETE NO ACTION
              ON UPDATE NO ACTION,
            CONSTRAINT `FK_dgau_grup`
              FOREIGN KEY (`gpo`)
              REFERENCES `grop` (`cve`)
              ON DELETE NO ACTION
              ON UPDATE NO ACTION)
          ENGINE = InnoDB
          DEFAULT CHARACTER SET = utf8mb4
          COLLATE = utf8mb4_spanish_ci;
          ");
    }

    public function dlis () {
        $this->db->query("CREATE TEMPORARY TABLE IF NOT EXISTS `dlis` (
            `ctr` CHAR(8) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_spanish_ci' NOT NULL,
            `gpo` CHAR(4) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_spanish_ci' NOT NULL,
            `mat` CHAR(4) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_spanish_ci' NOT NULL,
            UNIQUE INDEX `Unique` USING BTREE (`ctr`, `gpo`, `mat`),
            INDEX `FK_dlis_dalu_idx` (`ctr` ASC),
            INDEX `FK_dlis_dgau_idx` (`mat` ASC, `gpo` ASC),
            CONSTRAINT `FK_dlis_dalu`
              FOREIGN KEY (`ctr`)
              REFERENCES `dalu` (`ctr`)
              ON DELETE NO ACTION
              ON UPDATE NO ACTION,
            CONSTRAINT `FK_dlis_dgau`
              FOREIGN KEY (`mat` , `gpo`)
              REFERENCES `dgau` (`mat` , `gpo`)
              ON DELETE NO ACTION
              ON UPDATE NO ACTION)
          ENGINE = InnoDB
          DEFAULT CHARACTER SET = utf8mb4
          COLLATE = utf8mb4_spanish_ci;
          ");
    }
}