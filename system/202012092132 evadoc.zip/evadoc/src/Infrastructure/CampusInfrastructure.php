<?php
namespace App\Infrastructure;

use Medoo\Medoo;
use Psr\Container\ContainerInterface;

class CampusInfrastructure{
    private Medoo $db;
    private ContainerInterface $container;

    public function __construct(Medoo $db, ContainerInterface $container) {
        $this->db = $db;
        $this->container = $container;
    }

    public function insertCampus(array $campusData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $campus = $databaseInfra['campus'];

        $data = $this->db->insert($campus['table'],[
            $campus['name'] => $campusName]
        );

        return $data;
    }

    public function selectShowAllCampuses(): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $campus = $databaseInfra['campus'];

        $data = $this->db->select($campus['table'], [
            $campus['name']]
        );

        $emptyData = new EmptyData($this->db);
        return $emptyData->emptyData($data);
        //$emptyData = new EmptyData();
        //return $emptyData->emptyData($this->db, $data);
        //return $data;
    }

    public function selectOneCampus(array $campusData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $campus = $databaseInfra['campus'];

        $data = $this->db->select($campus['table'], [
            $campus['name']], [
                $campus['name'] => $campusName]
            );

        return $data;
    }

    public function updateCampus(array $campusData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $campus = $databaseInfra['campus'];

        $data = $this->db->update($campus['table'], [
            $campus['name'] => $campusName], [
                $campus['id'] => $campusId]
            );

        return $data;
    }
    
    public function deleteCampus(array $campusData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $campus = $databaseInfra['campus'];
        
        $data = $this->db->delete($campus['table'], [
            $campus['id'] => $campusId]
        );
        
        return $data;
    }
}