<?php

namespace App\Infrastructure;

use org\majkel\dbase\Table;
use Port\Spreadsheet\SpreadsheetReader;
use Medoo\Medoo;

class DbfImport {
    private Medoo $db;

    public function __construct(Medoo $db) {
        $this->db = $db;
    }

    public function loadModalityData(string $xlsxFileSpecialtyInformation) {
        $sql = <<<'EOD'
        INSERT IGNORE INTO modalidad 
            (id, nombre)
            values(:id, :nombre);
        EOD;

        $file = new \SplFileObject($xlsxFileSpecialtyInformation);
        $modalities = new SpreadsheetReader($file);
        $i = 2; // Rows to ignore.
        foreach ($modalities as $record) {
            if($i++ > 3) {

                $sth = $this->db->pdo->prepare($sql);
                $sth->bindParam(':id', $record[6]);
                $sth->bindParam(':nombre', $record[7]);
                $sth->execute();
            }
        }
    }

    public function loadCereerData(string $xlsxFileSpecialtyInformation) {
        $sql = <<<'EOD'
        INSERT IGNORE INTO carrera 
            (id, clave, nombre, nombre_corto) 
            values (:id, :clave, :nombre, :nombre_corto);
        EOD;

        $file = new \SplFileObject($xlsxFileSpecialtyInformation);
        $careers = new SpreadsheetReader($file);
        $i = 2; // Rows to ignore.
        foreach ($careers as $record) {
            if($i++ > 3) {

                $sth = $this->db->pdo->prepare($sql);
                $sth->bindParam(':id', $record[0]);
                $sth->bindParam(':clave', $record[1]);
                $sth->bindParam(':nombre', $record[2]);
                $sth->bindParam(':nombre_corto', $record[3]);
                $sth->execute();
            }
        }
    }

    public function loadCampusData(string $xlsxFileSpecialtyInformation) {
        $sql = <<<'EOD'
        INSERT IGNORE INTO campus
            (id, nombre)
            values(:id, :nombre);
        EOD;

        $file = new \SplFileObject($xlsxFileSpecialtyInformation);
        $campuses = new SpreadsheetReader($file);
        $i = 2; // Rows to ignore.
        foreach ($campuses as $record) {
            if($i++ > 3) {

                $sth = $this->db->pdo->prepare($sql);
                $sth->bindParam(':id', $record[4]);
                $sth->bindParam(':nombre', $record[5]);
                $sth->execute();
            }
        }
    }

    public function loadSpecialtyDictionary(string $xlsxFileDictionarySpecialty) {
        $sql = <<<'EOD'
        INSERT IGNORE INTO diccionario_especialidad 
            (cve, id_carrera, id_modalidad, id_campus) 
            values (:cve, :id_carrera, :id_modalidad, :id_campus);
        EOD;

        $file = new \SplFileObject($xlsxFileDictionarySpecialty);
        $specialties = new SpreadsheetReader($file);
        $i = 2; // Rows to ignore.
        foreach ($specialties as $record) {
            if($i++ > 3) {

                $sth = $this->db->pdo->prepare($sql);
                $sth->bindParam(':cve', $record[0]);
                $sth->bindParam(':id_carrera', $record[1]);
                $sth->bindParam(':id_modalidad', $record[2]);
                $sth->bindParam(':id_campus', $record[3]);
                $sth->execute();
            }
        }
    }
    
    public function loadSubjectDictionary(string $dbfFileDictionarySubject) {
        $sql = <<<'EOD'
        DROP TABLE IF EXISTS `temp_dret2`;
        CREATE TABLE IF NOT EXISTS `temp_dret2` (
            `mat` VARCHAR(4) CHARACTER SET 'utf8mb4' NOT NULL,
            `esp` INT(10) UNSIGNED NOT NULL,
            `clave_asignatura` CHAR(9) CHARACTER SET 'utf8mb4' NOT NULL,
            UNIQUE INDEX `mat_UNIQUE` (`mat` ASC, `esp` ASC, `clave_asignatura` ASC));
        EOD;

        $this->db->query($sql);

        $records = Table::fromFile($dbfFileDictionarySubject);
        foreach ($records as $record) {
            $hypen = substr($record['SIEVISUAL'], 6, 1);
            if($hypen === '-') {
                $row = [
                    'id_carrera'       => (int)substr($record['SIEVISUAL'], 0, 2),
                    'clave_asignatura' => substr($record['SIEVISUAL'], 3, 8),
                ];

                $sql = <<<'EOD'
                INSERT IGNORE INTO temp_dret2 
                    (mat, esp, clave_asignatura) 
                    values (:mat, :esp, :clave_asignatura);
                EOD;

                $sth = $this->db->pdo->prepare($sql);
                $sth->bindParam(':mat', $record['SIEDOS']);
                $sth->bindParam(':esp', $row['id_carrera']);
                $sth->bindParam(':clave_asignatura', $row['clave_asignatura']);
                $sth->execute();
            }
        }
    }
    
    
    public function loadGroupsDictionary(string $xlsxFileGroup) {
        $sql = <<<'EOD'
            DROP TABLE IF EXISTS `temp_grupo`;
            CREATE TEMPORARY TABLE IF NOT EXISTS `temp_grupo` (
                `cve`    CHAR(6) CHARACTER SET 'utf8mb4' NOT NULL,
                `nombre` CHAR(6) CHARACTER SET 'utf8mb4' NOT NULL,
                PRIMARY KEY (`cve`),
                UNIQUE INDEX `nombre_cve_UNIQUE` (`cve` ASC, `nombre` ASC)
            );
            EOD;
        
        $this->db->query($sql);
        
        $file = new \SplFileObject($xlsxFileGroup);
        $groups = new SpreadsheetReader($file);
        $i = 2; // Rows to ignore.
        foreach ($groups as $record) {
            if($i++ > 3) {
                $this->db->insert("temp_grupo", [
                    "cve"    => $record[0], 
                    "nombre" => $record[1],
                ]);
            }
        }
    }

    public function loadSieSpecialty (string $dbfFileSpecialty) {
        $sql = <<<'EOP'
            DROP TABLE IF EXISTS `temp_desp`;
            CREATE TEMPORARY TABLE IF NOT EXISTS `temp_desp` (
                `cve` INT(3) UNSIGNED NOT NULL,
                `nom` VARCHAR(250) CHARACTER SET 'utf8mb4' NOT NULL,
                `nco` VARCHAR(45) CHARACTER SET 'utf8mb4' NOT NULL,
            PRIMARY KEY (`cve`));
          EOP;

        $this->db->query($sql);

        $file = Table::fromFile($dbfFileSpecialty);
        
        foreach ($file as $record) {
            $this->db->insert("temp_desp", [
                "cve" => $record['ESP_CVE'], 
                "nom" => $record['ESP_NOM'],
                "nco" => $record['ESP_NCO']
            ]);
        }
    }

    public function loadSieDepartment (string $dbfFileDepartment){
        $sql = <<<'EOP'
        DROP TABLE IF EXISTS `temp_ddep`;
        CREATE TEMPORARY TABLE IF NOT EXISTS `temp_ddep` (
            `cve` INT(3) UNSIGNED NOT NULL,
            `nom` VARCHAR(250) CHARACTER SET 'utf8mb4' NOT NULL,
            `nco` VARCHAR(50) CHARACTER SET 'utf8mb4' NOT NULL,
            PRIMARY KEY (`cve`));
        EOP;

        $this->db->query($sql);

        $file = Table::fromFile($dbfFileDepartment);

        foreach ($file as $record) {
            $this->db->insert("temp_ddep", [
                "cve" => $record['DEP_CVE'],
                "nom" => $record['DEP_NOM'],
                "nco" => $record['DEP_NCO']
            ]);
        }
    }

    public function loadSieSubject (string $dbfFileSubject) {
        $sql = <<<'EOP'
        DROP TABLE IF EXISTS `temp_dret`;
        CREATE TEMPORARY TABLE IF NOT EXISTS `temp_dret` (
            `cve` CHAR(4) NOT NULL,
            `nom` VARCHAR(250) CHARACTER SET 'utf8mb4' NOT NULL,
            `nco` VARCHAR(50) CHARACTER SET 'utf8mb4' NOT NULL,
            PRIMARY KEY (`cve`));
        EOP;

        $this->db->query($sql);

        $file = Table::fromFile($dbfFileSubject);

        foreach ($file as $record) {
            $this->db->insert("temp_dret", [
                "cve" => $record['RET_CVE'],
                "nom" => $record['RET_NOM'],
                "nco" => $record['RET_NCO']
            ]);
        }
    }

    public function loadSieTeacher (string $dbfFileTeacher) {
        $sql = <<<'EOP'
        DROP TABLE IF EXISTS `temp_dcat`;
        CREATE TEMPORARY TABLE IF NOT EXISTS `temp_dcat` (
            `cve` INT(3) UNSIGNED NOT NULL,
            `dep` INT(3) NOT NULL,
            `nom` VARCHAR(255) CHARACTER SET 'utf8mb4' NOT NULL,
            PRIMARY KEY (`cve`));
        EOP;

        $this->db->query($sql);

        $file = Table::fromFile($dbfFileTeacher);

        foreach ($file as $record) {
            $this->db->insert("temp_dcat", [
                "cve" => $record['CAT_CVE'],
                "dep" => $record['CAT_DEP'],
                "nom" => $record['CAT_NOM']
            ]);
        }
    }

    public function loadSieStudent (string $dbfFileStudent) {
        $sql = <<<'EOP'
        DROP TABLE IF EXISTS `temp_dalu`;
        CREATE TEMPORARY TABLE IF NOT EXISTS `temp_dalu` (
            `ctr` CHAR(8) CHARACTER SET 'utf8mb4' NOT NULL,
            `nom` VARCHAR(250) CHARACTER SET 'utf8mb4' NOT NULL,
            `esp` INT(10) NOT NULL,
            `sem` TINYINT(12) UNSIGNED NOT NULL,
            PRIMARY KEY (`ctr`));
        EOP;

        $this->db->query($sql);

        $file = Table::fromFile($dbfFileStudent);

        foreach ($file as $record) {
            $this->db->insert("temp_dalu", [
                "ctr" => $record['ALU_CTR'],
                "nom" => $record['ALU_NOM'],
                "esp" => $record['ALU_ESP'],
                "sem" => $record['ALU_SEM']
            ]);
        }
    }

    public function loadSieCourse (string $dbfFileCourse) {
        $sql = <<<'EOP'
        DROP TABLE IF EXISTS `temp_dgau`;
        CREATE TEMPORARY TABLE IF NOT EXISTS `temp_dgau` (
            `gpo` CHAR(6) CHARACTER SET 'utf8mb4' NOT NULL,
            `cat` INT(3) NOT NULL,
            `mat` CHAR(4) CHARACTER SET 'utf8mb4' NOT NULL,
            UNIQUE INDEX `gpo_UNIQUE` USING BTREE (`gpo`, `cat`, `mat`));
        EOP;

        $this->db->query($sql);

        $file = Table::fromFile($dbfFileCourse);

        foreach ($file as $record) {
            $this->db->insert("temp_dgau", [
                "gpo" => $record['GPO_GPO'],
                "cat" => $record['GPO_CAT'],
                "mat" => $record['GPO_MAT']
            ]);
        }
    }

    public function loadSieInscription(string $dbfFileInscription) {
        $sql = <<<'EOP'
        DROP TABLE IF EXISTS `temp_dlis`;
        CREATE TEMPORARY TABLE IF NOT EXISTS `temp_dlis` (
            `ctr` CHAR(8) CHARACTER SET 'utf8mb4' NOT NULL,
            `gpo` CHAR(6) CHARACTER SET 'utf8mb4' NOT NULL,
            `mat` CHAR(4) CHARACTER SET 'utf8mb4' NOT NULL);
            UNIQUE INDEX `dlis_UNIQUE` USING BTREE (`ctr`, `gpo`, `mat`));
        EOP;

        $this->db->query($sql);
        $file = Table::fromFile($dbfFileInscription);

        foreach ($file as $record) {
            $this->db->insert("temp_dlis", [
                "ctr" => $record['LIS_CTR'],
                "gpo" => $record['LIS_MAT'],
                "mat" => $record['LIS_GPO']
            ]);
        }
    }

    public function importData () {
        
        $xlsxFileGroup = __DIR__.'/../../public/dbfFiles/Grupos.xlsx';
        $this->loadGroupsDictionary($xlsxFileGroup);

        $dbfFileDictionarySubject = __DIR__ . '/../../public/dbfFiles/dret2.DBF';
        $this->loadSubjectDictionary($dbfFileDictionarySubject);

        $dbfFileSpecialty = __DIR__.'/../../public/dbfFiles/desp.DBF';
        $this->loadSieSpecialty($dbfFileSpecialty);

        $dbfFileDepartment = __DIR__.'/../../public/dbfFiles/ddep.DBF';
        $this->loadSieDepartment($dbfFileDepartment);

        $dbfFileSubject = __DIR__.'/../../public/dbfFiles/dret.DBF';
        $this->loadSieSubject($dbfFileSubject);

        $dbfFileTeacher = __DIR__.'/../../public/dbfFiles/dcat.DBF';
        $this->loadSieTeacher($dbfFileTeacher);

        $dbfFileStudent = __DIR__.'/../../public/dbfFiles/dalu.DBF';
        $this->loadSieStudent($dbfFileStudent);

        $dbfFileCourse = __DIR__.'/../../public/dbfFiles/dgau.DBF';
        $this->loadSieCourse($dbfFileCourse);

        $dbfFileInscription = __DIR__.'/../../public/dbfFiles/dlis.DBF';
        $this->loadSieInscription($dbfFileInscription);

        $xlsxFileSpecialtyInformation = __DIR__.'/../../public/dbfFiles/InformacionTEC.xlsx';
        $this->loadCampusData($xlsxFileSpecialtyInformation);

        $xlsxFileSpecialtyInformation = __DIR__.'/../../public/dbfFiles/InformacionTEC.xlsx';
        $this->loadCereerData($xlsxFileSpecialtyInformation);

        $xlsxFileSpecialtyInformation = __DIR__.'/../../public/dbfFiles/InformacionTEC.xlsx';
        $this->loadModalityData($xlsxFileSpecialtyInformation);

        $xlsxFileDictionarySpecialty =__DIR__.'/../../public/dbfFiles/DiccionarioEspecialidad.xlsx';
        $this->loadSpecialtyDictionary($xlsxFileDictionarySpecialty);
    }
}