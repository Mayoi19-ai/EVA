<?php
namespace App\Validator;
use Rakit\Validation\Validator;

class ModalityValidator{
    private Validator $validator;

    public function __construct(Validator $validator) {
        $this->validator = $validator;
    }

    public function validateSaveModality(array $data, array &$resultData): bool {
        $validationRules = [
            'name'          =>  'required|alpha|alpha_spaces|uppercase',  
        ];

        $errorMessages = [
            'name:required'     => 'El nombre es obligatorio',
            'name:alpha'        => 'El nombre no es válido',
            'name:uppercase'    => 'El nombre debe estar en mayúsculas',
        ];

        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data, $resultData);
    }
}