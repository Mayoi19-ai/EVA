<?php

namespace App\Infrastructure\ImportData;

use Medoo\Medoo;

class SqlQueries {
    private Medoo $db;
    public function __construct(Medoo $db){
        $this->db = $db;
    }

    public function queries(){
        $period = 1;
        $password = 'hello';
        $sql = <<<'EOP'
        INSERT IGNORE  INTO asignatura  
        SELECT temp_dret2.clave_asignatura, temp_dret.nom
        FROM temp_dret2
        INNER JOIN temp_dret
        ON temp_dret2.mat = temp_dret.cve;

        INSERT IGNORE INTO departamento
        SELECT temp_ddep.cve, temp_ddep.nom 
        FROM temp_ddep;

        INSERT IGNORE INTO docente
        SELECT temp_dcat.cve, temp_dcat.nom, temp_dcat.dep
        FROM temp_dcat 
        INNER JOIN departamento 
        ON temp_dcat.dep = departamento.clave;

        INSERT IGNORE INTO materia 
        SELECT carrera.id, temp_dret2.clave_asignatura 
        FROM carrera
        INNER JOIN diccionario_especialidad 
        ON carrera.id = diccionario_especialidad.id_carrera 
        INNER JOIN temp_dret2 
        ON diccionario_especialidad.cve = temp_dret2.esp;

        INSERT IGNORE INTO grupo (nombre, id_periodo, id_carrera, id_modalidad, id_campus) 
        SELECT temp_grupo.nombre, :id_periodo, diccionario_especialidad.id_carrera, diccionario_especialidad.id_modalidad, diccionario_especialidad.id_campus 
        FROM temp_grupo 
        INNER JOIN 
        temp_dgau 
        ON temp_grupo.cve = temp_dgau.gpo 
        INNER JOIN 
        temp_dret 
        ON temp_dgau.mat = temp_dret.cve 
        INNER JOIN 
        temp_dret2 
        ON  temp_dret.cve = temp_dret2.mat 
        INNER JOIN 
        diccionario_especialidad
        ON temp_dret2.esp = diccionario_especialidad.cve 
        GROUP BY temp_grupo.nombre, 
        diccionario_especialidad.id_carrera, 
        diccionario_especialidad.id_modalidad,
        diccionario_especialidad.id_campus;

        INSERT IGNORE INTO curso (nombre_grupo, id_periodo, id_carrera, clave_asignatura, folio_docente)
        SELECT temp_grupo.nombre, :id_periodo, diccionario_especialidad.id_carrera, temp_dret2.clave_asignatura, temp_dgau.cat
        FROM temp_grupo
        INNER JOIN 
        temp_dgau
        ON temp_grupo.cve = temp_dgau.gpo
        INNER JOIN 
        temp_dret
        ON temp_dgau.mat = temp_dret.cve
        INNER JOIN 
        temp_dret2
        ON temp_dret.cve = temp_dret2.mat
        INNER JOIN 
        diccionario_especialidad
        ON temp_dret2.esp = diccionario_especialidad.cve;
        
        INSERT IGNORE INTO alumno (control, contrasenia)
        SELECT temp_dalu.ctr, :contrasenia_alumno
        FROM temp_dalu;

        DROP TABLE IF EXISTS `temp_inscripcion`;
        CREATE TEMPORARY TABLE `temp_inscripcion`(
        `ctr_alumno` CHAR(10) NOT NULL,
        `grupo` CHAR(6) NOT NULL,
        `id_periodo` INT(10) NOT NULL,
        `id_carrera` INT(10) NOT NULL, 
        `clave_asginatura` CHAR(10) NOT NULL,
        `folio_docente` INT(10) NOT NULL,
        UNIQUE INDEX `inscription_UNIQUE` USING BTREE (`ctr_alumno`, 
        `grupo`, `id_periodo`, `id_carrera`, `clave_asginatura`, `folio_docente`));

        INSERT IGNORE INTO temp_inscripcion 
        SELECT temp_dlis.ctr, temp_grupo.nombre, :id_periodo, diccionario_especialidad.id_carrera, temp_dret2.clave_asignatura, temp_dgau.cat
        FROM temp_grupo
        INNER JOIN 
        temp_dlis
        ON temp_grupo.cve = temp_dlis.gpo
        INNER JOIN 
        temp_dgau
        ON temp_dlis.gpo = temp_dgau.gpo AND temp_dlis.mat = temp_dgau.mat
        INNER JOIN 
        temp_dcat
        ON temp_dcat.cve =  temp_dgau.cat
        INNER JOIN
        temp_dret
        ON temp_dgau.mat = temp_dret.cve
        INNER JOIN 
        temp_dret2
        ON temp_dret.cve = temp_dret2.mat
        INNER JOIN 
        diccionario_especialidad
        ON temp_dret2.esp =  diccionario_especialidad.cve;

        INSERT INTO inscripcion (id_curso, alumno_control)
        SELECT curso.id, temp_inscripcion.ctr_alumno FROM curso
        INNER JOIN 
        temp_inscripcion
        ON curso.nombre_grupo = temp_inscripcion.grupo 
        AND 
        curso.id_periodo = temp_inscripcion.id_periodo
        AND 
        curso.id_carrera = temp_inscripcion.id_carrera
        AND 
        curso.clave_asignatura = temp_inscripcion.clave_asginatura
        AND 
        curso.folio_docente = temp_inscripcion.folio_docente;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':id_periodo', $period);
        $sth->bindParam(':contrasenia_alumno', $password);
        $sth->execute();
    }
}