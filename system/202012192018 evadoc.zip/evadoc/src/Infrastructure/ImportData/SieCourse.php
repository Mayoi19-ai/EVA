<?php
namespace App\Infrastructure\ImportData;

use org\majkel\dbase\Table;
use Medoo\Medoo;

class SieCourse {
    private Medoo $db;

    public function __construct(Medoo $db) {
        $this->db = $db;
    }
    
    public function loadSieCourse (string $dbfFileCourse) {
        $sql = <<<'EOP'
        DROP TABLE IF EXISTS `temp_dgau`;
        CREATE TEMPORARY TABLE IF NOT EXISTS `temp_dgau` (
            `gpo` CHAR(6) NOT NULL,
            `cat` INT(3) NOT NULL,
            `mat` CHAR(4) NOT NULL,
            UNIQUE INDEX `gpo_UNIQUE` USING BTREE (`gpo`, `cat`, `mat`));
        EOP;

        $this->db->query($sql);

        $file = Table::fromFile($dbfFileCourse);

        foreach ($file as $record) {
            $this->db->insert("temp_dgau", [
                "gpo" => $record['GPO_GPO'],
                "cat" => $record['GPO_CAT'],
                "mat" => $record['GPO_MAT']
            ]);
        }
    }
}