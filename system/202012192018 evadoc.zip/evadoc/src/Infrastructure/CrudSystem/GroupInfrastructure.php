<?php
namespace App\Infrastructure\CrudSystem;

use Medoo\Medoo;

class GroupInfrastructure{
    private Medoo $db;

    public function __construct(Medoo $db) {
        $this->db = $db;
    }

    public function create(array $data): ?array
    {
        $data = $this->db->insert('grupo', [
            'nombre' => $data['grupo'],
            'id_periodo' => $data['id_periodo'],
            'id_carrera' => $data['id_carrera'],
            'id_modalidad' => $data['id_modalidad'],
            'id_campus' => $data['id_campus']
            ]);

        return $data;
    }

    public function readAll(): ?array
    {
        $sql = <<<'EOP'
        SELECT grupo.nombre AS 'grupo',
        carrera.nombre_corto AS 'carrera',
        grupo.id_carrera AS 'id_carrera',
        modalidad.nombre AS 'modalidad',    
        grupo.id_modalidad AS 'id_modalidad',
        campus.nombre AS 'campus',
        grupo.id_campus AS 'id_campus'
        FROM 
        grupo,
        carrera,
        modalidad,
        campus
        WHERE
        grupo.id_carrera = carrera.id 
        AND 
        grupo.id_modalidad = modalidad.id
        AND 
        grupo.id_periodo = :id_periodo
        AND 
        grupo.id_campus = campus.id;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':id_periodo', $periodId);
        $sth->execute();
        $records = $sth->fetchAll();
        return $records;
    }

    public function readAuxiliary(int $periodId): ?array
    {
        $sql = <<<'EOP'
        SELECT grupo.nombre AS 'grupo',
        carrera.nombre_corto AS 'carrera',
        grupo.id_carrera AS 'id_carrera'
        FROM 
        grupo,
        carrera
        WHERE
        grupo.id_carrera = carrera.id 
        AND 
        grupo.id_modalidad = modalidad.id
        AND 
        grupo.id_periodo = :id_periodo
        AND 
        grupo.id_campus = campus.id;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':id_periodo', $periodId);
        $sth->execute();
        $records = $sth->fetchAll();
        return $records;
    }

    public function read(int $periodId, string $name): ?array
    {
        $sql = <<<'EOP'
        SELECT grupo.nombre AS 'grupo',
        carrera.nombre_corto AS 'carrera',
        grupo.id_carrera AS 'id_carrera',
        modalidad.nombre AS 'modalidad',    
        grupo.id_modalidad AS 'id_modalidad',
        campus.nombre AS 'campus',
        grupo.id_campus AS 'id_campus'
        FROM 
        grupo,
        carrera,
        modalidad,
        campus
        WHERE
        grupo.id_carrera = carrera.id 
        AND 
        grupo.id_modalidad = modalidad.id
        AND 
        grupo.id_campus = campus.id
        AND 
        grupo.id_periodo = :id_periodo
        AND 
        grupo.nombre LIKE '%' :nombre '%';
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':id_periodo', $periodId);
        $sth->bindParam(':nombre', $name);
        $sth->execute();
        $records = $sth->fetchAll();
        return $records;
    }

    public function update(array $data): ?array
    {
        $sql = $this->db->update('grupo', [
            'nombre' => $data['nombre'],
            'id_carrera' => $data['id_carrera'],
            'id_modalidad' => $data['id_modalidad'],
            'id_campus' => $data['id_campus']], [
                'AND' => [
                    'nombre' => $data['nombre_antiguo'],
                    'id_periodo' => $data['id_periodo'],
                    'id_carrera' => $data['id_carrera_antiguo'],
                    'id_modalidad' => $data['id_modalidad_antiguo'],
                    'id_campus' => $data['id_campus_antiguo']
                ]
            ]);
            
        return $sql;
    }
    
    public function delete(array $data): ?array
    {
        $sql = $this->db->delete('grupo', [
            'AND' => [
                'nombre' => $data['nombre'],
                'id_periodo' => $data['id_periodo'],
                'id_carrera' => $data['id_carrera'],
                'id_modalidad' => $data['id_modalidad'],
                'id_campus' => $data['id_campus']
            ]
        ]);

        return $sql;
    }
}