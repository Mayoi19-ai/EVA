<?php
namespace App\Infrastructure\CrudSystem;

use Medoo\Medoo;

class CampusInfrastructure{
    private Medoo $db;

    public function __construct(Medoo $db) {
        $this->db = $db;
    }

    public function create(array $data): ?array
    {
        $sql = $this->db->insert('campus',[
            'nombre' => $data['nombre']]);
        return $sql;
    }

    public function readAll(): ?array
    {
        $sql = $this->db->select('campus', [
            'id', 'nombre']);
        return $sql;
    }

    public function update(array $data): ?array
    {
        $sql = $this->db->update('campus', [
            'nombre' => $data['nombre']], [
                'id' => $data['id']]);
        return $sql;
    }
    
    public function delete(int $id): ?array
    {
        $sql = $this->db->delete('campus', [
            'id' => $id]);
        return $sql;
    }
}