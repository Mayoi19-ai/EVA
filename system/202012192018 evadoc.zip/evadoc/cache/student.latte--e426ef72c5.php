<?php
// source: Alumnos/student.latte

use Latte\Runtime as LR;

class Templatee426ef72c5 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		$this->parentName = 'studentform.latte';
		
	}

}
