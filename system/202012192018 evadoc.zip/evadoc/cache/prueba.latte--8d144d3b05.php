<?php
// source: Archivos/prueba.latte

use Latte\Runtime as LR;

class Template8d144d3b05 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>


            $nombres=$_FILES['archivo']['name'];
            $guardado=$_FILES['archivos']['tmp_name'];

            if(!file_exists('archivos')){
                mkdir('archivos',0777,true);
                if(file_exists('archivos')){
                    if(move_uploaded_file($guardado, 'Archivos/' .$nombre)){
                        echo "Archivo guardado con exito";
                    }else{
                        echo "Archivo no se pudo guardar";

                    }
                    }
                }else{
                    if(move_uploaded_file($guardado, 'Archivos/' .$nombre)){
                        echo "Archivo guardado con exito";

                    }else{
                        echo "Archivo no se pudo guardar";
                    }
                }
            
<?php
		return get_defined_vars();
	}

}
