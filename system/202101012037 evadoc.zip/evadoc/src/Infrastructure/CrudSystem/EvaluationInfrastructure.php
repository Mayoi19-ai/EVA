<?php
namespace App\Infrastructure\CrudSystem;

use Medoo\Medoo;
use App\Infrastructure\Exceptions\CustomException as Exception;

class EvaluationInfrastructure{
    private Medoo $db;
    private Exception $exception;

    public function __construct(Medoo $db, Exception $exception) {
        $this->db = $db;
        $this->exception = $exception;
    }

    public function activate(int $activate): array
    {
        $this->db->pdo->beginTransaction();

        $this->db->update('activar_evaluacion',[
            'activar' => $activate
        ]);

        $result = $this->exception->saveError((array) $this->db->error());
        return $result;
    }

    public function readAll(): array
    {
        $sql = $this->db->select('activar_evaluacion', [
            'activar'
        ]);
        
        $result = $this->exception->readError((array) $this->db->error(), (array) $sql);
        return $result;
    }
}