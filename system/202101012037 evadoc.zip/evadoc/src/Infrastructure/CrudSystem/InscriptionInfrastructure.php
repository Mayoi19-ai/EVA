<?php
namespace App\Infrastructure\CrudSystem;

use Medoo\Medoo;
use App\Infrastructure\Exceptions\CustomException as Exception;

class InscriptionInfrastructure{
    private Medoo $db;
    private Exception $exception;

    public function __construct(Medoo $db, Exception $exception) {
        $this->db = $db;
        $this->exception = $exception;
    }

    public function create(array $data): array
    {
        $this->db->pdo->beginTransaction();
        $this->db->insert('inscripcion',[
            'id_curso' => $data['id_curso'], 
            'alumno_control' => $data['control'], 
            'activar' => $data['activar']
        ]);

        $result = $this->exception->saveError((array) $this->db->error());
        return $result;
    }

    public function readAll(int $periodId): array
    {
        $sql = <<<'EOP'
        SELECT 
        inscripcion.id AS 'id',
        inscripcion.activar AS 'activar',
        inscripcion.alumno_control AS 'control',
        alumno.nombre AS 'alumno',
        curso.id AS 'id_curso',
        curso.nombre_grupo AS 'grupo',
        carrera.nombre AS 'carrera',
        curso.id_carrera AS 'id_carrera',
        asignatura.nombre AS 'asignatura',
        curso.clave_asignatura AS 'clave_asignatura',
        docente.nombre AS 'docente',
        curso.folio_docente AS 'folio_docente'
        FROM 
        inscripcion,
        alumno,
        curso,
        asignatura,
        carrera, 
        docente
        WHERE inscripcion.alumno_control = alumno.control
        AND inscripcion.id_curso = curso.id
        AND curso.id_carrera = carrera.id
        AND curso.clave_asignatura = asignatura.clave
        AND curso.folio_docente = docente.folio 
        AND curso.id_periodo = :id_periodo;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':id_periodo', $periodId);
        $sth->execute();
        $records = $sth->fetchAll();

        $result = $this->exception->readError((array) $this->db->error(), (array) $records);
        return $result;
    }

    public function readByStudent(string $control, int $periodId): array
    {
        $sql = <<<'EOP'
        SELECT 
        inscripcion.id AS 'id',
        inscripcion.activar AS 'activar',
        inscripcion.alumno_control AS 'control',
        alumno.nombre AS 'alumno',
        curso.id AS 'id_curso',
        curso.nombre_grupo AS 'grupo',
        carrera.nombre AS 'carrera',
        curso.id_carrera AS 'id_carrera',
        asignatura.nombre AS 'asignatura',
        curso.clave_asignatura AS 'clave_asignatura',
        docente.nombre AS 'docente',
        curso.folio_docente AS 'folio_docente'
        FROM 
        inscripcion,
        alumno,
        curso,
        asignatura,
        carrera, 
        docente
        WHERE inscripcion.alumno_control = alumno.control
        AND inscripcion.id_curso = curso.id
        AND curso.id_carrera = carrera.id
        AND curso.clave_asignatura = asignatura.clave
        AND curso.folio_docente = docente.folio 
        AND curso.id_periodo = :id_periodo
        AND inscripcion.alumno_control LIKE '%' :control '%';
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':id_periodo', $periodId);
        $sth->bindParam(':control', $name);
        $sth->execute();
        $records = $sth->fetchAll();
        
        $result = $this->exception->readError((array) $this->db->error(), (array) $records);
        return $result;
    }

    public function groupByCareer(int $periodId): array
    {
        $sql = <<<'EOP'
        SELECT 
        inscripcion.activar AS 'activar',
        carrera.nombre AS 'carrera',
        curso.id_carrera AS 'id_carrera'
        FROM 
        inscripcion,
        alumno,
        curso,
        asignatura,
        carrera, 
        docente
        WHERE inscripcion.alumno_control = alumno.control
        AND inscripcion.id_curso = curso.id
        AND curso.id_carrera = carrera.id
        AND curso.clave_asignatura = asignatura.clave
        AND curso.folio_docente = docente.folio 
        AND curso.id_periodo = :id_periodo
        GROUP BY curso.id_carrera;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':id_periodo', $periodId);
        $sth->execute();
        $records = $sth->fetchAll();
        
        $result = $this->exception->readError((array) $this->db->error(), (array) $records);
        return $result;
    }

    public function groupByGroups(int $periodId): array
    {
        $sql = <<<'EOP'
        SELECT 
        inscripcion.activar AS 'activar',
        curso.nombre_grupo AS 'grupo',
        carrera.nombre AS 'carrera',
        curso.id_carrera AS 'id_carrera'
        FROM 
        inscripcion,
        alumno,
        curso,
        asignatura,
        carrera, 
        docente
        WHERE inscripcion.alumno_control = alumno.control
        AND inscripcion.id_curso = curso.id
        AND curso.id_carrera = carrera.id
        AND curso.clave_asignatura = asignatura.clave
        AND curso.folio_docente = docente.folio 
        AND curso.id_periodo = :id_periodo
        GROUP BY curso.nombre_grupo;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':id_periodo', $periodId);
        $sth->execute();
        $records = $sth->fetchAll();
        
        $result = $this->exception->readError((array) $this->db->error(), (array) $records);
        return $result;
    }

    public function updateByCareer(array $data): array
    {
        $sql = <<<'EOP'
        UPDATE 
        inscripcion 
        SET inscripcion.activar = :activar
        WHERE
        inscripcion.id IN  
        (SELECT 
        inscripcion.id AS 'id'
        FROM 
        inscripcion,
        alumno,
        curso,
        asignatura,
        carrera, 
        docente
        WHERE inscripcion.alumno_control = alumno.control
        AND inscripcion.id_curso = curso.id
        AND curso.clave_asignatura = asignatura.clave
        AND curso.folio_docente = docente.folio 
        AND curso.id_periodo :id_periodo
        AND curso.id_carrera = :id_carrera);
        EOP;
        
        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':id_periodo', $data['id_periodo']);
        $sth->bindParam(':activar', $data['activar']);
        $sth->bindParam(':id_carrera', $data['id_carrera']);
        $sth->execute();

        $result = $this->exception->saveError((array) $this->db->error());
        return $result;
    }

    public function updateByGroup(array $data): array
    {
        $sql = <<<'EOP'
        UPDATE 
        inscripcion 
        SET inscripcion.activar = :activar
        WHERE
        inscripcion.id IN  (SELECT 
        inscripcion.id AS 'id'
        FROM 
        inscripcion,
        alumno,
        curso,
        asignatura,
        carrera, 
        docente
        WHERE inscripcion.alumno_control = alumno.control
        AND inscripcion.id_curso = curso.id
        AND curso.id_carrera = carrera.id
        AND curso.clave_asignatura = asignatura.clave
        AND curso.folio_docente = docente.folio 
        AND curso.id_periodo = :id_periodo
        AND curso.nombre_grupo LIKE '%' :grupo '%');
        EOP;
        
        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':id_periodo', $data['id_periodo']);
        $sth->bindParam(':activar', $data['activar']);
        $sth->bindParam(':grupo', $data['grupo']);
        $sth->execute();

        $result = $this->exception->saveError((array) $this->db->error());
        return $result;
    }

    public function update(array $data): array
    {
        $this->db->pdo->beginTransaction();
        $this->db->update('inscripcion', [
            'id_curso' => $data['id_curso'], 
            'alumno_control' => $data['control'],
            'activar' => $data['activar']], [
                'id' => $data['id']
        ]);

        $result = $this->exception->saveError((array) $this->db->error());
        return $result;
    }
    
    public function delete(int $id): array
    {
        $this->db->pdo->beginTransaction();
        $this->db->delete('inscripcion', [
            'id' => $id
        ]);
        
        $result = $this->exception->deleteError((array) $this->db->error());
        return $result;
    }
}