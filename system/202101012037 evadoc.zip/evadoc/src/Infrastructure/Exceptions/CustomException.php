<?php
namespace App\Infrastructure\Exceptions;

use Medoo\Medoo;

class CustomException {
    protected Medoo $db;
    
    public function __construct(Medoo $db)
    {
        $this->db = $db;
    }

    public function saveError(array $result): array
    {
        if(empty($result[1])) {

            $this->db->pdo->commit();
            $sqlResult = ['exito' => 'Guardado correctamente', 
                        'flag' => true, 
                        'consulta' => true];

        } else {
            $this->db->pdo->rollBack();
            $sqlResult = ['error' => 'Error al guardar', 
                        'flag' => false,
                        'consulta' => true];
        }
    }

    public function readError(array $result, array $sql): array 
    {
        if(empty($result[1])) {
            
            if(empty($sql)) {
                $sqlResult = ['error' => 'No hay registros', 
                        'flag' => true,
                        'consulta' => true];
            } else {
                $sqlResult = $sql;
            }

        } else {
            $sqlResult = ['error' => 'Error al mostrar registros', 
                        'flag' => false,
                        'consulta' => true];
        }

        return $sqlResult;
    }

    public function deleteError(array $result): array 
    {
        if(empty($result[1])) {

            $this->db->pdo->commit();
            $sqlResult = ['exito' => 'Registro elimnado correctamente', 
                        'flag' => true, 
                        'consulta' => true];

        } else {
            $this->db->pdo->rollBack();
            $sqlResult = ['error' => 'No se eliminó registro', 
                        'flag' => false,
                        'consulta' => true];
        }
        
        return $sqlResult;
    }

    public function login(array $result, array $sql): ?array 
    {
        if(empty($result[1])) {
            
            if(empty($sql)) {
                $sqlResult = null;
            } else {
                $sqlResult = $sql;
            }

        } else {
            $sqlResult = null;
        }

        return $sqlResult;
    }

    public function sessions(array $result): boolean
    {
        if(empty($result[1])) {

            $this->db->pdo->commit();
            $sqlResult = true;

        } else {
            $this->db->pdo->rollBack();
            $sqlResult = false;
        }

        return $sqlResult;
    }

    public function readRecord(array $result, array $sql): ?array 
    {
        if(empty($result[1])) {
            
            if(empty($sql)) {
                $sqlResult = false;
            } else {
                $sqlResult = $sql;
            }

        } else {
            $sqlResult = false;
        }

        return $sqlResult;
    }
}