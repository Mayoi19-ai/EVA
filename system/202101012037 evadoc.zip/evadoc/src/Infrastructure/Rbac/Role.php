<?php
namespace App\Infrastructure\Rbac;

use Medoo\Medoo;
use App\Infrastructure\Exceptions\CustomException as Exception;

class Role {
    private Medoo $db;
    private Exception $exception;
    
    public function __construct(Medoo $db, Exception $exception) {
        $this->db = $db;
        $this->exception = $exception;
    }

    public function create(array $data): array
    {
        $this->db->pdo->beginTransaction();
        $this->db->insert('roles',[
            'nombre' => $data['nombre']
        ]);

        $result = $this->exception->saveError((array) $this->db->error());
        return $result;
    }

    public function readAll(): array
    {
        $sql = $this->db->select('roles',[
            'id',
            'nombre'
        ]);

        $result = $this->exception->readError((array) $this->db->error(), (array) $sql);
        return $result;
    }

    public function update(array $data): array
    {
        $this->db->pdo->beginTransaction();
        $this->db->update('roles',[
            'nombre' => $data['nombre']], [
                'id' => $data['id']
        ]);

        $result = $this->exception->saveError((array) $this->db->error());
        return $result;
    }

    public function delete(int $id): array
    {
        $this->db->pdo->beginTransaction();
        $this->db->delete('roles', [
                'id' => $id
        ]);
        
        $result = $this->exception->deleteError((array) $this->db->error());
        return $result;
    }
}