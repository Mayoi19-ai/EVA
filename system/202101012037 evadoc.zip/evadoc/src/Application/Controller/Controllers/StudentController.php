<?php
namespace App\Controller\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use App\Validator\StudentValidator as Validator;
use Ujpef\LatteView;
use App\Infrastructure\CrudSystem\StudentInfrastructure as Infrastructure;

class StudentController{
    private Container $container;
    private Infrastructure $infrastructure;
    private Validator $validator;
    
    public function __construct(Container $container, Infrastructure $infrastructure, Validator $validator){
        $this->container = $container;
        $this->infrastructure = $infrastructure;
        $this->validator = $validator;
    }

    public function saveForm(Request $request, Response $response){
        return $this->container->get(LatteView::class)->render($response, 
            'Alumno/studentForm.latte');
    }

    public function register(Request $request, Response $response){
        $data = $request->getParsedBody();
        $validationResult = $this->validator->validateSaveStudent((array) $data);
        
        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->create((array) $data);
        } else {
            $sthResult = ['consulta' => false];
        }

        return $this->container->get(LatteView::class)->render(
            $response,
            'Alumno/studentValidation.latte', [
                'validation' => $validationResult, 
                'query' => $sthResult
            ]);
    }

    public function search(Request $request, Response $response){
        $validationResult = $this->validator->validateFindStudent((array) $_GET);
        
        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->read((string) $_GET['control']);
        } else {
            $sthResult = ['consulta' => false];
        }

        return $this->container->get(LatteView::class)->render(
            $response,
            'Alumno/studentSearch.latte', [
                'query' => $sthResult,
                'student_control' => $_GET['control'],
                'validation' => $validationResult
            ]);
    }
    
    public function show(Request $request, Response $response){
        $sthResult = $this->infrastructure->readAll();

        return $this->container->get(LatteView::class)->render(
            $response,
            'Alumno/studentTable.latte', [
                'query' => $sthResult
            ]);
    }

    public function updateForm(Request $request, Response $response){
        $data = $request->getParsedBody();
        return $this->container->get(LatteView::class)->render($response, 
            'Alumno/studentUpdate.latte', [
                'student_information' => $data
            ]);
    }

    public function update(Request $request, Response $response){
        $data = $request->getParsedBody();
        $validationResult = $this->validator->validateSaveStudent((array) $data);

        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->update((array) $data);
        } else {
            $sthResult = ['consulta' => false];
        }

        return $this->container->get(LatteView::class)->render(
            $response,
            'Alumno/studentValidation.latte', [
                'validation' => $validationResult, 
                'query' => $sthResult,
            ]);
    }

    public function delete(Request $request, Response $response){
        //$sthResult = $this->infrastructure->delete((string) '163z0000');
        $sthResult = $this->infrastructure->delete((string) $_GET['control']);
        
        return $this->container->get(LatteView::class)->render(
            $response,
            'Alumno/studentValidation.latte', [
                'query' => $sthResult
            ]);
    }

    public function message(Request $request, Response $response){
        return $this->container->get(LatteView::class)->render($response, 
            'Alumno/studentForm.latte');
    }
}