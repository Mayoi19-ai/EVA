<?php
namespace App\Controller\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use App\Validator\PeriodValidator as Validator;
use Ujpef\LatteView;
use Slim\Exception\HttpForbiddenException;
use App\Infrastructure\CrudSystem\PeriodInfrastructure as Infrastructure;
use App\Infrastructure\CrudSystem\EvaluationInfrastructure as EvaluationInfra;

class PeriodController{
    private Container $container;
    private Validator $validator;
    private Infrastructure $infrastructure;
    private EvaluationInfra $evaluationInfra;
    
    public function __construct(Container $container, Validator $validator, Infrastructure $infrastructure, EvaluationInfra $evaluationInfra){
        $this->container = $container;
        $this->validator = $validator;
        $this->infrastructure = $infrastructure;
        $this->evaluationInfra = $evaluationInfra;
    }

    public function saveForm(Request $request, Response $response){
        return $this->container->get(LatteView::class)->render($response, 'Periodo/periodForm.latte');
    }

    public function register(Request $request, Response $response){
        $data = $request->getParsedBody();
        $validationResult = $this->validator->validateSavePeriod($data);

        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->create((array) $data);
        } else {
            $sthResult = ['consulta' => false];
        }

        return $this->container->get(LatteView::class)->render(
            $response,
            'Periodo/periodValidation.latte', [
                'validation'=> $validationResult, 
                'query' => $sthResult
            ]);
    }

    public function show(Request $request, Response $response){
        $sthResult = $this->infrastructure->readAll();
        return $this->container->get(LatteView::class)->render(
            $response,
            'Periodo/periodTable.latte', [
                'query' => $sthResult
            ]);
    }
    
    public function activate(Request $request, Response $response){

        if(isset($_GET['id']) && isset($_GET['activar'])) {
            $sthResult = $this->infrastructure->activate($_GET['id']);
        }
        return $this->container->get(LatteView::class)->render(
            $response,
            'Periodo/periodTable.latte', [
                'query' => $sthResult
            ]);
    }

    public function updateForm(Request $request, Response $response){

        $data = (array)$request->getParsedBody();
        return $this->container->get(LatteView::class)->render($response, 
        'Periodo/periodUpdate.latte', [
            'period_data' => $data
        ]);
    }

    public function update(Request $request, Response $response){
        
        $data = $request->getParsedBody();
        $validationResult = $this->validator->validateSavePeriod((array) $data);
        
        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->update((array) $data);
        } else {
            $sthResult = ['consulta' => false];
        }

        return $this->container->get(LatteView::class)->render(
            $response,
            'Periodo/periodValidation.latte', [
                'validation' => $validationResult, 
                'query' => $sthResult,
            ]);
    }

    public function delete(Request $request, Response $response){
        $sthResult = $this->infrastructure->delete((int) $_GET['id']);
        return $this->container->get(LatteView::class)->render(
            $response,
            'Periodo/periodValidation.latte', [
                'query' => $sthResult
            ]);
    }

    public function showEvaluationState(Request $request, Response $response) {
        $sthResult = $this->evaluationInfra->readAll();
        return $this->container->get(LatteView::class)->render(
            $response,
            'Periodo/periodTable.latte', [
                'query' => $sthResult
            ]);
    }

    public function updateEvaluationState(Request $request, Response $response) {
        $sthResult = $this->evaluationInfra->activate((int) $_GET['evaluacion']);
        
        return $this->container->get(LatteView::class)->render(
            $response,
            'Periodo/periodTable.latte', [
                'query' => $sthResult
            ]);
    }
}