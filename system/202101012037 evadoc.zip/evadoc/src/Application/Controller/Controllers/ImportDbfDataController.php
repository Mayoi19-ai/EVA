<?php
namespace App\Controller\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use App\Infrastructure\SieTemporary\DbfImport;
use App\Infrastructure\CrudSystem\PeriodInfrastructure as Infrastructure;

class ImportDbfDataController {
    private DbfImport $dbf;
    private Infrastructure $infrastructure;

    public function __construct(DbfImport $dbf, Infrastructure $infrastructure) {
        $this->dbf = $dbf;
        $this->infrastructure = $infrastructure;
    }

    public function importAll(Request $request, Response $response){
        $period = $this->infrastructure->readActivedPeriod();
        $importResult = $this->dbf->importData((int) $period['id']);
        print_r($importResult);
        return $response;
    }
}