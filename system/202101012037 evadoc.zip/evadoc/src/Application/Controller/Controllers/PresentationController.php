<?php
namespace App\Controller\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use Ujpef\LatteView;
use Slim\Exception\HttpForbiddenException;

class PresentationController{
    private Container $container;

    public function __construct(Container $container){
        $this->container = $container;
    }

    public function presentation(Request $request, Response $response){
        return $response;
        return $this->container->get(LatteView::class)->render($response, 'Menu/layout.latte');
    }

    public function login(Request $request, Response $response){
        return $this->container->get(LatteView::class)->render($response, 'Menu/layout.latte');
    }
}