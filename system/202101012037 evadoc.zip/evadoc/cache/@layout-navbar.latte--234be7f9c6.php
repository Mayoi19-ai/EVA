<?php
// source: Departamento\@layout-navbar.latte

use Latte\Runtime as LR;

class Template234be7f9c6 extends Latte\Runtime\Template
{
	public $blocks = [
		'content' => 'blockContent',
	];

	public $blockTypes = [
		'content' => 'html',
	];


	function main()
	{
		extract($this->params);
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('content', get_defined_vars());
		return get_defined_vars();
	}


	function blockContent($_args)
	{
		extract($_args);
?>
  <!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 6 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
      <link type="text/css" rel="stylesheet" href="/materialize/css/style.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
       
     
</head>
<body>
 
    <div class="">
    
        <!-- Dropdown Structure -->
           
            <nav>
                <div class="nav-wrapper blue-grey lighten-3">
                     <ul id="slide-out" class="sidenav">
                            <li><a href="/panel/lesson/show">Asignatura</a></li>
                            <li><a href="/panel/campus/show">Campus</a></li>
                            <li><a href="/panel/career/show">Carrera</a></li>
                            <li><a href="/panel/department/show">Departamento</a></li>
                            <li><a href="/panel/teacher/show">Docente</a></li>
                            <li><a href="/panel/period/show">Periodo</a></li>
                        </ul>
                        <a href="#" data-target="slide-out" class="sidenav-trigger show-on-large"><i class="material-icons">menu</i></a>
          
                     <ul class="right hide-on-med-and-down">
                        <li><a class="dropdown-trigger" href="#!" data-target="dropdown1">Dropdown<i class="material-icons right">arrow_drop_down</i></a></li>
                        <ul id='dropdown1' class='dropdown-content'>
                            <li><a href="#!">First</a></li>
                            <li><a href="#!">Second</a></li>
                            <li><a href="#!">Third</a></li>
                            <li><a href="#!">Fourth</a></li>
                        </ul>
                    </ul>
    <a href="#" data-target="slide-out" class="sidenav-trigger"><i class="material-icons">menu</i></a>
          
                </div>
            </nav>
     </div>

</body>
<script> M.AutoInit(); </script>
</html>
  
    
<?php
	}

}
