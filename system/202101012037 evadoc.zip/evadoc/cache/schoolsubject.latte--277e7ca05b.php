<?php
// source: Materia/schoolsubject.latte

use Latte\Runtime as LR;

class Template277e7ca05b extends Latte\Runtime\Template
{
	public $blocks = [
		'content' => 'blockContent',
	];

	public $blockTypes = [
		'content' => 'html',
	];


	function main()
	{
		extract($this->params);
?>

<?php
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('content', get_defined_vars());
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		$this->parentName = 'subjectForm.latte';
		
	}


	function blockContent($_args)
	{
?><p>Este es el saludo probiene de schoolsubject.latte.</p>
<?php
	}

}
