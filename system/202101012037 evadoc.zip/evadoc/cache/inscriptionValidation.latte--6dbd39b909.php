<?php
// source: Inscripcion/inscriptionValidation.latte

use Latte\Runtime as LR;

class Template6dbd39b909 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		return get_defined_vars();
	}

}
