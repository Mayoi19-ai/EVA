<?php
// source: Modalidad/modality.latte

use Latte\Runtime as LR;

class Template65ac0d3046 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		?><<?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		$this->parentName = 'modalityTable.latte';
		
	}

}
