<?php
namespace App\Infrastructure\CrudSystem;
use App\Infrastructure\CrudSystem\CustomException as Exception;

use Medoo\Medoo;

class CareerInfrastructure{
    private Medoo $db;
    private Exception $exception;

    public function __construct(Medoo $db, Exception $exception) {
        $this->db = $db;
        $this->exception = $exception;
    }

    public function create(array $data): array
    {
        $this->db->pdo->beginTransaction();
        $this->db->insert('carrera',[
            'id' => $data['id'],
            'clave' => strtoupper($data['clave']), 
            'nombre' => strtoupper($data['nombre']),
            'nombre_corto' => strtoupper($data['nombre_corto'])
        ]);

        $result = $this->exception->saveError((array) $this->db->error());
        return $result;
    }

    public function readAll(): array
    {
        $sql = $this->db->select('carrera', [
            'id', 
            'clave',
            'nombre',
            'nombre_corto'
        ]);
        
        $result = $this->exception->readError((array) $this->db->error(), (array) $sql);
        return $result;
    }

    public function readAuxiliary(): array
    {
        $sql = $this->db->select('carrera', [
            'id',
            'nombre'
        ]);

        $result = $this->exception->readError((array) $this->db->error(), (array) $sql);
        return $result;
    }

    public function update(array $data): array
    {
        $this->db->pdo->beginTransaction();
        $this->db->update('carrera', [
            'clave'  => strtoupper($data['clave']),
            'nombre' => strtoupper($data['nombre']),
            'nombre_corto' => strtoupper($data['nombre_corto'])], [
            'id' => $data['id']
        ]);

        $result = $this->exception->saveError((array) $this->db->error());
        return $result;
    }
    
    public function delete(int $id): array
    {   
        $this->db->pdo->beginTransaction();
        $this->db->delete('carrera', [
            'id' => $id
        ]);

        $result = $this->exception->deleteError((array) $this->db->error());
        return $result;
    }
}