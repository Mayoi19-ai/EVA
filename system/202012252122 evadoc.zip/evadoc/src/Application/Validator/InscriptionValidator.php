<?php
namespace App\Validator;
use Rakit\Validation\Validator;

class InscriptionValidator{
    private Validator $validator;

    public function __construct(Validator $validator) {
        $this->validator = $validator;
    }

    public function validateSaveInscription(array $data): array {
        $validationRules = [
            'id_curso'         =>  'required|numeric|digits_between:1,10',
            'control'          =>  'required|alpha_dash|between:8,8',
        ];

        $errorMessages = [
            'id_curso:required'   => 'La clave del curso es obligatoria',
            'id_curso:numeric'    => 'La clave del curso solo acepta números',
            'id_curso:between'    => 'La clave del curso debe tener entre 1 y 10 caracteres',
            'control:required'    => 'El número de control es obligatorio',
            'control:alpha_dash'  => 'El número de control no es válido',
            'control:between'     => 'El número de control debe tener 8 caracteres',
            'control:required'    => 'El número de control es obligatorio',
        ];

        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data);
    }
}