<?php
namespace App\Controller\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use App\Validator\InscriptionValidator as Validator;
use App\Validator\StudentValidator as StudentVal;
use Ujpef\LatteView;
use App\Infrastructure\CrudSystem\InscriptionInfrastructure as Infrastructure;
use App\Infrastructure\CrudSystem\CourseInfrastructure as CourseInfra;
use App\Infrastructure\CrudSystem\StudentInfrastructure as StudentInfra;

class InscriptionController{
    private Container $container;
    private Infrastructure $infrastructure;
    private CourseInfra $courseInfra;
    private StudentInfra $studentInfra;
    private StudentVal $studentVal;
    
    public function __construct(Container $container, Infrastructure $infrastructure, CourseInfra $courseInfra, StudentInfra $studentInfra, StudentVal $studentVal){
        $this->container = $container;
        $this->infrastructure = $infrastructure;
        $this->courseInfra = $courseInfra;
        $this->studentInfra = $studentInfra;
        $this->studentVal = $studentVal;
    }

    public function saveForm(Request $request, Response $response, array $args){
        $courseData = $this->courseInfra->readAll();
        $studentData = $this->studentInfra->readAll();

        return $this->container->get(LatteView::class)->render($response, 
            'Inscripcion/inscriptionForm.latte', [
                'courses' => $courseData,
                'students' => $studentData
            ]);
    }

    public function register(Request $request, Response $response){
        $data = $request->getParsedBody();
        $validationResult = $this->validator->validateSaveInscription((array) $data);

        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->update((array) $data);
        } else {
            $sthResult = ['consulta' => false];
        }

        return $this->container->get(LatteView::class)->render(
            $response,
            'Inscripcion/inscriptionValidation.latte', [
                'validation' => $validationResult, 
                'query' => $sthResult,
            ]);
    }

    public function show(Request $request, Response $response){
        $sthResult = $this->infrastructure->readAll(2);
        //$sthResult = $this->infrastructure->readAll($_GET['id_periodo']);
        return $this->container->get(LatteView::class)->render(
            $response,
            'Inscripcion/inscriptionValidation.latte', [
                'query' => $sthResult,
            ]);
    }

    public function searchByStudent(Request $request, Response $response){
        $validationResult = $this->studentVal->validateFindStudent((array) $_GET);

        if(!empty($validationResult['flag'])) {
            $sthResult = $this->studentInfra->readByStudent($_GET['control'], $_GET['id_period']);
        } else {
            $sthResult = ['consulta' => false];
        }

        return $this->container->get(LatteView::class)->render(
            $response,
            'Inscripcion/inscriptionValidation.latte', [
                'query' => $sthResult,
                'inscription_information' => $_GET
            ]);
    }

    public function updateForm(Request $request, Response $response){
        $data = $request->getParsedBody();
        $courseData = $this->courseInfra->readAll();
        $studentData = $this->studentInfra->readAll();

        return $this->container->get(LatteView::class)->render($response, 
            'Inscripcion/inscription.latte', [
                'courses' => $courseData,
                'students' => $studentData,
                'inscription_information' => $data
            ]);
    }

    public function update(Request $request, Response $response){
        $data = $request->getParsedBody();
        $validationResult = $this->validator->validateSaveInscription((array) $data);

        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->update((array) $data);
        } else {
            $sthResult = ['consulta' => false];
        }

        return $this->container->get(LatteView::class)->render(
            $response,
            'Inscripcion/inscriptionValidation.latte', [
                'validation' => $validationResult, 
                'query' => $sthResult,
            ]);
    }

    public function delete(Request $request, Response $response){
        $sthResult = $this->infrastructure->delete($_GET['id']);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Modalidad/modalityValidation.latte', [
                'query' => $sthResult
            ]);
    }
}