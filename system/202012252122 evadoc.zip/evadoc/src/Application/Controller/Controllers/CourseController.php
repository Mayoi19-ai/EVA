<?php
namespace App\Controller\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use App\Validator\CourseValidator as Validator;
use Ujpef\LatteView;
use App\Infrastructure\CrudSystem\CourseInfrastructure as Infrastructure;
use App\Infrastructure\CrudSystem\GroupInfrastructure as GroupInfra;
use App\Infrastructure\CrudSystem\SchoolSubjectInfrastructure as SubjectInfra;
use App\Infrastructure\CrudSystem\TeacherInfrastructure as TeacherInfra;

class CourseController {
    private Container $container;
    private Validator $validator;
    private Infrastructure $infrastructure;
    private GroupInfra $groupInfra;
    private SubjectInfra $subjectInfra;
    private TeacherInfra $teacherInfra;
    
    public function __construct(Container $container, Validator $validator, Infrastructure $infrastructure, GroupInfra $groupInfra, SubjectInfra $subjectInfra, TeacherInfra $teacherInfra){
        $this->container = $container;
        $this->validator = $validator;
        $this->infrastructure = $infrastructure;
        $this->groupInfra = $groupInfra;
        $this->subjectInfra = $subjectInfra;
        $this->teacherInfra = $teacherInfra;
    }

    public function saveForm(Request $request, Response $response){
        $groupData = $this->groupInfra->readAuxiliary($_GET['id_periodo']);
        $subjectData = $this->subjectInfra->readAll();
        $teacherData = $this->teacherInfra->readAll();

        return $this->container->get(LatteView::class)->render($response, 'Curso/courseFrom.latte', [
            'groups' => $groupData,
            'subjects' => $groupData,
            'teachers' => $teacherData
        ]);
    }

    public function register(Request $request, Response $response){
        $data = $request->getParsedBody();
        $validationResult = $this->validator->validateSaveCourse((array) $data);

        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->create((array) $data);
        } else {
            $sthResult = ['consulta' => false];
        }

        return $this->container->get(LatteView::class)->render(
            $response,
            'Curso/courseValidation.latte', [
                'validation' => $validationResult, 
                'query' => $sthResult
            ]);
    }

    public function searchByGroup(Request $request, Response $response){
        $validationResult = $this->validator->validateFindGroup((array) $_GET);
        
        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->read((string) $_GET['grupo'], (int) $_GET['id_periodo']);
        } else {
            $sthResult = ['consulta' => false];
        }
        
        return $this->container->get(LatteView::class)->render(
            $response,
            'Curso/courseValidation.latte', [
                'query' => $sthResult,
                'lesson_name' => $_GET['grupo'],
                'validation' => $validationResult
            ]);
    }

    public function searchByLesson(Request $request, Response $response){
        $validationResult = $this->validator->validateFindLesson((array) $_GET);

        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->read((string) $_GET['clave_asignatura'], (int) $_GET['id_periodo']);
        } else {
            $sthResult = ['consulta' => false];
        }

        return $this->container->get(LatteView::class)->render(
            $response,
            'Curso/courseValidation.latte', [
                'query' => $sthResult,
                'lesson_name' => $_GET['asignatura'],
                'validation' => $validationResult
            ]);
    }

    public function show(Request $request, Response $response){
        $sthResult = $this->infrastructure->readAll((int) $_GET['id_periodo']);
        print_r($sthResult);
        return $this->container->get(LatteView::class)->render(
            $response,
            'Curso/courseTable.latte', [
                'query' => $sthResult
            ]);
    }

    public function updateForm(Request $request, Response $response){
        $data = $request->getParsedBody();
        $groupData = $this->groupInfra->readAuxiliary($_GET['id_periodo']);
        $subjectData = $this->subjectInfra->readAll();
        $teacherData = $this->teacherInfra->readAll();

        return $this->container->get(LatteView::class)->render($response, 'Curso/course.latte', [
            'course_information' => $data,
            'groups' => $groupData,
            'subjects' => $groupData,
            'teachers' => $teacherData
        ]);
    }

    public function update(Request $request, Response $response){
        $data = $request->getParsedBody();
        $validationResult = $this->validator->validateSaveCourse((array) $data);
        
        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->update((array) $data);
        } else {
            $sthResult = ['consulta' => false];
        }

        return $this->container->get(LatteView::class)->render(
            $response,
            'Curso/courseValidation.latte', [
                'validation' => $validationResult, 
                'query' => $sthResult,
            ]);
    }

    public function delete(Request $request, Response $response){
        $data = $request->getParsedBody();
        $sthResult = $this->infrastructure->delete((array) $data);
        
        return $this->container->get(LatteView::class)->render(
            $response,
            'Curso/courseValidation.latte', [
                'query' => $sthResult
            ]);
    }
}