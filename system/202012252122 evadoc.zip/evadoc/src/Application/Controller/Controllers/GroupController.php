<?php
namespace App\Controller\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use Ujpef\LatteView;
use App\Validator\GroupValidator as Validator;
use App\Infrastructure\CrudSystem\GroupInfrastructure as Infrastructure;
use App\Infrastructure\CrudSystem\CareerInfrastructure as CareerInfra;
use App\Infrastructure\CrudSystem\ModalityInfrastructure as ModalityInfra;
use App\Infrastructure\CrudSystem\CampusInfrastructure as CampusInfra;

class GroupController{
    private Container $container;
    private Infrastructure $infrastructure;
    private CareerInfra $careerInfra;
    private ModalityInfra $modalityInfra;
    private CampusInfra $campusInfra;

    public function __construct(Container $container, Infrastructure $infrastructure, CareerInfra $careerInfra, ModalityInfra $modalityInfra, CampusInfra $campusInfra ){
        $this->container = $container;
        $this->infrastructure = $infrastructure;
        $this->careerInfra = $careerInfra;
        $this->modalityInfra = $modalityInfra;
        $this->campusInfra = $campusInfra;
    }

    public function saveForm(Request $request, Response $response){
        $careerData = $this->careerInfra->readAuxiliary();
        $modalityData = $this->modalityInfra->readAll();
        $campusData = $this->campusInfra->readAll();

        return $this->container->get(LatteView::class)->render($response, 
        'Grupo/group.latte', [
            'all_careers_information' => $careerData,
            'all_modalities_information' => $modalityData,
            'all_campus_information' => $campusData
        ]);
    }

    public function register(Request $request, Response $response){
        $data = $request->getParsedBody();
        $validationResult = $this->validator->validateSaveGroup((array) $data);

        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->create((array) $data);
        } else {
            $sthResult = ['consulta' => false];
        }

        return $this->container->get(LatteView::class)->render(
            $response,
            'Grupo/groupvalidation.latte', [
                'validation' => $validationResult, 
                'query' => $sthResult
            ]);
    }

    public function search(Request $request, Response $response){
        $validationResult = $this->lessonVal->validateFindGroup((array) $_GET);

        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->readByLesson((string) $_GET['grupo'], (int) $_GET['id_periodo']);
        } else {
            $sthResult = ['consulta' => false];
        }

        return $this->container->get(LatteView::class)->render(
            $response,
            'Maestros/validationteacher.latte', [
                'query' => $sthResult,
                'lesson_name' => $_GET['nombre']
            ]);
    }

    public function show(Request $request, Response $response){
        $sthResult = $this->infrastructure->readAll($_GET['id_periodo']);
        return $this->container->get(LatteView::class)->render(
            $response,
            'Grupo/groupTable.latte', [
                'query' => $sthResult,
                'group_name' => $_GET['id_periodo']
            ]);
    }

    public function updateForm(Request $request, Response $response){
        $data = $request->getParsedBody();
        $careerData = $this->careerInfra->readAuxiliary();
        $modalityData = $this->modalityInfra->readAll();
        $campusData = $this->campusInfra->readAll();

        return $this->container->get(LatteView::class)->render($response, 
        'Grupo/group.latte', [
            'all_careers_information' => $careerData,
            'all_modalities_information' => $modalityData,
            'all_campus_information' => $campusData,
            'group_information' => $data
        ]);
    }

    public function update(Request $request, Response $response){
        $data = $request->getParsedBody();
        $validationResult = $this->validator->validateSaveGroup((array) $data);

        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->update((array) $data);
        } else {
            $sthResult = ['consulta' => false];
        }

        return $this->container->get(LatteView::class)->render(
            $response,
            'Maestros/validationteacher.latte', [
                'validation' => $validationResult, 
                'query' => $sthResult
            ]);
    }

    public function delete(Request $request, Response $response){
        $data = $request->getParsedBody();
        $sthResult = $this->infrastructure->delete((array) $data);
       
        return $this->container->get(LatteView::class)->render(
            $response,
            'Modalidad/modalityValidation.latte', [
                'query' => $sthResult
            ]);
    }
}