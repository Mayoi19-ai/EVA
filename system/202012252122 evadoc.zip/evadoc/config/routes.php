<?php declare(strict_types=1);

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Log\LoggerInterface;
use Slim\App;
use Ujpef\LatteView;
use Slim\Routing\RouteCollectorProxy;

//use App\Controller\Presentation\presentationController;
//use App\Controller\Saludos;

use App\Controller\Controllers\MenuController;
use App\Controller\Controllers\TeacherController;
use App\Controller\Controllers\CampusController;
use App\Controller\Controllers\ModalityController;
use App\Controller\Controllers\PeriodController;
use App\Controller\Controllers\CareerController;
use App\Controller\Controllers\LessonController;
use App\Controller\Controllers\DepartmentController;
use App\Controller\Controllers\StudentController;
use App\Controller\Controllers\InscriptionController;
use App\Controller\Controllers\SchoolSubjectController;
use App\Controller\Controllers\CourseController;
use App\Controller\Controllers\GroupController;
use App\Controller\Controllers\QuestionnaireController;
use App\Controller\Controllers\ImportDbfDataController;
use App\Controller\Controllers\PruebaController;

return function(App $app): void
{
    $app->get('/test', ImportDbfDataController::class . ':importAll')->setName('test');
    $app->group('/panel', function (RouteCollectorProxy $group) {
        
        $group->get('/questionnaire', QuestionnaireController::class . ':getAll')->setName('getQuestionnaire');

        $group->get('/menu', MenuController::class . ':menu')->setName('menuAdmin');
        $group->get('/prueba', PruebaController::class . ':prueba')->setName('PruebasGera');

        $group->group('/teacher', function (RouteCollectorProxy $group) {
            $group->get('/save-form', TeacherController::class . ':saveForm')->setName('teacherSaveForm');
            $group->post('/register', TeacherController::class . ':register')->setName('teacherRegister');

            $group->get('/search', TeacherController::class . ':search')->setName('teacherSearch');
            $group->get('/order-department', TeacherController::class . ':orderByDepartment')->setName('teacherOrderByDepartment');

            $group->get('/show', TeacherController::class . ':show')->setName('showAllTeachers');
            $group->post('/update-form', TeacherController::class . ':updateForm')->setName('teacherUpdateForm');
            $group->post('/update', TeacherController::class . ':update')->setName('teacherUpdate');
            $group->get('/delete', TeacherController::class . ':delete')->setName('teacherDelete');
        });

        $group->group('/campus', function (RouteCollectorProxy $group) {
            $group->get('/save-form', CampusController::class . ':saveForm')->setName('campusSaveForm');
            $group->post('/register', CampusController::class . ':register')->setName('campusRegister');

            $group->get('/show', CampusController::class . ':show')->setName('showAllCampuses');
            $group->post('/update-form', CampusController::class . ':updateForm')->setName('campusUpdateForm');
            $group->post('/update', CampusController::class . ':update')->setName('campusUpdate');
            $group->get('/delete', CampusController::class . ':delete')->setName('campusDelete');
        });

        $group->group('/modality', function (RouteCollectorProxy $group) {
            $group->get('/save-form', ModalityController::class . ':saveForm')->setName('modalitySaveForm');
            $group->post('/register', ModalityController::class . ':register')->setName('modalityRegister');

            $group->get('/show', ModalityController::class . ':show')->setName('showAllModalities');
            $group->post('/update', ModalityController::class . ':update')->setName('modalityUpdate');
            $group->get('/delete', ModalityController::class . ':delete')->setName('modalityDelete');
        });

        $group->group('/period', function (RouteCollectorProxy $group) {
            $group->get('/save-form', PeriodController::class . ':saveForm')->setName('periodSaveForm');
            $group->post('/register', PeriodController::class . ':register')->setName('periodRegister');

            $group->get('/show', PeriodController::class . ':show')->setName('showAllPeriods');
            $group->post('/update-form', PeriodController::class . ':updateForm')->setName('periodUpdateForm');
            $group->post('/update', PeriodController::class . ':update')->setName('periodUpdate');
            $group->get('/delete', PeriodController::class . ':delete')->setName('periodDelete');
        });

        $group->group('/career', function (RouteCollectorProxy $group) {
            $group->get('/save-form', CareerController::class . ':saveForm')->setName('careerSaveForm');
            $group->post('/register', CareerController::class . ':register')->setName('careerRegister');

            $group->get('/show', CareerController::class . ':show')->setName('showAllCareers');
            $group->post('/update-form', CareerController::class . ':updateForm')->setName('careerUpdateForm');
            $group->post('/update', CareerController::class . ':update')->setName('careerUpdate');
            $group->get('/delete', CareerController::class . ':delete')->setName('careerDelete');
        });

        $group->group('/lesson', function (RouteCollectorProxy $group) {
            $group->get('/save-form', LessonController::class . ':saveForm')->setName('lessonSaveForm');
            $group->post('/register', LessonController::class . ':register')->setName('lessonRegister');

            $group->get('/search', LessonController::class . ':search')->setName('lessonSearch');

            $group->get('/show', LessonController::class . ':show')->setName('showAllLessons');
            $group->post('/update-form', LessonController::class . ':updateForm')->setName('lessonUpdateForm');
            $group->post('/update', LessonController::class . ':update')->setName('lessonUpdate');
            $group->get('/delete', LessonController::class . ':delete')->setName('lessonDelete');
        });

        $group->group('/department', function (RouteCollectorProxy $group) {
            $group->get('/save-form',  DepartmentController::class . ':saveForm')->setName('departmentSaveForm');
            $group->post('/register', DepartmentController::class . ':register')->setName('departmentRegister');

            $group->get('/show',  DepartmentController::class . ':show')->setName('showAllDepartments');
            $group->post('/update-form',  DepartmentController::class . ':updateForm')->setName('departmentUpdateForm');
            $group->post('/update',  DepartmentController::class . ':update')->setName('departmentUpdate');
            $group->get('/delete', DepartmentController::class . ':delete')->setName('departmentDelete');
        });

        $group->group('/student', function (RouteCollectorProxy $group) {
            $group->get('/save-form',  StudentController::class . ':saveForm')->setName('studentSaveForm');
            $group->post('/register', StudentController::class . ':register')->setName('studentRegister');
            
            $group->get('/search', StudentController::class . ':search')->setName('studentSearch');

            $group->get('/show',  StudentController::class . ':show')->setName('showAllStudents');
            
            $group->post('/update-form',  StudentController::class . ':updateForm')->setName('studentUpdateForm');
            $group->post('/update', StudentController::class . ':update')->setName('studentUpdate');
            $group->get('/delete', StudentController::class . ':delete')->setName('studentDelete');
        });

        $group->group('/inscriptions', function (RouteCollectorProxy $group) {
            $group->get('/save-form', InscriptionController::class . ':saveForm')->setName('inscriptionSaveForm');
            $group->post('/register', InscriptionController::class . ':register')->setName('inscriptionRegister');

            $group->get('/search-student', CourseController::class . ':searchByStudent')->setName('inscriptionSearchByStudent');

            $group->get('/show', InscriptionController::class . ':show')->setName('showAllInscriptions');
            $group->post('/update-form', InscriptionController::class . ':updateForm')->setName('inscriptionUpdateForm');
            $group->get('/update', InscriptionController::class . ':update')->setName('inscriptionUpdate');
            $group->get('/delete', InscriptionController::class . ':delete')->setName('inscriptionDelete');
        });

        
        $group->group('/subject', function (RouteCollectorProxy $group) {
            $group->get('/save-form', SchoolSubjectController::class . ':saveForm')->setName('subjectSaveForm');
            $group->post('/register', SchoolSubjectController::class . ':register')->setName('subjectRegister');

            $group->get('/order-career', SchoolSubjectController::class . ':orderByCareer')->setName('subjectOrderByCareer');
            $group->get('/search-lesson', SchoolSubjectController::class . ':searchByLesson')->setName('subjectSearchByLesson');

            $group->get('/show', SchoolSubjectController::class . ':show')->setName('showAllSubjects');
            $group->post('/update-form', SchoolSubjectController::class . ':updateForm')->setName('updateForm');
            $group->post('/update', SchoolSubjectController::class . ':update')->setName('subjectUpdate');
            $group->get('/delete', SchoolSubjectController::class . ':delete')->setName('subjectDelete');
        });

        $group->group('/course', function (RouteCollectorProxy $group) {
            $group->get('/save-form', CourseController::class . ':saveForm')->setName('courseSaveForm');
            $group->post('/register', CourseController::class . ':register')->setName('courseRegister');

            $group->get('/search-group', CourseController::class . ':searchByGroup')->setName('courseSearchByGroup');
            $group->get('/search-lesson', CourseController::class . ':searchByLesson')->setName('courseSearchByLesson');

            $group->get('/show', CourseController::class . ':show')->setName('showAllCourses');
            $group->post('/update-form', CourseController::class . ':updateForm')->setName('courseUpdateForm');
            $group->post('/update', CourseController::class . ':update')->setName('courseUpdate');
            $group->post('/delete', CourseController::class . ':delete')->setName('courseDelete');
        });

        $group->group('/group', function (RouteCollectorProxy $group) {
            $group->get('/save-form', GroupController::class . ':saveForm')->setName('groupSaveForm');
            $group->post('/register', GroupController::class . ':register')->setName('groupRegister');
            
            $group->get('/search', GroupController::class . ':search')->setName('groupSearch');

            $group->get('/show', GroupController::class . ':show')->setName('showAllGroups');
            $group->post('/update-form', GroupController::class . ':updateForm')->setName('groupUpdateForm');
            $group->post('/update', GroupController::class . ':update')->setName('groupUpdate');
            $group->get('/delete', GroupController::class . ':delete')->setName('groupDelete');
        });

    });
};
           //Menu
        //$group->group('/menu', function (RouteCollectorProxy $group) {
        //    $group->get('/show/{id}', MenuController::class . ':form')->setName('menuTest');
        //});
    
    //$app->get('/', presentationController::class . ':index')->setName('presentation');
    /*$app->get('/', function(Request $request, Response $response) {
        $response->getBody()->write('¡Hola mundo feliz!');
        return $response;
    })->setName('index');

    $app->get('/teacher/{name}', add::class . ':register')->setName('docenteAdd');

    $app->get('/test/{id}', presentationController::class . ':testdb')->setName('test');

    /*$app->get('/hello/{name}', function(Request $request, Response $response, $name) {
        $logger = $this->get(LoggerInterface::class);
        $logger->debug('Obteniendo datos desde los sensores remotos.');
        $logger->warning('Los datos están incompletos.');

        return $this->get(LatteView::class)->render($response, 'index.latte', [
            'variable' => 123,
            'name'     => $name
        ]);
    })->setName('sayhello');*/
