<?php
// source: Periodo/periodTable.latte

use Latte\Runtime as LR;

class Template2a6136c08f extends Latte\Runtime\Template
{
	public $blocks = [
		'content' => 'blockContent',
	];

	public $blockTypes = [
		'content' => 'html',
	];


	function main()
	{
		extract($this->params);
		/* line 1 */
		$this->createTemplate('@layout-navbar.latte', $this->params, "include")->renderToContentType('html');
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('content', get_defined_vars());
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['periodShow'])) trigger_error('Variable $periodShow overwritten in foreach on line 28');
		
	}


	function blockContent($_args)
	{
		extract($_args);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 8 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
        <link type="text/css" rel="stylesheet" href="/materialize/css/style.css"  media="screen,projection">
</head>

<body>
 <div class="MiTabla">
 <table name="showAllPeriods" method="get" class="bordered striped hoverable centered responsive-table"> <!-- nombre de tabla-->
<thead>
<tr>
<th>Nombre</th>
<th>Inicio</th>
<th>Fin</th>
<th></th>
<th></th>
</tr>
</thead>
<tbody>
<?php
		$iterations = 0;
		foreach ($all_period_information as $periodShow) {
?>
<tr>
    <td><?php echo LR\Filters::escapeHtmlText($periodShow['nombre']) /* line 30 */ ?> </td>
    <td><?php echo LR\Filters::escapeHtmlText($periodShow['inicia']) /* line 31 */ ?> </td>
    <td><?php echo LR\Filters::escapeHtmlText($periodShow['termina']) /* line 32 */ ?> </td>
    <td>
<form action="<?php
			echo $router->relativeUrlFor("periodUpdateForm");
?>" method="post">
            <input type="hidden" name="id" value="<?php echo LR\Filters::escapeHtmlAttr($periodShow['id']) /* line 35 */ ?>">
            <input type="hidden" name="nombre" value="<?php echo LR\Filters::escapeHtmlAttr($periodShow['nombre']) /* line 36 */ ?>">
            <input type="hidden" name="inicia" value="<?php echo LR\Filters::escapeHtmlAttr($periodShow['inicia']) /* line 37 */ ?>">
            <input type="hidden" name="termina" value="<?php echo LR\Filters::escapeHtmlAttr($periodShow['termina']) /* line 38 */ ?>">
<input type="submit" class="btn btn-primary btn-sm" value='Editar'>
</form>
</td>
   <td>
    <form action="<?php
			echo $router->relativeUrlFor("periodDelete");
?>" method="get">
            <input type="hidden" name="id" value="<?php echo LR\Filters::escapeHtmlAttr($periodShow['id']) /* line 44 */ ?>">
    <input type="submit"  style="background-color: #f44336" class="btn btn-primary btn-sm #f44336" value='Eliminar'>
    </form>
   </td>

</tr>
<?php
			$iterations++;
		}
?>
</tbody>
</table>
<div class="fixed-action-btn">
<a href="save-form" style="background-color: #4caf50" class="btn-floating btn-large #4caf50" ><i class="material-icons">add</i></a>
</div>
</div>
</body>
</html>
<?php
	}

}
