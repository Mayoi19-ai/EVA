<?php
// source: Asignatura/lessonForm.latte

use Latte\Runtime as LR;

class Template4c64679802 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		/* line 1 */
		$this->createTemplate('@layout-navbar.latte', $this->params, "include")->renderToContentType('html');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 6 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
</head>
<body>
<form name="lessonSaveForm" method="post" action="<?php
		echo $router->relativeUrlFor("lessonRegister");
?>">
  <!-- Datos del formulario -->

<div class="container section">
<div class="row">
<form class="col s12 m4 l2">
      <div class="row">
        <div class="input-field col col s12 m4 l8">
          Clave de asignatura<input type="text" name="clave">
            Nombre<input type="text" name="nombre">
        </div>
      </div>
    </div>

  <!-- Botón de envío de formulario -->
  
  <input type="submit" class="btn btn-primary btn-sm" value="Enviar formulario">

</form>
 

    <footer class="copyright"> 
        <p>Todos los derechos reservados, Gerardo y Raul 2020</p>
        
        
    </footer>
</body>
</html><?php
		return get_defined_vars();
	}

}
