<?php
// source: Preguntas\@layout-header.latte

use Latte\Runtime as LR;

class Template25851e5386 extends Latte\Runtime\Template
{
	public $blocks = [
		'content' => 'blockContent',
	];

	public $blockTypes = [
		'content' => 'html',
	];


	function main()
	{
		extract($this->params);
		?>  {
<?php
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('content', get_defined_vars()) ?>    }<?php
		return get_defined_vars();
	}


	function blockContent($_args)
	{
?> <div style="style.css">
        <div class="myheade">
            <div class="container setcion">
                <!-- Dropdown Structure -->
                    <ul id="dropdown1" class="dropdown-content">
                        <li><a href="#!">one</a></li>
                        <li><a href="#!">two</a></li>
                        <li class="divider"></li>
                        <li><a href="#!">three</a></li>
                    </ul>
                    <nav>
                        <div class="nav-wrapper">
                            <a href="#!" class="brand-logo">Logo</a>
                                <ul class="right hide-on-med-and-down">
                                 <li><a href="sass.html">Sass</a></li>
      <li><a href="badges.html">Components</a></li>
      <!-- Dropdown Trigger -->
      <li><a class="dropdown-trigger" href="#!" data-target="dropdown1">Dropdown<i class="material-icons right">arrow_drop_down</i></a></li>
    </ul>
  </div>
</nav>


            </div>
        </div>
    </div>
  
    
<?php
	}

}
