<?php
namespace App\Infrastructure\CrudSystem;

use Medoo\Medoo;
use App\Infrastructure\CrudSystem\CustomException as Exception;

class CampusInfrastructure{
    private Medoo $db;
    private Exception $exception;

    public function __construct(Medoo $db, Exception $exception) {
        $this->db = $db;
        $this->exception = $exception;
    }

    public function create(array $data): ?array
    {
        $this->db->pdo->beginTransaction();

        $sql = $this->db->insert('campus',[
            'nombre' => strtoupper($data['nombre'])
        ]);

        $result = $this->exception->saveError((array) $this->db->error());
        return $result;
    }

    public function readAll(): ?array
    {
        $sql = $this->db->select('campus', [
            'id', 'nombre'
        ]);
        
        $result = $this->exception->readError((array) $this->db->error(), (array) $sql);
        return $result;
    }

    public function update(array $data): ?array
    {
        $this->db->pdo->beginTransaction();

        $this->db->update('campus', [
            'nombre' => strtoupper($data['nombre'])], [
                'id' => $data['id']]);

        $result = $this->exception->saveError((array) $this->db->error());
        return $result;
    }
    
    public function delete(int $id): ?array
    {
        $this->db->pdo->beginTransaction();
        $this->db->delete('campus', [
            'id' => $id
        ]);
        
        $result = $this->exception->deleteError((array) $this->db->error());
        return $result;
    }
}