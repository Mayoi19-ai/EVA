<?php
namespace App\Infrastructure\CrudSystem;

use Medoo\Medoo;
use App\Infrastructure\CrudSystem\CustomException as Exception;

class SchoolSubjectInfrastructure{
    private Medoo $db;
    private Exception $exception;

    public function __construct(Medoo $db, Exception $exception) {
        $this->db = $db;
        $this->exception = $exception;
    }

    public function create(array $data): ?array
    {
        $this->db->pdo->beginTransaction();
        $this->db->insert('materia',[
            'id_carrera' => $data['id_carrera'], 
            'clave_asignatura' => $data['clave_asignatura']
        ]);

        $result = $this->exception->saveError((array) $this->db->error());
        return $result;
    }

    public function readAll(): ?array
    {
        $sql = <<<'EOP'
        SELECT carrera.nombre AS 'carrera', 
        carrera.id AS 'id_carrera',
        asignatura.nombre AS 'asignatura',
        asignatura.clave AS 'clave_asignatura'
        FROM 
        carrera, 
        asignatura, 
        materia
        WHERE 
        materia.id_carrera = carrera.id
        AND
        materia.clave_asignatura = asignatura.clave
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->execute();
        $records = $sth->fetchAll();
        
        $result = $this->exception->readError((array) $this->db->error(), (array) $records);
        return $result;
    }

    public function orderByCareer(int $careerId): ?array
    {
        $sql = <<<'EOP'
        SELECT carrera.nombre AS 'carrera', 
        carrera.id AS 'id_carrera',
        asignatura.nombre AS 'asignatura',
        asignatura.clave AS 'clave_asignatura'
        FROM 
        carrera, 
        asignatura, 
        materia
        WHERE 
        materia.id_carrera = carrera.id
        AND
        materia.clave_asignatura = asignatura.clave
        AND 
        carrera.id LIKE '%' :id_carrera '%';
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':id_carrera', $careerId);
        $sth->execute();
        $records = $sth->fetchAll();
        
        $result = $this->exception->readError((array) $this->db->error(), (array) $records);
        return $result;
    }

    public function readByLesson(string $lessonName): ?array
    {
        $sql = <<<'EOP'
        SELECT carrera.nombre AS 'carrera', 
        carrera.id AS 'id_carrera',
        asignatura.nombre AS 'asignatura',
        asignatura.clave AS 'clave_asignatura'
        FROM 
        carrera, 
        asignatura, 
        materia
        WHERE 
        materia.id_carrera = carrera.id
        AND
        materia.clave_asignatura = asignatura.clave
        AND 
        asignatura.nombre LIKE '%' :asignatura '%';
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':asignatura', $lessonName);
        $sth->execute();
        $records = $sth->fetchAll();
        
        $result = $this->exception->readError((array) $this->db->error(), (array) $records);
        return $result;
    }

    public function update(array $data): ?array
    {
        $this->db->pdo->beginTransaction();
        $this->db->update('materia',[
            'id_carrera' => $data['id_carrera'], 
            'clave_asignatura' => $data['clave_asignatura']],[
                'AND' => [
                'id_carrera' => $data['id_carrera_antiguo'], 
                'clave_asignatura' => $data['clave_asignatura_antiguo']
                ]
        ]);

        $result = $this->exception->saveError((array) $this->db->error());
        return $result;
    }
    
    public function delete(int $careerId, string $lessonCode): ?array
    {
        $this->db->pdo->beginTransaction();
        $this->db->delete('materia', [
            'AND' => [
            'id_carrera' => $careerId,
            'clave_asignatura' => $lessonCode
            ]
        ]);
        
        $result = $this->exception->deleteError((array) $this->db->error());
        return $result;
    }
}