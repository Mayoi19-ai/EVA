<?php
namespace App\Infrastructure;

use Medoo\Medoo;
use Psr\Container\ContainerInterface;

class LessonInfrastructure{
    private Medoo $db;
    private ContainerInterface $container;

    public function __construct(Medoo $db, ContainerInterface $container) {
        $this->db = $db;
        $this->container = $container;
    }

    public function insertLesson(array $lessonData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $lesson = $databaseInfra['lesson'];

        $data = $this->db->insert($lesson['table'],[
            $lesson['lessonCode'] => $teacherCode, 
            $lesson['lessonName'] => $teacherName]
        );

        return $data;
    }

    public function selectShowAllLesson(): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $lesson = $databaseInfra['lesson'];

        $data = $this->db->select($lesson['table'],[
            $lesson['lessonCode'], 
            $lesson['lessonName']]
        );

        return $data;
    }

    public function selectOneLesson(array $lessonData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $lesson = $databaseInfra['lesson'];

        $data = $this->db->select($lesson['table'], [
            $lesson['lessonCode'], 
            $lesson['lessonName']],[
                $lesson['lessonCode'] => $lessonCode]
            );

        return $data;
    }

    public function updateLesson(array $lessonData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $lesson = $databaseInfra['lesson'];

        $data = $this->db->update($lesson['table'], [
            $lesson['lessonCode'], 
            $lesson['lessonName']],[
                "AND" => [
                $lesson['lessonCode'] => $lessonCode,
                $lesson['lessonName'] => $lessonName]]
            );

        return $data;
    }
    
    public function deleteLesson(array $lessonData): ?array
    {
        $databaseInfra = $this->container->get('databaseTables');
        $lesson = $databaseInfra['lesson'];

        $data = $this->db->delete($lesson['table'], [
                "AND" => [
                $lesson['lessonCode'] => $lessonCode,
                $lesson['lessonName'] => $lessonName]]
        );

        return $data;
    }
}