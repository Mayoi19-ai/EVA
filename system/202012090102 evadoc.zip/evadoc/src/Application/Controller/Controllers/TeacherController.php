<?php
namespace App\Controller\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use App\Validator\TeacherValidator;
use Ujpef\LatteView;
use Slim\Exception\HttpForbiddenException;
use Medoo\Medoo;
use App\Infrastructure\TeacherInfrastructure;

class TeacherController{
    private $container;
    
    public function __construct(Container $container){
        $this->container = $container;
    }

    public function saveForm(Request $request, Response $response, array $args){
        // Simula que la lógica de negocios valida el id
        $id = (int) $args['id'];
        if($id > 5) {
            throw new HttpForbiddenException($request);
        }
        return $this->container->get(LatteView::class)->render($response, 'Maestros/teacher.latte', [
            'id' => $id,
        ]);
    }

    public function register(Request $request, Response $response, array $args){
        $resultData = [];
        
        $data = (array)$request->getParsedBody();
        $teacherVal = $this->container->get(TeacherValidator::class);
        
        $validationResult = $teacherVal->ValidateSaveTeacher($data, $resultData);
        
        if(empty($validationResult)){

            return $this->container->get(LatteView::class)->render(
                $response,
                'Maestros/validationteacher.latte',
                ['validacion_exitosa' => $validationResult] + $resultData
            );

        } else {
            $teacherInfraestructure = $this->container->get(TeacherInfrastructure::class);
            $dataTeacher = $teacherInfraestructure->insertTeacher($data);
        }
    }

    public function searchForm(Request $request, Response $response, array $args){
        // Simula que la lógica de negocios valida el id
        $id = (int) $args['id'];
        if($id > 5) {
            throw new HttpForbiddenException($request);
        }
        return $this->container->get(LatteView::class)->render($response, 'Maestros/teacher.latte', [
            'id' => $id,
        ]);
    }

    public function search(Request $request, Response $response, array $args){
        $resultData = [];
        
        $data = array("folio" => $args['folio']);
        
        $teacherVal = $this->container->get(TeacherValidator::class);
        
        $validationResult = $teacherVal->ValidateSearch($data, $resultData);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Maestros/validationteacher.latte',
            ['validacion_exitosa' => $validationResult] + $resultData
        );
    }

    public function show(Request $request, Response $response, array $args){
        $teacherInfraestructure = $this->container->get(TeacherInfrastructure::class);
        $dataTeacher = $teacherInfraestructure->selectDataTeacher();

        if(empty( $dataTeacher )) {
            $response->getBody()->write("No hay docentes registrados");
        }
        return $this->container->get(LatteView::class)->render(
            $response,
            'Maestros/teacherTable.latte'
        );
    }

    public function update(Request $request, Response $response, array $args){
        $resultData = [];
        
        $data = (array)$request->getParsedBody();
        $teacherVal = $this->container->get(TeacherValidator::class);
        
        $validationResult = $teacherVal->ValidateUpdate($data, $resultData);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Maestros/validationteacher.latte',
            ['validacion_exitosa' => $validationResult] + $resultData
        );
    }

    public function delete(Request $request, Response $response, array $args){
        $name = $args['folio'];
        $response->getBody()->write("$name");
        return $response;
    }
}

/*
   public function form(Request $request, Response $response, array $args){
        // Simula que la lógica de negocios valida el id
        $id = (int) $args['id'];
        if($id > 5) {
            throw new HttpForbiddenException($request);
        }
        return $this->container->get(LatteView::class)->render($response, 'Maestros/teacher.latte', [
            'id' => $id,
        ]);
    }

 */