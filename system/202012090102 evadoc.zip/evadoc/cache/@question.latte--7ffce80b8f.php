<?php
// source: Preguntas\@question.latte

use Latte\Runtime as LR;

class Template7ffce80b8f extends Latte\Runtime\Template
{
	public $blocks = [
		'content' => 'blockContent',
	];

	public $blockTypes = [
		'content' => 'html',
	];


	function main()
	{
		extract($this->params);
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('content', get_defined_vars());
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['question'])) trigger_error('Variable $question overwritten in foreach on line 31');
		
	}


	function blockContent($_args)
	{
		extract($_args);
?>


<!DOCTYPE html>
<html>
<head>
<h1><?php echo LR\Filters::escapeHtmlText($title) /* line 7 */ ?></h1>
 <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
 <link type="text/css" rel="stylesheet" href="/materialize/css/style.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <meta charset="utf-8">
</head>
<body>
 <form name="questionSaveForm" method="post" action="<?php
		echo $router->relativeUrlFor("studentRegister", ['id' => $id]);
?>">
 <div class="questionTabla"> 
       <table class="bordered striped hoverable centered responsive-table  " >
      
        <thead>
          <tr>
              <th>Preguntas</th>
              <th>Totalmente desacuerdo</th>
              <th>Desacuerdo</th>
              <th>Indeciso</th>
              <th>De acuerdo</th>
              <th>Totalmente de acuerdo</th>
          </tr>
        </thead>

        <tbody>
          
<?php
		$iterations = 0;
		foreach ($data as $question) {
?>
            <tr>
            <td><?php echo LR\Filters::escapeHtmlText($question['pregunta']) /* line 33 */ ?></td>
             
             
       <td>         
        <form>

    
      <label>
        <input class="with-gap" name="group1" type="radio" value="1" required>
        <span></span>
      </label>
   
    </td>

     <td>         
    
      <label>
        <input class="with-gap" name="group1" type="radio" value="2"  required>
        <span></span>
      </label>
   
    </td>

     <td>         
    
      <label>
        <input class="with-gap" name="group1" type="radio" value="3"  required>
        <span></span>
      </label>
   
    </td>

     <td>         
    
      <label>
        <input class="with-gap" name="group1" type="radio" value="4" required>
        <span></span>
      </label>
   
    </td>

     <td>         
    
      <label>
        <input class="with-gap" name="group1" type="radio" value="5" required>
        <span></span>
      </label>
   
    </td>
        </form>  
<?php
			$iterations++;
		}
?>
             </tr>
        </table>
</div>
</tbody>
  <input type="submit" value="Enviar formulario">
             </form>

</body>
<footer class="copyright"> 
        <p>Todos los derechos reservados, Gerardo y Raul 2020</p>
</footer>

</html>
<?php
	}

}
