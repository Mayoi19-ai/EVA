<?php
// source: Alumno/studentSearch.latte

use Latte\Runtime as LR;

class Templatef6a1d579bc extends Latte\Runtime\Template
{
	public $blocks = [
		'content' => 'blockContent',
	];

	public $blockTypes = [
		'content' => 'html',
	];


	function main()
	{
		extract($this->params);
		/* line 1 */
		$this->createTemplate('@layout-navbar.latte', $this->params, "include")->renderToContentType('html');
?>

<?php
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('content', get_defined_vars());
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['studentSearch'])) trigger_error('Variable $studentSearch overwritten in foreach on line 36');
		
	}


	function blockContent($_args)
	{
		extract($_args);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 9 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
        <link type="text/css" rel="stylesheet" href="/materialize/css/style.css"  media="screen,projection">
</head>

<body>
 <div class="MiTabla">
 <div class="row">
<div class="input-field col s6">
<form action="<?php
		echo $router->relativeUrlFor("studentSearch");
?>" method="get"> <!-- buscar -->
          <label><input type="text" id="control" name="control" value="<?php echo LR\Filters::escapeHtmlAttr($student_control) /* line 21 */ ?>" class="validate"></label>
    <input type="submit" class="btn btn-primary btn-sm" value='Buscar'>
    </form>
    </div>
<table name="showAllStudent" method="get" class="bordered striped hoverable centered responsive-table"> <!-- nombre de tabla-->
<thead>
</tr>
<tr>
<th>Control</th>
<th>Nombre</th>
<th></th>
<th></th>
</tr>
</thead>
<tbody>
<?php
		$iterations = 0;
		foreach ($query as $studentSearch) {
?>
<tr>
    <td><?php echo LR\Filters::escapeHtmlText($studentSearch['control']) /* line 38 */ ?> </td>
    <td><?php echo LR\Filters::escapeHtmlText($studentSearch['nombre']) /* line 39 */ ?> </td>
    <td>
<form action="<?php
			echo $router->relativeUrlFor("studentUpdateForm");
?>" method="post">
            <input type="hidden" name="control" value="<?php echo LR\Filters::escapeHtmlAttr($studentSearch['control']) /* line 42 */ ?>">
             <input type="hidden" name="nombre" value="<?php echo LR\Filters::escapeHtmlAttr($studentSearch['nombre']) /* line 43 */ ?>">
              <input type="hidden" name="contrasenia" value="<?php echo LR\Filters::escapeHtmlAttr($studentSearch['contrasenia']) /* line 44 */ ?>">
<input type="submit" class="btn btn-primary btn-sm" value='Editar'>
</form>
</td>
   <td>
    <form action="<?php
			echo $router->relativeUrlFor("studentDelete");
?>" method="get">
            <input type="hidden" name="control" value="<?php echo LR\Filters::escapeHtmlAttr($studentSearch['control']) /* line 50 */ ?>">
    <input type="submit" style="background-color: #f44336" class="btn btn-primary btn-sm" value='Eliminar'>
    </form>
   </td>

</tr>
<?php
			$iterations++;
		}
?>
<tbody>
<table>
</div>
</body>
</html>
<?php
	}

}
