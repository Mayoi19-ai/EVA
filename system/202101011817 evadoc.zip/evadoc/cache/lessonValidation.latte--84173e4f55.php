<?php
// source: Asignatura/lessonValidation.latte

use Latte\Runtime as LR;

class Template84173e4f55 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		return get_defined_vars();
	}

}
