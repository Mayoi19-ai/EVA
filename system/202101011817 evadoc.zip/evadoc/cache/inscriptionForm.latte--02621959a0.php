<?php
// source: Inscripcion\inscriptionForm.latte

use Latte\Runtime as LR;

class Template02621959a0 extends Latte\Runtime\Template
{
	public $blocks = [
		'content' => 'blockContent',
	];

	public $blockTypes = [
		'content' => 'html',
	];


	function main()
	{
		extract($this->params);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 5 */ ?></title>
</head>
<body>
    <h1><?php echo LR\Filters::escapeHtmlText($title) /* line 8 */ ?></h1>
    <?php
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('content', get_defined_vars());
?>
  
  <form name="inscriptionSaveForm" method="post" action="<?php
		echo $router->relativeUrlFor("inscriptionRegister", ['id' => $id]);
?>">
  <!-- Datos del formulario -->

  Codigo del curso <input type="text" name="courseCode">
  Numero de control <input type="text" name="studentControl">
  <!-- Botón de envío de formulario -->
  
  <input type="submit" value="Enviar formulario">

</form>
 
</form>
    <footer class="copyright"> 
        <p>Todos los derechos reservados, Gerardo y Raul 2020</p>
    </footer>
</body>
</html><?php
		return get_defined_vars();
	}


	function blockContent($_args)
	{
		
	}

}
