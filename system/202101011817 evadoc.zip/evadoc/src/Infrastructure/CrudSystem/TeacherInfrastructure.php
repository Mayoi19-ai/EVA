<?php
namespace App\Infrastructure\CrudSystem;

use Medoo\Medoo;
use App\Infrastructure\Exceptions\CustomException as Exception;

class TeacherInfrastructure{
    private Medoo $db;
    private Exception $exception;

    public function __construct(Medoo $db, Exception $exception) {
        $this->db = $db;
        $this->exception = $exception;
    }

    public function create(array $data): array
    {
        $this->db->pdo->beginTransaction();
        $this->db->insert('docente',[
            'folio' => $data['folio'], 
            'nombre' => strtoupper($data['nombre']),
            'clave_departamento' => $data['clave_departamento']
        ]);
        
        $result = $this->exception->saveError((array) $this->db->error());
        return $result;
    }

    public function readAll(): array
    {
        $sql = <<<'EOP'
        SELECT docente.folio AS 'folio', 
        docente.nombre AS 'nombre',
        departamento.clave AS 'clave_departamento',
        departamento.nombre  AS 'departamento'
        FROM 
        docente,
        departamento 
        where docente.clave_departamento =  departamento.clave;
        EOP;
        $sth = $this->db->pdo->prepare($sql);
        $sth->execute();
        $records = $sth->fetchAll();

        $result = $this->exception->readError((array) $this->db->error(), (array) $records);
        return $result;
    }

    public function read(string $name): array
    {
        $sql = <<<'EOP'
        SELECT docente.folio AS 'folio', 
        docente.nombre AS 'nombre',
        departamento.clave AS 'clave_departamento',
        departamento.nombre  AS 'departamento'
        FROM 
        docente,
        departamento 
        where docente.clave_departamento = departamento.clave
        AND docente.nombre LIKE '%' :nombre '%';
        EOP;
        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':nombre', strtoupper($name));
        $sth->execute();
        $records = $sth->fetchAll();

        $result = $this->exception->readError((array) $this->db->error(), (array) $records);
        return $result;
    }

    public function orderByDepartment(int $codeDepartment): array
    {
        $sql = <<<'EOP'
        SELECT docente.folio AS 'folio', 
        docente.nombre AS 'nombre',
        departamento.clave AS 'clave_departamento',
        departamento.nombre  AS 'departamento'
        FROM 
        docente,
        departamento 
        WHERE docente.clave_departamento = departamento.clave
        AND departamento.clave LIKE '%' :clave_departamento '%';
        EOP;
        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':clave_departamento', (int) $codeDepartment);
        $sth->execute();
        $records = $sth->fetchAll();

        $result = $this->exception->readError((array) $this->db->error(), (array) $records);
        return $result;
    }

    public function update(array $data): array
    {
        $this->db->pdo->beginTransaction();

        $this->db->update('docente', [
            'folio' => $data['folio'], 
            'nombre' => strtoupper($data['nombre']),
            'clave_departamento' => $data['clave_departamento']], [
                'folio' => $data['folio_antiguo']
            ]);

        $result = $this->exception->saveError((array) $this->db->error());
        return $result;
    }
    
    public function delete(int $code): array
    {
        $this->db->pdo->beginTransaction();
        $this->db->delete('docente', [
            'folio' => $code
        ]);
        
        $result = $this->exception->deleteError((array) $this->db->error());
        return $result;
    }
}