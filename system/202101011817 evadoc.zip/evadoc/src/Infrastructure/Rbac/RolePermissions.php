<?php
namespace App\Infrastructure\Rbac;

use Medoo\Medoo;
use App\Infrastructure\Exceptions\CustomException as Exception;

class RolePermissions {
    private Medoo $db;
    private Exception $exception;
    
    public function __construct(Medoo $db, Exception $exception) {
        $this->db = $db;
        $this->exception = $exception;
    }

    public function create(array $data): array
    {
        $this->db->pdo->beginTransaction();
        $this->db->insert('roles_permisos',[
            'id_roles' => $data['id_roles'],
            'id_permisos' => $data['id_permisos'],
            'activar' => 1
        ]);

        $result = $this->exception->saveError((array) $this->db->error());
        return $result;
    }

    public function readAll(): array
    {
        $sql = <<<'EOP'
        SELECT
        roles.id AS 'id_roles',
        roles.nombre AS 'rol',
        permisos.id AS 'id_permisos',
        permisos.categoria AS 'categoria',
        permisos.nombre AS 'permiso',
        roles_permisos.activar AS 'activar'
        FROM
        roles,
        permisos,
        roles_permisos
        WHERE
        roles.id = roles_permisos.id_roles
        AND 
        permisos.id = roles_permisos.id_permisos
        ORDER BY roles_permisos.id_roles ASC;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->execute();
        $records = $sth->fetchAll();
        
        $result = $this->exception->readError((array) $this->db->error(), (array) $records);
        return $result;
    }

    public function groupByRole(int $roleId): array
    {
        $sql = <<<'EOP'
        SELECT
        roles.id AS 'id_roles',
        roles.nombre AS 'rol',
        permisos.id AS 'id_permisos',
        permisos.categoria AS 'categoria',
        permisos.nombre AS 'permiso',
        roles_permisos.activar AS 'activar'
        FROM
        roles,
        permisos,
        roles_permisos
        WHERE
        roles.id = roles_permisos.id_roles
        AND 
        permisos.id = roles_permisos.id_permisos
        AND
        roles_permisos.id_roles = :id_roles;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':id_roles', $roleId);
        $sth->execute();
        $records = $sth->fetchAll();
        
        $result = $this->exception->readError((array) $this->db->error(), (array) $records);
        return $result;
    }

    public function update(array $data): array
    {
        $this->db->pdo->beginTransaction();
        $this->db->update('roles_permisos',[
            'id_roles' => $data['id_roles'],
            'id_permisos' => $data['id_permisos'], 
            'activar' => $data['activar']], [
                'AND' => [
                    'id_roles' => $data['id_roles_antiguo'],
                    'id_permisos' => $data['id_permisos_antiguo']
                ]
            ]);

        $result = $this->exception->saveError((array) $this->db->error());
        return $result;
    }

    public function delete(array $data): array
    {
        $this->db->pdo->beginTransaction();
        $this->db->delete('roles_permisos', [
            'AND' => [
                'id_roles' => $data['id_roles'],
                'id_permisos' => $data['id_permisos']
            ]
        ]);
        
        $result = $this->exception->deleteError((array) $this->db->error());
        return $result;
    }
}