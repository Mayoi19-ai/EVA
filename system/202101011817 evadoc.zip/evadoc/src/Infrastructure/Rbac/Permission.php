<?php
namespace App\Infrastructure\Rbac;

use Medoo\Medoo;
use App\Infrastructure\Exceptions\CustomException as Exception;

class Permission {
    private Medoo $db;
    private Exception $exception;
    
    public function __construct(Medoo $db, Exception $exception) {
        $this->db = $db;
        $this->exception = $exception;
    }

    public function readAll(): array
    {
        $sql = $this->db->select('permisos',[
            'id',
            'categoria',
            'nombre',
            'enlace'],[
                'ORDER' => ['categoria' => 'ASC']
            ]);

        $result = $this->exception->readError((array) $this->db->error(), (array) $sql);
        return $result;
    }

    public function readByCategory(string $category): array
    {
        $sql = $this->db->select('permisos',[
            'id',
            'categoria',
            'nombre',
            'enlace'],[
                'categoria' => $category
            ]);

        $result = $this->exception->readError((array) $this->db->error(), (array) $sql);
        return $result;
    }
}