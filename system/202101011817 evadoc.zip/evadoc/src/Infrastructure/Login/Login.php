<?php
namespace App\Infrastructure\Login;

use Medoo\Medoo;
use App\Infrastructure\Exceptions\CustomException as Exception;

class Login {
    private Medoo $db;
    private Exception $exception;
    
    public function __construct(Medoo $db, Exception $exception) {
        $this->db = $db;
        $this->exception = $exception;
    }

    public function findStudent(array $data): ?array
    {
        $sql = $this->db->get('alumno',[
            'control',
            'contrasenia'], [
                'control' => $data['nombre']
            ]);

        $result = $this->exception->readError((array) $this->db->error(), (array) $sql);
        return $result;
    }

    public function findUser(array $data): ?array
    {
        $sql = $this->db->get('usuario',[
            'id',
            'nombre',
            'contrasenia'], [
                'nombre' => $data['nombre']
            ]);

        $result = $this->exception->readError((array) $this->db->error(), (array) $sql);
        return $result;
    }

    public function saveSession(array $data): ? array
    {
        $this->db->pdo->beginTransaction();
        $this->db->insert('session',[
            'id' => $data['id'], 
            'visitante' => $data['visitante'],
            'ip' => $data['ip'],
            'navegador' => $data['userAgent']
        ]);
        
        $result = $this->exception->saveError((array) $this->db->error());
        return $result;
    }

    public function logged(string $id): ?array
    {
        $sql = $this->db->get('session',[
            'visitante',
            'ip',
            'navegador'], [
                'id' => $id
            ]);

        $result = $this->exception->readRecord((array) $this->db->error(), (array) $sql);
        return $result;
    }

    public function searchPermission(string $link): boolean
    {
        $sql = $this->db->get('permisos',[
            'enlace'], [
                'enlace' => $link
            ]);

        $result = $this->exception->readRecord((array) $this->db->error(), (array) $sql);
        return $result;
    }

    public function searchUserPermission(string $link, int $user): boolean
    {
        $sql = <<<'EOP'
        SELECT usuario.nombre,
        usuario.id,
        permisos.enlace
        FROM 
        usuario
        INNER JOIN 
        roles_usuario
        ON usuario.id = roles_usuario.id_usuario
        INNER JOIN 
        roles
        ON roles_usuario.id_roles = roles.id
        INNER JOIN 
        roles_permisos
        ON roles.id = roles_permisos.id_roles
        INNER JOIN 
        permisos
        ON roles_permisos.id_permisos = permisos.id
        WHERE usuario.id = :id_usuario AND permisos.enlace = :enlace;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':id_usuario', $user);
        $sth->bindParam(':enlace', $link);
        $sth->execute();
        $records = $sth->fetchAll();
        
        $result = $this->exception->readRecord((array) $this->db->error(), (array) $records);
        return $result;
    }

    public function deleteSession(string $id): boolean
    {
        $this->db->delete('session', [
            'id' => $id
        ]);
    }
}