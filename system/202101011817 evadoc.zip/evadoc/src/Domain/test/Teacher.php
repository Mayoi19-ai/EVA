<?php
namespace App\Infrastructure;

use Medoo\Medoo;

Class Teacher {

    private Medoo $db;

    public function __construct(Medoo $db) {
        $this->db = $db;
    }

    public function get(int $id): ?array
    {
        return $this->db->get('campus', ['nombre'], ['id' => $id]);
    }

}
