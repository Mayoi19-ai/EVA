<?php
namespace App\Validator;
use Rakit\Validation\Validator;

class GroupValidator{
    private Validator $validator;

    public function __construct(Validator $validator) {
        $this->validator = $validator;
    }

    public function validateSaveGroup(array $data): array {
        $validationRules = [
            'nombre'        =>  'required|alpha_dash|between:5,5',
            'id_periodo'    =>  'required|numeric|digits_between:1,10',
            'id_carrera'    =>  'required|numeric|digits_between:1,10',
            'id_modalidad'  =>  'required|numeric|digits_between:1,10',
            'id_campus'     =>  'required|numeric|digits_between:1,10',
        ];

        $errorMessages = [
            'nombre:required'              => 'El nombre es obligatorio',
            'nombre:alpha_dash'            => 'El nombre no acepta espacios ni caracteres especiales',
            'nombre:between'               => 'El nombre debe tener 5 caracteres',
            'id_periodo:required'          => 'La clave del periodo es obligatoria',
            'id_periodo:numeric'           => 'La clave del periodo es numerica',
            'id_periodo:digits_between'    => 'La clave del periodo debe tener entre 1 a 1 caracteres',
            'id_carrera:required'          => 'La clave es obligatoria',
            'id_carrera:numeric'           => 'La clave de carrera es numerica',
            'id_carrera:between'           => 'La clave de carrera debe tener entre 1 a 10 caracteres',
            'id_modalidad:required'        => 'La clave de modalidad es obligatoria',
            'id_modalidad:numeric'         => 'La clave de modalidad solo acepta números',
            'id_modalidad:digits_between'  => 'La clave de modadalidad debe tener entre 1 a 10 caracteres',
            'id_campus:required'           => 'La clave de campus es obligatoria',
            'id_campus:numeric'            => 'La clave de campus solo acepta números',
            'id_campus:digits_between'     => 'La clave de campus debe tener entre 1 a 10 caracteres',
        ];

        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data);
    }

    public function validateFindGroup(array $data): array {
        $validationRules = [
            'nombre'        =>  'required|alpha_dash|between:1,5',
            'id_periodo'    =>  'required|numeric|digits_between:1,10',
        ];

        $errorMessages = [
            'nombre:required'              => 'El nombre es obligatorio',
            'nombre:alpha_dash'            => 'El nombre no acepta espacios ni caracteres especiales',
            'nombre:between'               => 'El nombre debe tener 1 a 5 caracteres',
            'id_periodo:required'          => 'La clave del periodo es obligatoria',
            'id_periodo:numeric'           => 'La clave del periodo es numerica',
            'id_periodo:digits_between'    => 'La clave del periodo debe tener entre 1 a 1 caracteres',
        ];

        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data);
    }
}