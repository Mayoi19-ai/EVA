<?php
namespace App\Validator;
use Rakit\Validation\Validator;

class UserRolesValidator{
    private Validator $validator;

    public function __construct(Validator $validator) {
        $this->validator = $validator;
    }

    public function validateSaveRolePermissions(array $data): array {
        $validationRules = [
            'id_usuario'    =>  'required|numeric|digits_between:1,10',
            'id_roles'      =>  'required|numeric|digits_between:1,10',
        ];

        $errorMessages = [
            'id_usuario:required'    => 'La clave de usuario es obligatoria',
            'id_usuario:numeric'     => 'La clave de usuario solo acepta números',
            'id_usuario:between'     => 'La clave de usuario debe tener entre 1 y 10 caracteres',
            'id_roles:required'      => 'La clave de rol es obligatoria',
            'id_roles:numeric'       => 'La clave de rol solo acepta números',
            'id_roles:between'       => 'La clave de rol debe tener entre 1 y 10 caracteres',
        ];

        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data);
    }
}