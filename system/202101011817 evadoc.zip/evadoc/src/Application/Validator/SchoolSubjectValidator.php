<?php
namespace App\Validator;
use Rakit\Validation\Validator;

class SchoolSubjectValidator{
    private Validator $validator;

    public function __construct(Validator $validator) {
        $this->validator = $validator;
    }

    public function validateSaveSubject(array $data): array {
        $validatorRules = [
            'id_carrera'          =>  'required|alpha_dash|between:13,13',
            'clave_asignatura'    =>  'required|alpha_dash|between:8,8',
        ];

        $errorMessages = [
            'id_carrera:required'            => 'La clave de carrera es obligatoria',
            'id_carrera:between'             => 'La clave de carrera debe tener 13 caracteres',
            'clave_asignatura:required'      => 'La clave de asignatura es obligatoria',
            'clave_asignatura:alpha_dash'    => 'La clave de asignatura no acepta espacios o caracteres especiales',
            'clave_asignatura:between'       => 'La clave de asignatura debe tener 8 caracteres',
        ];

        $validator = new CustomValidator($this->validator, $validatorRules, $errorMessages);
        return $validator->validate($data);
    }
}