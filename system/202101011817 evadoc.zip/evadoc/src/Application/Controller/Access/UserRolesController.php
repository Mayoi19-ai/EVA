<?php
namespace App\Controller\Access;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use Ujpef\LatteView;
use App\Validator\UserRolesValidator as Validator;
use App\Validator\UserValidator as UserVal;
use App\Infrastructure\Rbac\UserRoles as Infrastructure;
use App\Infrastructure\Rbac\User as UserInfra;
use App\Infrastructure\Rbac\Role as RoleInfra;

class UserRolesController{
    private Container $container;
    private Validator $validator;
    private UserVal $userVal;
    private Infrastructure $infrastructure;
    private UserInfra $userInfra;
    private RoleInfra $roleInfra;

    public function __construct(Container $container, Validator $validator,Infrastructure $infrastructure, UserVal $userVal, UserInfra $userInfra, RoleInfra $roleInfra){
        $this->container = $container;
        $this->validator = $validator;
        $this->infrastructure = $infrastructure;
        $this->userVal = $userVal;
        $this->userInfra = $userInfra;
        $this->roleInfra = $roleInfra;
    }

    public function saveForm(Request $request, Response $response){
        $userData = $this->userInfra->readAll();
        $roleData = $this->roleInfra->readAll();
        return $this->container->get(LatteView::class)->render(
            $response, 'Campus/campusForm.latte', [
                'users' => $userData,
                'roles' => $roleData
            ]);
    }

    public function register(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $validationResult = $this->validator->validateSaveRolePermissions($data);

        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->create((array) $data);
        } else {
            $sthResult = ['consulta' => false];
        }
        return $this->container->get(LatteView::class)->render(
            $response,
            'Campus/campusValidation.latte',[
                'validation' => $validationResult, 
                'query' => $sthResult
            ]);
    }

    public function show(Request $request, Response $response){
        $sthResult = $this->infrastructure->readAll();
        
        return $this->container->get(LatteView::class)->render(
            $response,
            'Campus/campusTable.latte',
            ['query' => $sthResult
        ]);
    }

    public function searchByUser(Request $request, Response $response){
        $validationResult = $this->userVal->validateFindUser((array) $_GET);

        if(!empty($validationResult['flag'])) {
            $sthResult = $this->studentInfra->readByUser($_GET['nombre']);
        } else {
            $sthResult = ['consulta' => false];
        }

        return $this->container->get(LatteView::class)->render(
            $response,
            'Inscripcion/inscriptionValidation.latte', [
                'query' => $sthResult,
                'inscription_information' => $_GET['nombre']
            ]);
    }

    public function update(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $validationResult = $this->validator->validateSaveRolePermissions((array) $data);
        
        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->update((array) $data);
        } else {
            $sthResult = ['consulta' => false];
        }

        $this->infrastructure->update($data);
        return $this->container->get(LatteView::class)->render(
            $response,
            'Campus/campusValidation.latte', [
                'validation' => $validationResult,
                'query' => $sthResult
            ]);
    }

    public function updateForm(Request $request, Response $response){
        $userData = $this->userInfra->readAll();
        $roleData = $this->roleInfra->readAll();
        $data = (array)$request->getParsedBody();

        return $this->container->get(LatteView::class)->render(
            $response,
            'Campus/updateCampus.latte', [
                'data' => $data,
                'users' => $userData,
                'roles' => $roleData
            ]);
    }

    public function delete(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $sthResult = $this->infrastructure->delete((array) $data);
        return $this->container->get(LatteView::class)->render(
            $response,
            'Modalidad/modalityValidation.latte', [
                'query' => $sthResult
            ]);
    }
}