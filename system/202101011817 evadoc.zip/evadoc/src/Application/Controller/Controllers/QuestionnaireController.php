<?php
 namespace App\Controller\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use Slim\Exception\HttpForbiddenException;
use Ujpef\LatteView;

class QuestionnaireController {
    private Container $container;
    
    public function __construct(Container $container) {
        $this->container = $container;
    }

    public function getAll(Request $request, Response $response): Response {

        $latte = $this->container->get(LatteView::class)->render(
            $response,
            'Preguntas/layout.latte',           
        );
        return $latte;
    }
}