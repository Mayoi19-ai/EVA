<?php
namespace App\SessionLife;

use App\Infrastructure\Login\Login as Infrastructure;

class SessionLife{
    private Infrastructure $infrastructure;

    public function __construct(Infrastructure $infrastructure){
        $this->infrastructure = $infrastructure;
    }

    private function renewSession(array $session): boolean
    {
        if(isset($session['lastActivity']) ) {
            $sessionLife = time() -  $session['lastActivity'];
                if($sessionLife > 600) {
                    $this->logOut();
                    $this->infrastructure->deleteSession((string) $session['id']);
                    return false;
            }
        }
        $session['tiempo'] = time();
        return true;
    }

    private function logOut() {
        session_unset();
        session_destroy();
    }
}