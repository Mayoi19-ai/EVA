<?php
namespace App\Domain\Code;

class Code {
    public function code (array $individualCodes): string
    {
        foreach ($individualCodes as $code) {
            $codes[] = $code['clave'];
        }
        
        return implode($codes);
    }
}