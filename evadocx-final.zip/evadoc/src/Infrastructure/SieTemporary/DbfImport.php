<?php
namespace App\Infrastructure\SieTemporary;
use App\Infrastructure\SieTemporary\GroupDictionary as Group;
use App\Infrastructure\SieTemporary\SieCourse as Course;
use App\Infrastructure\SieTemporary\SieDepartment as Department;
use App\Infrastructure\SieTemporary\SieInscription as Inscription;
use App\Infrastructure\SieTemporary\SieSpecialty as Specialty;
use App\Infrastructure\SieTemporary\SieStudent as Student;
use App\Infrastructure\SieTemporary\SieSubject as Subject;
use App\Infrastructure\SieTemporary\SieTeacher as Teacher;
use App\Infrastructure\SieTemporary\SubjectDictionary;
use App\Infrastructure\ImportData\Queries;

class DbfImport {
    private Group $group;
    private Course $course;
    private Department $department;
    private Inscription $inscription;
    private Specialty $specialty;
    private Student $student;
    private Subject $subject;
    private Teacher $teacher;
    private SubjectDictionary $subjecDictionary;
    private Queries $queries;

    public function __construct(Group $group, Course $course, Department $department, Inscription $inscription, Specialty $specialty, Student $student, Subject $subject, Teacher $teacher, SubjectDictionary $subjecDictionary, Queries $queries) 
    {
        $this->group = $group;
        $this->course = $course;
        $this->department = $department;
        $this->inscription = $inscription;
        $this->specialty = $specialty;
        $this->student = $student;
        $this->subject = $subject;
        $this->teacher = $teacher;
        $this->subjecDictionary = $subjecDictionary;
        $this->queries = $queries;
    }

    public function importData (): bool
    { 
        //$directory = $this->container->get('settings')['files'];

        $xlsxFileGroup = __DIR__.'/../../../public/dbfFiles/Grupos.xlsx';
        //$xlsxFileGroup = __DIR__ . $directory . '/Grupos.xlsx';
        $temporaryGroupDictionary = $this->group->loadGroupDictionary($xlsxFileGroup);
        
        if(!empty($temporaryGroupDictionary)) {
            return $temporaryGroupDictionary;
        }

        $dbfFileDictionarySubject = __DIR__ . '/../../../public/dbfFiles/dret2.DBF';
        //$dbfFileDictionarySubject = __DIR__ . $directory . '/dret2.DBF';
        $temporarySubjectDictionary = $this->subjecDictionary->loadSubjectDictionary($dbfFileDictionarySubject);

        if(!empty($temporarySubjectDictionary)) {
            return $temporarySubjectDictionary;
        }

        $dbfFileSpecialty = __DIR__.'/../../../public/dbfFiles/desp.DBF';
        //$dbfFileSpecialty = __DIR__ . $directory . '/desp.DBF';
        $temporarySpecialty = $this->specialty->loadSieSpecialty($dbfFileSpecialty);

        if(!empty($temporarySpecialty)) {
            return $temporarySpecialty;
        }

        $dbfFileDepartment = __DIR__.'/../../../public/dbfFiles/ddep.DBF';
        //$dbfFileDepartment = __DIR__ . $directory . '/ddep.DBF';
        $temporaryDepartment = $this->department->loadSieDepartment($dbfFileDepartment);

        if(!empty($temporaryDepartment)) {
            return $temporaryDepartment;
        }

        $dbfFileSubject = __DIR__.'/../../../public/dbfFiles/dret.DBF';
        //$dbfFileSubject = __DIR__ . $directory . '/dret.DBF';
        $temporarySubject = $this->subject->loadSieSubject($dbfFileSubject);

        if(!empty($temporarySubject)) {
            return $temporarySubject;
        }

        $dbfFileTeacher = __DIR__.'/../../../public/dbfFiles/dcat.DBF';
        //$dbfFileTeacher = __DIR__ . $directory . '/dcat.DBF';
        $temporaryTeacher = $this->teacher->loadSieTeacher($dbfFileTeacher);

        if(!empty($temporaryTeacher)) {
            return $temporaryTeacher;
        }

        $dbfFileStudent = __DIR__.'/../../../public/dbfFiles/dalu.DBF';
        //$dbfFileStudent = __DIR__ . $directory . '/dalu.DBF';
        $temporaryStudent = $this->student->loadSieStudent($dbfFileStudent);

        if(!empty($temporaryStudent)) {
            return $temporaryStudent;
        }

        $dbfFileCourse = __DIR__.'/../../../public/dbfFiles/dgau.DBF';
        //$dbfFileCourse = __DIR__ . $directory . '/dgau.DBF';
        $temporaryCourse = $this->course->loadSieCourse($dbfFileCourse);

        if(!empty($temporaryCourse)) {
            return $temporaryCourse;
        }

        $dbfFileInscription = __DIR__.'/../../../public/dbfFiles/dlis.DBF';
        //$dbfFileInscription = __DIR__ . $directory . '/dlis.DBF';
        $temporaryInscription = $this->inscription->loadSieInscription($dbfFileInscription);

        if(!empty($temporaryInscription)) {
            return $temporaryInscription;
        }

        $importData = $this->queries->queries();
        
        if(!empty($importData)) {
            return $importData;
        }

        return true;
    }
}