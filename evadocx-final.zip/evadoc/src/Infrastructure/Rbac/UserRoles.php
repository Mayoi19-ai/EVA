<?php
namespace App\Infrastructure\Rbac;

use Medoo\Medoo;
use App\Infrastructure\Exceptions\CustomException as Exception;
use App\Infrastructure\Binnacle\Binnacle;

class UserRoles {
    private Medoo $db;
    private Exception $exception;
    private Binnacle $binnacle;
    
    public function __construct(Medoo $db, Exception $exception, Binnacle $binnacle)
    {
        $this->db = $db;
        $this->exception = $exception;
        $this->binnacle = $binnacle;
    }

    public function create(array $data): bool
    {
        $this->db->pdo->beginTransaction();
        $this->db->insert('roles_usuario',[
            'id_usuario' => $data['id_usuario'],
            'id_roles' => $data['id_roles']
        ]);

        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Registrar',
        'tabla_afectada' => 'Roles usuario'));

        return $this->exception->save((array) $this->db->error());
    }

    public function readAll(): ?array
    {
        $sql = <<<'EOP'
        SELECT
        usuario.id as 'id_usuario',
        usuario.nombre as 'usuario',
        roles.id as 'id_roles',
        roles.nombre as 'rol'
        FROM 
        usuario,
        roles,
        roles_usuario
        WHERE 
        roles_usuario.id_roles = roles.id
        AND
        roles_usuario.id_usuario = usuario.id
        ORDER BY usuario.nombre ASC;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->execute();
        $records = $sth->fetchAll();
        
        return $this->exception->read((array) $this->db->error(), (array) $records);
    }

    public function update(array $data): bool
    {
        $this->db->pdo->beginTransaction();
        $this->db->update('roles_usuario',[
            'id_usuario' => $data['id_usuario'],
            'id_roles' => $data['id_roles']], [
                'AND' => [
                    'id_usuario' => $data['id_usuario_antiguo'],
                    'id_roles' => $data['id_roles_antiguo']
                ]
        ]);
        
        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Actualizar',
        'tabla_afectada' => 'Roles usuario'));

        return $this->exception->save((array) $this->db->error());
    }

    public function delete(array $data): bool
    {
        $this->db->pdo->beginTransaction();
        $this->db->delete('roles_usuario', [
            'AND' => [
                'id_usuario' => $data['id_usuario'],
                'id_roles' => $data['id_roles']
            ]
        ]);
        
        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Eliminar',
        'tabla_afectada' => 'Roles usuario'));

        return $this->exception->delete((array) $this->db->error());
    }
}