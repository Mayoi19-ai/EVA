<?php
namespace App\Infrastructure\Reports;

use Medoo\Medoo;
use App\Infrastructure\Exceptions\CustomException as Exception;
use App\Infrastructure\Binnacle\Binnacle;

class TeacherReports
{
    private Medoo $db;
    private Exception $exception;
    private Binnacle $binnacle;

    public function __construct(Medoo $db, Exception $exception, Binnacle $binnacle) 
    {
        $this->db = $db;
        $this->exception = $exception;
        $this->binnacle = $binnacle;
    }

    public function readByTeacher(int $teacher): ?array
    {
        $sql = <<<'EOP'
        SELECT asignatura.clave,
        asignatura.nombre,
        curso.nombre_grupo,
        docente.nombre,
        COUNT(inscripcion.id),
        COUNT(evaluo.id)
        FROM evaluo
        RIGHT JOIN inscripcion
        ON evaluo.id = inscripcion.id
        INNER JOIN curso
        ON inscripcion.id_curso = curso.id
        INNER JOIN docente
        ON docente.folio = curso.folio_docente
        INNER JOIN materia
        ON curso.id_carrera = materia.id_carrera AND curso.clave_asignatura = materia.clave_asignatura
        INNER JOIN asignatura
        ON materia.clave_asignatura = asignatura.clave
        WHERE curso.id_periodo = (SELECT periodo.id FROM periodo WHERE periodo.activar = 1)
        AND inscripcion.activar = 1
        AND docente.folio = :folio
        GROUP BY inscripcion.id_curso;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':folio', $teacher);
        $sth->execute();
        $records = $sth->fetchAll();
        
        return $this->exception->read((array) $this->db->error(), (array) $records);
    }


    public function teacherResponses(int $teacher): ?array
    {
        $sql = <<<'EOP'
        SELECT respuestas_evaluacion.respuestas
        FROM respuestas_evaluacion
        INNER JOIN curso
        ON respuestas_evaluacion.id_curso = curso.id
        INNER JOIN docente
        ON curso.folio_docente = docente.folio
        WHERE docente.folio = :folio
        AND curso.id_periodo = (SELECT periodo.id FROM periodo WHERE periodo.activar = 1);
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':folio', $teacher);
        $sth->execute();
        $records = $sth->fetchAll();
        
        return $this->exception->read((array) $this->db->error(), (array) $records);
    }

    public function showByTeachers(int $department): ?array
    {
        $sql = <<<'EOP'
        SELECT docente.folio AS 'folio',
        docente.nombre AS 'docente',
        departamento.clave AS 'clave_departamento',
        departamento.nombre AS 'departamento'
        FROM respuestas_evaluacion
        INNER JOIN curso
        ON respuestas_evaluacion.id_curso = curso.id
        INNER JOIN docente
        ON curso.folio_docente = docente.folio
        INNER JOIN departamento
        ON docente.clave_departamento = departamento.clave
        WHERE docente.clave_departamento = :departamento
        AND curso.id_periodo = (SELECT periodo.id FROM periodo WHERE periodo.activar = 1);
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':departamento', $department);
        $sth->execute();
        $records = $sth->fetchAll();
        
        return $this->exception->read((array) $this->db->error(), (array) $records);
    }

    public function courses(int $teacher) {
        $sql = <<<'EOP'
        SELECT asignatura.clave,
        asignatura.nombre,
        curso.nombre_grupo,
        docente.nombre,
        COUNT(inscripcion.id),
        COUNT(evaluo.id)
        FROM evaluo
        RIGHT JOIN inscripcion
        ON evaluo.id = inscripcion.id
        INNER JOIN curso
        ON inscripcion.id_curso = curso.id
        INNER JOIN docente
        ON docente.folio = curso.folio_docente
        INNER JOIN materia
        ON curso.id_carrera = materia.id_carrera AND curso.clave_asignatura = materia.clave_asignatura
        INNER JOIN asignatura
        ON materia.clave_asignatura = asignatura.clave
        WHERE curso.id_periodo = (SELECT periodo.id FROM periodo WHERE periodo.activar = 1)
        AND inscripcion.activar = 1
        AND docente.folio = :folio
        GROUP BY inscripcion.id_curso
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':folio', $teacher);
        $sth->execute();
        $records = $sth->fetchAll();
        
        return $this->exception->read((array) $this->db->error(), (array) $records);
    }

    public function showByDepartments(): ?array
    {
        $sql = <<<'EOP'
        SELECT DISTINCT departamento.clave AS 'clave_departamento',
        departamento.nombre AS 'departamento'
        FROM respuestas_evaluacion
        INNER JOIN curso
        ON respuestas_evaluacion.id_curso = curso.id
        INNER JOIN docente
        ON curso.folio_docente = docente.folio
        INNER JOIN departamento
        ON docente.clave_departamento = departamento.clave
        WHERE curso.id_periodo = (SELECT periodo.id FROM periodo WHERE periodo.activar = 1);
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->execute();
        $records = $sth->fetchAll();
        
        return $this->exception->read((array) $this->db->error(), (array) $records);
    }

    public function departmentResponses(int $department): ?array
    {
        $sql = <<<'EOP'
        SELECT respuestas_evaluacion.respuestas
        FROM respuestas_evaluacion
        INNER JOIN curso
        ON respuestas_evaluacion.id_curso = curso.id
        INNER JOIN docente
        ON curso.folio_docente = docente.folio
        INNER JOIN departamento
        ON docente.clave_departamento = departamento.clave
        WHERE departamento.clave = :departamento
        AND curso.id_periodo = (SELECT periodo.id FROM periodo WHERE periodo.activar = 1);
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':departamento', $department);
        $sth->execute();
        $records = $sth->fetchAll();
        
        return $this->exception->read((array) $this->db->error(), (array) $records);
    }
}