<?php
namespace App\Infrastructure\CrudSystem;

use Medoo\Medoo;
use App\Infrastructure\Exceptions\CustomException as Exception;
use App\Infrastructure\Binnacle\Binnacle;

class SchoolSubjectInfrastructure{
    private Medoo $db;
    private Exception $exception;
    private Binnacle $binnacle;

    public function __construct(Medoo $db, Exception $exception, Binnacle $binnacle) 
    {
        $this->db = $db;
        $this->exception = $exception;
        $this->binnacle = $binnacle;
    }

    public function create(array $data): bool
    {
        $this->db->pdo->beginTransaction();
        $this->db->insert('materia',[
            'id_carrera' => $data['id_carrera'], 
            'clave_asignatura' => strtoupper($data['clave_asignatura'])
        ]);

        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Registrar',
        'tabla_afectada' => 'Materia'));
        
        return $this->exception->save((array) $this->db->error());
    }

    public function readAll(): ?array
    {
        $sql = <<<'EOP'
        SELECT carrera.nombre AS 'carrera', 
        carrera.id AS 'id_carrera',
        asignatura.nombre AS 'asignatura',
        asignatura.clave AS 'clave_asignatura'
        FROM 
        carrera, 
        asignatura, 
        materia
        WHERE 
        materia.id_carrera = carrera.id
        AND
        materia.clave_asignatura = asignatura.clave
        ORDER BY carrera.id ASC;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->execute();
        $records = $sth->fetchAll();
        
        return $this->exception->read((array) $this->db->error(), (array) $records);
    }

    public function showByCareer(int $careerId): ?array
    {
        $sql = <<<'EOP'
        SELECT carrera.nombre AS 'carrera', 
        carrera.id AS 'id_carrera',
        asignatura.nombre AS 'asignatura',
        asignatura.clave AS 'clave_asignatura'
        FROM 
        carrera, 
        asignatura, 
        materia
        WHERE 
        materia.id_carrera = carrera.id
        AND
        materia.clave_asignatura = asignatura.clave
        AND 
        carrera.id = :id_carrera
        ORDER BY carrera.id, asignatura.nombre ASC;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':id_carrera', $careerId);
        $sth->execute();
        $records = $sth->fetchAll();
        
        return $this->exception->read((array) $this->db->error(), (array) $records);
    }

    public function readByLesson(string $lessonName): ?array
    {
        $sql = <<<'EOP'
        SELECT carrera.nombre AS 'carrera', 
        carrera.id AS 'id_carrera',
        asignatura.nombre AS 'asignatura',
        asignatura.clave AS 'clave_asignatura'
        FROM 
        carrera, 
        asignatura, 
        materia
        WHERE 
        materia.id_carrera = carrera.id
        AND
        materia.clave_asignatura = asignatura.clave
        AND 
        asignatura.nombre LIKE '%' :asignatura '%'
        ORDER BY carrera.id ASC;
        EOP;

        $lesson = strtoupper($lessonName);
        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':asignatura', $lesson);
        $sth->execute();
        $records = $sth->fetchAll();
        
        return $this->exception->read((array) $this->db->error(), (array) $records);
    }

    public function update(array $data): bool
    {
        $this->db->pdo->beginTransaction();
        $this->db->update('materia',[
            'id_carrera' => $data['id_carrera'], 
            'clave_asignatura' => strtoupper($data['clave_asignatura'])],[
                'AND' => [
                'id_carrera' => $data['id_carrera_antiguo'], 
                'clave_asignatura' => $data['clave_asignatura_antiguo']
                ]
        ]);

        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Actualizar',
        'tabla_afectada' => 'Materia'));

        return $this->exception->save((array) $this->db->error());
    }
    
    public function delete(array $data): bool
    {
        $this->db->pdo->beginTransaction();
        $this->db->delete('materia', [
            'AND' => [
            'id_carrera' => $data['id_carrera'],
            'clave_asignatura' => $data['clave_asignatura']
            ]
        ]);
        
        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Eliminar',
        'tabla_afectada' => 'Materia'));

        return $this->exception->delete((array) $this->db->error());
    }
}