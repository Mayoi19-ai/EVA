<?php
namespace App\Validator;
use Rakit\Validation\Validator;

class ModalityValidator{
    private Validator $validator;

    public function __construct(Validator $validator) {
        $this->validator = $validator;
    }

    public function validateSaveModality(array $data): array {
        $validationRules = [
            'nombre'          =>  'required|alpha_spaces',  
        ];

        $errorMessages = [
            'nombre:required'       => 'El nombre es obligatorio',
            'nombre:alpha_spaces'   => 'El nombre no es válido',
        ];

        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data);
    }
}