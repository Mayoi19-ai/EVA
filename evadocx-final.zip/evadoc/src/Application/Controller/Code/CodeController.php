<?php
namespace App\Controller\Code;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use Ujpef\LatteView;
use App\Infrastructure\Code\Code as Infrastructure;

class CodeController{
    private Infrastructure $infrastructure;

    public function __construct(Container $container, Infrastructure $infrastructure){
        $this->container = $container;
        $this->infrastructure = $infrastructure;
    }

    public function verification (Request $request, Response $response, array $args) {
        $studentCode = (string) $args['code'];
        $data = $this->infrastructure->readAll();

        foreach ($data as $codes) {
            foreach ($codes as $key => $code) {
                if($key === 'clave') {
                    $codesArray[] = $code;
                }
            }
        }

        if(!empty($data)){
            $codeData = implode($codesArray);

            if (strpos($codeData, $studentCode) === false) {
                $message = false;
            } else {
                $message = true;
            }
        }

        return $this->container->get(LatteView::class)->render(
            $response, 
            'Codigo/code.latte', [
                'message' => $message
        ]);
    }
}