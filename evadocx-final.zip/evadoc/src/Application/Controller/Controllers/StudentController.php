<?php
namespace App\Controller\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use App\Validator\StudentValidator as Validator;
use Ujpef\LatteView;
use App\Infrastructure\CrudSystem\StudentInfrastructure as Infrastructure;
use App\Infrastructure\Login\Login as LoginInfra;

class StudentController{
    private Container $container;
    private Infrastructure $infrastructure;
    private Validator $validator;
    private LoginInfra $LoginInfra;
    
    public function __construct(Container $container, Infrastructure $infrastructure, Validator $validator, LoginInfra $LoginInfra)
    {
        $this->container = $container;
        $this->infrastructure = $infrastructure;
        $this->validator = $validator;
        $this->loginInfra = $LoginInfra;
    }

    public function saveForm(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $permissions = $this->loginInfra->userPermissions((array) $data);
        $sthResult = $this->infrastructure->readAll();

        return $this->container->get(LatteView::class)->render($response, 
            'Alumno/studentForm.latte', [
                'permissions' => $permissions,
                'query' => $sthResult,
                'data' => $data
            ]);
    }

    public function register(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $validationResult = $this->validator->validateSaveStudent((array) $data);
        
        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->create((array) $data);
        } else {
            $sthResult = false;
        }

        return $this->container->get(LatteView::class)->render(
            $response,
            'Alumno/studentForm.latte', [
                'validation' => $validationResult, 
                'query' => $sthResult,
                'data' => $data
            ]);
    }

    public function search(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $permissions = $this->loginInfra->userPermissions((array) $data);
        $validationResult = $this->validator->validateFindStudent((array) $data);

        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->read((string) $data['control']);
        } else {
            $sthResult = false;
        }

        return $this->container->get(LatteView::class)->render(
            $response,
            'Alumno/studentTable.latte', [
                'query' => $sthResult,
                'data' => $data,
                'permissions' => $permissions,
                'validation' => $validationResult,  
            ]);
    }
    
    public function show(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $sthResult = $this->infrastructure->readAll();
        $permissions = $this->loginInfra->userPermissions((array) $data);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Alumno/studentTable.latte', [
                'query' => $sthResult,
                'data' => $data,
                'permissions' => $permissions,
            ]);
    }

    public function updateForm(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $permissions = $this->loginInfra->userPermissions((array) $data);
        $sthResult = $this->infrastructure->readAll();

        return $this->container->get(LatteView::class)->render($response, 
            'Alumno/studentUpdate.latte', [
                'permissions' => $permissions,
                'query' => $sthResult,
                'data' => $data
            ]);
    }

    public function update(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $validationResult = $this->validator->validateSaveStudent((array) $data);

        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->update((array) $data);
        } else {
            $sthResult = false;
        }


        return $this->container->get(LatteView::class)->render(
            $response,
            'Alumno/studentUpdate.latte', [
                'validation' => $validationResult,
                'query' => $sthResult,
                'data' => $data
            ]);
    }

    public function updatePassword(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $this->infrastructure->updatePasswordAdmin((array) $data);
        $sthResult = $this->infrastructure->readAll();
        $permissions = $this->loginInfra->userPermissions((array) $data);

        return $this->container->get(LatteView::class)->render(
            $response,
                'Alumno/studentTable.latte', [
                'query' => $sthResult,
                'data' => $data,
                'permissions' => $permissions
            ]);
    }

    public function delete(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $this->infrastructure->delete((array) $data);
        $sthResult = $this->infrastructure->readAll();
        $permissions = $this->loginInfra->userPermissions((array) $data);
        
        return $this->container->get(LatteView::class)->render(
            $response,
                'Alumno/studentTable.latte', [
                'query' => $sthResult,
                'data' => $data,
                'permissions' => $permissions
            ]);
    }
}