<?php
namespace App\UploadFiles;
use Psr\Http\Message\UploadedFileInterface;
use Psr\Container\ContainerInterface as Container;

class UploadFiles{
    private Container $container;

    public function __construct(Container $container) 
    {
        $this->container = $container;
    }

    public function upload(array $uploadedFiles): ?bool 
    {
        foreach ($uploadedFiles['files'] as $uploadedFile) {
            if ($uploadedFile->getError() === UPLOAD_ERR_OK) {
                $extension = pathinfo($uploadedFile->getClientFilename(), PATHINFO_EXTENSION);
                $basename = pathinfo($uploadedFile->getClientFilename(), PATHINFO_FILENAME);
                $filename = $basename . "." . $extension;
                $files[$filename] = $uploadedFile;
            }
        }
        return $this->verification((array) $files);
    }

    private function moveUploadedFile(string $directory, string $file ,UploadedFileInterface $object): void 
    {
        $object->moveTo($directory . DIRECTORY_SEPARATOR . $file);
    }

    private function verification(array $files): bool
    {
        $directory = $this->container->get('settings')['files'];

        foreach($files as $file => $object) {
            $this->moveUploadedFile($directory, $file, $object);
            $filename[] = $file;
        }

        $sieFiles = array('Grupos.xlsx' ,'dret2.DBF' ,'desp.DBF' ,'ddep.DBF', 'dret.DBF','dcat.DBF','dalu.DBF','dgau.DBF', 'dlis.DBF');
        
        if(empty(array_diff($filename, $sieFiles))){
            return true;
        }

        $this->deleteFiles();
        return false;
    }

    public function deleteFiles(): bool
    {
        $directory = $this->container->get('settings')['files'];
        array_map('unlink', glob($directory . '/*'));
        return true;
    }
}