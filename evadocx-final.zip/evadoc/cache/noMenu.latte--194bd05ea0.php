<?php
// source: Menu\noMenu.latte

use Latte\Runtime as LR;

class Template194bd05ea0 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 5 */ ?></title>
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
      <script type="text/javascript" src="/materialize/js/jquery.min.js"></script>
      <script type="text/javascript" src="/materialize/js/jquery-qrcode-0.18.0.js"></script>
      <script src="/materialize/js/materialize.min.js"></script>
      <link type="text/css" rel="stylesheet" href="/materialize/css/naver.css"  media="screen,projection">
      <script>
      $(document).ready(function () {
        $('select').selectize({
          sortField: 'text'
        });
      });
      </script>

</head>  
  <body>
    <nav>
      <div class="nav-wrapper blue-grey lighten-3">
        <img class="logo" src="https://www.itshuatusco.edu.mx/inicio/images/Logo%20ITSH%20300x312%20negritas.png">
          <ul id="nav-mobile" class="right hide-on-med-and-down">
            <li>
              <a class="dropdown-trigger" href="#!" data-target="dropdown1">Opciones<i class="material-icons right">arrow_drop_down</i></a></li>
                <ul id='dropdown1' class='dropdown-content'>
                  <li><a href="<?php
		echo $router->relativeUrlFor("usersLogin");
?>">Cerrar sesion</a></li>                  
                  <li> <form method="post" action="<?php
		echo $router->relativeUrlFor("studentPasswordUpdateForm");
?>">
<?php
		$iterations = 0;
		foreach ($categories as $Category) {
			?>                   <form action="<?php
			echo $router->relativeUrlFor("userPasswordUpdateForm");
?>" method="post">
                      <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($user) /* line 33 */ ?>">
                      <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($Category['categoria_permisos']) /* line 34 */ ?>">
<?php
			$iterations++;
		}
?>
        <input type="submit" value="cambiar contraseña" >  
        </form> 
                </ul>
            </ul>
          </li>
        </ul>
      </div>
    </nav>
  </body>
</html><?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['Category'])) trigger_error('Variable $Category overwritten in foreach on line 31');
		
	}

}
