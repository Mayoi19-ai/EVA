<?php
// source: Materia/subjectForm.latte

use Latte\Runtime as LR;

class Template76693676c9 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		/* line 1 */
		$this->createTemplate('../validationCreate.latte', $this->params, "include")->renderToContentType('html');
		/* line 2 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 7 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
       <link type="text/css" rel="stylesheet" href="/materialize/css/formularios.css"  media="screen,projection">
</head>
<body>
<ul id="nav-mobile">
<div class="container section">
<form name="subjectSaveForm" method="post" action="<?php
		echo $router->relativeUrlFor("subjectRegister");
?>">

 <label for="id_carrera">Selecciona una carrera:</label>
<select class="browser-default" name="id_carrera">
  <option value="" name="id_carrera">Selecciona una carrera</option>
<?php
		$iterations = 0;
		foreach ($all_careers_information as $idCarrera) {
			?>      <option  value="<?php echo LR\Filters::escapeHtmlAttr($idCarrera['id']) /* line 22 */ ?>" ><?php
			echo LR\Filters::escapeHtmlText($idCarrera['nombre']) /* line 22 */ ?></option>
<?php
			$iterations++;
		}
?>
  </select>

 <label for="clave_asignatura">Selecciona una asignatura:</label>
  <select class="browser-default" name="clave_asignatura">
  <option value="" name="clave_asignatura">Selecciona una asignatura</option>
<?php
		$iterations = 0;
		foreach ($all_lessons_information as $idAsignatura) {
			?>      <option  value="<?php echo LR\Filters::escapeHtmlAttr($idAsignatura['clave']) /* line 30 */ ?>" ><?php
			echo LR\Filters::escapeHtmlText($idAsignatura['nombre']) /* line 30 */ ?></option>
<?php
			$iterations++;
		}
?>
  </select>
  <!-- -->
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 34 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 35 */ ?>">
  <!-- -->
 <button id="guardar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Guardar<i class="material-icons left">send</i></button>

</form>
</div>
<div>
<form action="<?php
		echo $router->relativeUrlFor("showAllSubjects");
?>" method="post">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 43 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 44 */ ?>">
 <button id="retornar" type="submit" class="btn btn-primary btn-sm float-1" style="background-color: #10c2ee" >Retornar<i class="material-icons left">arrow_back</i></button>
            </form>
            </div>
     <!--footer -->
                  <div class="content"></div>
            <div class="footer-copyright blue-grey lighten-3" >
            <div class="container">
           <img class="header container section" src="/materialize/css/pie.jpg">
            </div>
          </div>
        </footer>
</body>
 <script>M.AutoInit();</script>
</html><?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['idCarrera'])) trigger_error('Variable $idCarrera overwritten in foreach on line 21');
		if (isset($this->params['idAsignatura'])) trigger_error('Variable $idAsignatura overwritten in foreach on line 29');
		
	}

}
