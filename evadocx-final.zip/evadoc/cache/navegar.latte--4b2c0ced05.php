<?php
// source: Menu\navegar.latte

use Latte\Runtime as LR;

class Template4b2c0ced05 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 5 */ ?></title>
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
      <script type="text/javascript" src="/materialize/js/jquery.min.js"></script>
      <script type="text/javascript" src="/materialize/js/jquery-qrcode-0.18.0.js"></script>
      <script src="/materialize/js/materialize.min.js"></script>
      <link type="text/css" rel="stylesheet" href="/materialize/css/naver.css"  media="screen,projection">
      <!-- -->
      
      <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js%22%3E"></script>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js%22%3E"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.6/js/standalone/selectize.min.js" integrity="sha256-+C0A5Ilqmu4QcSPxrlGpaZxJ04VjsRjKu+G82kl5UJk=" crossorigin="anonymous"></script>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.6/css/selectize.bootstrap3.min.css" integrity="sha256-ze/OEYGcFbPRmvCnrSeKbRTtjG4vGLHXgOqsyLFTRjg=" crossorigin="anonymous">
   
      <script>
      $(document).ready(function () {
        $('select').selectize({
          sortField: 'text'
        });
      });
      </script>

</head>  
  <body>
   <img class="header container section" src="/materialize/css/cabeza.jpg">
    <nav>
      <div class="nav-wrapper blue-grey lighten-3">
        <img class="logo" src="https://www.itshuatusco.edu.mx/inicio/images/Logo%20ITSH%20300x312%20negritas.png">
          <ul id="nav-mobile" class="right hide-on-med-and-down">
            <li><form action="<?php
		echo $router->relativeUrlFor("userMenu");
?>" method="post">
                <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 35 */ ?>">
                <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 36 */ ?>">
                <input type="submit" class="botonMenu  waves-light" value="Menu">
                </form>
            </li>
            <li>
              <a class="dropdown-trigger" data-target="dropdown1"><i class="material-icons right">arrow_drop_down</i></a></li>
                <ul id='dropdown1' class='dropdown-content'>
                  <li><a href="<?php
		echo $router->relativeUrlFor("usersLogin");
?>">Cerrar sesion</a></li>                  
                </ul>
            </ul>
          </li>
        </ul>
      </div>
    </nav>
  </body>
  <script> M.AutoInit(); </script>
</html><?php
		return get_defined_vars();
	}

}
