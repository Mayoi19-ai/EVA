<?php
// source: Docente/teacherTable.latte

use Latte\Runtime as LR;

class Template1f657a137b extends Latte\Runtime\Template
{
	public $blocks = [
		'content' => 'blockContent',
	];

	public $blockTypes = [
		'content' => 'html',
	];


	function main()
	{
		extract($this->params);
		/* line 1 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
		/* line 2 */
		$this->createTemplate('../validationDelete.latte', $this->params, "include")->renderToContentType('html');
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('content', get_defined_vars());
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['searchOption'])) trigger_error('Variable $searchOption overwritten in foreach on line 35');
		if (isset($this->params['permissionInfor'])) trigger_error('Variable $permissionInfor overwritten in foreach on line 93, 108, 125');
		if (isset($this->params['teacherShow'])) trigger_error('Variable $teacherShow overwritten in foreach on line 78');
		
	}


	function blockContent($_args)
	{
		extract($_args);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 9 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
      <link type="text/css" rel="stylesheet" href="/materialize/css/formularios.css"  media="screen,projection">
</head>
<!-- -->
<div class="container section">
  <ul id="nav-mobile">
    <div class="row">
      <div class="col s12 m6 l3">
   <form name="SearchForm" method="post" action="<?php
		echo $router->relativeUrlFor("teacherSearch");
?>">
   <label for="nombre">Busqueda por nombre</label>
        <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 22 */ ?>">
        <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 23 */ ?>">
        <input type="text" name="nombre">
       <button id="buscar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee">Buscar<i class="material-icons left">search</i></button>
</div>
</form>
   <div class="col s12 m6 l3">
<form name="SearchFormDepartment" method="post" action="<?php
		echo $router->relativeUrlFor("teacherShowByDepartment");
?>">
<label for="nombre">Busqueda por departamento</label>
          <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 31 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 32 */ ?>">
      <select class="browser-default" name="clave_departamento">
      <option value="<?php echo LR\Filters::escapeHtmlAttr($data['clave']) /* line 34 */ ?>" name="clave_departamento"></option>
<?php
		$iterations = 0;
		foreach ($all_departments_information as $searchOption) {
			?>      <option  value="<?php echo LR\Filters::escapeHtmlAttr($searchOption['clave']) /* line 36 */ ?>" ><?php
			echo LR\Filters::escapeHtmlText($searchOption['nombre']) /* line 36 */ ?> </option>
<?php
			$iterations++;
		}
?>
    </select>
<button id="buscar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee">Buscar<i class="material-icons left">search</i></button>
</div>
</div>
</div>
</form>
<!-- -->

<body>

<!-- -->
<?php
		if (empty ($query)) {
?>
       <div class="container section">
       <div class="card center">
              <div class="card center">
              <img class="logo" src="/materialize/css/alerta3.png">
                     <h5>NO HAY DOCENTES REGISTRADOS</h5>
                       <form action="<?php
			echo $router->relativeUrlFor("userMenu");
?>" method="post">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 56 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 57 */ ?>">
 <input id="retorno" type="submit" class="btn btn-primary btn-sm" value='Retornar'>
            </form>
                    
              </div>
       </div>
</div>

<?php
		}
		else {
?>

<table name="showAllTeacher" method="get" class="bordered striped hoverable centered highlight responsive-table"> <!-- nombre de tabla-->
<thead>
<tr>
<th>Folio de docente</th>
<th>Nombre de docente</th>
<th>Nombre de departamento</th>
<th></th>
<th></th>
</tr>
</thead>
<tbody>
<?php
			$iterations = 0;
			foreach ($query as $teacherShow) {
?>
<tr>
    <td><?php echo LR\Filters::escapeHtmlText($teacherShow['folio']) /* line 80 */ ?> </td>
    <td><?php echo LR\Filters::escapeHtmlText($teacherShow['nombre']) /* line 81 */ ?> </td>
    <td><?php echo LR\Filters::escapeHtmlText($teacherShow['departamento']) /* line 82 */ ?> </td>
    <td>
<form action="<?php
				echo $router->relativeUrlFor("teacherUpdateForm");
?>" method="post">
            <input type="hidden" name="folio" value="<?php echo LR\Filters::escapeHtmlAttr($teacherShow['folio']) /* line 85 */ ?>">
             <input type="hidden" name="nombre" value="<?php echo LR\Filters::escapeHtmlAttr($teacherShow['nombre']) /* line 86 */ ?>">
              <input type="hidden" name="clave_departamento" value="<?php echo LR\Filters::escapeHtmlAttr($teacherShow['clave']) /* line 87 */ ?>">
              <input type="hidden" name="nombre_departamento" value="<?php echo LR\Filters::escapeHtmlAttr($teacherShow['departamento']) /* line 88 */ ?>">
              <!-- -->
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 90 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 91 */ ?>">
            <!-- -->
<?php
				$iterations = 0;
				foreach ($permissions as $permissionInfor) {
					$permisos  = explode(" - ", $permissionInfor['enlace']);
					;
					if ($permisos[1] == "teacherUpdateForm") {
?>
        <button id="actualizar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Editar<i class="material-icons left">edit</i></button>
<?php
					}
					$iterations++;
				}
?>
</form>
</td>
<td>
    <form action="<?php
				echo $router->relativeUrlFor("teacherDelete");
?>" method="post" onsubmit="return confirmation()">
      <input type="hidden" name="folio" value="<?php echo LR\Filters::escapeHtmlAttr($teacherShow['folio']) /* line 103 */ ?>">
            <!-- No tocar lo de abajo-->
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 105 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 106 */ ?>">
            <!--No tocar lo de arriba -->
<?php
				$iterations = 0;
				foreach ($permissions as $permissionInfor) {
					$permisos  = explode(" - ", $permissionInfor['enlace']);
					;
					if ($permisos[1] == "teacherDelete") {
?>
    <button type="submit" id="eliminar" style="background-color: #f44336" class="btn btn-primary btn-sm #f44336" value='Eliminar'>Eliminar<i class="material-icons left">delete</i></button>
<?php
					}
					$iterations++;
				}
?>
    </form>
</td>

</tr>
<?php
				$iterations++;
			}
?>

</tbody>
 <form action="<?php
			echo $router->relativeUrlFor("teacherSaveForm");
?>" method="post">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 122 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 123 */ ?>">
   <div class="fixed-action-btn">
<?php
			$iterations = 0;
			foreach ($permissions as $permissionInfor) {
				$permisos  = explode(" - ", $permissionInfor['enlace']);
				;
				if ($permisos[1] == "teacherSaveForm") {
?>
<button id="agrerar" type="submit" class="btn btn-primary btn-sm float-2" style="background-color: #22DD22" >Agregar<i class="material-icons left">add</i></button>
<?php
				}
				$iterations++;
			}
		}
?>
</form>
</table>
</div>
<!--footer -->
                   <div class="content"></div>
            <div class="footer-copyright blue-grey lighten-3" >
            <div class="container">
           <img class="header container section" src="/materialize/css/pie.jpg">
            </div>
          </div>
        </footer>
</body>
<script> M.AutoInit(); </script>
</html>
<?php
	}

}
