<?php
// source: Curso/coursesUpdate.latte

use Latte\Runtime as LR;

class Templateffab435ae2 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		/* line 1 */
		$this->createTemplate('../validationUpdate.latte', $this->params, "include")->renderToContentType('html');
		/* line 2 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 7 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
      <link type="text/css" rel="stylesheet" href="/materialize/css/formularios.css"  media="screen,projection">
</head>
<body>
<div class="container section">
<form name="courseUpdateForm" method="post" action="<?php
		echo $router->relativeUrlFor("courseUpdate");
?>">
               <input type="hidden" name="grupo" value="<?php echo LR\Filters::escapeHtmlAttr($data['grupo']) /* line 16 */ ?>">
              <input type="hidden" name="clave_asignatura" value="<?php echo LR\Filters::escapeHtmlAttr($data['clave_asignatura']) /* line 17 */ ?>">
              <input type="hidden" name="folio_docente" value="<?php echo LR\Filters::escapeHtmlAttr($data['folio_docente']) /* line 18 */ ?>">
              <input type="hidden" name="carrera" value="<?php echo LR\Filters::escapeHtmlAttr($data['carrera']) /* line 19 */ ?>">
              <input type="hidden" name="asignatura" value="<?php echo LR\Filters::escapeHtmlAttr($data['asignatura']) /* line 20 */ ?>">
              <input type="hidden" name="docente" value="<?php echo LR\Filters::escapeHtmlAttr($data['docente']) /* line 21 */ ?>">
            <!-- -->
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 23 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 24 */ ?>">
            <!-- -->

<div class="container section">
<input type="hidden" name="id_curso" id="id_curso" value="<?php echo LR\Filters::escapeHtmlAttr($data['id_curso']) /* line 28 */ ?>">
    <ul>
  <li>
    <label for="grupo">seleccione un grupo:</label>
      <select class="browser-default" name="grupo">
      <option value="<?php echo LR\Filters::escapeHtmlAttr($data['grupo']) /* line 33 */ ?>" name="grupo"><?php
		echo LR\Filters::escapeHtmlText($data['grupo']) /* line 33 */ ?> - <?php echo LR\Filters::escapeHtmlText($data['carrera']) /* line 33 */ ?></option>
<?php
		$iterations = 0;
		foreach ($all_groups_information as $groupOption) {
			?>      <option  value="<?php echo LR\Filters::escapeHtmlAttr($groupOption['grupo']) /* line 35 */ ?>" ><?php
			echo LR\Filters::escapeHtmlText($groupOption['grupo']) /* line 35 */ ?> - <?php echo LR\Filters::escapeHtmlText($groupOption['carrera']) /* line 35 */ ?></option>
<?php
			$iterations++;
		}
?>
    </select>
  </li>
  <li>
  
    <label for="clave_asignatura_id_carrera">seleccione una asignatura:</label>
      <select class="browser-default" name="clave_asignatura_id_carrera" id="clave_asignatura_id_carrera">
      <option value="<?php echo LR\Filters::escapeHtmlAttr($data['asignatura']) /* line 43 */ ?> <?php echo LR\Filters::escapeHtmlAttr($data['carrera']) /* line 43 */ ?>" name="clave_asignatura_id_carrera"><?php
		echo LR\Filters::escapeHtmlText($data['asignatura']) /* line 43 */ ?> - <?php echo LR\Filters::escapeHtmlText($data['carrera']) /* line 43 */ ?></option>
<?php
		$iterations = 0;
		foreach ($all_subjects_information as $subjectOption) {
			?>      <option  value="<?php echo LR\Filters::escapeHtmlAttr($subjectOption['clave_asignatura']) /* line 45 */ ?> <?php
			echo LR\Filters::escapeHtmlAttr($subjectOption['id_carrera']) /* line 45 */ ?>" ><?php echo LR\Filters::escapeHtmlText($subjectOption['asignatura']) /* line 45 */ ?> - <?php
			echo LR\Filters::escapeHtmlText($subjectOption['carrera']) /* line 45 */ ?></option>
<?php
			$iterations++;
		}
?>
    </select>
  </li>

  <li>
    <label for="folio_docente">Seleccione un docente:</label>
      <select class="browser-default" name="folio_docente">
      <option value="<?php echo LR\Filters::escapeHtmlAttr($data['docente']) /* line 53 */ ?>" name="folio_docente"><?php
		echo LR\Filters::escapeHtmlText($data['docente']) /* line 53 */ ?></option>
<?php
		$iterations = 0;
		foreach ($all_teachers_information as $teachersOption) {
			?>      <option  value="<?php echo LR\Filters::escapeHtmlAttr($teachersOption['folio']) /* line 55 */ ?>" ><?php
			echo LR\Filters::escapeHtmlText($teachersOption['nombre']) /* line 55 */ ?></option>
<?php
			$iterations++;
		}
?>
    </select>
  </li>

 </ul>
<button id="guardar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Guardar<i class="material-icons left">send</i></button>
</div>
</form>


</div>
<form action="<?php
		echo $router->relativeUrlFor("showAllCourses");
?>" method="post">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 68 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 69 */ ?>">
 <button id="retornar" type="submit" class="btn btn-primary btn-sm float-1" style="background-color: #10c2ee" >Retornar<i class="material-icons left">arrow_back</i></button>
            </form>
            </div>

    <!--footer -->
                   <div class="content"></div>
            <div class="footer-copyright blue-grey lighten-3" >
            <div class="container">
           <img class="header container section" src="/materialize/css/pie.jpg">
            </div>
          </div>
        </footer>
</body>
<script> M.AutoInit(); </script>
</html><?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['groupOption'])) trigger_error('Variable $groupOption overwritten in foreach on line 34');
		if (isset($this->params['subjectOption'])) trigger_error('Variable $subjectOption overwritten in foreach on line 44');
		if (isset($this->params['teachersOption'])) trigger_error('Variable $teachersOption overwritten in foreach on line 54');
		
	}

}
