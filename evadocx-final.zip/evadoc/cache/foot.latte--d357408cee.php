<?php
// source: Menu\foot.latte

use Latte\Runtime as LR;

class Templated357408cee extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
 <footer class="page-footer blue-grey lighten-3">
          <div class="footer-copyright">
            <div class="row">
              <div class="s12 m4 l8">
                <p>© 2021 Copyright Todos los derechos reservados, Gerardo y Raul 2020</p>
              </div>
            </div>
          </div>
        </footer>    <?php
		return get_defined_vars();
	}

}
