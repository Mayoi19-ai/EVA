<?php
// source: Usuario/userTable.latte

use Latte\Runtime as LR;

class Template78ccd7ade7 extends Latte\Runtime\Template
{
	public $blocks = [
		'content' => 'blockContent',
	];

	public $blockTypes = [
		'content' => 'html',
	];


	function main()
	{
		extract($this->params);
		/* line 1 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
		/* line 2 */
		$this->createTemplate('../validationDelete.latte', $this->params, "include")->renderToContentType('html');
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('content', get_defined_vars());
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['permissionInfor'])) trigger_error('Variable $permissionInfor overwritten in foreach on line 38, 51, 68');
		if (isset($this->params['UserInfo'])) trigger_error('Variable $UserInfo overwritten in foreach on line 29');
		
	}


	function blockContent($_args)
	{
		extract($_args);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 9 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
        <link type="text/css" rel="stylesheet" href="/materialize/css/formularios.css"  media="screen,projection">
</head>

<body>
  <ul id="nav-mobile">
<div class="MiTabla" class="container setcion responsive-table" >
<table name="showAllCampuses" method="get" class="bordered striped hoverable centered responsive-table">
<thead>
<tr>
<th>Usuario</th>
<th></th>
<th></th>
</tr>
</thead>
<tbody>

<?php
		$iterations = 0;
		foreach ($query as $UserInfo) {
?>
<tr>
    <td><?php echo LR\Filters::escapeHtmlText($UserInfo['nombre']) /* line 31 */ ?> </td>
    <td>
<form action="<?php
			echo $router->relativeUrlFor("userUpdateForm");
?>" method="post">
            <input type="hidden" name="id" value="<?php echo LR\Filters::escapeHtmlAttr($UserInfo['id']) /* line 34 */ ?>">
            <input type="hidden" name="usuario" value="<?php echo LR\Filters::escapeHtmlAttr($UserInfo['nombre']) /* line 35 */ ?>">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 36 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 37 */ ?>">
<?php
			$iterations = 0;
			foreach ($permissions as $permissionInfor) {
				$permisos  = explode(" - ", $permissionInfor['enlace']);
				;
				if ($permisos[1] == "userUpdateForm") {
?>
        <button id="actualizar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Editar<i class="material-icons left">edit</i></button>
<?php
				}
				$iterations++;
			}
?>
</form>
</td>
<td>
    <form action="<?php
			echo $router->relativeUrlFor("userDelete");
?>" method="post" onsubmit="return confirmation()">
            <input type="hidden" name="id" value="<?php echo LR\Filters::escapeHtmlAttr($UserInfo['id']) /* line 48 */ ?>">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 49 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 50 */ ?>">
<?php
			$iterations = 0;
			foreach ($permissions as $permissionInfor) {
				$permisos  = explode(" - ", $permissionInfor['enlace']);
				;
				if ($permisos[1] == "userDelete") {
?>
    <button type="submit" id="eliminar" style="background-color: #f44336" class="btn btn-primary btn-sm #f44336" value='Eliminar'>Eliminar<i class="material-icons left">delete</i></button>
<?php
				}
				$iterations++;
			}
?>
    </form>
</td>

</tr>
<?php
			$iterations++;
		}
?>

</tbody>
 <form action="<?php
		echo $router->relativeUrlFor("userSaveForm");
?>" method="post">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 65 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 66 */ ?>">
   <div class="fixed-action-btn">
<?php
		$iterations = 0;
		foreach ($permissions as $permissionInfor) {
			$permisos  = explode(" - ", $permissionInfor['enlace']);
			;
			if ($permisos[1] == "userSaveForm") {
?>
<button type="submit" class="float" ><i class="material-icons center">add</i></button>
<?php
			}
			$iterations++;
		}
?>
</form>
</table>
</div>
<!--footer -->
                   <div class="content"></div>
            <div class="footer-copyright blue-grey lighten-3" >
            <div class="container">
           <img class="header container section" src="/materialize/css/pie.jpg">
            </div>
          </div>
        </footer>
</body>
</html>
<?php
	}

}
