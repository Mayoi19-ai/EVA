<?php
// source: Reporte/reportTable.latte

use Latte\Runtime as LR;

class Template6a9343315d extends Latte\Runtime\Template
{
	public $blocks = [
		'content' => 'blockContent',
	];

	public $blockTypes = [
		'content' => 'html',
	];


	function main()
	{
		extract($this->params);
		/* line 1 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('content', get_defined_vars());
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['departmentOption'])) trigger_error('Variable $departmentOption overwritten in foreach on line 30');
		if (isset($this->params['permissionInfor'])) trigger_error('Variable $permissionInfor overwritten in foreach on line 81');
		if (isset($this->params['teacherShow'])) trigger_error('Variable $teacherShow overwritten in foreach on line 66');
		if (isset($this->params['datos'])) trigger_error('Variable $datos overwritten in foreach on line 105');
		
	}


	function blockContent($_args)
	{
		extract($_args);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 8 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
        <link type="text/css" rel="stylesheet" href="/materialize/css/style.css"  media="screen,projection">
        
<!-- Prueba de graficos-->
<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>
<!-- -->

</head>
<!-- -->
<div class="container section">
<form name="teachersShowList" method="post" action="<?php
		echo $router->relativeUrlFor("teachersShowList");
?>">
          <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 25 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 26 */ ?>">
        
        <select class="browser-default" name="clave_departamento" required>
      <option value="" name="clave_departamento"></option>
<?php
		$iterations = 0;
		foreach ($all_departments_information as $departmentOption) {
			?>      <option  value="<?php echo LR\Filters::escapeHtmlAttr($departmentOption['clave_departamento']) /* line 31 */ ?>" ><?php
			echo LR\Filters::escapeHtmlText($departmentOption['departamento']) /* line 31 */ ?> </option>
<?php
			$iterations++;
		}
?>
    </select>
  
  <button id="buscar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee">Buscar<i class="material-icons left">search</i></button>
  </form>
  </div>
<!-- -->

<body>

<!-- -->
<?php
		if (empty ($all_teachers_information)) {
?>
       <div class="container section">
       <div class="card center">
              <div class="card center">
                     <h5>SELECCIONA UN DEPARTAMENTO</h5>
                    
              </div>
       </div>
</div>

<?php
		}
		else {
?>

<div class="MiTabla" class="container setcion responsive-table" >
<table name="showAllStudent" method="get" class="bordered striped hoverable centered responsive-table">
<thead>
<tr>
<th>Folio docente</th>
<th>Nombre del docente</th>
<th></th>

</tr>
</thead>
<tbody>
<?php
			$iterations = 0;
			foreach ($all_teachers_information as $teacherShow) {
?>
<tr>
    <td><?php echo LR\Filters::escapeHtmlText($teacherShow['folio']) /* line 68 */ ?> </td>
    <td><?php echo LR\Filters::escapeHtmlText($teacherShow['docente']) /* line 69 */ ?> </td>
    <td>
   
    
<form action="<?php
				echo $router->relativeUrlFor("teacherShowReports");
?>" method="post">
            <input type="hidden" name="docente" value="<?php echo LR\Filters::escapeHtmlAttr($teacherShow['docente']) /* line 74 */ ?>">
             <input type="hidden" name="clave_departamento" value="<?php echo LR\Filters::escapeHtmlAttr($teacherShow['clave_departamento']) /* line 75 */ ?>">
              <input type="hidden" name="folio" value="<?php echo LR\Filters::escapeHtmlAttr($teacherShow['folio']) /* line 76 */ ?>">
             <!-- -->
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 78 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 79 */ ?>">
            <!-- -->
<?php
				$iterations = 0;
				foreach ($permissions as $permissionInfor) {
					$permisos  = explode(" - ", $permissionInfor['enlace']);
					;
					if ($permisos[2] == "teacherShowReports") {
?>
     <input id="actualizar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" value='Imprimir reporte'>
            <!--<?php
						if ($students['percentage'] < 60) {
?>

    <?php
						}
						else {
?>-->
       
        <!--<?php
						}
?> -->
<?php
					}
					$iterations++;
				}
?>
</form>
</td>

<?php
				$iterations++;
			}
?>
 
</form>
</table>
</div>
<script>
let dimension = [];
let status = [];
let average = [];
</script>

<?php
			$iterations = 0;
			foreach ($average_department as $datos) {
?>
  <script>
    dimension.push(<?php echo LR\Filters::escapeJs($datos['dimension']) /* line 107 */ ?>);
    status.push(<?php echo LR\Filters::escapeJs($datos['status']) /* line 108 */ ?>);
    average.push(<?php echo LR\Filters::escapeJs($datos['average']) /* line 109 */ ?>);
  </script>  
<?php
				$iterations++;
			}
?>

<div id="dona"></div>
<script>
new Morris.Bar({
  element: 'dona',
  data: [

    { dimension: dimension[0], value: average[0]},
    { label: dimension[1], value: average[1]}, 
    { label: dimension[2], value: average[2]}, 
    { label: dimension[3], value: average[3]}, 
    { label: dimension[4], value: average[4]}, 
    { label: dimension[5], value: average[5]}, 
    { label: dimension[6], value: average[6]}, 
    { label: dimension[7], value: average[7]}, 
    { label: dimension[8], value: average[8]}, 
    { label: dimension[9], value: average[9]}, 
    { label: dimension[10], value: average[10]}
  ],
  colors: [
    '#E0F7FA',
    '#B2EBF2',
    '#80DEEA',
    '#4DD0E1',
    '#26C6DA',
    '#00BCD4',
    '#00ACC1',
    '#0097A7',
    '#00838F',
    '#006064'
  ],
  // The name of the data record attribute that contains x-values.
  xkey: 'label',
  // A list of names of data record attributes that contain y-values.
  ykeys: ['value'],
  // Labels for the ykeys -- will be displayed when you hover over the
  // chart.
  labels: ['Resultado']
});
</script>
<?php
		}
?>
 <div class="content"></div>
            <div class="footer-copyright blue-grey lighten-3" >
            <div class="container">
           <img class="header container section" src="/materialize/css/pie.jpg">
            </div>
          </div>
        </footer>
</body>
<script> M.AutoInit(); </script>
</html>
<?php
	}

}
