<?php
// source: Asignatura/lessonUpdate.latte

use Latte\Runtime as LR;

class Templatef22c0b0fa9 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		/* line 1 */
		$this->createTemplate('../validationUpdate.latte', $this->params, "include")->renderToContentType('html');
		/* line 2 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 7 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
      <link type="text/css" rel="stylesheet" href="/materialize/css/formularios.css"  media="screen,projection">
</head>
<body>
 <ul id="nav-mobile">
<div class="container section">
<form name="lessonUpdateForm" method="post" action="<?php
		echo $router->relativeUrlFor("lessonUpdate");
?>">
            <!-- -->
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 18 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 19 */ ?>">
            <!-- -->
            

<ul>
  <li>
    <label><input type="hidden" id="clave_antigua" name="clave_antigua" value="<?php echo LR\Filters::escapeHtmlAttr($data['clave']) /* line 25 */ ?>" class="validate"></label>
  </li>
  <li>
    <label for="clave">Clave:</label>
    <label><input type="text" id="clave" name="clave" value="<?php echo LR\Filters::escapeHtmlAttr($data['clave']) /* line 29 */ ?>" class="validate"></label>
  </li>
  <li>
    <label for="nombre">Nombre:</label>
    <input type="text" id="nombre" name="nombre" value="<?php echo LR\Filters::escapeHtmlAttr($data['nombre']) /* line 33 */ ?>" class="validate"></label>
  </li>
 </ul>
<button id="guardar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Guardar<i class="material-icons left">send</i></button>
</form>
<div>
<form action="<?php
		echo $router->relativeUrlFor("showAllLessons");
?>" method="post">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 40 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 41 */ ?>">
 <button id="retornar" type="submit" class="btn btn-primary btn-sm float-1" style="background-color: #10c2ee" >Retornar<i class="material-icons left">arrow_back</i></button>
            </form>

</div>
</div>
                 <div class="content"></div>
            <div class="footer-copyright blue-grey lighten-3" >
            <div class="container">
           <img class="header container section" src="/materialize/css/pie.jpg">
            </div>
          </div>
        </footer>
</body>
<script> M.AutoInit(); </script>
</html><?php
		return get_defined_vars();
	}

}
