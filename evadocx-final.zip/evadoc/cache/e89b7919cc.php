<?php
// source: validationUpdatePassword.latte

use Latte\Runtime as LR;

class Templatee89b7919cc extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		if (!empty($validation) && empty($validation['flag'])) {
			$iterations = 0;
			foreach ($validation['errorMessages'] as $error) {
?>
      <script type='text/javascript'>
        alert(<?php echo LR\Filters::escapeJs($error) /* line 4 */ ?>);
      </script>
<?php
				$iterations++;
			}
		}
		elseif (!empty($validation) && empty($validation['flag']) && empty($query)) {
?>
  <script>
    alert("Error al almacenar registro");
  </script>
<?php
		}
		elseif (!empty($validation['flag']) && !empty($query)) {
?>
  <script>
    alert("Registro almacenado");
  </script> 
<?php
		}
?>

<?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['error'])) trigger_error('Variable $error overwritten in foreach on line 2');
		
	}

}
