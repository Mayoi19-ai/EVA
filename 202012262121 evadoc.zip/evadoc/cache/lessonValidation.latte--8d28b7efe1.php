<?php
// source: Asignatura/lessonValidation.latte

use Latte\Runtime as LR;

class Template8d28b7efe1 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		return get_defined_vars();
	}

}
