<?php
// source: Alumno/studentUpdate.latte

use Latte\Runtime as LR;

class Template7e2189e6b7 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		/* line 1 */
		$this->createTemplate('@layout-navbar.latte', $this->params, "include")->renderToContentType('html');
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 7 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>

</head>
<body>
<div class="container section">
<form name="studentUpdateForm" method="post" action="<?php
		echo $router->relativeUrlFor("studentUpdate");
?>">
<ul>
  <li>
    <label><input type="hidden" id="control_antiguo" name="control_antiguo" value="<?php echo LR\Filters::escapeHtmlAttr($student_information['control']) /* line 18 */ ?>" class="validate"></label>
  </li>
  <li>
    <label for="clave">Control:</label>
    <label><input type="text" id="control" name="control" value="<?php echo LR\Filters::escapeHtmlAttr($student_information['control']) /* line 22 */ ?>" class="validate"></label>
  </li>
  <li>
    <label for="nombre">Nombre:</label>
    <input type="text" id="nombre" name="nombre" value="<?php echo LR\Filters::escapeHtmlAttr($student_information['nombre']) /* line 26 */ ?>" class="validate"></label>
  </li>
  <li>
    <label for="nombre">Contraseña:</label>
    <input type="text" id="contrasenia" name="contrasenia" value="<?php echo LR\Filters::escapeHtmlAttr($student_information['control']) /* line 30 */ ?>" class="validate"></label>
  </li>
 </ul>
<input type="submit" value="Registrar" name="registrar">
</div>
</form>




    <footer class="copyright"> 
        <p>Todos los derechos reservados, Gerardo y Raul 2020</p>
    </footer>
</body>
</html><?php
		return get_defined_vars();
	}

}
