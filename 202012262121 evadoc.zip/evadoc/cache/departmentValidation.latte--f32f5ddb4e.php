<?php
// source: Departamento/departmentValidation.latte

use Latte\Runtime as LR;

class Templatef32f5ddb4e extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		return get_defined_vars();
	}

}
