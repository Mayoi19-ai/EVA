<?php
// source: Preguntas\@groupAnswer.latte

use Latte\Runtime as LR;

class Template92067fe413 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<form>
    <p>
      <label>
        <input name="group1" type="radio" values="1" >
        <span>Totalmente en desacuerdo</span>
      </label>
    </p>
    <p>
      <label>
        <input name="group1" type="radio" values="2">
        <span>En desacuerdo</span>
      </label>
    </p>
    <p>
      <label>
        <input name="group1" type="radio" values="3">
        <span>Indeciso</span>
      </label>
    </p>
   <p>
      <label>
        <input name="group1" type="radio" values="4">
        <span>De acuerdo</span>
      </label>
    </p>
    <p>
      <label>
        <input name="group1" type="radio" values="5">
        <span>Totalmente de acuerdo</span>
      </label>
    </p>
  </form>
        <?php
		return get_defined_vars();
	}

}
