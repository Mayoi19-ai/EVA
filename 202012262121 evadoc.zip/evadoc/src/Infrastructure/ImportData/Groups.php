<?php

namespace App\Infrastructure\ImportData;

use App\Infrastructure\CrudSystem\GroupInfrastructure;
use Medoo\Medoo;

class Groups {
    private Medoo $db;
    private GroupInfrastructure $groupInfrastructure;

    public function __construct(Medoo $db, GroupInfrastructure $groupInfrastructure){
        $this->db = $db;
        $this->groupInfrastructure = $groupInfrastructure;
    }

    public function groups (int $period): ?array
    {
        $groups = $this->importGroups($period);

        if (array_key_exists('error', $this->groupInfrastructure->readAll((int) $period))) {
            $result = ['flag' => true, 
            'error' => 'Error al importar registros en Grupo'];
        }
        
        return null;
    }

    private function importGroups (int $period)
    {
        $sql = <<<'EOP'
        INSERT IGNORE INTO grupo (nombre, id_periodo, id_carrera, id_modalidad, id_campus) 
        SELECT temp_grupo.nombre, :id_periodo, diccionario_especialidad.id_carrera, diccionario_especialidad.id_modalidad, diccionario_especialidad.id_campus 
        FROM temp_grupo 
        INNER JOIN 
        temp_dgau 
        ON temp_grupo.cve = temp_dgau.gpo 
        INNER JOIN 
        temp_dret 
        ON temp_dgau.mat = temp_dret.cve 
        INNER JOIN 
        temp_dret2 
        ON  temp_dret.cve = temp_dret2.mat 
        INNER JOIN 
        diccionario_especialidad
        ON temp_dret2.esp = diccionario_especialidad.cve 
        GROUP BY temp_grupo.nombre, 
        diccionario_especialidad.id_carrera, 
        diccionario_especialidad.id_modalidad,
        diccionario_especialidad.id_campus;
        EOP;
        
        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':id_periodo', $period);
        $sth->execute();
    }
}