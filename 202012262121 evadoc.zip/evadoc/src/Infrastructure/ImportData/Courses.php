<?php

namespace App\Infrastructure\ImportData;

use Medoo\Medoo;
use App\Infrastructure\CrudSystem\CourseInfrastructure;

class Courses {
    private Medoo $db;
    private CourseInfrastructure $courseInfrastructure;

    public function __construct(Medoo $db, CourseInfrastructure $courseInfrastructure){
        $this->db = $db;
        $this->courseInfrastructure = $courseInfrastructure;
    }

    public function courses (int $period): ?array
    {
        $courses = $this->importCourses((int) $period);

        if (array_key_exists('error', $this->courseInfrastructure->readAll((int) $period))) {
            $result = ['flag' => true, 
            'error' => 'Error al importar registros en Curso'];
       }
       
       return null;
    }

    private function importCourses (int $period)
    {
        $sql = <<<'EOP'
        INSERT IGNORE INTO curso (nombre_grupo, id_periodo, id_carrera, clave_asignatura, folio_docente)
        SELECT temp_grupo.nombre, :id_periodo, diccionario_especialidad.id_carrera, temp_dret2.clave_asignatura, temp_dgau.cat
        FROM temp_grupo
        INNER JOIN 
        temp_dgau
        ON temp_grupo.cve = temp_dgau.gpo
        INNER JOIN 
        temp_dret
        ON temp_dgau.mat = temp_dret.cve
        INNER JOIN 
        temp_dret2
        ON temp_dret.cve = temp_dret2.mat
        INNER JOIN 
        diccionario_especialidad
        ON temp_dret2.esp = diccionario_especialidad.cve;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':id_periodo', $period);
        $sth->execute();
    }
}