<?php
namespace App\Infrastructure\CrudSystem;

use Medoo\Medoo;

class CustomException {
    protected Medoo $db;
    
    public function __construct(Medoo $db)
    {
        $this->db = $db;
    }

    public function saveError(array $result): array
    {
        if(empty($result[1])) {

            $this->db->pdo->commit();
            $sqlResult = ['exito' => 'Registro insertado correctamente', 
                        'flag' => true, 
                        'consulta' => true];

        } else {
            $this->db->pdo->rollBack();
            $sqlResult = ['error' => 'Error al insertar registro', 
                        'flag' => false,
                        'consulta' => true];
        }

        return $sqlResult;
    }

    public function readError(array $result, array $sql): array 
    {
        if(empty($result[1])) {
            
            if(empty($sql)) {
                $sqlResult = ['error' => 'No hay registros', 
                        'flag' => false,
                        'consulta' => true];
            } else {
                $sqlResult = $sql;
            }

        } else {
            $sqlResult = ['error' => 'Error al mostrar registros', 
                        'flag' => false,
                        'consulta' => true];
        }

        return $sqlResult;
    }

    public function deleteError(array $result): array 
    {
        if(empty($result[1])) {

            $this->db->pdo->commit();
            $sqlResult = ['exito' => 'Registro elimnado correctamente', 
                        'flag' => true, 
                        'consulta' => true];

        } else {
            $this->db->pdo->rollBack();
            $sqlResult = ['error' => 'No se eliminó registro', 
                        'flag' => false,
                        'consulta' => true];
        }
        
        return $sqlResult;
    }
}