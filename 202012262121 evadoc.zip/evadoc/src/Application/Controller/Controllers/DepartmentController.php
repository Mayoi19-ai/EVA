<?php
namespace App\Controller\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use Ujpef\LatteView;
use App\Validator\DepartmentValidator as Validator;
use App\Infrastructure\CrudSystem\DepartmentInfrastructure as Infrastructure;

class DepartmentController{
    private Container $container;
    private Validator $validator;
    private Infrastructure $infrastructure;
    
    public function __construct(Container $container, Validator $validator, Infrastructure $infrastructure){
        $this->container = $container;
        $this->validator = $validator;
        $this->infrastructure = $infrastructure;
    }

    public function saveForm(Request $request, Response $response){
        return $this->container->get(LatteView::class)->render($response, 
        'Departamento/departmentForm.latte');
    }

    public function register(Request $request, Response $response){
        $data = $request->getParsedBody();
        $validationResult = $this->validator->validateSaveDepartment((array) $data);

        
        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->create((array) $data);
        } else {
            $sthResult = ['consulta' => false];
        }

        return $this->container->get(LatteView::class)->render(
            $response,
            'Departamento/departmentValidation.latte', [
                'validation' => $validationResult, 
                'query' => $sthResult
            ]);
    }

    public function show(Request $request, Response $response){
        $sthResult = $this->infrastructure->readAll();

        return $this->container->get(LatteView::class)->render(
            $response,
            'Departamento/departmentTable.latte', [
                'query' => $sthResult
            ]);
    }

    public function updateForm(Request $request, Response $response){
        $data = $request->getParsedBody();

        return $this->container->get(LatteView::class)->render($response, 
        'Departamento/departmentUpdate.latte', [
            'department_information' => $data
        ]);
    }

    public function update(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $validationResult = $this->validator->validateSaveDepartment((array) $data);
        
        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->update((array) $data);
        } else {
            $sthResult = ['consulta' => false];
        }

        return $this->container->get(LatteView::class)->render(
            $response,
            'Departamento/departmentValidation.latte', [
                'validation' => $validationResult, 
                'query' => $sthResult,
            ]);
    }

    public function delete(Request $request, Response $response){
        $sthResult = $this->infrastructure->delete((string) $_GET['clave']);
        
        return $this->container->get(LatteView::class)->render(
            $response,
            'Departamento/departmentValidation.latte', [
                'query' => $sthResult
            ]);
    }
}