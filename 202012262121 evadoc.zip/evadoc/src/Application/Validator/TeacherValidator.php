<?php
namespace App\Validator;
use Rakit\Validation\Validator;

class TeacherValidator {
    private Validator $validator;

    public function __construct(Validator $validator) {
        $this->validator = $validator;
    }

    public function validateSaveTeacher(array $data): array {
        $validationRules = [
            'folio'               =>  'required|numeric|digits_between:1,3',
            'nombre'              =>  'required|alpha_spaces',
            'clave_departamento'  =>  'required|digits_between:1,3',
        ];

        $errorMessages = [
            'folio:required'                    =>  'El folio es obligatorio',
            'folio:digits_between'              =>  'El folio debe tener 1 a 3 digitos',
            'folio:numeric'                     =>  'El folio solo acepta números',
            'nombre:required'                   =>  'El nombre es obligatorio',
            'nombre:alpha_spaces'               =>  'El nombre no es válido',
            'clave_departamento:required'       =>  'El departamento es obligatorio',
            'clave_departamento:digits_between' =>  'La clave del departamento debe tener tres digitos',
        ];

        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data);
    }

    public function validateFindTeacher(array $data): array {
        $validationRules = [
            'nombre'              =>  'required|alpha_spaces',
        ];

        $errorMessages = [
            'nombre:required'        =>  'El nombre es obligatorio',
            'nombre:alpha_spaces'    =>  'El nombre no es válido',
        ];

        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data);
    }
}
