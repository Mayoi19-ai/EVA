<?php
namespace App\Validator;
use Rakit\Validation\Validator;

class LessonValidator{
    private Validator $validator;

    public function __construct(Validator $validator) {
        $this->validator = $validator;
    }

    public function validateSaveLesson(array $data): array {
        $validationRules = [
            'clave'          =>  'required|alpha_dash|between:8,8',
            'nombre'         =>  'required|alpha_spaces',
        ];

        $errorMessages = [
            'clave:required'      => 'La clave es obligatoria',
            'clave:alpha_dash'    => 'La clave no acepta espacios o caracteres especiales',
            'clave:between'       => 'La clave debe tener 8 caracteres',
            'nombre:requied'      => 'El nombre es obligatorio',
            'nombre:alpha_spaces' => 'El nombre no es válido',
        ];

        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data);
    }

    public function validateFindLesson(array $data): array {
        $validationRules = [
            'nombre'         =>  'required|alpha_spaces',
        ];

        $errorMessages = [
            'nombre:requied'      => 'El nombre es obligatorio',
            'nombre:alpha_spaces' => 'El nombre no es válido',
        ];

        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data);
    }
}