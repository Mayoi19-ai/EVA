-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         10.4.14-MariaDB - mariadb.org binary distribution
-- SO del servidor:              Win64
-- HeidiSQL Versión:             11.1.0.6116
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Volcando estructura de base de datos para proyecto
CREATE DATABASE IF NOT EXISTS `proyecto` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci */;
USE `proyecto`;

-- Volcando estructura para tabla proyecto.diccionario_especialidad
CREATE TABLE IF NOT EXISTS `diccionario_especialidad` (
  `cve` int(10) unsigned NOT NULL,
  `id_carrera` int(10) unsigned NOT NULL,
  `id_modalidad` int(10) unsigned NOT NULL,
  `id_campus` int(10) unsigned NOT NULL,
  PRIMARY KEY (`cve`),
  KEY `FK_despecial_modalidad_idx` (`id_modalidad`),
  KEY `FK_despecial_carrera_idx` (`id_carrera`),
  KEY `FK_despecial_campus_idx` (`id_campus`),
  CONSTRAINT `FK_despecial_campus` FOREIGN KEY (`id_campus`) REFERENCES `campus` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_despecial_carrera` FOREIGN KEY (`id_carrera`) REFERENCES `carrera` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_despecial_modalidad` FOREIGN KEY (`id_modalidad`) REFERENCES `modalidad` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- Volcando datos para la tabla proyecto.diccionario_especialidad: ~14 rows (aproximadamente)
/*!40000 ALTER TABLE `diccionario_especialidad` DISABLE KEYS */;
INSERT INTO `diccionario_especialidad` (`cve`, `id_carrera`, `id_modalidad`, `id_campus`) VALUES
	(1, 1, 1, 1),
	(2, 2, 1, 1),
	(3, 3, 1, 1),
	(4, 4, 1, 1),
	(5, 5, 1, 1),
	(8, 6, 1, 1),
	(9, 5, 3, 1),
	(10, 6, 3, 1),
	(11, 1, 2, 2),
	(13, 6, 1, 2),
	(14, 2, 1, 2),
	(15, 1, 2, 1),
	(16, 4, 3, 1),
	(17, 7, 1, 1);
/*!40000 ALTER TABLE `diccionario_especialidad` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
