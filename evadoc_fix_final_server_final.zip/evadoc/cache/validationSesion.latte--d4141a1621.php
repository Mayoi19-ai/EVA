<?php
// source: Sesion\validationSesion.latte

use Latte\Runtime as LR;

class Templated4141a1621 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<script>

var $control = document.getElementById('control');
var $contrasenia = document.getElementById('contrasenia');
var $error = document.getElementById('error');
error.style.color ="red";
function Logeo(){

    var mensajesError =[];

    if(control.value === null || control.value === ""){
        mensajesError.push('Datos erróneos. Por favor, inténtelo otra vez. ');

    }
     if(contrasenia.value === null || control.value === ""){
        mensajesError.push('Datos erróneos. Por favor, inténtelo otra vez.');

    }

    error.innerHTML = mensajesError.join(', ');
    return false;  
}



</script>
<?php
		return get_defined_vars();
	}

}
