<?php
// source: Sesion/loginStudent.latte

use Latte\Runtime as LR;

class Template2c0afd8a8b extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		?><!--<?php
		/* line 1 */
		$this->createTemplate('validationSesion.latte', $this->params, "include")->renderToContentType('htmlComment');
?>-->
<!DOCTYPE html>
  <html>
    <head>
      <meta charset="utf-8">
      <title><?php echo LR\Filters::escapeHtmlText($title) /* line 6 */ ?></title>
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
        <script src="/materialize/js/materialize.min.js"></script>
        <link type="text/css" rel="stylesheet" href="/materialize/css/Logeo.css"  media="screen,projection">
    </head>
  <body>
  <img class="header container section" src="/materialize/css/cabeza.jpg">
  <ul id="nav-mobile">
    <!-- form sesion start -->
     <div class="row container section">
        <div class="col s12 ">
          <div class="card horizontal ">
            <img class="inicio" src="https://www.itshuatusco.edu.mx/inicio/images/Logo%20ITSH%20300x312%20negritas.png">
              <div class="card-stacked">
                <div class="card-content">
                  <!-- sesion form -->
                  <form name="loginStudent" method="post" action="<?php
		echo $router->relativeUrlFor("studentCoursesMenu");
?>" > 
                    <div class="container section">
                      <label for="control">Numero de control:</label>
                      <input type="text" id="control" name="control" class="validate">
                      <label for="contrasenia">Contraseña:</label>
                      <input type="password" id="contrasenia" name="contrasenia" class="validate" >
                      <input class="sesion file-path btn " type="submit" value="Iniciar sesion" onclick ="return Logeo();">
                  
                    <!--Modal -->
                    <a class="sesion file-path btn  modal-trigger" href="#modal1"><i class="material-icons">help_outline</i></a> 
                    <!-- Modal Structure -->
                      <div id="modal1" class="modal">
                        <div class="modal-content">
                          <h4>Derechos ARCO</h4>
                              <p>El Instituto Tecnológico Superior de Huatusco es el responsable del tratamiento de los datos personales que nos
                                 proporcione, los cuales serán protegidos conforme a lo dispuesto por la Ley 316 de Protección de Datos
                                 Personales en Posesión de Sujetos Obligados para el Estado de Veracruz, y demás normatividad que
                                 resulte aplicable.</p>
                        </div>
                      </div>
                    </div>
                  </form>
                    <!-- Modal end -->
                      <div  id="error"></div> 
                    <!-- sesion end -->
                  </div>
                </div>
              </div>
            </div>
          </div>
    <!-- form sesion end -->   
      <!--footer-->
      <footer class="page-footer blue-grey lighten-3">
           <img class="header container section" src="/materialize/css/pie.jpg">
        </footer>
       
      </body>
    <script> M.AutoInit(); </script>
</html><?php
		return get_defined_vars();
	}

}
