<?php
// source: Contraseñas/studentContrasenia.latte

use Latte\Runtime as LR;

class Template8a5522076d extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		/* line 1 */
		$this->createTemplate('../validationUpdate.latte', $this->params, "include")->renderToContentType('html');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 6 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
<link type="text/css" rel="stylesheet" href="/materialize/css/student-naver.css"  media="screen,projection">

</head>
<body>
<nav>
      <div class="nav-wrapper blue-grey lighten-3">
        <img class="logo" src="https://www.itshuatusco.edu.mx/inicio/images/Logo%20ITSH%20300x312%20negritas.png">
          <ul id="nav-mobile" class="right hide-on-med-and-down">
            <li>
              <a class="dropdown-trigger" href="#!" data-target="dropdown1">Opciones<i class="material-icons right">arrow_drop_down</i></a></li>
                <ul id='dropdown1' class='dropdown-content'>
                  <li><a href="<?php
		echo $router->relativeUrlFor("loginStudent");
?>">Cerrar sesion</a></li>                  
                </ul>
            </ul>
          </li>
        </ul>
      </div>
    </nav>
  <ul id="nav-mobile">
<div class="container section">
<form method="post" action="<?php
		echo $router->relativeUrlFor("studenPasswordUpdate");
?>">
<ul>
<li>
    <label><input type="hidden" id="control" name="control" value="<?php echo LR\Filters::escapeHtmlAttr($student_information['control']) /* line 33 */ ?>" class="validate"></label>
  </li>
  <li>
    <label><input type="hidden" id="nombre" name="nombre" value="<?php echo LR\Filters::escapeHtmlAttr($student_information['nombre']) /* line 36 */ ?>" class="validate"></label>
  </li>
  <li>
    <input placeholder="Nueva contraseña" type="text" id="contrasenia" name="contrasenia" class="validate"></label>
  </li>
  <li>
    <input placeholder="Confirmar nueva contraseña" type="text" id="contrasenia_same" name="contrasenia_same" class="validate"></label>
  </li>

 </ul>
   
<input type="submit" >
</div>
</form>
<div>
</div>

    <!--footer -->
                  <div class="content"></div>
                    <footer class="page-footer blue-grey lighten-3">
                      <div class="footer-copyright">
                         <div class="row">
                           <div class="s12 m4 l8">
                              <p>© 2021 Copyright Todos los derechos reservados, Gerardo y Raul 2020</p>
                          </div>
                       </div>
                     </div>
                   </footer>
</body>
<script> M.AutoInit(); </script>
</html><?php
		return get_defined_vars();
	}

}
