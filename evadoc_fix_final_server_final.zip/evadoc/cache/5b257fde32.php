<?php
// source: validationPassword.latte

use Latte\Runtime as LR;

class Template5b257fde32 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
 <script type="text/javascript">
     function confirmationContrasenia() 
     {
        if(confirm("¿Desea restablecer la contraseña?"))
	{
	   return true;
	}
	else
	{
	   return false;
	}
     }
    </script><?php
		return get_defined_vars();
	}

}
