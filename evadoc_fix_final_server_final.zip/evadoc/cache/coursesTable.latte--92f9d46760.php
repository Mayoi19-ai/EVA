<?php
// source: Curso/coursesTable.latte

use Latte\Runtime as LR;

class Template92f9d46760 extends Latte\Runtime\Template
{
	public $blocks = [
		'content' => 'blockContent',
	];

	public $blockTypes = [
		'content' => 'html',
	];


	function main()
	{
		extract($this->params);
		/* line 1 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
		/* line 2 */
		$this->createTemplate('../validationDelete.latte', $this->params, "include")->renderToContentType('html');
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('content', get_defined_vars());
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['permissionInfor'])) trigger_error('Variable $permissionInfor overwritten in foreach on line 91, 106, 123');
		if (isset($this->params['courseShow'])) trigger_error('Variable $courseShow overwritten in foreach on line 70');
		
	}


	function blockContent($_args)
	{
		extract($_args);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 9 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
          
</head>
<body>
<div class="container section">
<ul id="nav-mobile">
                <div class="row">
                <div class="col s12 m6 l3">
<form name="grupo" method="post" action="<?php
		echo $router->relativeUrlFor("courseSearchByGroup");
?>">
<label for="autocomplete-input">Busqueda por Grupo</label>
          <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 22 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 23 */ ?>">
             <input type="text" name="grupo" id="grupo">
  <button id="buscar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee">Buscar<i class="material-icons left">search</i></button>
</div>
</form>

    <div class="col s12 m6 l3">
<form name="SearchForm" method="post" action="<?php
		echo $router->relativeUrlFor("courseSearchByLesson");
?>">
        <label for="asignatura">Busqueda por materia</label>
          <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 32 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 33 */ ?>">
             <input type="text" name="asignatura" id="asignatura">
       <button id="buscar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee">Buscar<i class="material-icons left">search</i></button>
  </div>
</div>
</div>
</form>
<!-- -->
<?php
		if (empty ($query)) {
?>
       <div class="container section">
       <div class="card center">
              <div class="card center">
              <img class="logo" src="/materialize/css/alerta3.png">
                     <h5>NO HAY GRUPOS REGISTRADOS</h5>
                       <form action="<?php
			echo $router->relativeUrlFor("userMenu");
?>" method="post">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 48 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 49 */ ?>">
 <input id="retorno" type="submit" class="btn btn-primary btn-sm" value='Retornar'>
            </form>
                    
              </div>
       </div>
</div>

<?php
		}
		else {
?>
<table name="showAllGroup" method="get" class="bordered striped hoverable centered responsive-table"> <!-- nombre de tabla-->
<thead>
<tr>
<th>Grupo</th>
<th>Carrera</th>
<th>Asignatura</th>
<th>Docente</th>
<th></th>
<th></th>
</tr>
</thead>
<tbody>
<?php
			$iterations = 0;
			foreach ($query as $courseShow) {
?>

<tr>
    <td><?php echo LR\Filters::escapeHtmlText($courseShow['grupo']) /* line 73 */ ?> </td>
    <td><?php echo LR\Filters::escapeHtmlText($courseShow['carrera']) /* line 74 */ ?> </td>
     <td><?php echo LR\Filters::escapeHtmlText($courseShow['asignatura']) /* line 75 */ ?> </td>
    <td><?php echo LR\Filters::escapeHtmlText($courseShow['docente']) /* line 76 */ ?> </td>
    <td>
<form action="<?php
				echo $router->relativeUrlFor("courseUpdateForm");
?>" method="post">
              <input type="hidden" name="grupo" value="<?php echo LR\Filters::escapeHtmlAttr($courseShow['grupo']) /* line 79 */ ?>">
              <input type="hidden" name="id_curso" value="<?php echo LR\Filters::escapeHtmlAttr($courseShow['id_curso']) /* line 80 */ ?>">
              <input type="hidden" name="clave_asignatura" value="<?php echo LR\Filters::escapeHtmlAttr($courseShow['clave_asignatura']) /* line 81 */ ?>">
              <input type="hidden" name="folio_docente" value="<?php echo LR\Filters::escapeHtmlAttr($courseShow['folio_docente']) /* line 82 */ ?>">
              <input type="hidden" name="carrera" value="<?php echo LR\Filters::escapeHtmlAttr($courseShow['carrera']) /* line 83 */ ?>">
              <input type="hidden" name="id_carrera" value="<?php echo LR\Filters::escapeHtmlAttr($courseShow['id_carrera']) /* line 84 */ ?>">
              <input type="hidden" name="asignatura" value="<?php echo LR\Filters::escapeHtmlAttr($courseShow['asignatura']) /* line 85 */ ?>">
              <input type="hidden" name="docente" value="<?php echo LR\Filters::escapeHtmlAttr($courseShow['docente']) /* line 86 */ ?>">
             <!--No borrar -->
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 88 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 89 */ ?>">
            <!--No borrar -->
<?php
				$iterations = 0;
				foreach ($permissions as $permissionInfor) {
					$permisos  = explode(" - ", $permissionInfor['enlace']);
					;
					if ($permisos[1] == "courseUpdateForm") {
?>
       <button id="actualizar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Editar<i class="material-icons left">edit</i></button>
<?php
					}
					$iterations++;
				}
?>
</form>
</td>
<td>
    <form action="<?php
				echo $router->relativeUrlFor("courseDelete");
?>" method="post" onsubmit="return confirmation()">
             <input type="hidden" name="id_curso" value="<?php echo LR\Filters::escapeHtmlAttr($courseShow['id_curso']) /* line 101 */ ?>">
            <!-- No tocar lo de abajo-->
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 103 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 104 */ ?>">
            <!--No tocar lo de arriba -->
<?php
				$iterations = 0;
				foreach ($permissions as $permissionInfor) {
					$permisos  = explode(" - ", $permissionInfor['enlace']);
					;
					if ($permisos[1] == "courseDelete") {
?>
    <button type="submit" id="eliminar" style="background-color: #f44336" class="btn btn-primary btn-sm #f44336" value='Eliminar'>Eliminar<i class="material-icons left">delete</i></button>
<?php
					}
					$iterations++;
				}
?>
    </form>
</td>

</tr>
<?php
				$iterations++;
			}
?>

</tbody>
 <form action="<?php
			echo $router->relativeUrlFor("courseSaveForm");
?>" method="post">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 120 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 121 */ ?>">
   <div class="fixed-action-btn">
<?php
			$iterations = 0;
			foreach ($permissions as $permissionInfor) {
				$permisos  = explode(" - ", $permissionInfor['enlace']);
				;
				if ($permisos[1] == "courseSaveForm") {
?>
<button id="agrerar" type="submit" class="btn btn-primary btn-sm float-2" style="background-color: #22DD22" >Agregar<i class="material-icons left">add</i></button>
<?php
				}
				$iterations++;
			}
		}
?>
</form>
</table>
</div>
</div>
<!--footer -->
                   <div class="content"></div>
            <div class="footer-copyright blue-grey lighten-3" >
            <div class="container">
           <img class="header container section" src="/materialize/css/pie.jpg">
            </div>
          </div>
        </footer>
</body>
<script> M.AutoInit(); </script>
</html>
<?php
	}

}
