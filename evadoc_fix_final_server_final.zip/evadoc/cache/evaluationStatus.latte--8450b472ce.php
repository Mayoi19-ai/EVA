<?php
// source: Estado/evaluationStatus.latte

use Latte\Runtime as LR;

class Template8450b472ce extends Latte\Runtime\Template
{
	public $blocks = [
		'content' => 'blockContent',
	];

	public $blockTypes = [
		'content' => 'html',
	];


	function main()
	{
		extract($this->params);
		/* line 1 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('content', get_defined_vars());
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['evaluationShow'])) trigger_error('Variable $evaluationShow overwritten in foreach on line 43');
		
	}


	function blockContent($_args)
	{
		extract($_args);
?>
            <!DOCTYPE html>
                <html>
                    <head>
                        <meta charset="utf-8">
                            <title><?php echo LR\Filters::escapeHtmlText($title) /* line 7 */ ?></title>
                           <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
                            <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
                            <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
                            <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
                            </head>
                        <body>
<?php
		if (empty ($query)) {
?>
       <div class="container section">
       <div class="card center">
              <div class="card center">
                    <img class="logo" src="/materialize/css/alerta3.png">
                        <p>NO HAY ALUMNOS REGISTRADOS</p>
                          <form action="<?php
			echo $router->relativeUrlFor("userMenu");
?>" method="post">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 21 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 22 */ ?>">
 <input id="retorno" type="submit" class="btn btn-primary btn-sm" value='Retornar'>
            </form>
              </div>
       </div>
</div>
<?php
		}
		else {
?>
<div class="MiTabla" class="container setcion responsive-table" >
<table name="showAllInscription" method="get" class="bordered striped hoverable centered responsive-table"> <!-- nombre de tabla-->
<thead>
<tr>
<th>Numero de control</th>
<th>Alumno</th>
<th>Grupo</th>
<th>Carrera</th>
<th>Asignatura</th>
<th>Clave asignatura</th>
<th>Docente</th>
</tr>
</thead>
<tbody>
<?php
			$iterations = 0;
			foreach ($query as $evaluationShow) {
?>
<tr>
    <td><?php echo LR\Filters::escapeHtmlText($evaluationShow['control']) /* line 45 */ ?> </td>
     <td><?php echo LR\Filters::escapeHtmlText($evaluationShow['alumno']) /* line 46 */ ?> </td>
     <td><?php echo LR\Filters::escapeHtmlText($evaluationShow['grupo']) /* line 47 */ ?> </td>
     <td><?php echo LR\Filters::escapeHtmlText($evaluationShow['carrera']) /* line 48 */ ?> </td>
     <td><?php echo LR\Filters::escapeHtmlText($evaluationShow['asignatura']) /* line 49 */ ?> </td>
      <td><?php echo LR\Filters::escapeHtmlText($evaluationShow['clave_asignatura']) /* line 50 */ ?> </td>
     <td><?php echo LR\Filters::escapeHtmlText($evaluationShow['docente']) /* line 51 */ ?> </td>
<?php
				$iterations++;
			}
?>
</tbody>
</table>
<?php
		}
?>
                                </div>
                                    <!--footer -->
                                      
            <div class="footer-copyright blue-grey lighten-3" >
            <div class="container">
           <img class="header container section" src="/materialize/css/pie.jpg">
            </div>
          </div>
        </footer>
                                        </body>
                                    <script> M.AutoInit(); </script>
                                </html>
<?php
	}

}
