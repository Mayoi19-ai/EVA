<?php
// source: Rol/rolTable.latte

use Latte\Runtime as LR;

class Template5d3195398e extends Latte\Runtime\Template
{
	public $blocks = [
		'content' => 'blockContent',
	];

	public $blockTypes = [
		'content' => 'html',
	];


	function main()
	{
		extract($this->params);
		/* line 1 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
		/* line 2 */
		$this->createTemplate('../validationDelete.latte', $this->params, "include")->renderToContentType('html');
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('content', get_defined_vars());
		?>><?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['permissionInfor'])) trigger_error('Variable $permissionInfor overwritten in foreach on line 52, 65, 82');
		if (isset($this->params['rolInfo'])) trigger_error('Variable $rolInfo overwritten in foreach on line 43');
		
	}


	function blockContent($_args)
	{
		extract($_args);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 9 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
      
</head>

<body>
<?php
		if (empty ($query)) {
?>
                <div class="container section">
                    <div class="card center">
                        <div class="card center">
                         <img class="logo" src="/materialize/css/alerta3.png">
                        <p>NO SE CUENTA CON ROLES REGISTRADOS</p>
                        <form action="<?php
			echo $router->relativeUrlFor("userMenu");
?>" method="post">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 24 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 25 */ ?>">
 <input id="retorno" type="submit" class="btn btn-primary btn-sm" value='Retornar'>
            </form>
                    </div>
                 </div>
            </div>
<?php
		}
		else {
?>
<div class="responsive-table table-status-sheet"> 
<table name="showAllroles" method="get" class="bordered striped hoverable centered responsive-table">
<thead>
<tr>
<th>Nombre</th>
<th></th>
<th></th>
</tr>
</thead>
<tbody>

<?php
			$iterations = 0;
			foreach ($query as $rolInfo) {
?>
<tr>
    <td><?php echo LR\Filters::escapeHtmlText($rolInfo['nombre']) /* line 45 */ ?> </td>
    <td>
<form action="<?php
				echo $router->relativeUrlFor("roleUpdateForm");
?>" method="post">
            <input type="hidden" name="id" value="<?php echo LR\Filters::escapeHtmlAttr($rolInfo['id']) /* line 48 */ ?>">
            <input type="hidden" name="nombre" value="<?php echo LR\Filters::escapeHtmlAttr($rolInfo['nombre']) /* line 49 */ ?>">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 50 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 51 */ ?>">
<?php
				$iterations = 0;
				foreach ($permissions as $permissionInfor) {
					$permisos  = explode(" - ", $permissionInfor['enlace']);
					;
					if ($permisos[1] == "roleUpdateForm") {
?>
        <button id="actualizar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Editar<i class="material-icons left">edit</i></button>
<?php
					}
					$iterations++;
				}
?>
</form>
</td>
<td>
    <form action="<?php
				echo $router->relativeUrlFor("roleDelete");
?>" method="post" onsubmit="return confirmation()">
            <input type="hidden" name="id" value="<?php echo LR\Filters::escapeHtmlAttr($rolInfo['id']) /* line 62 */ ?>">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 63 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 64 */ ?>">
<?php
				$iterations = 0;
				foreach ($permissions as $permissionInfor) {
					$permisos  = explode(" - ", $permissionInfor['enlace']);
					;
					if ($permisos[1] == "roleDelete") {
?>
    <button type="submit" id="eliminar" style="background-color: #f44336" class="btn btn-primary btn-sm #f44336" value='Eliminar'>Eliminar<i class="material-icons left">delete</i></button>
<?php
					}
					$iterations++;
				}
?>
    </form>
</td>

</tr>
<?php
				$iterations++;
			}
?>

</tbody>
 <form action="<?php
			echo $router->relativeUrlFor("roleSaveForm");
?>" method="post">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 79 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 80 */ ?>">
   <div class="fixed-action-btn">
<?php
			$iterations = 0;
			foreach ($permissions as $permissionInfor) {
				$permisos  = explode(" - ", $permissionInfor['enlace']);
				;
				if ($permisos[1] == "roleSaveForm") {
?>
<button id="agrerar" type="submit" class="btn btn-primary btn-sm float-2" style="background-color: #22DD22" >Agregar<i class="material-icons left">add</i></button>
<?php
				}
				$iterations++;
			}
?>
</form>
</table>
<?php
		}
?>
</div>
<!--footer -->
                  <div class="content"></div>
            <div class="footer-copyright blue-grey lighten-3" >
            <div class="container">
           <img class="header container section" src="/materialize/css/pie.jpg">
            </div>
          </div>
        </footer>
</body>
</html>
<?php
	}

}
