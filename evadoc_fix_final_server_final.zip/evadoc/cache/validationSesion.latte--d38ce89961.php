<?php
// source: Sesion/validationSesion.latte

use Latte\Runtime as LR;

class Templated38ce89961 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<script>

var $control = document.getElementById('control');
var $contrasenia = document.getElementById('contrasenia');
var $error = document.getElementById('error');
error.style.color ="red";
function Logeo(){

    var mensajesError =[];

     if(control.value === null || contrasenia.value === null){
         mensajesError.push('Datos erróneos. Por favor, inténtelo otra vez. ');
           error.innerHTML = mensajesError.join(', '); 
         return false;
    }
    if(control.value === "" || contrasenia.value === ""){
         mensajesError.push('Datos erróneos. Por favor, inténtelo otra vez. ');
           error.innerHTML = mensajesError.join(', '); 
         return false;
    }

    if(control.value === null && contrasenia.value === null){
        mensajesError.push('Datos erróneos. Por favor, inténtelo otra vez. ');
          error.innerHTML = mensajesError.join(', '); 
        return false;
    }
     if(control.value === "" && contrasenia.value === ""){
        mensajesError.push('Datos erróneos. Por favor, inténtelo otra vez.');
          error.innerHTML = mensajesError.join(', '); 
        return false;
    }



</script>
<?php
		return get_defined_vars();
	}

}
