<?php
// source: Codigo/code.latte

use Latte\Runtime as LR;

class Template55f00c5b6f extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 5 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
 <script type="text/javascript" src="/materialize/js/jquery.min.js"></script>
    <script type="text/javascript" src="/materialize/js/jquery-qrcode-0.18.0.js"></script>
       <script src="/materialize/js/materialize.min.js"></script>
       <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
       <link type="text/css" rel="stylesheet" href="/materialize/css/studentNaver.css"  media="screen,projection">

    
</head>
<body>
 <img class="header container section" src="/materialize/css/cabeza.jpg">
<nav>
    <div class="nav-wrapper blue-grey lighten-3">
      <img class="logo" src="https://www.itshuatusco.edu.mx/inicio/images/Logo%20ITSH%20300x312%20negritas.png"></a>
</nav>


       <div class="container section">
       <div class="card center">
<?php
		if (!empty ($message)) {
?>
                     <h3>ALUMNO REALIZO LA EVALUACION</h3>
<?php
		}
		else {
?>
                     <H3>NO SE ENCONTRO ALUMNO</H3>
<?php
		}
?>
</div>
</div>
 </body>
  <div class="content"></div>
            <div class="footer-copyright blue-grey lighten-3" >
            <div class="container">
           <img class="header container section" src="/materialize/css/pie.jpg">
            </div>
          </div>
        </footer>
 </html><?php
		return get_defined_vars();
	}

}
