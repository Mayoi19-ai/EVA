<?php
// source: Curso/coursesForm.latte

use Latte\Runtime as LR;

class Templateb01ae8ea51 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		/* line 1 */
		$this->createTemplate('../validationCreate.latte', $this->params, "include")->renderToContentType('html');
		/* line 2 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 7 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
       <link type="text/css" rel="stylesheet" href="/materialize/css/formularios.css"  media="screen,projection">
</head>
<body>
<ul id="nav-mobile">
<form name="courseSaveForm" method="post" action="<?php
		echo $router->relativeUrlFor("courseRegister");
?>">
<div class="container section">

<label for="grupo">Selecciona un grupo:</label>
<select class="browser-default" name="grupo" id="grupo">
  <option value="" name="grupo" >Selecciona un grupo</option>
<?php
		$iterations = 0;
		foreach ($all_groups_information as $nombre_grupo) {
			?>      <option  value="<?php echo LR\Filters::escapeHtmlAttr($nombre_grupo['grupo']) /* line 22 */ ?>" ><?php
			echo LR\Filters::escapeHtmlText($nombre_grupo['grupo']) /* line 22 */ ?> - <?php echo LR\Filters::escapeHtmlText($nombre_grupo['carrera']) /* line 22 */ ?></option>
<?php
			$iterations++;
		}
?>
  </select>

<label for="clave_asignatura_id_carrera">Selecciona una asignatura:</label>
  <select class="browser-default" name="clave_asignatura_id_carrera" id="clave_asignatura_id_carrera">
  <option value="" name="clave_asignatura_id_carrera">Selecciona una asignatura </option>
<?php
		$iterations = 0;
		foreach ($all_subjects_information as $subjectOption) {
			?>    <option  value="<?php echo LR\Filters::escapeHtmlAttr($subjectOption['clave_asignatura']) /* line 30 */ ?> <?php
			echo LR\Filters::escapeHtmlAttr($subjectOption['id_carrera']) /* line 30 */ ?>" ><?php echo LR\Filters::escapeHtmlText($subjectOption['asignatura']) /* line 30 */ ?> - <?php
			echo LR\Filters::escapeHtmlText($subjectOption['carrera']) /* line 30 */ ?></option>
    
<?php
			$iterations++;
		}
?>
  </select>

<label for="folio_docente">Selecciona un docente:</label>
    <select class="browser-default" name="folio_docente" id="folio_docente">
  <option value="" name="folio_docente">Selecciona un docente </option>
<?php
		$iterations = 0;
		foreach ($all_teachers_information as $subjectTeacher) {
			?>      <option  value="<?php echo LR\Filters::escapeHtmlAttr($subjectTeacher['folio']) /* line 39 */ ?>" ><?php
			echo LR\Filters::escapeHtmlText($subjectTeacher['nombre']) /* line 39 */ ?></option>
<?php
			$iterations++;
		}
?>
  </select>
  

  <!-- -->
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 45 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 46 */ ?>">
  <!-- -->
  <button id="guardar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Guardar<i class="material-icons left">send</i></button>

</form>
<div>
<form action="<?php
		echo $router->relativeUrlFor("showAllCourses");
?>" method="post">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 53 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 54 */ ?>">
 <button id="retornar" type="submit" class="btn btn-primary btn-sm float-1" style="background-color: #10c2ee" >Retornar<i class="material-icons left">arrow_back</i></button>
            </form>
            </div>
     <!--footer -->
                  <div class="content"></div>
            <div class="footer-copyright blue-grey lighten-3" >
            <div class="container">
           <img class="header container section" src="/materialize/css/pie.jpg">
            </div>
          </div>
        </footer>
</body>
 <script>M.AutoInit();</script>
</html><?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['nombre_grupo'])) trigger_error('Variable $nombre_grupo overwritten in foreach on line 21');
		if (isset($this->params['subjectOption'])) trigger_error('Variable $subjectOption overwritten in foreach on line 29');
		if (isset($this->params['subjectTeacher'])) trigger_error('Variable $subjectTeacher overwritten in foreach on line 38');
		
	}

}
