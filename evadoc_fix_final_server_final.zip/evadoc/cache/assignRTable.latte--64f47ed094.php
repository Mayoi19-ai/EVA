<?php
// source: AsignarR/assignRTable.latte

use Latte\Runtime as LR;

class Template64f47ed094 extends Latte\Runtime\Template
{
	public $blocks = [
		'content' => 'blockContent',
	];

	public $blockTypes = [
		'content' => 'html',
	];


	function main()
	{
		extract($this->params);
		/* line 1 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
		/* line 2 */
		$this->createTemplate('../validationDelete.latte', $this->params, "include")->renderToContentType('html');
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('content', get_defined_vars());
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['permissionInfor'])) trigger_error('Variable $permissionInfor overwritten in foreach on line 53, 67, 84');
		if (isset($this->params['asignR'])) trigger_error('Variable $asignR overwritten in foreach on line 40');
		
	}


	function blockContent($_args)
	{
		extract($_args);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 9 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
       
</head>

<body>
<?php
		if (empty ($query)) {
?>
                <div class="container section">
                    <div class="card center">
                        <div class="card center">
                         <img class="logo" src="/materialize/css/alerta3.png">
                        <h5>NO SE CUENTA CON ROLES REGISTRADOS</h5>
                    </div>
                 </div>
            </div>
<?php
		}
		else {
?>
 <ul id="nav-mobile">
<div class="MiTabla" class="responsive-table" >
<table name="showAllroles" method="get" class="bordered striped hoverable centered responsive-table">
<thead>
<tr>
<th>Usuario</th>
<th>Rol</th>
<th></th>
<th></th>
</tr>
</thead>
<tbody>

<?php
			$iterations = 0;
			foreach ($query as $asignR) {
?>
<tr>
    <td><?php echo LR\Filters::escapeHtmlText($asignR['usuario']) /* line 42 */ ?> </td>
    <td><?php echo LR\Filters::escapeHtmlText($asignR['rol']) /* line 43 */ ?> </td>
    
    <td>
<form action="<?php
				echo $router->relativeUrlFor("userRolesUpdateForm");
?>" method="post">
            <input type="hidden" name="id_usuario" value="<?php echo LR\Filters::escapeHtmlAttr($asignR['id_usuario']) /* line 47 */ ?>">
            <input type="hidden" name="usuario" value="<?php echo LR\Filters::escapeHtmlAttr($asignR['usuario']) /* line 48 */ ?>">
             <input type="hidden" name="id_roles" value="<?php echo LR\Filters::escapeHtmlAttr($asignR['id_roles']) /* line 49 */ ?>">
            <input type="hidden" name="rol" value="<?php echo LR\Filters::escapeHtmlAttr($asignR['rol']) /* line 50 */ ?>">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 51 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 52 */ ?>">
<?php
				$iterations = 0;
				foreach ($permissions as $permissionInfor) {
					$permisos  = explode(" - ", $permissionInfor['enlace']);
					;
					if ($permisos[1] == "userRolesUpdateForm") {
?>
        <button id="actualizar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Editar<i class="material-icons left">edit</i></button>
<?php
					}
					$iterations++;
				}
?>
</form>
</td>
<td>
    <form action="<?php
				echo $router->relativeUrlFor("userRolesDelete");
?>" method="post" onsubmit="return confirmation()">
            <input type="hidden" name="id_usuario" value="<?php echo LR\Filters::escapeHtmlAttr($asignR['id_usuario']) /* line 63 */ ?>">
            <input type="hidden" name="id_roles" value="<?php echo LR\Filters::escapeHtmlAttr($asignR['id_roles']) /* line 64 */ ?>">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 65 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 66 */ ?>">
<?php
				$iterations = 0;
				foreach ($permissions as $permissionInfor) {
					$permisos  = explode(" - ", $permissionInfor['enlace']);
					;
					if ($permisos[1] == "userRolesDelete") {
?>
    <button type="submit" id="eliminar" style="background-color: #f44336" class="btn btn-primary btn-sm #f44336" value='Eliminar'>Eliminar<i class="material-icons left">delete</i></button>
<?php
					}
					$iterations++;
				}
?>
    </form>
</td>

</tr>
<?php
				$iterations++;
			}
?>

</tbody>
 <form action="<?php
			echo $router->relativeUrlFor("userRolesSaveForm");
?>" method="post">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 81 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 82 */ ?>">
   <div class="fixed-action-btn">
<?php
			$iterations = 0;
			foreach ($permissions as $permissionInfor) {
				$permisos  = explode(" - ", $permissionInfor['enlace']);
				;
				if ($permisos[1] == "userRolesSaveForm") {
?>
<button id="agrerar" type="submit" class="btn btn-primary btn-sm float-2" style="background-color: #22DD22" >Agregar<i class="material-icons left">add</i></button>
<?php
				}
				$iterations++;
			}
?>
</form>
</table>
<?php
		}
?>
</div>
 <div class="content"></div>
            <div class="footer-copyright blue-grey lighten-3" >
            <div class="container">
           <img class="header container section" src="/materialize/css/pie.jpg">
            </div>
          </div>
        </footer>
</body>
</html>
<?php
	}

}
