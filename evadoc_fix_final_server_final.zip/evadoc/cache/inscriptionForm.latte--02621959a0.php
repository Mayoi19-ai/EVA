<?php
// source: Inscripcion/inscriptionForm.latte

use Latte\Runtime as LR;

class Template02621959a0 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		/* line 1 */
		$this->createTemplate('../validationCreate.latte', $this->params, "include")->renderToContentType('html');
		/* line 2 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 7 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
       <link type="text/css" rel="stylesheet" href="/materialize/css/formularios.css"  media="screen,projection">
</head>
<body>
 <ul id="nav-mobile">
<form name="inscriptionSaveForm" method="post" action="<?php
		echo $router->relativeUrlFor("inscriptionRegister");
?>">
  <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 16 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 17 */ ?>">

  <div class="container section">
  
   <label for="id_curso">Selecciona un curso:</label>
 <select class="browser-default"  name="id_curso" id="id_curso">
  <option value="" name="id_curso">selecciona un curso</option>
<?php
		$iterations = 0;
		foreach ($all_courses_information as $cursoOption) {
			?>      <option  value="<?php echo LR\Filters::escapeHtmlAttr($cursoOption['id_curso']) /* line 25 */ ?>"><?php
			echo LR\Filters::escapeHtmlText($cursoOption['grupo']) /* line 25 */ ?> - <?php echo LR\Filters::escapeHtmlText($cursoOption['carrera']) /* line 25 */ ?> - <?php
			echo LR\Filters::escapeHtmlText($cursoOption['asignatura']) /* line 25 */ ?> - <?php echo LR\Filters::escapeHtmlText($cursoOption['docente']) /* line 25 */ ?></option>
<?php
			$iterations++;
		}
?>
  </select>

   <label for="control">Selecciona un alumno:</label>
  <select class="browser-default"  name="control" id="control">
  <option value="" name="control">Selecciona un alumno</option>
<?php
		$iterations = 0;
		foreach ($all_students_information as $controlOption) {
			?>      <option  value="<?php echo LR\Filters::escapeHtmlAttr($controlOption['control']) /* line 33 */ ?>" ><?php
			echo LR\Filters::escapeHtmlText($controlOption['control']) /* line 33 */ ?> - <?php echo LR\Filters::escapeHtmlText($controlOption['nombre']) /* line 33 */ ?></option>
<?php
			$iterations++;
		}
?>
  </select>

 <label for="activar">Selecciona el estado de un alumno:</label>
  <select class="browser-default"  name="activar" id="activar">
  <option value="" name="activar">Selecciona el estado del alumno </option>
      <option  value="1" >Activo</option>
       <option  value="0" >No activo</option>
  </select>
  
<button id="guardar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Guardar<i class="material-icons left">send</i></button>
</div>
</form>
<div>
<form action="<?php
		echo $router->relativeUrlFor("showAllInscriptions");
?>" method="post">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 49 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 50 */ ?>">
 <button id="retornar" type="submit" class="btn btn-primary btn-sm float-1" style="background-color: #10c2ee" >Retornar<i class="material-icons left">arrow_back</i></button>
            </form>
            </div>
     <!--footer -->
                  <div class="content"></div>
            <div class="footer-copyright blue-grey lighten-3" >
            <div class="container">
           <img class="header container section" src="/materialize/css/pie.jpg">
            </div>
          </div>
        </footer>
</body>
 <script>M.AutoInit();</script>
</html><?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['cursoOption'])) trigger_error('Variable $cursoOption overwritten in foreach on line 24');
		if (isset($this->params['controlOption'])) trigger_error('Variable $controlOption overwritten in foreach on line 32');
		
	}

}
