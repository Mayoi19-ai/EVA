<?php
// source: Preguntas/validation.latte

use Latte\Runtime as LR;

class Template4082fb2218 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<script>
 function validation(){
	
  opciones = document.getElementsByName("group1");
  var seleccionado = false;
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 1 ");
    return false;
  }


opciones = document.getElementsByName("group2");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 2 ");
    return false;
  }

  opciones = document.getElementsByName("group3");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 3 ");
    return false;
  }

  opciones = document.getElementsByName("group4");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 4 ");
    return false;
  }

  opciones = document.getElementsByName("group5");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 5 ");
    return false;
  }

  opciones = document.getElementsByName("group6");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 6 ");
    return false;
  }

  opciones = document.getElementsByName("group7");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 7 ");
    return false;
  }

  opciones = document.getElementsByName("group8");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 8 ");
    return false;
  }

  opciones = document.getElementsByName("group9");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 9 ");
    return false;
  }

  opciones = document.getElementsByName("group10");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 10 ");
    return false;
  }

  opciones = document.getElementsByName("group11");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 11 ");
    return false;
  }

  opciones = document.getElementsByName("group12");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 12 ");
    return false;
  }

  opciones = document.getElementsByName("group13");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 13 ");
    return false;
  }

  opciones = document.getElementsByName("group14");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 14 ");
    return false;
  }

  opciones = document.getElementsByName("group15");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 15 ");
    return false;
  }

  opciones = document.getElementsByName("group16");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 16 ");
    return false;
  }

  opciones = document.getElementsByName("group17");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 17 ");
    return false;
  }

  opciones = document.getElementsByName("group18");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 18 ");
    return false;
  }

  opciones = document.getElementsByName("group19");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 19 ");
    return false;
  }

  opciones = document.getElementsByName("group20");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 20 ");
    return false;
  }

  opciones = document.getElementsByName("group21");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 21 ");
    return false;
  }

  opciones = document.getElementsByName("group22");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 22 ");
    return false;
  }

  opciones = document.getElementsByName("group23");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 23 ");
    return false;
  }

  opciones = document.getElementsByName("group24");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 24 ");
    return false;
  }

  opciones = document.getElementsByName("group25");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 25 ");
    return false;
  }

  opciones = document.getElementsByName("group26");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 26 ");
    return false;
  }

  opciones = document.getElementsByName("group27");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 27 ");
    return false;
  }

  opciones = document.getElementsByName("group28");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 28 ");
    return false;
  }

  opciones = document.getElementsByName("group29");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 29 ");
    return false;
  }

  opciones = document.getElementsByName("group30");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 30 ");
    return false;
  }

  opciones = document.getElementsByName("group31");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 31 ");
    return false;
  }

  opciones = document.getElementsByName("group32");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 32 ");
    return false;
  }

  opciones = document.getElementsByName("group33");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 33 ");
    return false;
  }

  opciones = document.getElementsByName("group34");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 34 ");
    return false;
  }

  opciones = document.getElementsByName("group35");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 35 ");
    return false;
  }

  opciones = document.getElementsByName("group36");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 36 ");
    return false;
  }

  opciones = document.getElementsByName("group37");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 37 ");
    return false;
  }

  opciones = document.getElementsByName("group38");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 38 ");
    return false;
  }

  opciones = document.getElementsByName("group39");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 39 ");
    return false;
  }

  opciones = document.getElementsByName("group40");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 41 ");
    return false;
  }

  opciones = document.getElementsByName("group42");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 42 ");
    return false;
  }

  opciones = document.getElementsByName("group43");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 43 ");
    return false;
  }
  

  opciones = document.getElementsByName("group44");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 44 ");
    return false;
  }

  opciones = document.getElementsByName("group45");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 45 ");
    return false;
  }

  opciones = document.getElementsByName("group46");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 46 ");
    return false;
  }

  opciones = document.getElementsByName("group47");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 47 ");
    return false;
  }
  

  opciones = document.getElementsByName("group48");
  var seleccionado = false; 
  for(var i= 0; i < opciones.length; i++){
    if(opciones[i].checked){
      seleccionado = true;
      break;
    } 
  }
  if (!seleccionado){
    alert("Falta responder pregunta 48 ");
    return false;
  }


  
}
</script>
<?php
		return get_defined_vars();
	}

}
