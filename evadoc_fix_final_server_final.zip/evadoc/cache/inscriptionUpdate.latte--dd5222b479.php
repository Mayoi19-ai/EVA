<?php
// source: Inscripcion/inscriptionUpdate.latte

use Latte\Runtime as LR;

class Templatedd5222b479 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		/* line 1 */
		$this->createTemplate('../validationUpdate.latte', $this->params, "include")->renderToContentType('html');
		/* line 2 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 7 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
         <link type="text/css" rel="stylesheet" href="/materialize/css/selectize.bootstrap3.min.css"  media="screen,projection">
 <link type="text/css" rel="stylesheet" href="/materialize/css/formularios.css"  media="screen,projection">
<script>
     $(document).ready(function () {
      $('select').selectize({
          sortField: 'text'
      });
  });
  </script>
</head>
<body>
 <ul id="nav-mobile">
<div class="container section">
<form name="inscriptionUpdateForm" method="post" action="<?php
		echo $router->relativeUrlFor("inscriptionUpdate");
?>">
              <input type="hidden" name="id" value="<?php echo LR\Filters::escapeHtmlAttr($data['id']) /* line 24 */ ?>">
             <input type="hidden" name="id_curso" value="<?php echo LR\Filters::escapeHtmlAttr($data['id_curso']) /* line 25 */ ?>">
             <input type="hidden" name="control" value="<?php echo LR\Filters::escapeHtmlAttr($data['control']) /* line 26 */ ?>">
               <input type="hidden" name="nombre" value="<?php echo LR\Filters::escapeHtmlAttr($data['nombre']) /* line 27 */ ?>">
              <input type="hidden" name="grupo" value="<?php echo LR\Filters::escapeHtmlAttr($data['grupo']) /* line 28 */ ?>">
              <input type="hidden" name="carrera" value="<?php echo LR\Filters::escapeHtmlAttr($data['carrera']) /* line 29 */ ?>">
              <input type="hidden" name="asignatura" value="<?php echo LR\Filters::escapeHtmlAttr($data['asignatura']) /* line 30 */ ?>">
              <input type="hidden" name="docente" value="<?php echo LR\Filters::escapeHtmlAttr($data['docente']) /* line 31 */ ?>">
             <input type="hidden" name="activar" value="<?php echo LR\Filters::escapeHtmlAttr($data['activar']) /* line 32 */ ?>">
            <!-- -->
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 34 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 35 */ ?>">
            <!-- -->
             


            
<ul>
  <li>
    <label><input type="hidden" id="id" name="id" value="<?php echo LR\Filters::escapeHtmlAttr($data['id']) /* line 43 */ ?>" class="validate"></label>
  </li>
  <li>
    <label for="id_curso">Selecciona un curso:</label>
      <select  class="browser-default"  name="id_curso" >
      <option value="<?php echo LR\Filters::escapeHtmlAttr($data['id_curso']) /* line 48 */ ?>" name="id_curso"><?php
		echo LR\Filters::escapeHtmlText($data['grupo']) /* line 48 */ ?> - <?php echo LR\Filters::escapeHtmlText($data['carrera']) /* line 48 */ ?> - <?php
		echo LR\Filters::escapeHtmlText($data['asignatura']) /* line 48 */ ?> - <?php echo LR\Filters::escapeHtmlText($data['docente']) /* line 48 */ ?></option>
<?php
		$iterations = 0;
		foreach ($all_courses_information as $cursoOption) {
			?>      <option  value="<?php echo LR\Filters::escapeHtmlAttr($cursoOption['id_curso']) /* line 50 */ ?>"><?php
			echo LR\Filters::escapeHtmlText($cursoOption['grupo']) /* line 50 */ ?> - <?php echo LR\Filters::escapeHtmlText($cursoOption['carrera']) /* line 50 */ ?> - <?php
			echo LR\Filters::escapeHtmlText($cursoOption['asignatura']) /* line 50 */ ?> - <?php echo LR\Filters::escapeHtmlText($cursoOption['docente']) /* line 50 */ ?></option>
<?php
			$iterations++;
		}
?>
    </select>
  </li>


  <li>
   <label for="id_curso">Selecciona un alumno:</label>
      <select name="control" class="browser-default">
      <option value="<?php echo LR\Filters::escapeHtmlAttr($data['control']) /* line 59 */ ?>" name="control"><?php
		echo LR\Filters::escapeHtmlText($data['control']) /* line 59 */ ?> - <?php echo LR\Filters::escapeHtmlText($data['nombre']) /* line 59 */ ?></option>
<?php
		$iterations = 0;
		foreach ($all_students_information as $controlOption) {
			?>      <option  value="<?php echo LR\Filters::escapeHtmlAttr($controlOption['control']) /* line 61 */ ?>" ><?php
			echo LR\Filters::escapeHtmlText($controlOption['control']) /* line 61 */ ?> - <?php echo LR\Filters::escapeHtmlText($controlOption['nombre']) /* line 61 */ ?></option>
<?php
			$iterations++;
		}
?>
    </select>
  </li>

 <label for="activar">Estado de inscripcion</label>
      <select name="activar"  class="browser-default">
      <option value="<?php echo LR\Filters::escapeHtmlAttr($data['activar']) /* line 68 */ ?>" name="activar"><?php
		if ($data['activar'] == 1) {
?>Activo
                                          <?php
		}
		else {
?>No activo
<?php
		}
?>
     </option>
      <option value=1>Activo</option>
      <option value=0>No activo</option>
    </select>


   
<button id="guardar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Guardar<i class="material-icons left">send</i></button>
</div>
</form>
<div>
<form action="<?php
		echo $router->relativeUrlFor("showAllInscriptions");
?>" method="post">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 83 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 84 */ ?>">
 <button id="retornar" type="submit" class="btn btn-primary btn-sm float-1" style="background-color: #10c2ee" >Retornar<i class="material-icons left">arrow_back</i></button>
            </form>

</div>

    <!--footer -->
                  <div class="content"></div>
            <div class="footer-copyright blue-grey lighten-3" >
            <div class="container">
           <img class="header container section" src="/materialize/css/pie.jpg">
            </div>
          </div>
        </footer>
</body>
<script> M.AutoInit(); </script>
</html><?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['cursoOption'])) trigger_error('Variable $cursoOption overwritten in foreach on line 49');
		if (isset($this->params['controlOption'])) trigger_error('Variable $controlOption overwritten in foreach on line 60');
		
	}

}
