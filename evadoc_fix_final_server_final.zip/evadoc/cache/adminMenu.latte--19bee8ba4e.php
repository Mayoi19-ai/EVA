<?php
// source: Menu/adminMenu.latte

use Latte\Runtime as LR;

class Template19bee8ba4e extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<!DOCTYPE html>
  <html>
    <head>
      <meta charset="utf-8">
        <title><?php echo LR\Filters::escapeHtmlText($title) /* line 5 */ ?></title>
          <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
          <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
          <script type="text/javascript" src="/materialize/js/jquery.min.js"></script>
          <script type="text/javascript" src="/materialize/js/jquery-qrcode-0.18.0.js"></script>
          <script src="/materialize/js/materialize.min.js"></script>
          <link type="text/css" rel="stylesheet" href="/materialize/css/naver.css"  media="screen,projection">
    </head>  
    <body>
    <img class="header container section" src="/materialize/css/cabeza.jpg">
<?php
		if (empty ($categories)) {
?>
           <nav>
              <div class="nav-wrapper blue-grey lighten-3">
                <img class="logo" src="https://www.itshuatusco.edu.mx/inicio/images/Logo%20ITSH%20300x312%20negritas.png">
                  <ul id="nav-mobile" class="right hide-on-med-and-down">
                    <li><form action="<?php
			echo $router->relativeUrlFor("userPasswordUpdateForm");
?>" method="post">
                          <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($user) /* line 21 */ ?>">
                          <input type="submit" class="botonMenu  waves-light" value="Cambiar contraseña">
                        </form>
                    </li>
                      <li>
                        <a class="dropdown-trigger" data-target="dropdown1"><i class="material-icons right">arrow_drop_down</i></a></li>
                        <ul id='dropdown1' class='dropdown-content'>
                        <li><a href="<?php
			echo $router->relativeUrlFor("usersLogin");
?>">Cerrar sesion</a></li>                  
                      </ul>
                    </ul>
                  </li>
                </ul>
              </div>
            </nav>
              <ul id="nav-mobile">
                <div class="container section">
                  <div class="card center">
                    <img class="logo" src="/materialize/css/alerta3.png">
                    <h5>No cuenta con permisos, favor de hablar con el administrador</h5>
                  </div>
                </div>
<?php
		}
		else {
?>
                <nav>
                  <div class="nav-wrapper blue-grey lighten-3">
                    <img class="logo" src="https://www.itshuatusco.edu.mx/inicio/images/Logo%20ITSH%20300x312%20negritas.png">
                      <ul id="nav-mobile" class="right hide-on-med-and-down">
                        <li><form action="<?php
			echo $router->relativeUrlFor("userPasswordUpdateForm");
?>" method="post">
<?php
			$iterations = 0;
			foreach ($categories as $usuarioDatos) {
				?>                            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($user) /* line 49 */ ?>">
                            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($usuarioDatos['categoria_permisos']) /* line 50 */ ?>">    
<?php
				$iterations++;
			}
?>
                        <input type="submit" class="botonMenu  waves-light" value="Cambiar contraseña">
                            </form>
                          </li>
                            <li>
                              <a class="dropdown-trigger" data-target="dropdown1"><i class="material-icons right">arrow_drop_down</i></a></li>
                              <ul id='dropdown1' class='dropdown-content'>
                              <li><a href="<?php
			echo $router->relativeUrlFor("usersLogin");
?>">Cerrar sesion</a></li>                  
                            </ul>
                          </ul>
                        </li>
                      </ul>
                    </div>
                  </nav>
<?php
		}
?>
 <div class="row">
  <div class="col s12">
<?php
		$iterations = 0;
		foreach ($categories as $Category) {
			$rediret  = explode(" - ", $Category['enlace']);
			;
?>
                      <div class="col s12 m6 l4">
                        <ul>
                         <div class="card">
                            <form action="<?php
			echo $router->relativeUrlFor($rediret['0']);
?>" method="post">
                              <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($user) /* line 74 */ ?>">
                              <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($Category['categoria_permisos']) /* line 75 */ ?>">
                               <input type="submit" class="waves-effect" value="<?php echo LR\Filters::escapeHtmlAttr($Category['categoria_permisos']) /* line 76 */ ?>">
                            </form>
                          </div>
                         </ul> 
                      </div>
                     
<?php
			$iterations++;
		}
?>
</div>
</div>

              
                    <div class="footer-copyright blue-grey lighten-3" >
                      <div class="container">
                        <img class="header container section" src="/materialize/css/pie.jpg">
                      </div>
                    </div>
                  </footer>
                </body>
        <script> M.AutoInit(); </script>
      </html><?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['usuarioDatos'])) trigger_error('Variable $usuarioDatos overwritten in foreach on line 48');
		if (isset($this->params['Category'])) trigger_error('Variable $Category overwritten in foreach on line 68');
		
	}

}
