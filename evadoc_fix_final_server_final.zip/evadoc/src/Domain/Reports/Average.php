<?php
namespace App\Domain\Reports;

class Average {
    public function receiver(array $answersArray): array
    {
        foreach ($answersArray as $stringAnswers) {
            $answersContainer[] = str_split($stringAnswers[0]);
        }
        
        return $this->separateDimensions((array) $answersContainer);
    }


    private function separateDimensions(array $answersContainer): array
    {
        foreach ($answersContainer as $answer) {
            for($i = 0; $i < count($answer); $i++){
    
                if ($i <= 4) {
                    $dimensionA[] = $answer[$i];
    
                } else if ($i >= 5 && $i <= 7) {
                    $dimensionB[] = $answer[$i];
    
                } elseif ($i >= 8 && $i <= 12) {
                    $dimensionC[] = $answer[$i];
    
                } elseif ($i >= 13 && $i <= 19) {
                    $dimensionD[] = $answer[$i];
    
                } elseif ($i >= 20 && $i <= 26) {
                    $dimensionE[] = $answer[$i];
    
                } elseif ($i >= 27 && $i <= 34) {
                    $dimensionF[] = $answer[$i];
    
                } elseif ($i >= 35 && $i <= 37) {
                    $dimensionG[] = $answer[$i];
    
                } elseif ($i >= 38 && $i <= 41) {
                    $dimensionH[] = $answer[$i];
    
                } elseif ($i >= 42 && $i <= 44) {
                    $dimensionI[] = $answer[$i];
    
                } elseif ($i >= 45 && $i <= 47) {
                    $dimensionJ[] = $answer[$i];
                }
            }
        }

        return $this->average((array) array('dimensionA' => $dimensionA,
		'dimensionB' => $dimensionB,
		'dimensionC' => $dimensionC,
		'dimensionD' => $dimensionD,
		'dimensionE' => $dimensionE,
		'dimensionF' => $dimensionF,
		'dimensionG' => $dimensionG,
		'dimensionH' => $dimensionH,
		'dimensionI' => $dimensionI,
		'dimensionJ' => $dimensionJ));
    }

    private function average (array $dimensions): array
    {
        $averageA = array_sum($dimensions['dimensionA']) / count($dimensions['dimensionA']);
        $averageB = array_sum($dimensions['dimensionB']) / count($dimensions['dimensionB']);
        $averageC = array_sum($dimensions['dimensionC']) / count($dimensions['dimensionC']);
        $averageD = array_sum($dimensions['dimensionD']) / count($dimensions['dimensionD']);
        $averageE = array_sum($dimensions['dimensionE']) / count($dimensions['dimensionE']);
        $averageF = array_sum($dimensions['dimensionF']) / count($dimensions['dimensionF']);
        $averageG = array_sum($dimensions['dimensionG']) / count($dimensions['dimensionG']);
        $averageH = array_sum($dimensions['dimensionH']) / count($dimensions['dimensionH']);
        $averageI = array_sum($dimensions['dimensionI']) / count($dimensions['dimensionI']);
        $averageJ = array_sum($dimensions['dimensionJ']) / count($dimensions['dimensionJ']);
    
        $averageK  = ($averageA + $averageB + $averageC + $averageD + $averageE + $averageF + $averageG + $averageH + $averageI + $averageJ) / 10;
    
        return $this->results((array) array(array('A. Dominio de la asignatura' => $averageA),
            array('B. Planificación del curso' => $averageB),
            array('C. Ambientes de aprendizaje' => $averageC),
            array('D. Estrategias, métodos y técnicas' => $averageD),
            array('E. Motivación' => $averageE),
            array('F. Evaluación' => $averageF),
            array('G. Comunicación' => $averageG),
            array('H. Gestión del curso' => $averageH),
            array('I. Tecnologías de la información y comunicación' => $averageI),
            array('J. Satisfacción general' => $averageJ),
            array('K. RESULTADO GLOBAL' => $averageK))
        );
    }

    private function results(array $averages): array
    {
        foreach ($averages as $dimension) {
            foreach ($dimension as $average) {
                switch ($average) {
                case 4.75 <= $average:
                    $resultsDimension[] = array('dimension' => array_search($average, $dimension),
                    'status' => 'EXCELENTE',
                    'average' => round($average, 2));
                    break;
                
                case 4.25 <= $average && $average < 4.75:
                    $resultsDimension[] = array('dimension' => array_search($average, $dimension),
                    'status' => 'NOTABLE',
                    'average' => round($average, 2));
                    break;
    
                case 3.75 <= $average && $average < 4.25:
                    $resultsDimension[] = array('dimension' => array_search($average, $dimension),
                    'status' => 'BUENO',
                    'average' => round($average, 2));
                    break;
    
                case 3.25 <= $average && $average < 3.75:
                    $resultsDimension[] = array('dimension' => array_search($average, $dimension),
                    'status' => 'SUFICIENTE',
                    'average' => round($average, 2));
                    break;
    
                case $average < 3.25:
                    $resultsDimension[] = array('dimension' => array_search($average, $dimension),
                    'status' => 'INSUFICIENTE',
                    'average' => round($average, 2));
                    break;
    
                default:
                    $resultsDimension = array('ERROR');
                    break;
                }
            }
        }

        return $resultsDimension;
    }
}