<?php

namespace App\Infrastructure\ImportData;

use Medoo\Medoo;

class Teachers {
    private Medoo $db;
    public function __construct(Medoo $db){
        $this->db = $db;
    }

    public function teachers()
    {
        $sql = <<<'EOP'
        INSERT IGNORE INTO docente
        SELECT temp_dcat.cve, temp_dcat.nom, temp_dcat.dep
        FROM temp_dcat 
        INNER JOIN departamento 
        ON temp_dcat.dep = departamento.clave;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->execute();
    }
}