<?php

namespace App\Infrastructure\ImportData;

use Medoo\Medoo;
use App\Infrastructure\CrudSystem\CourseInfrastructure;

class Courses {
    private Medoo $db;
    private CourseInfrastructure $courseInfrastructure;

    public function __construct(Medoo $db, CourseInfrastructure $courseInfrastructure){
        $this->db = $db;
        $this->courseInfrastructure = $courseInfrastructure;
    }

    public function courses (): ?array
    {
        $courses = $this->importCourses();
        return $this->courseInfrastructure->readAll();
        /*if (empty($this->courseInfrastructure->readAll())) {
            $result = ['message' => 'Error al importar registros en Curso',
                'success' => false];
        }
       
       return null;*/
    }

    private function importCourses ()
    {
        $sql = <<<'EOP'
        INSERT IGNORE INTO curso (nombre_grupo, id_periodo, id_carrera, clave_asignatura, folio_docente)
        SELECT temp_grupo.nombre, periodo.id, diccionario_especialidad.id_carrera, temp_dret2.clave_asignatura, temp_dgau.cat
        FROM periodo,
        temp_grupo
        INNER JOIN 
        temp_dgau
        ON temp_grupo.cve = temp_dgau.gpo
        INNER JOIN 
        temp_dret
        ON temp_dgau.mat = temp_dret.cve
        INNER JOIN 
        temp_dret2
        ON temp_dret.cve = temp_dret2.mat
        INNER JOIN 
        diccionario_especialidad
        ON temp_dret2.esp = diccionario_especialidad.cve
        WHERE
        periodo.id = (SELECT periodo.id FROM periodo WHERE periodo.activar = 1);
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->execute();
    }
}