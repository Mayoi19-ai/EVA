<?php
namespace App\Infrastructure\EvaluationStatus;

use Medoo\Medoo;
use App\Infrastructure\Exceptions\CustomException as Exception;

class EvaluationStatus {
    private Medoo $db;
    private Exception $exception;
    
    public function __construct(Medoo $db, Exception $exception) {
        $this->db = $db;
        $this->exception = $exception;
    }

    public function readAll(): ?array
    {
        $sql = <<<'EOP'
        SELECT 
        inscripcion.alumno_control AS 'control',
        alumno.nombre AS 'alumno',
        curso.nombre_grupo AS 'grupo',
        carrera.nombre AS 'carrera',
        asignatura.nombre AS 'asignatura',
        curso.clave_asignatura AS 'clave_asignatura',
        docente.nombre AS 'docente'
        FROM 
        periodo,
        evaluo
        RIGHT JOIN 
        inscripcion
        ON evaluo.id = inscripcion.id
        INNER JOIN alumno
        ON alumno.control = inscripcion.alumno_control
        INNER JOIN 
        curso 
        ON inscripcion.id_curso = curso.id
        INNER JOIN docente
        ON docente.folio = curso.folio_docente
        INNER JOIN materia
        ON curso.id_carrera = materia.id_carrera AND curso.clave_asignatura = materia.clave_asignatura
        INNER JOIN asignatura
        ON asignatura.clave = materia.clave_asignatura
        INNER JOIN carrera
        ON materia.id_carrera = carrera.id
        WHERE inscripcion.activar = 1
        AND periodo.nombre = (SELECT periodo.nombre FROM periodo WHERE periodo.activar = 1)
        AND inscripcion.id NOT IN (SELECT evaluo.id FROM evaluo)
        AND curso.id_periodo = (SELECT periodo.id FROM periodo WHERE periodo.activar = 1)
        ORDER BY curso.nombre_grupo ASC;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->execute();
        $records = $sth->fetchAll();

        return $this->exception->read((array) $this->db->error(), (array) $records);
    }
}