<?php
namespace App\Infrastructure\Rbac;

use Medoo\Medoo;
use App\Infrastructure\Exceptions\CustomException as Exception;
use App\Infrastructure\Binnacle\Binnacle;

class User {
    private Medoo $db;
    private Exception $exception;
    private Binnacle $binnacle;
    
    public function __construct(Medoo $db, Exception $exception, Binnacle $binnacle) {
        $this->db = $db;
        $this->exception = $exception;
        $this->binnacle = $binnacle;
    }

    public function create(array $data): bool
    {
        $password = password_hash($data['contrasenia'], PASSWORD_DEFAULT);

        $this->db->pdo->beginTransaction();
        $this->db->insert('usuario',[
            'nombre' => $data['usuario'], 
            'contrasenia' => $password
        ]);

        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Registrar',
        'tabla_afectada' => 'Usuario'));

        return $this->exception->save((array) $this->db->error());
    }

    public function readAll(): ?array
    {
        $sql = $this->db->select('usuario',[
            'id',
            'nombre'
        ]);

        $result = $this->exception->read((array) $this->db->error(), (array) $sql);
        return $result;
    }

    public function update(array $data): bool
    {
        $password = password_hash($data['contrasenia'], PASSWORD_DEFAULT);

        $this->db->pdo->beginTransaction();
        $this->db->update('usuario',[
            'nombre' => $data['usuario'], 
            'contrasenia' => $password], [
                'id' => $data['id']
        ]);

        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Actualizar',
        'tabla_afectada' => 'Usuario'));

        $result = $this->exception->save((array) $this->db->error());
        return $result;
    }

    public function updatePassword(array $data): bool
    {
        $password = password_hash($data['contrasenia'], PASSWORD_DEFAULT);

        $this->db->pdo->beginTransaction();
        $this->db->update('usuario',[
            'contrasenia' => $password], [
                'nombre' => $data['usuario_activo']
        ]);

        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Actualizar',
        'tabla_afectada' => 'Usuario'));

        $result = $this->exception->save((array) $this->db->error());
        return $result;
    }

    public function delete(array $data): bool
    {
        $this->db->pdo->beginTransaction();
        $this->db->delete('usuario', [
                'id' => $data['id']
        ]);
        
        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Eliminar',
        'tabla_afectada' => 'Usuario'));

        $result = $this->exception->delete((array) $this->db->error());
        return $result;
    }
}