<?php
namespace App\Infrastructure\Exceptions;

use Medoo\Medoo;

class CustomException {
    protected Medoo $db;
    
    public function __construct(Medoo $db)
    {
        $this->db = $db;
    }

    public function save(array $result): bool
    {
        if(empty($result[1])) {

            $this->db->pdo->commit();
            $sqlResult = true;

        } else {
            $this->db->pdo->rollBack();
            $sqlResult = false;
        }
        
        return $sqlResult;
    }

    public function read(array $result, array $sql): ?array
    {
        if(empty($result[1])) {
            
            if(empty($sql)) {
                $sqlResult = null;

            } else {
                $sqlResult = $sql;
            }

        } else {
            $sqlResult = null;
        }

        return $sqlResult;
    }

    public function delete(array $result): bool
    {
        if(empty($result[1])) {

            $this->db->pdo->commit();
            $sqlResult = true;

        } else {
            $this->db->pdo->rollBack();
            $sqlResult = false;
        }
        
        return $sqlResult;
    }

    public function sessions(array $result): bool
    {
        if(empty($result[1])) {

            $this->db->pdo->commit();
            $sqlResult = true;

        } else {
            $this->db->pdo->rollBack();
            $sqlResult = false;
        }

        return $sqlResult;
    }
}