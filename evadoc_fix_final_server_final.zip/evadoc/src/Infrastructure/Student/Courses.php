<?php
namespace App\Infrastructure\Student;

use Medoo\Medoo;
use App\Infrastructure\Exceptions\CustomException as Exception;

class Courses {
    private Medoo $db;
    private Exception $exception;
    
    public function __construct(Medoo $db, Exception $exception) {
        $this->db = $db;
        $this->exception = $exception;
    }

    public function readAll(string $control): ?array
    {
        $sql = <<<'EOP'
        SELECT 
        inscripcion.id AS 'id',
        inscripcion.alumno_control AS 'control',
        alumno.nombre AS 'alumno',
        curso.nombre_grupo AS 'grupo',
        carrera.nombre AS 'carrera',
        asignatura.nombre AS 'asignatura',
        curso.clave_asignatura AS 'clave_asignatura',
        docente.nombre AS 'docente',
        periodo.nombre AS 'periodo',
        curso.id AS 'curso'
        FROM 
        periodo,
        evaluo
        RIGHT JOIN 
        inscripcion
        ON evaluo.id = inscripcion.id
        INNER JOIN alumno
        ON alumno.control = inscripcion.alumno_control
        INNER JOIN 
        curso 
        ON inscripcion.id_curso = curso.id
        INNER JOIN docente
        ON docente.folio = curso.folio_docente
        INNER JOIN materia
        ON curso.id_carrera = materia.id_carrera AND curso.clave_asignatura = materia.clave_asignatura
        INNER JOIN asignatura
        ON asignatura.clave = materia.clave_asignatura
        INNER JOIN carrera
        ON materia.id_carrera = carrera.id
        WHERE inscripcion.activar = 1
        AND periodo.nombre = (SELECT periodo.nombre FROM periodo WHERE periodo.activar = 1)
        AND inscripcion.id NOT IN (SELECT evaluo.id FROM evaluo)
        AND curso.id_periodo = (SELECT periodo.id FROM periodo WHERE periodo.activar = 1)
        AND inscripcion.alumno_control = :control
        ORDER BY curso.nombre_grupo ASC;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':control', $control);
        $sth->execute();
        $records = $sth->fetchAll();

        return $this->exception->read((array) $this->db->error(), (array) $records);
    }

    public function saveQuiz(array $data): bool
    {
        $this->db->pdo->beginTransaction();
        $answers = implode(array_slice($data, 10, 48));
        $code = hash('md5', str_replace(' ', '', implode($data)) . substr(str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!#/()-_:;*'), 0, 20));

        $sql = <<<'EOP'
        CALL evaluar(:id_inscripcion, :clave, :id_curso, :respuestas);
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':id_inscripcion', $data['id']);
        $sth->bindParam(':clave', $code);
        $sth->bindParam(':id_curso', $data['id_curso']);
        $sth->bindParam(':respuestas', $answers);
        $sth->execute();

        return $this->exception->save((array) $this->db->error());
    }

    public function code(string $control): ?array
    {
        $sql = <<<'EOP'
        SELECT evaluo.clave
        FROM evaluo
        INNER JOIN inscripcion
        ON evaluo.id = inscripcion.id
        INNER JOIN curso
        ON inscripcion.id_curso = curso.id
        WHERE inscripcion.activar = 1
        AND curso.id_periodo = (SELECT periodo.id FROM periodo WHERE periodo.activar = 1)
        AND inscripcion.alumno_control = :control
        ORDER BY evaluo.id DESC;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':control', $control);
        $sth->execute();
        $records = $sth->fetchAll();

        return $this->exception->read((array) $this->db->error(), (array) $records);
    }
}