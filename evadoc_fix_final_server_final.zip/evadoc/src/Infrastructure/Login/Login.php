<?php
namespace App\Infrastructure\Login;

use Medoo\Medoo;
use App\Infrastructure\Exceptions\CustomException as Exception;

class Login {
    private Medoo $db;
    private Exception $exception;
    
    public function __construct(Medoo $db, Exception $exception) {
        $this->db = $db;
        $this->exception = $exception;
    }

    public function findStudent(array $data): ?array
    {
        $sql = $this->db->get('alumno',[
            'control',
            'contrasenia'], [
                'control' => $data['control']
            ]);

        $result = $this->exception->read((array) $this->db->error(), (array) $sql);
        return $result;
    }

    public function findUser(array $data): ?array
    {
        $sql = $this->db->get('usuario',[
            'id',
            'nombre',
            'contrasenia'], [
                'nombre' => $data['usuario_activo']
            ]);

        $result = $this->exception->read((array) $this->db->error(), (array) $sql);
        return $result;
    }

    public function userPermissions(array $data): ?array
    {
        $sql = <<<'EOP'
        SELECT permisos.nombre AS 'permiso',
        permisos.enlace AS 'enlace'
        FROM usuario
        INNER JOIN roles_usuario
        ON usuario.id = roles_usuario.id_usuario
        INNER JOIN roles
        ON roles_usuario.id_roles = roles.id
        INNER JOIN roles_permisos
        ON roles.id = roles_permisos.id_roles
        INNER JOIN permisos
        ON roles_permisos.id_permisos = permisos.id 
        INNER JOIN categoria
        ON permisos.categoria_id = categoria.id 
        WHERE roles_permisos.activar = 1
        AND usuario.nombre = :usuario
        AND categoria.nombre = :categoria
        ORDER BY permisos.nombre ASC;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':usuario', $data['usuario_activo']);
        $sth->bindParam(':categoria', $data['categoria_permisos']);
        $sth->execute();
        $records = $sth->fetchAll();
        
        $result = $this->exception->read((array) $this->db->error(), (array) $records);
        return $result;
    }

    public function userPermissionsCategories(string $user): ?array
    {
        $sql = <<<'EOP'
        SELECT categoria.nombre AS 'categoria_permisos',
        permisos.enlace AS 'enlace'
        FROM usuario
        INNER JOIN roles_usuario
        ON usuario.id = roles_usuario.id_usuario
        INNER JOIN roles
        ON roles_usuario.id_roles = roles.id
        INNER JOIN roles_permisos
        ON roles.id = roles_permisos.id_roles
        INNER JOIN permisos
        ON roles_permisos.id_permisos = permisos.id 
        INNER JOIN categoria 
        ON permisos.categoria_id = categoria.id 
        WHERE roles_permisos.activar = 1
        AND usuario.nombre = :usuario
        GROUP BY categoria.nombre
        ORDER BY categoria.nombre ASC;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':usuario', $user);
        $sth->execute();
        $records = $sth->fetchAll();
        
        $result = $this->exception->read((array) $this->db->error(), (array) $records);
        return $result;
    }

    /*public function userPermissions(array $data): ?array
    {
        $sql = <<<'EOP'
        SELECT permisos.nombre AS 'permiso',
        permisos.enlace AS 'enlace'
        FROM usuario
        INNER JOIN roles_usuario
        ON usuario.id = roles_usuario.id_usuario
        INNER JOIN roles
        ON roles_usuario.id_roles = roles.id
        INNER JOIN roles_permisos
        ON roles.id = roles_permisos.id_roles
        INNER JOIN permisos
        ON roles_permisos.id_permisos = permisos.id
        WHERE roles_permisos.activar = 1
        AND usuario.nombre = :usuario
        AND permisos.categoria = :categoria
        ORDER BY permisos.nombre ASC;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':usuario', $data['usuario_activo']);
        $sth->bindParam(':categoria', $data['categoria_permisos']);
        $sth->execute();
        $records = $sth->fetchAll();
        
        $result = $this->exception->read((array) $this->db->error(), (array) $records);
        return $result;
    }

    public function userPermissionsCategories(string $user): ?array
    {
        $sql = <<<'EOP'
        SELECT permisos.categoria AS 'categoria_permisos',
        permisos.enlace AS 'enlace'
        FROM usuario
        INNER JOIN roles_usuario
        ON usuario.id = roles_usuario.id_usuario
        INNER JOIN roles
        ON roles_usuario.id_roles = roles.id
        INNER JOIN roles_permisos
        ON roles.id = roles_permisos.id_roles
        INNER JOIN permisos
        ON roles_permisos.id_permisos = permisos.id
        WHERE roles_permisos.activar = 1
        AND usuario.nombre = :usuario
        GROUP BY permisos.categoria
        ORDER BY permisos.categoria ASC;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':usuario', $user);
        $sth->execute();
        $records = $sth->fetchAll();
        
        $result = $this->exception->read((array) $this->db->error(), (array) $records);
        return $result;
    }*/

    public function saveSession(array $data): bool
    {
        $this->db->pdo->beginTransaction();
        $this->db->insert('sesion',[
            'id_sesion' => $data['session_id'],
            'id_usuario' => $data['id'],
            'ip' => $data['ip'],
            'navegador' => $data['userAgent']
        ]);
        
        return $this->exception->save((array) $this->db->error());
    }

    public function logged(string $id): ?array
    {
        $sql = $this->db->get('sesion',[
            'id_usuario',
            'ip',
            'navegador'], [
                'id_sesion' => $id
            ]);

        return $this->exception->read((array) $this->db->error(), (array) $sql);
    }

    public function searchPermission(string $link): boolean
    {
        $sql = $this->db->get('permisos',[
            'enlace'], [
                'enlace' => $link
            ]);

        $result = $this->exception->read((array) $this->db->error(), (array) $sql);
        return $result;
    }

    public function searchUserPermission(string $link, int $user): boolean
    {
        $sql = <<<'EOP'
        SELECT usuario.nombre,
        usuario.id,
        permisos.enlace
        FROM 
        usuario
        INNER JOIN 
        roles_usuario
        ON usuario.id = roles_usuario.id_usuario
        INNER JOIN 
        roles
        ON roles_usuario.id_roles = roles.id
        INNER JOIN 
        roles_permisos
        ON roles.id = roles_permisos.id_roles
        INNER JOIN 
        permisos
        ON roles_permisos.id_permisos = permisos.id
        WHERE usuario.id = :id_usuario AND permisos.enlace '%' :enlace '%'
        ORDER BY permisos.categoria ORDER ASC;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':id_usuario', $user);
        $sth->bindParam(':enlace', $link);
        $sth->execute();
        $records = $sth->fetchAll();
        
        return $this->exception->read((array) $this->db->error(), (array) $records);
    }

    public function deleteSession(string $id): boolean
    {
        $this->db->delete('session', [
            'id' => $id
        ]);
    }
}