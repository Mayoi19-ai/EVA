<?php
namespace App\Infrastructure\CrudSystem;
use App\Infrastructure\Exceptions\CustomException as Exception;
use App\Infrastructure\Binnacle\Binnacle;

use Medoo\Medoo;

class CareerInfrastructure{
    private Medoo $db;
    private Exception $exception;
    private Binnacle $binnacle;

    public function __construct(Medoo $db, Exception $exception, Binnacle $binnacle)
    {
        $this->db = $db;
        $this->exception = $exception;
        $this->binnacle = $binnacle;
    }

    public function create(array $data): bool
    {
        $this->db->pdo->beginTransaction();
        $this->db->insert('carrera',[
            'id' => $data['id'],
            'clave' => strtoupper($data['clave']), 
            'nombre' => strtoupper($data['nombre']),
            'nombre_corto' => strtoupper($data['nombre_corto'])
        ]);

        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Registrar',
        'tabla_afectada' => 'Carrera'));

        return $this->exception->save((array) $this->db->error());
    }

    public function readAll(): ?array
    {
        $sql = $this->db->select('carrera', [
            'id', 
            'clave',
            'nombre',
            'nombre_corto'
        ]);
        
        return $this->exception->read((array) $this->db->error(), (array) $sql);
    }

    public function readAuxiliary(): ?array
    {
        $sql = $this->db->select('carrera', [
            'id',
            'nombre'
        ]);

        return $this->exception->read((array) $this->db->error(), (array) $sql);
    }

    public function update(array $data): bool
    {
        $this->db->pdo->beginTransaction();
        $this->db->update('carrera', [
            'id' => $data['id'],
            'clave'  => strtoupper($data['clave']),
            'nombre' => strtoupper($data['nombre']),
            'nombre_corto' => strtoupper($data['nombre_corto'])], [
            'id' => $data['id_antiguo']
        ]);

        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Actualizar',
        'tabla_afectada' => 'Carrera'));

        return $this->exception->save((array) $this->db->error());
    }
    
    public function delete(array $data): bool
    {   
        $this->db->pdo->beginTransaction();
        $this->db->delete('carrera', [
            'id' => $data['id']
        ]);

        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Eliminar',
        'tabla_afectada' => 'Carrera'));

        return $this->exception->delete((array) $this->db->error());
    }
}