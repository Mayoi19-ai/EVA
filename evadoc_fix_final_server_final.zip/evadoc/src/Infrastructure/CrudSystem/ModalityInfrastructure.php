<?php
namespace App\Infrastructure\CrudSystem;

use Medoo\Medoo;
use App\Infrastructure\Exceptions\CustomException as Exception;
use App\Infrastructure\Binnacle\Binnacle;

class ModalityInfrastructure {
    private Medoo $db;
    private Exception $exception;
    private Binnacle $binnacle;

    public function __construct(Medoo $db, Exception $exception, Binnacle $binnacle) 
    {
        $this->db = $db;
        $this->exception = $exception;
        $this->binnacle = $binnacle;
    }

    public function create(array $data): bool
    {
        $this->db->pdo->beginTransaction();
        $this->db->insert('modalidad',[
            'nombre' => strtoupper($data['nombre'])
        ]);

        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Registrar',
        'tabla_afectada' => 'Modalidad'));

        return $this->exception->save((array) $this->db->error());
    }

    //is too auxiliary
    public function readAll(): ?array
    {
        $sql = $this->db->select('modalidad',[
            'id',
            'nombre'
        ]);
        
        return $this->exception->read((array) $this->db->error(), (array) $sql);
    }

    public function update(array $data): bool
    {
        $this->db->pdo->beginTransaction();
        
        $this->db->update('modalidad', [
            'nombre' => strtoupper($data['nombre'])], [
            'id' => $data['id']
        ]);

        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Actualizar',
        'tabla_afectada' => 'Modalidad'));

        return $this->exception->save((array) $this->db->error());
    }
    
    public function delete(array $data): bool
    {
        $this->db->pdo->beginTransaction();
        $this->db->delete('modalidad', [
            'id' => $data['id']
        ]);
        
        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Eliminar',
        'tabla_afectada' => 'Roles modalidad'));

        return $this->exception->delete((array) $this->db->error());
    }
}