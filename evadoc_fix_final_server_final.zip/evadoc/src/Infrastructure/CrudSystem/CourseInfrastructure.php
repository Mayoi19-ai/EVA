<?php
namespace App\Infrastructure\CrudSystem;

use Medoo\Medoo;
use App\Infrastructure\Exceptions\CustomException as Exception;
use App\Infrastructure\Binnacle\Binnacle;

class CourseInfrastructure{
    private Medoo $db;
    private Exception $exception;
    private Binnacle $binnacle;

    public function __construct(Medoo $db, Exception $exception, Binnacle $binnacle) 
    {
        $this->db = $db;
        $this->exception = $exception;
        $this->binnacle = $binnacle;
    }

    public function create(array $data): bool
    {
        $this->db->pdo->beginTransaction();
        $sql = <<<'EOP'
        INSERT INTO curso (nombre_grupo, id_periodo, id_carrera, clave_asignatura, folio_docente) 
        SELECT :grupo, periodo.id, :id_carrera, :clave_asignatura, :folio_docente 
        FROM periodo WHERE periodo.activar = 1;
        EOP;

        $group = strtoupper($data['grupo']);
        $assignature = explode(" ", $data['clave_asignatura_id_carrera']);
        $career = explode(" ", $data['clave_asignatura_id_carrera']);

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':grupo', $group);
        $sth->bindParam(':id_carrera', $career[1]);
        $sth->bindParam(':clave_asignatura', $assignature[0]);
        $sth->bindParam(':folio_docente', $data['folio_docente']);
        $sth->execute();

        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Registrar',
        'tabla_afectada' => 'Curso'));

        return $this->exception->save((array) $this->db->error());
    }

    public function readAll(): ?array
    {
        $sql = <<<'EOP'
        SELECT curso.id AS 'id_curso',
        curso.nombre_grupo AS 'grupo',
        carrera.nombre AS 'carrera',
        curso.id_carrera AS 'id_carrera',
        asignatura.nombre AS 'asignatura',
        curso.clave_asignatura AS 'clave_asignatura',
        docente.nombre AS 'docente',
        curso.folio_docente AS 'folio_docente'
        FROM 
        curso
        INNER JOIN docente 
        ON docente.folio = curso.folio_docente
        INNER JOIN materia
        ON curso.id_carrera = materia.id_carrera AND curso.clave_asignatura = materia.clave_asignatura
        INNER JOIN asignatura
        ON asignatura.clave = materia.clave_asignatura
        INNER JOIN carrera
        ON materia.id_carrera = carrera.id
        WHERE curso.id_periodo = (SELECT periodo.id FROM periodo WHERE periodo.activar = 1)
        ORDER BY carrera.nombre_corto, curso.nombre_grupo ASC;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->execute();
        $records = $sth->fetchAll();
        
        return $this->exception->read((array) $this->db->error(), (array) $records);
    }

    public function readBygroup(string $group): ?array
    {
        $sql = <<<'EOP'
        SELECT curso.id AS 'id_curso',
        curso.nombre_grupo AS 'grupo',
        carrera.nombre AS 'carrera',
        curso.id_carrera AS 'id_carrera',
        asignatura.nombre AS 'asignatura',
        curso.clave_asignatura AS 'clave_asignatura',
        docente.nombre AS 'docente',
        curso.folio_docente AS 'folio_docente'
        FROM 
        curso
        INNER JOIN docente 
        ON docente.folio = curso.folio_docente
        INNER JOIN materia
        ON curso.id_carrera = materia.id_carrera AND curso.clave_asignatura = materia.clave_asignatura
        INNER JOIN asignatura
        ON asignatura.clave = materia.clave_asignatura
        INNER JOIN carrera
        ON materia.id_carrera = carrera.id
        WHERE curso.id_periodo = (SELECT periodo.id FROM periodo WHERE periodo.activar = 1)
        AND curso.nombre_grupo LIKE '%' :grupo '%'
        ORDER BY carrera.nombre_corto, curso.nombre_grupo ASC;
        EOP;

        $group = strtoupper($group);

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':grupo', $group);
        $sth->execute();
        $records = $sth->fetchAll();
        
        return $this->exception->read((array) $this->db->error(), (array) $records);
    }

    public function readByLesson(string $lesson): ?array
    {
        $sql = <<<'EOP'
        SELECT curso.id AS 'id_curso',
        curso.nombre_grupo AS 'grupo',
        carrera.nombre AS 'carrera',
        curso.id_carrera AS 'id_carrera',
        asignatura.nombre AS 'asignatura',
        curso.clave_asignatura AS 'clave_asignatura',
        docente.nombre AS 'docente',
        curso.folio_docente AS 'folio_docente'
        FROM 
        curso
        INNER JOIN docente 
        ON docente.folio = curso.folio_docente
        INNER JOIN materia
        ON curso.id_carrera = materia.id_carrera AND curso.clave_asignatura = materia.clave_asignatura
        INNER JOIN asignatura
        ON asignatura.clave = materia.clave_asignatura
        INNER JOIN carrera
        ON materia.id_carrera = carrera.id
        WHERE curso.id_periodo = (SELECT periodo.id FROM periodo WHERE periodo.activar = 1)
        AND asignatura.nombre LIKE '%' :asignatura '%'
        ORDER BY carrera.nombre_corto, curso.nombre_grupo ASC;
        EOP;

        $lesson = strtoupper($lesson);

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':asignatura', $lesson);
        $sth->execute();
        $records = $sth->fetchAll();
        
        return $this->exception->read((array) $this->db->error(), (array) $records);
    }

    public function update(array $data): bool
    {
        $this->db->pdo->beginTransaction();
        
        $assignature = explode(" ", $data['clave_asignatura_id_carrera']);
        $career = explode(" ", $data['clave_asignatura_id_carrera']);

        $this->db->update('curso',[
            'nombre_grupo' => strtoupper($data['grupo']),
            'id_carrera' => $career[1],
            'clave_asignatura' => $assignature[0],
            'folio_docente' => $data['folio_docente']], [
                'curso.id' => $data['id_curso']
        ]);

        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Actualizar',
        'tabla_afectada' => 'Curso'));

        return $this->exception->save((array) $this->db->error());
    }
    
    public function delete(array $data): bool
    {
        $this->db->pdo->beginTransaction();
        $this->db->delete('curso', [
            'AND' => [
                'curso.id' => $data['id_curso']
            ]
        ]);

        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Eliminar',
        'tabla_afectada' => 'Curso'));
        
        return $this->exception->delete((array) $this->db->error());
    }
}