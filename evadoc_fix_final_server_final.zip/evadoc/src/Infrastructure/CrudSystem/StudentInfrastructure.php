<?php
namespace App\Infrastructure\CrudSystem;

use Medoo\Medoo;
use App\Infrastructure\Exceptions\CustomException as Exception;
use App\Infrastructure\Binnacle\Binnacle;

class StudentInfrastructure{
    private Medoo $db;
    private Exception $exception;
    private Binnacle $binnacle;

    public function __construct(Medoo $db, Exception $exception, Binnacle $binnacle) 
    {
        $this->db = $db;
        $this->exception = $exception;
        $this->binnacle = $binnacle;
    }

    public function create(array $data): bool
    {
        $this->db->pdo->beginTransaction();
        $password = password_hash(strtoupper($data['control']), PASSWORD_DEFAULT);

        $this->db->insert('alumno',[
            'control' => strtoupper($data['control']), 
            'nombre' => strtoupper($data['nombre']),
            'contrasenia' => $password
        ]);

        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Registrar',
        'tabla_afectada' => 'Estudiante'));

        return $this->exception->save((array) $this->db->error());
    }

    public function readAll(): ?array
    {
        $sql = $this->db->select('alumno',[
            'control',
            'nombre'
        ]);

        return $this->exception->read((array) $this->db->error(), (array) $sql);
    }

    public function read(string $control): ?array
    {
        $sql = $this->db->select('alumno',[
            'nombre',
            'control'], [
                'control' => strtoupper($control)
        ]);

        return $this->exception->read((array) $this->db->error(), (array) $sql);
    }

    public function update(array $data): bool
    {
        $this->db->pdo->beginTransaction();
        $password = password_hash(strtoupper($data['control']), PASSWORD_DEFAULT);
        
        $this->db->update('alumno',[
            'control' => strtoupper($data['control']), 
            'nombre' => strtoupper($data['nombre']),
            'contrasenia' => $password], [
                'control' => strtoupper($data['control_antiguo'])
        ]);

        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Actualizar',
        'tabla_afectada' => 'Estudiante'));

        return $this->exception->save((array) $this->db->error());
    }

    public function updatePassword(array $data): bool
    {
        $password = password_hash($data['contrasenia'], PASSWORD_DEFAULT);

        $this->db->pdo->beginTransaction();
        $this->db->update('alumno',[
            'contrasenia' => $password], [
                'control' => strtoupper($data['control'])
                ]);

        return $this->exception->save((array) $this->db->error());
    }

    public function updatePasswordAdmin(array $data): bool
    {
        $password = password_hash(strtoupper($data['control']), PASSWORD_DEFAULT);

        $this->db->pdo->beginTransaction();
        $this->db->update('alumno',[
            'contrasenia' => $password], [
                'control' => strtoupper($data['control'])
            ]);

        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Actualizar contrasenia',
        'tabla_afectada' => 'Estudiante'));

        return $this->exception->save((array) $this->db->error());
    }
    
    public function delete(array $data): bool
    {
        $this->db->pdo->beginTransaction();
        $this->db->delete('alumno', [
                'control' => $data['control']
        ]);

        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Eliminar',
        'tabla_afectada' => 'Estudiante'));
        
        return $this->exception->delete((array) $this->db->error());
    }
}