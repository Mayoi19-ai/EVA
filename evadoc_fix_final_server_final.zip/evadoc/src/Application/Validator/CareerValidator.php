<?php
namespace App\Validator;
use Rakit\Validation\Validator;

class CareerValidator{
    private Validator $validator;

    public function __construct(Validator $validator) {
        $this->validator = $validator;
    }

    public function validateSaveCareer(array $data): array {
        $validationRules = [
            'id'             =>  'required|numeric|digits_between:1,10',
            'clave'          =>  'required|alpha_dash|between:13,13',
            'nombre'         =>  'required|alpha_spaces',
            'nombre_corto'   =>  'required|alpha|between:2,5',
        ];
    
        $errorMessages = [
            'id:required'            => 'El identificador de carrera es obligatorio',
            'id:numeric'             => 'El identificador de carrera es numerico',
            'id:digits_between'      => 'El identificador de carrera debe tener entre 1 a 10 caracteres',
            'clave:required'         => 'La clave es obligatoria',
            'clave:alpha_dash'       => 'La clave no es válida',
            'clave:between'          => 'La clave debe tener 13 caracteres',
            'nombre:required'        => 'El nombre es obligatorio',
            'nombre:alpha_espaces'   => 'El nombre no es válido',
            'nombre_corto:required'  => 'El nombre es obligatorio',
            'nombre_corto:alpha'     => 'El nombre corto no es válido',
            'nombre_corto:between'   => 'El nombre corto debe tener entre 2 y 5 caracteres',
        ];
    
        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data);
    }

    public function validateFindCareer(array $data): array {
        $validationRules = [
            'nombre'          =>  'required|alpha_spaces',
        ];
    
        $errorMessages = [
            'nombre:required'        => 'El nombre es obligatorio',
            'nombre:alpha_espaces'   => 'El nombre no es válido',
        ];
    
        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data);
    }
}