<?php
namespace App\Validator;

use Rakit\Validation\Validator;

class CustomValidator {

    protected Validator $validator;
    protected array $valiationRules;
    protected array $errorMessages;

    public function __construct(Validator $validator, array $validationRules, array $errorMessages) {
        $this->validator = $validator;
        $this->validationRules = $validationRules;
        $this->errorMessages = $errorMessages;
    }

    public function validate(array $data): array {
        $validation = $this->validator->make($data, $this->validationRules, $this->errorMessages);
        $validation->validate();

        if ($validation->fails()) {
            $errors        = $validation->errors();
            $errorMessages = $errors->firstOfAll();
            $resultData = ['errorMessages' => $errorMessages, 
            'flag' => false];
            return $resultData;
        } else {
            $resultData = ['flag' => true];
            return $resultData;
        }
    }
}