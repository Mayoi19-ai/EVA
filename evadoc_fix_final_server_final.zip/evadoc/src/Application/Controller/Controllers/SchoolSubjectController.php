<?php
namespace App\Controller\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use App\Validator\SchoolSubjectValidator as Validator;
use Ujpef\LatteView;
use App\Infrastructure\CrudSystem\SchoolSubjectInfrastructure as Infrastructure;
use App\Infrastructure\CrudSystem\CareerInfrastructure as CareerInfra;
use App\Infrastructure\CrudSystem\LessonInfrastructure as LessonInfra;
use App\Validator\LessonValidator as LessonVal;
use App\Infrastructure\Login\Login as LoginInfra;

class SchoolSubjectController{
    private Container $container;
    private Infrastructure $infrastructure;
    private CareerInfra $careerInfra;
    private LessonInfra $lessonInfra;
    private Validator $validator;
    private LessonVal $lessonVal;
    private LoginInfra $LoginInfra;

    public function __construct(Container $container, Infrastructure $infrastructure, CareerInfra $careerInfra, LessonInfra $lessonInfra, Validator $validator, LessonVal $lessonVal, LoginInfra $LoginInfra)
    {
        $this->container = $container;
        $this->infrastructure = $infrastructure;
        $this->careerInfra = $careerInfra;
        $this->lessonInfra = $lessonInfra;
        $this->validator = $validator;
        $this->lessonVal = $lessonVal;
        $this->loginInfra = $LoginInfra;
    }

    public function saveForm(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $permissions = $this->loginInfra->userPermissions((array) $data);
        $careerData = $this->careerInfra->readAuxiliary();
        $lessonData = $this->lessonInfra->readAll();
        $sthResult = $this->infrastructure->readAll();

        return $this->container->get(LatteView::class)->render($response, 
        'Materia/subjectForm.latte',[
            'all_careers_information' => $careerData,
            'all_lessons_information' => $lessonData,
            'permissions' => $permissions,
            'query' => $sthResult,
            'data' => $data
        ]);
    }

    public function register(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $validationResult = $this->validator->validateSaveSubject((array) $data);
        $permissions = $this->loginInfra->userPermissions((array) $data);
        $sthResult = $this->infrastructure->readAll();
        $careerData = $this->careerInfra->readAuxiliary();
        $lessonData = $this->lessonInfra->readAll();

        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->create((array) $data);
        } else {
            $sthResult = false;
        }

        return $this->container->get(LatteView::class)->render(
            $response,
            'Materia/subjectForm.latte', [
                'all_careers_information' => $careerData,
                'all_lessons_information' => $lessonData,
                'validation' => $validationResult, 
                'permissions' => $permissions,
                'query' => $sthResult,
                'data' => $data
            ]);
    }

    public function showByCareer(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $permissions = $this->loginInfra->userPermissions((array) $data);
        $sthResult = $this->infrastructure->showByCareer((int) $data['id_career']);
        $careerData = $this->careerInfra->readAuxiliary();

        return $this->container->get(LatteView::class)->render(
            $response,
            'Materia/subjectTable.latte', [
                'query' => $sthResult,
                'data' => $data,
                'permissions' => $permissions,
                'all_careers_information' => $careerData,
            ]);
    }

    public function searchByLesson(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $permissions = $this->loginInfra->userPermissions((array) $data);
        $validationResult = $this->lessonVal->validateFindLesson((array) $data);
        $careerData = $this->careerInfra->readAuxiliary();

        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->readByLesson((string) $data['asignatura']);
        } else {
            $sthResult = false;
        }

        return $this->container->get(LatteView::class)->render(
            $response,
            'Materia/subjectTable.latte', [
                'query' => $sthResult,
                'data' => $data,
                'permissions' => $permissions,
                'validation' => $validationResult, 
                'all_careers_information' => $careerData,
            ]);
    }

    public function show(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $sthResult = $this->infrastructure->readAll();
        $permissions = $this->loginInfra->userPermissions((array) $data);
        $careerData = $this->careerInfra->readAuxiliary();

        return $this->container->get(LatteView::class)->render(
            $response,
            'Materia/subjectTable.latte', [
                'query' => $sthResult,
                'data' => $data,
                'permissions' => $permissions,
                'all_careers_information' => $careerData,
            ]);
    }

    public function updateForm(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $careerData = $this->careerInfra->readAuxiliary();
        $lessonData = $this->lessonInfra->readAll();
        $permissions = $this->loginInfra->userPermissions((array) $data);
        $sthResult = $this->infrastructure->readAll();

        return $this->container->get(LatteView::class)->render($response, 
        'Materia/subjectUpdate.latte',[
            'data' => $data,
            'all_careers_information' => $careerData,
            'all_lessons_information' => $lessonData,
            'permissions' => $permissions,
            'query' => $sthResult,
        ]);
    }

    public function update(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $careerData = $this->careerInfra->readAuxiliary();
        $lessonData = $this->lessonInfra->readAll();
        $validationResult = $this->validator->validateSaveSubject((array) $data);
        $permissions = $this->loginInfra->userPermissions((array) $data);

        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->update((array) $data);
        } else {
            $sthResult = false;
        }

        return $this->container->get(LatteView::class)->render(
            $response,
            'Materia/subjectUpdate.latte', [
                'validation' => $validationResult, 
                'query' => $sthResult,
                'all_careers_information' => $careerData,
                'all_lessons_information' => $lessonData,
                'data' => $data,
                'permissions' => $permissions,
            ]);
    }

    public function delete(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $this->infrastructure->delete($data);
        $sthResult = $this->infrastructure->readAll();
        $permissions = $this->loginInfra->userPermissions((array) $data);
        $careerData = $this->careerInfra->readAuxiliary();
        $lessonData = $this->lessonInfra->readAll();

        return $this->container->get(LatteView::class)->render(
            $response,
            'Materia/subjectTable.latte', [
                'query' => $sthResult,
                'data' => $data,
                'permissions' => $permissions,
                'all_careers_information' => $careerData,
                'all_lessons_information' => $lessonData,
            ]);
    }
}