<?php
namespace App\Controller\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use Ujpef\LatteView;
use App\Validator\GroupValidator as Validator;
use App\Infrastructure\CrudSystem\GroupInfrastructure as Infrastructure;
use App\Infrastructure\CrudSystem\CareerInfrastructure as CareerInfra;
use App\Infrastructure\CrudSystem\ModalityInfrastructure as ModalityInfra;
use App\Infrastructure\CrudSystem\CampusInfrastructure as CampusInfra;
use App\Infrastructure\Login\Login as LoginInfra;

class GroupController{
    private Container $container;
    private Infrastructure $infrastructure;
    private Validator $validator;
    private CareerInfra $careerInfra;
    private ModalityInfra $modalityInfra;
    private CampusInfra $campusInfra;
    private LoginInfra $LoginInfra;

    public function __construct(Container $container, Infrastructure $infrastructure, CareerInfra $careerInfra, ModalityInfra $modalityInfra, CampusInfra $campusInfra, Validator $validator, LoginInfra $LoginInfra)
    {
        $this->container = $container;
        $this->infrastructure = $infrastructure;
        $this->careerInfra = $careerInfra;
        $this->modalityInfra = $modalityInfra;
        $this->campusInfra = $campusInfra;
        $this->validator = $validator;
        $this->loginInfra = $LoginInfra;
    }

    public function saveForm(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $permissions = $this->loginInfra->userPermissions((array) $data);
        $careerData = $this->careerInfra->readAuxiliary();
        $modalityData = $this->modalityInfra->readAll();
        $campusData = $this->campusInfra->readAll();
        $sthResult = $this->infrastructure->readAll();

        return $this->container->get(LatteView::class)->render($response, 
        'Grupo/groupForm.latte', [
            'all_careers_information' => $careerData,
            'all_modalities_information' => $modalityData,
            'all_campus_information' => $campusData,
            'permissions' => $permissions,
            'query' => $sthResult,
            'data' => $data
        ]);
    }

    public function register(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $permissions = $this->loginInfra->userPermissions((array) $data);
        $careerData = $this->careerInfra->readAuxiliary();
        $modalityData = $this->modalityInfra->readAll();
        $campusData = $this->campusInfra->readAll();
        $sthResult = $this->infrastructure->readAll();
        $validationResult = $this->validator->validateSaveGroup((array) $data);

        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->create((array) $data);
        } else {
            $sthResult = false;
        }

        return $this->container->get(LatteView::class)->render(
            $response,
            'Grupo/groupForm.latte', [
                'validation' => $validationResult, 
                'all_careers_information' => $careerData,
                'all_modalities_information' => $modalityData,
                'all_campus_information' => $campusData,
                'permissions' => $permissions,
                'query' => $sthResult,
                'data' => $data
            ]);
    }

    public function search(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $permissions = $this->loginInfra->userPermissions((array) $data);
        $validationResult = $this->validator->validateFindGroup((array) $data);

        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->readByGroup((string) $data['grupo']);
        } else {
            $sthResult = false;
        }

        return $this->container->get(LatteView::class)->render(
            $response,
            'Grupo/groupTable.latte', [
                'query' => $sthResult,
                'data' => $data,
                'permissions' => $permissions,
                'validation' => $validationResult, 
            ]);
    }

    public function show(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $sthResult = $this->infrastructure->readAll();
        $permissions = $this->loginInfra->userPermissions((array) $data);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Grupo/groupTable.latte', [
                'query' => $sthResult,
                'data' => $data,
                'permissions' => $permissions,
            ]);
    }

    public function updateForm(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $careerData = $this->careerInfra->readAuxiliary();
        $modalityData = $this->modalityInfra->readAll();
        $campusData = $this->campusInfra->readAll();
        $permissions = $this->loginInfra->userPermissions((array) $data);
        $sthResult = $this->infrastructure->readAll();

        return $this->container->get(LatteView::class)->render($response, 
        'Grupo/groupUpdate.latte', [
            'all_careers_information' => $careerData,
            'all_modalities_information' => $modalityData,
            'all_campus_information' => $campusData,
            'permissions' => $permissions,
            'query' => $sthResult,
            'data' => $data
        ]);
    }

    public function update(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $validationResult = $this->validator->validateSaveGroup((array) $data);
        $careerData = $this->careerInfra->readAuxiliary();
        $modalityData = $this->modalityInfra->readAll();
        $campusData = $this->campusInfra->readAll();

        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->update((array) $data);
        } else {
            $sthResult = false;
        }

        return $this->container->get(LatteView::class)->render(
            $response,
            'Grupo/groupUpdate.latte', [
                'all_careers_information' => $careerData,
                'all_modalities_information' => $modalityData,
                'all_campus_information' => $campusData,
                'validation' => $validationResult,
                'query' => $sthResult,
                'data' => $data
            ]);
    }

    public function delete(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $this->infrastructure->delete((array) $data);
        $sthResult = $this->infrastructure->readAll();
        $permissions = $this->loginInfra->userPermissions((array) $data);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Grupo/groupTable.latte', [
                'query' => $sthResult,
                'data' => $data,
                'permissions' => $permissions
            ]);
    }
}