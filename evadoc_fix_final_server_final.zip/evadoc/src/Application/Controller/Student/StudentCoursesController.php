<?php
namespace App\Controller\Student;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use Ujpef\LatteView;
use App\Validator\StudentValidator as Validator;
use App\Infrastructure\CrudSystem\StudentInfrastructure as Infrastructure;
use App\Infrastructure\Student\Courses as CoursesInfra;
use App\Domain\Code\Code;
use App\Infrastructure\CrudSystem\PeriodInfrastructure as PeriodInfra;

class StudentCoursesController{
    private Container $container;
    private Validator $validator;
    private Infrastructure $infrastructure;
    private CoursesInfra $coursesInfra;
    private Code $code;
    private PeriodInfra $periodInfra;

    public function __construct(Container $container, Validator $validator, Infrastructure $infrastructure, CoursesInfra $coursesInfra, Code $code, PeriodInfra $periodInfra)
    {
        $this->container = $container;
        $this->validator = $validator;
        $this->infrastructure = $infrastructure;
        $this->coursesInfra = $coursesInfra;
        $this->code = $code;
        $this->periodInfra = $periodInfra;
    }

    public function menu (Request $request, Response $response) {
        $student = $request->getParsedBody();
        $data = $this->infrastructure->read((string) $student['control']);
        $evaluation = $this->periodInfra->evaluationState();

        if($evaluation['activar'] == 1) {
            $sthResult = $this->coursesInfra->readAll((string) $student['control']);
            $evaluationCode = null;

            if(empty($sthResult)) {
                $codes = $this->coursesInfra->code((string) $student['control']);
    
                if(!empty($codes)) {
                    $evaluationCode = $this->container->get('settings')['link'] . $this->code->code((array) $codes);
                    
                } else {
                    $evaluationCode = false;
                }
            }

        } else {
            $sthResult = false;
            $evaluationCode = false;
        }

        return $this->container->get(LatteView::class)->render(
            $response, 
            'Menu/studentMenu.latte', [
                'student_information' => $data,
                'query' => $sthResult,
                'code' => $evaluationCode
        ]);
    }

    public function updateForm (Request $request, Response $response) {
        $data = $request->getParsedBody();

        return $this->container->get(LatteView::class)->render($response, 
            'Contrasenas/studentContrasenia.latte', [
                'student_information' => $data,
            ]);
    }

    public function update(Request $request, Response $response) {
        $data = $request->getParsedBody();
        
        $validationResult = $this->validator->validateUpdatePassword((array) $data);
        
        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->updatePassword((array) $data);
        } else {
            $sthResult = false;
        }

        return $this->container->get(LatteView::class)->render(
            $response,
            'Contrasenas/passwordStudentSave.latte', [
                'student_information' => $data,
                'validation' => $validationResult, 
                'query' => $sthResult,
            ]);
    }

    public function showQuiz (Request $request, Response $response) {
        $data = $request->getParsedBody();

        return $this->container->get(LatteView::class)->render(
            $response,
            'Preguntas/@layout.latte', [
                'courseData' => $data
        ]);
    }

    public function saveQuiz (Request $request, Response $response) {
        $data = $request->getParsedBody();

        $arrayExtract = strlen(implode(array_slice($data, 10, 48)));
        
        if($arrayExtract == 48) {
            if(is_numeric($arrayExtract)) {
                $sthResult = $this->coursesInfra->saveQuiz($data);
            }
           
        } else {
            $sthResult = false;
        }

        return $this->container->get(LatteView::class)->render(
            $response,
            'Preguntas/questionarySave.latte', [
                'saveResult' => $sthResult,
                'data' => $data
            ]);
    }
}