<?php declare(strict_types=1);
namespace App\Middleware;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Server\MiddlewareInterface as Middleware;
use Psr\Http\Server\RequestHandlerInterface as RequestHandler;
use Slim\Routing\RouteContext;
use Psr\Http\Message\ResponseFactoryInterface as Factory;
use Odan\Session\PhpSession as Session;

class SessionDeleteMiddleware implements Middleware
{
    private Session $session;

    public function __construct(Session $session)
    {
        $this->session = $session;
    }

    public function process(Request $request, RequestHandler $handler): Response
    {

        if($this->session->get('logged')) {
            $this->session->clear();
            $this->session->destroy();
            $this->session->setName('eva');
            $this->session->start();
            $handler->handle($request);
        }

        return $handler->handle($request);
    }
}