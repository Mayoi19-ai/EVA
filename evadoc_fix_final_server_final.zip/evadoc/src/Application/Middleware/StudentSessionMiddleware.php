<?php declare(strict_types=1);
namespace App\Middleware;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Server\MiddlewareInterface as Middleware;
use Psr\Http\Server\RequestHandlerInterface as RequestHandler;
use Slim\Routing\RouteContext;
use Psr\Http\Message\ResponseFactoryInterface as Factory;
use App\Validator\LoginValidator as Validator;
use App\Infrastructure\Login\Login as Infrastructure;
use Odan\Session\PhpSession as Session;

class StudentSessionMiddleware implements Middleware
{
    private Factory $responseFactory;
    private Validator $validator;
    private Infrastructure $infrastructure;
    private Session $session;

    public function __construct(Factory $responseFactory, Validator $validator, Infrastructure $infrastructure, Session $session)
    {
        $this->responseFactory = $responseFactory;
        $this->validator = $validator;
        $this->infrastructure = $infrastructure;
        $this->session = $session;
    }

    public function process(Request $request, RequestHandler $handler): Response
    {
        if($this->session->get('logged') && $this->session->get('student')) {
            return $handler->handle($request);

        } else {
            $data = $request->getParsedBody();
            $student = $this->student($data);

            if(empty($student)) {
                $routeParser = RouteContext::fromRequest($request)->getRouteParser();
                $url = $routeParser->urlFor('loginStudent');
                
                $response = $this->responseFactory->createResponse();
                return $response->withStatus(302)->withHeader('Location', $url);

            } else {

                if(password_verify($data['contrasenia'], $student['contrasenia'])) {
                    $this->session->replace(['logged' => true, 'student' => true]);
                    $this->session->save();

                    return $handler->handle($request);
                } else {
                
                    $routeParser = RouteContext::fromRequest($request)->getRouteParser();
                    $url = $routeParser->urlFor('loginStudent');
                    $response = $this->responseFactory->createResponse();
                    return $response->withStatus(302)->withHeader('Location', $url);
                }
            }

        }        
    }

    private function student(array $data): ?array
    {
        $validationResult = $this->validator->studentValidator((array) $data);

        if(!empty($validationResult['flag'])) {
            return $this->infrastructure->findStudent((array) $data);
        }

        return null;
    }
}