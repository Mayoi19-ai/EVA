<?php declare(strict_types=1);

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Log\LoggerInterface;
use Slim\App;
use Ujpef\LatteView;
use Slim\Routing\RouteCollectorProxy;

use App\Controller\Controllers\TeacherController;
use App\Controller\Controllers\CampusController;
use App\Controller\Controllers\ModalityController;
use App\Controller\Controllers\PeriodController;
use App\Controller\Controllers\CareerController;
use App\Controller\Controllers\LessonController;
use App\Controller\Controllers\DepartmentController;
use App\Controller\Controllers\StudentController;
use App\Controller\Controllers\InscriptionController;
use App\Controller\Controllers\SchoolSubjectController;
use App\Controller\Controllers\CourseController;
use App\Controller\Controllers\GroupController;
use App\Controller\Controllers\QuestionnaireController;
use App\Controller\Controllers\ImportDbfDataController;
use App\Controller\Access\UserController;
use App\Controller\Access\RoleController;
use App\Controller\Access\UserRolesController;
use App\Controller\Access\RolePermissionsController;
use App\Controller\Controllers\EvaluationStatus;

use App\Controller\Student\LoginStudentController;
use App\Controller\Student\StudentCoursesController;

use App\Controller\User\LoginUserController;
use App\Controller\User\MenuController;

use App\Controller\Code\CodeController;
use App\Controller\Reports\ReportsController;

use App\Middleware\StudentSessionMiddleware;
use App\Middleware\UserSessionMiddleware;
use App\Middleware\SessionStartMiddleware;
use App\Middleware\SessionDeleteMiddleware;

return function(App $app): void
{
    $app->get('/login', LoginUserController::class . ':login')->setName('usersLogin')->add(SessionDeleteMiddleware::class);
    $app->post('/login', MenuController::class . ':menu')->setName('userMenu')->add(UserSessionMiddleware::class);

    $app->group('/users', function (RouteCollectorProxy $group) {

        $group->group('/logged', function (RouteCollectorProxy $group) {
            $group->post('/update-password-form', MenuController::class . ':updateForm')->setName('userPasswordUpdateForm');
            $group->post('/update', MenuController::class . ':update')->setName('userPasswordUpdate');
        });

        $group->group('/status', function (RouteCollectorProxy $group) {
            $group->post('/students', EvaluationStatus::class . ':show')->setName('studentStatusEvaluation');
        });

        $group->group('/teacher', function (RouteCollectorProxy $group) {
            $group->post('/save-form', TeacherController::class . ':saveForm')->setName('teacherSaveForm');
            $group->post('/register', TeacherController::class . ':register')->setName('teacherRegister');

            $group->post('/search-teacher', TeacherController::class . ':searchByTeacher')->setName('teacherSearch');
            $group->post('/department-show', TeacherController::class . ':showByDepartment')->setName('teacherShowByDepartment');

            $group->post('/show', TeacherController::class . ':show')->setName('showAllTeachers');
            $group->post('/update-form', TeacherController::class . ':updateForm')->setName('teacherUpdateForm');
            $group->post('/update', TeacherController::class . ':update')->setName('teacherUpdate');
            $group->post('/delete', TeacherController::class . ':delete')->setName('teacherDelete');
        });

        $group->group('/campus', function (RouteCollectorProxy $group) {
            $group->post('/save-form', CampusController::class . ':saveForm')->setName('campusSaveForm');
            $group->post('/register', CampusController::class . ':register')->setName('campusRegister');
            $group->post('/show', CampusController::class . ':show')->setName('showAllCampuses');

            $group->post('/update-form', CampusController::class . ':updateForm')->setName('campusUpdateForm');
            $group->post('/update', CampusController::class . ':update')->setName('campusUpdate');
            $group->post('/delete', CampusController::class . ':delete')->setName('campusDelete');
        });

        $group->group('/reports', function (RouteCollectorProxy $group) {
            $group->post('/show-departments', ReportsController::class . ':showDepartments')->setName('departmentsShowList');
            $group->post('/show-teachers', ReportsController::class . ':showTeachers')->setName('teachersShowList');
            $group->post('/show-teachers-reports', ReportsController::class . ':teacherResponses')->setName('teacherShowReports');
        });

        $group->group('/modality', function (RouteCollectorProxy $group) {
            $group->post('/save-form', ModalityController::class . ':saveForm')->setName('modalitySaveForm');
            $group->post('/register', ModalityController::class . ':register')->setName('modalityRegister');

            $group->post('/show', ModalityController::class . ':show')->setName('showAllModalities');
            $group->post('/update-form', ModalityController::class . ':updateForm')->setName('modalityUpdateForm');
            $group->post('/update', ModalityController::class . ':update')->setName('modalityUpdate');
            $group->post('/delete', ModalityController::class . ':delete')->setName('modalityDelete');
        });

        $group->group('/period', function (RouteCollectorProxy $group) {
            $group->post('/save-form', PeriodController::class . ':saveForm')->setName('periodSaveForm');
            $group->post('/register', PeriodController::class . ':register')->setName('periodRegister');

            $group->post('/update-p', PeriodController::class . ':update')->setName('periodEneableShow');
            $group->post('/show', PeriodController::class . ':show')->setName('showAllPeriods');
            $group->post('/update-form', PeriodController::class . ':updateForm')->setName('periodUpdateForm');
            $group->post('/update', PeriodController::class . ':update')->setName('periodUpdate');
            $group->post('/activate', PeriodController::class . ':activate')->setName('periodActivateEvaluation');
            $group->post('/delete', PeriodController::class . ':delete')->setName('periodDelete');
        });

        $group->group('/data', function (RouteCollectorProxy $group) {
            $group->post('/import-form', ImportDbfDataController::class . ':importForm')->setName('importSieDataForm');
            $group->post('/import', ImportDbfDataController::class . ':importAll')->setName('importSieData');
        });

        $group->group('/career', function (RouteCollectorProxy $group) {
            $group->post('/save-form', CareerController::class . ':saveForm')->setName('careerSaveForm');
            $group->post('/register', CareerController::class . ':register')->setName('careerRegister');

            $group->post('/show', CareerController::class . ':show')->setName('showAllCareers');
            $group->post('/update-form', CareerController::class . ':updateForm')->setName('careerUpdateForm');
            $group->post('/update', CareerController::class . ':update')->setName('careerUpdate');
            $group->post('/delete', CareerController::class . ':delete')->setName('careerDelete');
        });

        $group->group('/lesson', function (RouteCollectorProxy $group) {
            $group->post('/save-form', LessonController::class . ':saveForm')->setName('lessonSaveForm');
            $group->post('/register', LessonController::class . ':register')->setName('lessonRegister');

            $group->post('/search-lesson', LessonController::class . ':search')->setName('lessonSearch');
            $group->post('/show', LessonController::class . ':show')->setName('showAllLessons');
            $group->post('/update-form', LessonController::class . ':updateForm')->setName('lessonUpdateForm');
            $group->post('/update', LessonController::class . ':update')->setName('lessonUpdate');
            $group->post('/delete', LessonController::class . ':delete')->setName('lessonDelete');
        });

        $group->group('/department', function (RouteCollectorProxy $group) {
            $group->post('/save-form',  DepartmentController::class . ':saveForm')->setName('departmentSaveForm');
            $group->post('/register', DepartmentController::class . ':register')->setName('departmentRegister');

            $group->post('/show',  DepartmentController::class . ':show')->setName('showAllDepartments');
            $group->post('/update-form',  DepartmentController::class . ':updateForm')->setName('departmentUpdateForm');
            $group->post('/update',  DepartmentController::class . ':update')->setName('departmentUpdate');
            $group->post('/delete', DepartmentController::class . ':delete')->setName('departmentDelete');
        });

        $group->group('/student', function (RouteCollectorProxy $group) {
            $group->post('/save-form',  StudentController::class . ':saveForm')->setName('studentSaveForm');
            $group->post('/register', StudentController::class . ':register')->setName('studentRegister');

            $group->post('/search', StudentController::class . ':search')->setName('studentSearch');
            $group->post('/show',  StudentController::class . ':show')->setName('showAllStudents');
            
            $group->post('/update-form',  StudentController::class . ':updateForm')->setName('studentUpdateForm');
            $group->post('/update', StudentController::class . ':update')->setName('studentUpdate');
            $group->post('/update-password-show', StudentController::class . ':update')->setName('studentUpdatePasswordShow');
            $group->post('/update-password', StudentController::class . ':updatePassword')->setName('studentUpdatePassword');
            $group->post('/delete', StudentController::class . ':delete')->setName('studentDelete');
        });

        $group->group('/inscriptions', function (RouteCollectorProxy $group) {
            $group->post('/save-form', InscriptionController::class . ':saveForm')->setName('inscriptionSaveForm');
            $group->post('/register', InscriptionController::class . ':register')->setName('inscriptionRegister');

            $group->post('/show', InscriptionController::class . ':show')->setName('showAllInscriptions');
            $group->post('/search-student', InscriptionController::class . ':searchByStudent')->setName('inscriptionSearchByStudent');
            $group->post('/search-group', InscriptionController::class . ':searchByGroup')->setName('inscriptionSearchByGroup');

            $group->post('/show-career', InscriptionController::class . ':showByCareer')->setName('inscriptionShowByCareer');
            $group->post('/show-group', InscriptionController::class . ':showByGroup')->setName('inscriptionShowByGroup');


            $group->post('/update-career', InscriptionController::class . ':updateByCareer')->setName('inscriptionUpdateByCareer');
            $group->post('/update-group', InscriptionController::class . ':updateByGroup')->setName('inscriptionUpdateByGroup');
            
            $group->post('/update-form', InscriptionController::class . ':updateForm')->setName('inscriptionUpdateForm');
            $group->post('/update', InscriptionController::class . ':update')->setName('inscriptionUpdate');
            $group->post('/delete', InscriptionController::class . ':delete')->setName('inscriptionDelete');
        });

        
        $group->group('/subject', function (RouteCollectorProxy $group) {
            $group->post('/save-form', SchoolSubjectController::class . ':saveForm')->setName('subjectSaveForm');
            $group->post('/register', SchoolSubjectController::class . ':register')->setName('subjectRegister');

            $group->post('/show-career', SchoolSubjectController::class . ':showByCareer')->setName('lessonShowByCareer');
            $group->post('/search-lesson', SchoolSubjectController::class . ':searchByLesson')->setName('subjectSearchByLesson');

            $group->post('/show', SchoolSubjectController::class . ':show')->setName('showAllSubjects');
            $group->post('/update-form', SchoolSubjectController::class . ':updateForm')->setName('subjectUpdateForm');
            $group->post('/update', SchoolSubjectController::class . ':update')->setName('subjectUpdate');
            $group->post('/delete', SchoolSubjectController::class . ':delete')->setName('subjectDelete');
        });

        $group->group('/course', function (RouteCollectorProxy $group) {
            $group->post('/save-form', CourseController::class . ':saveForm')->setName('courseSaveForm');
            $group->post('/register', CourseController::class . ':register')->setName('courseRegister');

            $group->post('/search-group', CourseController::class . ':searchByGroup')->setName('courseSearchByGroup');
            $group->post('/search-lesson', CourseController::class . ':searchByLesson')->setName('courseSearchByLesson');

            $group->post('/show', CourseController::class . ':show')->setName('showAllCourses');

            $group->post('/update-form', CourseController::class . ':updateForm')->setName('courseUpdateForm');
            $group->post('/update', CourseController::class . ':update')->setName('courseUpdate');
            $group->post('/delete', CourseController::class . ':delete')->setName('courseDelete');
        });

        $group->group('/group', function (RouteCollectorProxy $group) {
            $group->post('/save-form', GroupController::class . ':saveForm')->setName('groupSaveForm');
            $group->post('/register', GroupController::class . ':register')->setName('groupRegister');
            $group->post('/search', GroupController::class . ':search')->setName('groupSearch');
            $group->post('/show', GroupController::class . ':show')->setName('showAllGroups');
            $group->post('/update-form', GroupController::class . ':updateForm')->setName('groupUpdateForm');
            $group->post('/update', GroupController::class . ':update')->setName('groupUpdate');
            $group->post('/delete', GroupController::class . ':delete')->setName('groupDelete');
        });

        $group->group('/user', function (RouteCollectorProxy $group) {
            $group->post('/save-form', UserController::class . ':saveForm')->setName('userSaveForm');
            $group->post('/register', UserController::class . ':register')->setName('userRegister');

            $group->post('/show', UserController::class . ':show')->setName('showAllUsers');
            $group->post('/update', UserController::class . ':update')->setName('userUpdate');
            $group->post('/update-form', UserController::class . ':updateForm')->setName('userUpdateForm');
            $group->post('/delete', UserController::class . ':delete')->setName('userDelete');
        });

        $group->group('/role', function (RouteCollectorProxy $group) {
            $group->post('/save-form', RoleController::class . ':saveForm')->setName('roleSaveForm');
            $group->post('/register', RoleController::class . ':register')->setName('roleRegister');

            $group->post('/show', RoleController::class . ':show')->setName('showAllRoles');
            $group->post('/update-form', RoleController::class . ':updateForm')->setName('roleUpdateForm');
            $group->post('/update', RoleController::class . ':update')->setName('roleUpdate');
            $group->post('/delete', RoleController::class . ':delete')->setName('roleDelete');
        });

        $group->group('/user-roles', function (RouteCollectorProxy $group) {
            $group->post('/save-form', UserRolesController::class . ':saveForm')->setName('userRolesSaveForm');
            $group->post('/register', UserRolesController::class . ':register')->setName('userRolesRegister');

            $group->post('/search-user', UserRolesController::class . ':searchByUser')->setName('userRolesSearchByUser');

            $group->post('/show', UserRolesController::class . ':show')->setName('showAllUserRoles');
            $group->post('/update-form', UserRolesController::class . ':updateForm')->setName('userRolesUpdateForm');
            $group->post('/update', UserRolesController::class . ':update')->setName('userRolesUpdate');
            $group->post('/delete', UserRolesController::class . ':delete')->setName('userRolesDelete');
        });

        $group->group('/role-permissions', function (RouteCollectorProxy $group) {
            $group->post('/save-form', RolePermissionsController::class . ':saveForm')->setName('rolePermissionsSaveForm');
            $group->post('/register', RolePermissionsController::class . ':register')->setName('rolePermissionsRegister');

            $group->post('/search-role', RolePermissionsController::class . ':showByRole')->setName('rolePermissionsSearchByRole');

            $group->post('/show', RolePermissionsController::class . ':show')->setName('showAllRolePermissions');
            $group->post('/update-form', RolePermissionsController::class . ':updateForm')->setName('rolePermissionsUpdateForm');
            $group->post('/update', RolePermissionsController::class . ':update')->setName('rolePermissionsUpdate');
            $group->post('/delete', RolePermissionsController::class . ':delete')->setName('rolePermissionsDelete');
        });
    })->add(UserSessionMiddleware::class);

    $app->get('/', LoginStudentController::class . ':login')->setName('loginStudent')->add(SessionDeleteMiddleware::class);
    $app->post('/', StudentCoursesController::class . ':menu')->setName('studentCoursesMenu')->add(StudentSessionMiddleware::class);
    $app->group('/student', function (RouteCollectorProxy $group) {
         //$group->post('/menu', StudentCoursesController::class . ':menu')->setName('studentCoursesMenu');

        $group->group('/logged', function (RouteCollectorProxy $group) {
            $group->post('/update-password-form', StudentCoursesController::class . ':updateForm')->setName('studentPasswordUpdateForm');
            $group->post('/update', StudentCoursesController::class . ':update')->setName('studenPasswordUpdate');
            $group->post('/code', StudentCoursesController::class . ':createCode')->setName('studentCoursesCode');
            $group->post('/quiz', StudentCoursesController::class . ':showQuiz')->setName('studentCoursesShowQuiz');
            $group->post('/save-quiz', StudentCoursesController::class . ':saveQuiz')->setName('studentCoursesSaveQuiz');
        });
    })->add(StudentSessionMiddleware::class);

    $app->get('/code-verification/{code}', CodeController::class . ':verification')->setName('studentVerification');
};