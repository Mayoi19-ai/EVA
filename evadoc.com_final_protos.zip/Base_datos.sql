-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         10.4.14-MariaDB - mariadb.org binary distribution
-- SO del servidor:              Win64
-- HeidiSQL Versión:             11.1.0.6116
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Volcando estructura de base de datos para proyecto
CREATE DATABASE IF NOT EXISTS `proyecto` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci */;
USE `proyecto`;

-- Volcando estructura para tabla proyecto.activar_evaluacion
CREATE TABLE IF NOT EXISTS `activar_evaluacion` (
  `activar` tinyint(3) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- Volcando datos para la tabla proyecto.activar_evaluacion: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `activar_evaluacion` DISABLE KEYS */;
INSERT INTO `activar_evaluacion` (`activar`) VALUES
	(1);
/*!40000 ALTER TABLE `activar_evaluacion` ENABLE KEYS */;

-- Volcando estructura para tabla proyecto.alumno
CREATE TABLE IF NOT EXISTS `alumno` (
  `control` char(12) COLLATE utf8mb4_spanish_ci NOT NULL,
  `contrasenia` varchar(250) COLLATE utf8mb4_spanish_ci NOT NULL,
  `nombre` varchar(250) COLLATE utf8mb4_spanish_ci NOT NULL,
  PRIMARY KEY (`control`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- Volcando datos para la tabla proyecto.alumno: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `alumno` DISABLE KEYS */;
/*!40000 ALTER TABLE `alumno` ENABLE KEYS */;

-- Volcando estructura para tabla proyecto.asignatura
CREATE TABLE IF NOT EXISTS `asignatura` (
  `clave` char(10) COLLATE utf8mb4_spanish_ci NOT NULL,
  `nombre` varchar(250) COLLATE utf8mb4_spanish_ci NOT NULL,
  PRIMARY KEY (`clave`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- Volcando datos para la tabla proyecto.asignatura: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `asignatura` DISABLE KEYS */;
/*!40000 ALTER TABLE `asignatura` ENABLE KEYS */;

-- Volcando estructura para tabla proyecto.bitacora
CREATE TABLE IF NOT EXISTS `bitacora` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `usuario` varchar(250) COLLATE utf8mb4_spanish_ci NOT NULL,
  `actividad` varchar(250) COLLATE utf8mb4_spanish_ci NOT NULL,
  `tabla_afectada` varchar(250) COLLATE utf8mb4_spanish_ci NOT NULL,
  `fecha_modificacion` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=461 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- Volcando datos para la tabla proyecto.bitacora: ~6 rows (aproximadamente)
/*!40000 ALTER TABLE `bitacora` DISABLE KEYS */;
INSERT INTO `bitacora` (`id`, `usuario`, `actividad`, `tabla_afectada`, `fecha_modificacion`) VALUES
	(455, 'raul', 'Actualizar', 'Usuario', '2021-02-08 16:55:31'),
	(456, 'raul', 'Actualizar', 'Usuario', '2021-02-08 16:56:28'),
	(457, 'administrador', 'Actualizar', 'Usuario', '2021-02-08 16:58:25'),
	(458, 'administrador', 'Registrar', 'Usuario', '2021-02-08 16:58:58'),
	(459, 'administrador', 'Eliminar', 'Usuario', '2021-02-08 16:59:08'),
	(460, 'administrador', 'Registrar', 'Roles permisos', '2021-02-16 02:56:53');
/*!40000 ALTER TABLE `bitacora` ENABLE KEYS */;

-- Volcando estructura para procedimiento proyecto.bitacoras
DELIMITER //
CREATE PROCEDURE `bitacoras`(IN usuario VARCHAR(250), IN actividad VARCHAR(250), IN tabla_afectada VARCHAR(250))
BEGIN 
    INSERT INTO bitacora(usuario, actividad, tabla_afectada) VALUES (usuario, actividad, tabla_afectada);
COMMIT; 
END//
DELIMITER ;

-- Volcando estructura para tabla proyecto.campus
CREATE TABLE IF NOT EXISTS `campus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(250) COLLATE utf8mb4_spanish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- Volcando datos para la tabla proyecto.campus: ~2 rows (aproximadamente)
/*!40000 ALTER TABLE `campus` DISABLE KEYS */;
INSERT INTO `campus` (`id`, `nombre`) VALUES
	(1, 'HUATUSCO'),
	(2, 'COSCOMATEPEC');
/*!40000 ALTER TABLE `campus` ENABLE KEYS */;

-- Volcando estructura para tabla proyecto.carrera
CREATE TABLE IF NOT EXISTS `carrera` (
  `id` int(10) unsigned NOT NULL,
  `clave` char(16) COLLATE utf8mb4_spanish_ci NOT NULL,
  `nombre` varchar(250) COLLATE utf8mb4_spanish_ci NOT NULL,
  `nombre_corto` char(7) COLLATE utf8mb4_spanish_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clave_UNIQUE` (`clave`),
  UNIQUE KEY `nombre_corto_UNIQUE` (`nombre_corto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- Volcando datos para la tabla proyecto.carrera: ~7 rows (aproximadamente)
/*!40000 ALTER TABLE `carrera` DISABLE KEYS */;
INSERT INTO `carrera` (`id`, `clave`, `nombre`, `nombre_corto`) VALUES
	(1, 'IIND-2010-227', 'INGENIERÍA INDUSTRIAL', 'II'),
	(2, 'IIAL-2010-219', 'INGENIERÍA EN INDUSTRIAS ALIMENTARIAS', 'IIA'),
	(3, 'IEME-2010-210', 'INGENIERÍA ELECTROMECÁNICA', 'IE'),
	(4, 'ISIC-2010-224', 'INGENIERÍA EN SISTEMAS COMPUTACIONALES', 'ISC'),
	(5, 'IGEM-2009-201', 'INGENIERÍA EN GESTIÓN EMPRESARIAL', 'IGE'),
	(6, 'COPU-2010-205', 'CONTADOR  PÚBLICO', 'CP'),
	(7, 'IAMB-2010-206', 'INGENIERÍA AMBIENTAL', 'IA');
/*!40000 ALTER TABLE `carrera` ENABLE KEYS */;

-- Volcando estructura para tabla proyecto.categoria
CREATE TABLE IF NOT EXISTS `categoria` (
  `id` int(10) unsigned NOT NULL,
  `nombre` varchar(250) COLLATE utf8mb4_spanish_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre_UNIQUE` (`nombre`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- Volcando datos para la tabla proyecto.categoria: ~19 rows (aproximadamente)
/*!40000 ALTER TABLE `categoria` DISABLE KEYS */;
INSERT INTO `categoria` (`id`, `nombre`) VALUES
	(16, 'ASIGNAR ROLES'),
	(7, 'ASIGNATURA'),
	(2, 'CAMPUS'),
	(6, 'CARRERA'),
	(12, 'CURSO'),
	(8, 'DEPARTAMENTO'),
	(1, 'DOCENTES'),
	(19, 'ESTADO EVALUACION'),
	(9, 'ESTUDIANTE'),
	(13, 'GRUPO'),
	(5, 'IMPORTAR SIE'),
	(10, 'INSCRIPCION'),
	(11, 'MATERIA'),
	(3, 'MODALIDAD'),
	(4, 'PERIODO'),
	(18, 'REPORTES'),
	(15, 'ROL'),
	(17, 'ROLES Y PERMISOS'),
	(14, 'USUARIO');
/*!40000 ALTER TABLE `categoria` ENABLE KEYS */;

-- Volcando estructura para tabla proyecto.curso
CREATE TABLE IF NOT EXISTS `curso` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre_grupo` char(6) COLLATE utf8mb4_spanish_ci NOT NULL,
  `id_periodo` int(10) unsigned NOT NULL,
  `id_carrera` int(10) unsigned NOT NULL,
  `clave_asignatura` char(10) COLLATE utf8mb4_spanish_ci NOT NULL,
  `folio_docente` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre_grupo_UNIQUE` (`nombre_grupo`,`id_periodo`,`id_carrera`,`clave_asignatura`,`folio_docente`),
  KEY `folio_docente` (`folio_docente`) USING BTREE,
  KEY `fk_curso_materia1_idx` (`id_carrera`,`clave_asignatura`),
  KEY `fk_curso_grupo1_idx` (`nombre_grupo`,`id_periodo`,`id_carrera`),
  CONSTRAINT `FK_curso_docente` FOREIGN KEY (`folio_docente`) REFERENCES `docente` (`folio`),
  CONSTRAINT `fk_curso_grupo1` FOREIGN KEY (`nombre_grupo`, `id_periodo`, `id_carrera`) REFERENCES `grupo` (`nombre`, `id_periodo`, `id_carrera`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_curso_materia1` FOREIGN KEY (`id_carrera`, `clave_asignatura`) REFERENCES `materia` (`id_carrera`, `clave_asignatura`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=427 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- Volcando datos para la tabla proyecto.curso: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `curso` DISABLE KEYS */;
/*!40000 ALTER TABLE `curso` ENABLE KEYS */;

-- Volcando estructura para tabla proyecto.departamento
CREATE TABLE IF NOT EXISTS `departamento` (
  `clave` int(3) unsigned NOT NULL,
  `nombre` varchar(250) COLLATE utf8mb4_spanish_ci NOT NULL,
  PRIMARY KEY (`clave`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- Volcando datos para la tabla proyecto.departamento: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `departamento` DISABLE KEYS */;
/*!40000 ALTER TABLE `departamento` ENABLE KEYS */;

-- Volcando estructura para tabla proyecto.diccionario_especialidad
CREATE TABLE IF NOT EXISTS `diccionario_especialidad` (
  `cve` int(10) unsigned NOT NULL,
  `id_carrera` int(10) unsigned NOT NULL,
  `id_modalidad` int(10) unsigned NOT NULL,
  `id_campus` int(10) unsigned NOT NULL,
  PRIMARY KEY (`cve`),
  KEY `FK_despecial_modalidad_idx` (`id_modalidad`),
  KEY `FK_despecial_carrera_idx` (`id_carrera`),
  KEY `FK_despecial_campus_idx` (`id_campus`),
  CONSTRAINT `FK_despecial_campus` FOREIGN KEY (`id_campus`) REFERENCES `campus` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_despecial_carrera` FOREIGN KEY (`id_carrera`) REFERENCES `carrera` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_despecial_modalidad` FOREIGN KEY (`id_modalidad`) REFERENCES `modalidad` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- Volcando datos para la tabla proyecto.diccionario_especialidad: ~14 rows (aproximadamente)
/*!40000 ALTER TABLE `diccionario_especialidad` DISABLE KEYS */;
INSERT INTO `diccionario_especialidad` (`cve`, `id_carrera`, `id_modalidad`, `id_campus`) VALUES
	(1, 1, 1, 1),
	(2, 2, 1, 1),
	(3, 3, 1, 1),
	(4, 4, 1, 1),
	(5, 5, 1, 1),
	(8, 6, 1, 1),
	(9, 5, 3, 1),
	(10, 6, 3, 1),
	(11, 1, 2, 2),
	(13, 6, 1, 2),
	(14, 2, 1, 2),
	(15, 1, 2, 1),
	(16, 4, 3, 1),
	(17, 7, 1, 1);
/*!40000 ALTER TABLE `diccionario_especialidad` ENABLE KEYS */;

-- Volcando estructura para tabla proyecto.docente
CREATE TABLE IF NOT EXISTS `docente` (
  `folio` int(10) unsigned NOT NULL,
  `nombre` varchar(250) COLLATE utf8mb4_spanish_ci NOT NULL DEFAULT '',
  `clave_departamento` int(3) unsigned NOT NULL,
  PRIMARY KEY (`folio`) USING BTREE,
  KEY `FK_docente_departamento` (`clave_departamento`),
  CONSTRAINT `FK_docente_departamento` FOREIGN KEY (`clave_departamento`) REFERENCES `departamento` (`clave`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- Volcando datos para la tabla proyecto.docente: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `docente` DISABLE KEYS */;
/*!40000 ALTER TABLE `docente` ENABLE KEYS */;

-- Volcando estructura para procedimiento proyecto.eliminar_sesiones
DELIMITER //
CREATE PROCEDURE `eliminar_sesiones`()
BEGIN
DELETE FROM sesion WHERE sesion.fecha <= (CURRENT_TIMESTAMP - INTERVAL 1 DAY);
END//
DELIMITER ;

-- Volcando estructura para procedimiento proyecto.evaluar
DELIMITER //
CREATE PROCEDURE `evaluar`(IN id_inscripcion INT, IN clave VARCHAR(250), IN id_curso INT, IN respuestas CHAR(50))
BEGIN 

DECLARE exit handler for SQLEXCEPTION 
	BEGIN  
	ROLLBACK; 
END;
 
DECLARE exit handler for SQLWARNING 
	BEGIN 
	ROLLBACK; 
END; 

START TRANSACTION; 
	INSERT INTO evaluo VALUES(id_inscripcion, clave);
	INSERT INTO respuestas_evaluacion  VALUES(id_curso, respuestas);
COMMIT; 
END//
DELIMITER ;

-- Volcando estructura para tabla proyecto.evaluo
CREATE TABLE IF NOT EXISTS `evaluo` (
  `id` int(10) unsigned NOT NULL,
  `clave` varchar(250) COLLATE utf8mb4_spanish_ci NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_id_inscripcion` FOREIGN KEY (`id`) REFERENCES `inscripcion` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- Volcando datos para la tabla proyecto.evaluo: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `evaluo` DISABLE KEYS */;
/*!40000 ALTER TABLE `evaluo` ENABLE KEYS */;

-- Volcando estructura para tabla proyecto.grupo
CREATE TABLE IF NOT EXISTS `grupo` (
  `nombre` char(6) COLLATE utf8mb4_spanish_ci NOT NULL,
  `id_periodo` int(10) unsigned NOT NULL,
  `id_carrera` int(10) unsigned NOT NULL,
  `id_modalidad` int(10) unsigned NOT NULL,
  `id_campus` int(10) unsigned NOT NULL,
  PRIMARY KEY (`nombre`,`id_periodo`,`id_carrera`) USING BTREE,
  KEY `FK_grupo_periodo` (`id_periodo`),
  KEY `fk_grupo_carrera1_idx` (`id_carrera`),
  KEY `fk_grupo_modalidad_idx` (`id_modalidad`),
  KEY `fk_grupo_campus_idx` (`id_campus`),
  CONSTRAINT `FK_grupo_periodo` FOREIGN KEY (`id_periodo`) REFERENCES `periodo` (`id`),
  CONSTRAINT `fk_grupo_campus` FOREIGN KEY (`id_campus`) REFERENCES `campus` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_grupo_carrera1` FOREIGN KEY (`id_carrera`) REFERENCES `carrera` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_grupo_modalidad` FOREIGN KEY (`id_modalidad`) REFERENCES `modalidad` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- Volcando datos para la tabla proyecto.grupo: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `grupo` DISABLE KEYS */;
/*!40000 ALTER TABLE `grupo` ENABLE KEYS */;

-- Volcando estructura para tabla proyecto.inscripcion
CREATE TABLE IF NOT EXISTS `inscripcion` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_curso` int(10) unsigned NOT NULL,
  `alumno_control` char(12) COLLATE utf8mb4_spanish_ci NOT NULL,
  `activar` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `grupo_curso_alumno_periodo` (`id_curso`,`alumno_control`),
  KEY `FK_inscripcion_curso` (`id_curso`),
  KEY `FK_inscripcion_alumno` (`alumno_control`),
  CONSTRAINT `FK_inscripcion_alumno` FOREIGN KEY (`alumno_control`) REFERENCES `alumno` (`control`),
  CONSTRAINT `FK_inscripcion_curso` FOREIGN KEY (`id_curso`) REFERENCES `curso` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11704 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- Volcando datos para la tabla proyecto.inscripcion: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `inscripcion` DISABLE KEYS */;
/*!40000 ALTER TABLE `inscripcion` ENABLE KEYS */;

-- Volcando estructura para evento proyecto.limpieza
DELIMITER //
CREATE EVENT `limpieza` ON SCHEDULE EVERY 1 MINUTE STARTS '2021-01-22 11:43:19' ON COMPLETION PRESERVE ENABLE DO BEGIN
CALL eliminar_sesiones();
END//
DELIMITER ;

-- Volcando estructura para tabla proyecto.materia
CREATE TABLE IF NOT EXISTS `materia` (
  `id_carrera` int(10) unsigned NOT NULL,
  `clave_asignatura` char(10) COLLATE utf8mb4_spanish_ci NOT NULL,
  PRIMARY KEY (`id_carrera`,`clave_asignatura`),
  KEY `fk_materia_carrera1_idx` (`id_carrera`),
  KEY `FK_carga_asignatura_idx` (`clave_asignatura`),
  CONSTRAINT `FK_carga_asignatura` FOREIGN KEY (`clave_asignatura`) REFERENCES `asignatura` (`clave`),
  CONSTRAINT `fk_materia_carrera1` FOREIGN KEY (`id_carrera`) REFERENCES `carrera` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- Volcando datos para la tabla proyecto.materia: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `materia` DISABLE KEYS */;
/*!40000 ALTER TABLE `materia` ENABLE KEYS */;

-- Volcando estructura para tabla proyecto.modalidad
CREATE TABLE IF NOT EXISTS `modalidad` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(250) COLLATE utf8mb4_spanish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- Volcando datos para la tabla proyecto.modalidad: ~3 rows (aproximadamente)
/*!40000 ALTER TABLE `modalidad` DISABLE KEYS */;
INSERT INTO `modalidad` (`id`, `nombre`) VALUES
	(1, 'ESCOLARIZADO'),
	(2, 'NO ESCOLARIZADO'),
	(3, 'MIXTO');
/*!40000 ALTER TABLE `modalidad` ENABLE KEYS */;

-- Volcando estructura para tabla proyecto.periodo
CREATE TABLE IF NOT EXISTS `periodo` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(250) COLLATE utf8mb4_spanish_ci NOT NULL,
  `inicia` date NOT NULL,
  `termina` date DEFAULT NULL,
  `activar` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- Volcando datos para la tabla proyecto.periodo: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `periodo` DISABLE KEYS */;
/*!40000 ALTER TABLE `periodo` ENABLE KEYS */;

-- Volcando estructura para tabla proyecto.permisos
CREATE TABLE IF NOT EXISTS `permisos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `categoria_id` int(10) unsigned NOT NULL,
  `nombre` varchar(250) COLLATE utf8mb4_spanish_ci NOT NULL,
  `enlace` varchar(250) COLLATE utf8mb4_spanish_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `enlace_UNIQUE` (`enlace`),
  KEY `FK_permisos_categoria_idx` (`categoria_id`),
  CONSTRAINT `FK_permisos_categoria` FOREIGN KEY (`categoria_id`) REFERENCES `categoria` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- Volcando datos para la tabla proyecto.permisos: ~54 rows (aproximadamente)
/*!40000 ALTER TABLE `permisos` DISABLE KEYS */;
INSERT INTO `permisos` (`id`, `categoria_id`, `nombre`, `enlace`) VALUES
	(1, 1, 'AGREGAR DOCENTE', 'showAllTeachers - teacherSaveForm - teacherRegister - teacherSearch - orderByDepartment'),
	(2, 1, 'ACTUALIZAR DOCENTE', 'showAllTeachers - teacherUpdateForm - teacherUpdate - teacherSearch - orderByDepartment'),
	(3, 1, 'ELIMINAR DOCENTE', 'showAllTeachers - teacherDelete - teacherSearch - orderByDepartment'),
	(4, 2, 'AGREGAR CAMPUS', 'showAllCampuses - campusSaveForm - campusRegister '),
	(5, 2, 'ACTUALIZAR CAMPUS', 'showAllCampuses - campusUpdateForm - campusUpdate'),
	(6, 2, 'ELIMINAR CAMPUS', 'showAllCampuses - campusDelete'),
	(7, 3, 'AGREGAR MODALIDAD', 'showAllModalities - modalitySaveForm - modalityRegister'),
	(8, 3, 'ACTUALIZAR MODALIDAD', 'showAllModalities - modalityUpdateForm - modalityUpdate'),
	(9, 3, 'ELIMINAR MODALIDAD', 'showAllModalities - modalityDelete'),
	(10, 4, 'AGREGAR PERIODO', 'showAllPeriods - periodSaveForm - periodRegister'),
	(11, 4, 'ACTUALIZAR PERIODO', 'showAllPeriods - periodUpdateForm - periodUpdate - periodActivateEvaluation'),
	(12, 4, 'ELIMINAR PERIODO', 'showAllPeriods - periodDelete'),
	(14, 5, 'IMPORTAR SIE', 'importSieDataForm - importSieData'),
	(15, 6, 'AGREGAR CARRERA', 'showAllCareers - careerSaveForm - careerRegister'),
	(16, 6, 'ACTUALIZAR CARRERA', 'showAllCareers - careerUpdateForm - careerUpdate'),
	(17, 6, 'ELIMINAR CARRERA', 'showAllCareers - careerDelete'),
	(18, 7, 'AGREGAR ASIGNATURA', 'showAllLessons - lessonSaveForm - lessonRegister - lessonSearch'),
	(19, 7, 'ACTUALIZAR ASIGNATURA', 'showAllLessons - lessonUpdateForm - lessonUpdate'),
	(20, 7, 'ELIMINAR ASIGNATURA', 'showAllLessons - lessonDelete'),
	(21, 8, 'AGREGAR DEPARTAMENTO', 'showAllDepartments - departmentSaveForm - departmentRegister'),
	(22, 8, 'ACTUALIZAR DEPARTAMENTO', 'showAllDepartments - departmentUpdateForm - departmentUpdate'),
	(23, 8, 'ELIMINAR DEPARTAMENTO', 'showAllDepartments - departmentDelete'),
	(24, 9, 'AGREGAR ESTUDIANTE', 'showAllStudents - studentSaveForm - studentRegister - studentSearch'),
	(25, 9, 'ACTUALIZAR ESTUDIANTE', 'showAllStudents - studentUpdateForm - studentUpdate - studentSearch'),
	(26, 9, 'ELIMINAR ESTUDIANTE', 'showAllStudents - studentDelete - studentSearch'),
	(27, 9, 'ACTUALIZAR PASSWORD', 'showAllStudents - studentUpdatePasswordShow - studentUpdatePassword'),
	(28, 10, 'AGREGAR INSCRIPCION', 'showAllInscriptions - inscriptionSaveForm - inscriptionRegister - searchByStudent'),
	(30, 10, 'ACTUALIZAR INSCRIPCION', 'showAllInscriptions - inscriptionUpdateForm - inscriptionUpdate - inscriptionUpdateByCareer'),
	(31, 10, 'ELIMINAR INSCRIPCION', 'showAllInscriptions - inscriptionDelete'),
	(32, 11, 'AGREGAR MATERIA', 'showAllSubjects - subjectSaveForm - subjectRegister - subjectOrderByCareer - subjectSearchByLesson'),
	(33, 11, 'ACTUALIZAR MATERIA', 'showAllSubjects - subjectUpdateForm - subjectUpdate - subjectOrderByCareer - subjectSearchByLesson'),
	(34, 11, 'ELIMINAR MATERIA', 'showAllSubjects - subjectDelete - subjectOrderByCareer - subjectSearchByLesson'),
	(35, 12, 'AGREGAR CURSO', 'showAllCourses - courseSaveForm - courseRegister - courseSearchByGroup - courseSearchByLesson'),
	(36, 12, 'ACTUALIZAR CURSO', 'showAllCourses - courseUpdateForm - courseSearchByGroup -  courseSearchByLesson'),
	(37, 12, 'ELIMINAR CURSO', 'showAllCourses - courseDelete - searchByGroup - searchByLesson'),
	(38, 13, 'AGREGAR GRUPO', 'showAllGroups - groupSaveForm - groupRegister - groupSearch'),
	(39, 13, 'ACTUALIZAR GRUPO', 'showAllGroups - groupUpdateForm - groupUpdate - groupSearch'),
	(40, 13, 'ELIMINAR GRUPO', 'showAllGroups - groupDelete - groupSearch'),
	(41, 14, 'REGISTRAR USUARIO', 'showAllUsers - userSaveForm - userRegister'),
	(42, 14, 'ACTUALIZAR USUARIO', 'showAllUsers - userUpdateForm - userUpdate'),
	(43, 14, 'ELIMINAR USUARIO', 'showAllUsers - userDelete'),
	(44, 15, 'CREAR ROL', 'showAllRoles - roleSaveForm - roleRegister'),
	(45, 15, 'ACTUALIZAR ROL', 'showAllRoles - roleUpdateForm - roleUpdate'),
	(46, 15, 'DELETE ROL', 'showAllRoles - roleDelete'),
	(47, 16, 'ASGINAR ROL', 'showAllUserRoles - userRolesSaveForm - userRolesRegister - userRolesSearchByUser'),
	(48, 16, 'ACTUALIZAR ASIGNACION DE ROLES', 'showAllUserRoles - userRolesUpdateForm - userRolesUpdate - userRolesSearchByUser'),
	(49, 16, 'RETIRAR ROLES A USUARIO', 'showAllUserRoles - userRolesDelete - userRolesSearchByUser'),
	(50, 17, 'ASIGNAR PERMISOS A ROL', 'showAllRolePermissions - rolePermissionsSaveForm - rolePermissionsRegister'),
	(51, 17, 'ACTULIZAR PERMISOS DE ROLES', 'showAllRolePermissions - rolePermissionsUpdateForm - rolePermissionsUpdate'),
	(52, 17, 'ELIMINAR ROL', 'showAllRolePermissions - rolePermissionsDelete'),
	(53, 10, 'ACTIVAR POR GRUPO', 'inscriptionShowByGroup - inscriptionUpdateByGroup'),
	(54, 10, 'ACTIVAR POR CARRERA', 'inscriptionShowByCareer - inscriptionUpdateByCareer'),
	(55, 18, 'GENERAR REPORTES', 'departmentsShowList - teachersShowList - teacherShowReports'),
	(56, 19, 'ESTADO EVALUACION', 'studentStatusEvaluation');
/*!40000 ALTER TABLE `permisos` ENABLE KEYS */;

-- Volcando estructura para tabla proyecto.respuestas_evaluacion
CREATE TABLE IF NOT EXISTS `respuestas_evaluacion` (
  `id_curso` int(10) unsigned NOT NULL,
  `respuestas` char(50) COLLATE utf8mb4_spanish_ci NOT NULL,
  KEY `FK_evalum_curso` (`id_curso`),
  CONSTRAINT `FK_evalum_curso` FOREIGN KEY (`id_curso`) REFERENCES `curso` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- Volcando datos para la tabla proyecto.respuestas_evaluacion: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `respuestas_evaluacion` DISABLE KEYS */;
/*!40000 ALTER TABLE `respuestas_evaluacion` ENABLE KEYS */;

-- Volcando estructura para tabla proyecto.roles
CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(250) COLLATE utf8mb4_spanish_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre_UNIQUE` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- Volcando datos para la tabla proyecto.roles: ~19 rows (aproximadamente)
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` (`id`, `nombre`) VALUES
	(18, 'ADMINISTRADOR'),
	(16, 'GESTIONAR ASIGNACION DE ROLES'),
	(7, 'GESTIONAR ASIGNATURA'),
	(2, 'GESTIONAR CAMPUS'),
	(6, 'GESTIONAR CARRERA'),
	(12, 'GESTIONAR CURSOS'),
	(8, 'GESTIONAR DEPARTAMENTO'),
	(1, 'GESTIONAR DOCENTE'),
	(9, 'GESTIONAR ESTUDIANTE'),
	(13, 'GESTIONAR GRUPO'),
	(5, 'GESTIONAR IMPORTACION DE SIE'),
	(10, 'GESTIONAR INSCRIPCION'),
	(11, 'GESTIONAR MATERIA'),
	(3, 'GESTIONAR MODALIDAD'),
	(4, 'GESTIONAR PERIODOS'),
	(15, 'GESTIONAR ROLES'),
	(17, 'GESTIONAR ROLES Y PERMISOS'),
	(14, 'GESTIONAR USUARIO'),
	(23, 'ROL DE PRUEBA');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;

-- Volcando estructura para tabla proyecto.roles_permisos
CREATE TABLE IF NOT EXISTS `roles_permisos` (
  `id_roles` int(10) unsigned NOT NULL,
  `id_permisos` int(10) unsigned NOT NULL,
  `activar` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id_roles`,`id_permisos`),
  KEY `fk_roles_permisos_roles_idx` (`id_roles`),
  KEY `fk_roles_permisos_permisos_idx` (`id_permisos`),
  CONSTRAINT `fk_roles_permisos_permisos` FOREIGN KEY (`id_permisos`) REFERENCES `permisos` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_roles_permisos_roles` FOREIGN KEY (`id_roles`) REFERENCES `roles` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- Volcando datos para la tabla proyecto.roles_permisos: ~56 rows (aproximadamente)
/*!40000 ALTER TABLE `roles_permisos` DISABLE KEYS */;
INSERT INTO `roles_permisos` (`id_roles`, `id_permisos`, `activar`) VALUES
	(7, 18, 1),
	(13, 38, 1),
	(18, 1, 1),
	(18, 2, 1),
	(18, 3, 1),
	(18, 4, 1),
	(18, 5, 1),
	(18, 6, 1),
	(18, 7, 1),
	(18, 8, 1),
	(18, 9, 1),
	(18, 10, 1),
	(18, 11, 1),
	(18, 12, 1),
	(18, 14, 1),
	(18, 15, 1),
	(18, 16, 1),
	(18, 17, 1),
	(18, 18, 1),
	(18, 19, 1),
	(18, 20, 1),
	(18, 21, 1),
	(18, 22, 1),
	(18, 23, 1),
	(18, 24, 1),
	(18, 25, 1),
	(18, 26, 1),
	(18, 27, 1),
	(18, 28, 1),
	(18, 30, 1),
	(18, 31, 1),
	(18, 32, 1),
	(18, 33, 1),
	(18, 34, 1),
	(18, 35, 1),
	(18, 36, 1),
	(18, 37, 1),
	(18, 38, 1),
	(18, 39, 1),
	(18, 40, 1),
	(18, 41, 1),
	(18, 42, 1),
	(18, 43, 1),
	(18, 44, 1),
	(18, 45, 1),
	(18, 46, 1),
	(18, 47, 1),
	(18, 48, 1),
	(18, 49, 1),
	(18, 50, 1),
	(18, 51, 1),
	(18, 52, 1),
	(18, 53, 1),
	(18, 54, 1),
	(18, 55, 1),
	(18, 56, 1);
/*!40000 ALTER TABLE `roles_permisos` ENABLE KEYS */;

-- Volcando estructura para tabla proyecto.roles_usuario
CREATE TABLE IF NOT EXISTS `roles_usuario` (
  `id_usuario` int(10) unsigned NOT NULL,
  `id_roles` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id_usuario`,`id_roles`),
  KEY `fk_roles_usuario_roles1_idx` (`id_roles`),
  CONSTRAINT `fk_roles_usuario_roles1` FOREIGN KEY (`id_roles`) REFERENCES `roles` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_roles_usuario_usuario1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- Volcando datos para la tabla proyecto.roles_usuario: ~2 rows (aproximadamente)
/*!40000 ALTER TABLE `roles_usuario` DISABLE KEYS */;
INSERT INTO `roles_usuario` (`id_usuario`, `id_roles`) VALUES
	(5, 18),
	(38, 7);
/*!40000 ALTER TABLE `roles_usuario` ENABLE KEYS */;

-- Volcando estructura para tabla proyecto.sesion
CREATE TABLE IF NOT EXISTS `sesion` (
  `id_sesion` varchar(250) COLLATE utf8mb4_spanish_ci NOT NULL,
  `id_usuario` int(10) unsigned NOT NULL,
  `ip` varchar(250) COLLATE utf8mb4_spanish_ci NOT NULL,
  `navegador` varchar(250) COLLATE utf8mb4_spanish_ci NOT NULL,
  `fecha` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_sesion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- Volcando datos para la tabla proyecto.sesion: ~6 rows (aproximadamente)
/*!40000 ALTER TABLE `sesion` DISABLE KEYS */;
INSERT INTO `sesion` (`id_sesion`, `id_usuario`, `ip`, `navegador`, `fecha`) VALUES
	('0da14d1b186021b7cfba50e1.40976520', 5, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:85.0) Gecko/20100101 Firefox/85.0', '2021-02-08 16:14:39'),
	('244322386e602b88bad5e052.13037930', 5, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.152 Safari/537.36', '2021-02-16 02:56:26'),
	('5d854b46bd6021c1f6e832a1.13019239', 5, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:85.0) Gecko/20100101 Firefox/85.0', '2021-02-08 16:57:58'),
	('7b1bf7fb016021b7e0af2da1.14416394', 5, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:85.0) Gecko/20100101 Firefox/85.0', '2021-02-08 16:14:56'),
	('b589ca7ff76021bf20ee8fa2.09505330', 5, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:85.0) Gecko/20100101 Firefox/85.0', '2021-02-08 16:45:52'),
	('d26e908fe26021b9fe600ec7.36454389', 5, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:85.0) Gecko/20100101 Firefox/85.0', '2021-02-08 16:23:58');
/*!40000 ALTER TABLE `sesion` ENABLE KEYS */;

-- Volcando estructura para tabla proyecto.usuario
CREATE TABLE IF NOT EXISTS `usuario` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(250) COLLATE utf8mb4_spanish_ci NOT NULL,
  `contrasenia` varchar(250) COLLATE utf8mb4_spanish_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `nombre_UNIQUE` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- Volcando datos para la tabla proyecto.usuario: ~3 rows (aproximadamente)
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` (`id`, `nombre`, `contrasenia`) VALUES
	(5, 'Administrador', '$2y$10$KFR/OEvUOHbdaU2kFpyEPOAumw6Hg1erEiCioYmOFMvRz7jALOZnS'),
	(37, ' leo12', '$2y$10$P/spq1s2oVAUa4SmQYD/9up.nUYxdDMdMaK86QPwvppimlWcYlnb.'),
	(38, 'tutu', '$2y$10$PdH3paRP3076XKzybgmrJeNdQrc6CDm6cVrPvzHDp/3Nls24deJKG');
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
