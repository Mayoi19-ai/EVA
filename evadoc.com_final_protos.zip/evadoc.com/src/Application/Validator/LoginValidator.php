<?php
namespace App\Validator;
use Rakit\Validation\Validator;

class LoginValidator{
    private Validator $validator;

    public function __construct(Validator $validator) {
        $this->validator = $validator;
    }

    public function userValidator(array $data): array {
        $validationRules = [
            'usuario_activo'   =>  'required|alpha_dash|between:3,240',
            'contrasenia'      =>  'required|between:8,12',
        ];

        $errorMessages = [
            'usuario_activo:required'    => 'El usuario es obligatorio',
            'usuario_activo:between'     => 'El usuario debe tener al menos 3 caracteres y no más de 240',
            'usuario_activo:alpha_dash'  => 'El usuario solo acepta letras, números y guiones',
            'contrasenia:required'       => 'La clave de acceso es obligatoria',
            'contrasenia:between'        => 'La clave de acceso debe tener de 8 a 12 caracteres',
        ];

        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data);
    }

    public function studentValidator(array $data): array {
        $validationRules = [
            'control'          =>  'required|alpha_dash|between:8,12',
            'contrasenia'      =>  'required|between:8,12',
        ];

        $errorMessages = [
            'control:required'      => 'El número de control es obligatorio',
            'control:alpha_dash'    => 'El número de control no es válido',
            'control:between'       => 'El número de control debe tener entre 8 y 12 caracteres',
            'contrasenia:required'  => 'La clave de acceso es obligatoria',
            'contrasenia:between'   => 'La clave de acceso debe tener de 8 a 12 caracteres',
        ];

        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data);
    }
}
