<?php
namespace App\Validator;
use Rakit\Validation\Validator;

class PeriodValidator{
    private Validator $validator;

    public function __construct(Validator $validator) {
        $this->validator = $validator;
    }

    public function validateSavePeriod(array $data): array {
        $validationRules = [
            'nombre'           =>  'required',
            'inicia'           =>  'required|date:Y-m-d',
            'termina'          =>  'date:Y-m-d',
        ];

        $errorMessages = [
            'nombre:required'    => 'El nombre es obligatorio',
            'inicia:required'    => 'La fecha de inicio es obligatoria',
            'inicia:date'        => 'El formato de fecha inicio no es válido',
            'termina:date'       => 'El formato de fecha fin no es válido',
        ];

        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data);
    }

    public function validateSaveUpdatePeriod(array $data): array {
        $validationRules = [
            'nombre'           =>  'required',
            'inicia'           =>  'required|date:Y-m-d',
            'termina'          =>  'date:Y-m-d',
            'activar'          =>  'required|between:1,1|numeric'
        ];

        $errorMessages = [
            'nombre:required'    => 'El nombre es obligatorio',
            'inicia:required'    => 'La fecha de inicio es obligatoria',
            'inicia:date'        => 'El formato de fecha inicio no es válido',
            'termina:date'       => 'El formato de fecha fin no es válido',
            'activar:required'   => 'El periodo debe de estar activado o desactivado',
            'activar:between'    => 'El formato no es aceptado para activar periodo',
            'activar:numeric'    => 'El formato no es aceptado para activar periodo',
        ];

        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data);
    }
}