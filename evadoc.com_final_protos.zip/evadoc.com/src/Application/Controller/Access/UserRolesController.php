<?php
namespace App\Controller\Access;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use Ujpef\LatteView;
use App\Validator\UserRolesValidator as Validator;
use App\Validator\UserValidator as UserVal;
use App\Infrastructure\Rbac\UserRoles as Infrastructure;
use App\Infrastructure\Rbac\User as UserInfra;
use App\Infrastructure\Rbac\Role as RoleInfra;
use App\Infrastructure\Login\Login as LoginInfra;

class UserRolesController{
    private Container $container;
    private Validator $validator;
    private UserVal $userVal;
    private Infrastructure $infrastructure;
    private UserInfra $userInfra;
    private RoleInfra $roleInfra;
    private LoginInfra $LoginInfra;

    public function __construct(Container $container, Validator $validator,Infrastructure $infrastructure, UserVal $userVal, UserInfra $userInfra, RoleInfra $roleInfra, LoginInfra $LoginInfra)
    {
        $this->container = $container;
        $this->validator = $validator;
        $this->infrastructure = $infrastructure;
        $this->userVal = $userVal;
        $this->userInfra = $userInfra;
        $this->roleInfra = $roleInfra;
        $this->loginInfra = $LoginInfra;
    }

    public function saveForm(Request $request, Response $response){
        $userData = $this->userInfra->readAll();
        $roleData = $this->roleInfra->readAll();

        $data = (array)$request->getParsedBody();
        $sthResult = $this->infrastructure->readAll();

        return $this->container->get(LatteView::class)->render(
            $response, 'AsignarR/assignRForm.latte', [
                'users' => $userData,
                'roles' => $roleData,
                'query' => $sthResult,
                'data' => $data
            ]);
    }

    public function register(Request $request, Response $response){
        $userData = $this->userInfra->readAll();
        $roleData = $this->roleInfra->readAll();

        $data = (array)$request->getParsedBody();
        $validationResult = $this->validator->validateSaveUserRole($data);

        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->create((array) $data);
        } else {
            $sthResult = false;
        }

        return $this->container->get(LatteView::class)->render(
            $response,
            'AsignarR/assignRForm.latte',[
                'users' => $userData,
                'roles' => $roleData,
                'validation' => $validationResult,
                'query' => $sthResult,
                'data' => $data
            ]);
    }

    public function show(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $sthResult = $this->infrastructure->readAll();
        $permissions = $this->loginInfra->userPermissions((array) $data);

        return $this->container->get(LatteView::class)->render(
            $response,
            'AsignarR/assignRTable.latte', [
                'query' => $sthResult,
                'data' => $data,
                'permissions' => $permissions
        ]);
    }

    public function updateForm(Request $request, Response $response){
        $userData = $this->userInfra->readAll();
        $roleData = $this->roleInfra->readAll();
        $data = (array)$request->getParsedBody();

        return $this->container->get(LatteView::class)->render(
            $response,
            'AsignarR/assignRUpdate.latte', [
                'data' => $data,
                'users' => $userData,
                'roles' => $roleData
            ]);
    }

    public function update(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
	$userData = $this->userInfra->readAll();
        $roleData = $this->roleInfra->readAll();
        
	$validationResult = $this->validator->validateSaveUserRole((array) $data);
        
        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->update((array) $data);
        } else {
            $sthResult = false;
        }

        return $this->container->get(LatteView::class)->render(
            $response,
            'AsignarR/assignRUpdate.latte', [
                'validation' => $validationResult,
                'query' => $sthResult,
                'data' => $data,
		'users' => $userData,
                'roles' => $roleData,
            ]);
    }

    public function delete(Request $request, Response $response){
        $data = (array)$request->getParsedBody();

        $this->infrastructure->delete((array) $data);
        $sthResult = $this->infrastructure->readAll();
        $permissions = $this->loginInfra->userPermissions((array) $data);

        return $this->container->get(LatteView::class)->render(
            $response,
            'AsignarR/assignRTable.latte', [
                'query' => $sthResult,
                'data' => $data,
                'permissions' => $permissions
            ]);
    }
}
