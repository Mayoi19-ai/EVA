<?php
namespace App\Controller\Reports;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use Ujpef\LatteView;
use App\Infrastructure\Reports\TeacherReports as Infrastructure;
use App\Infrastructure\Login\Login as LoginInfra;
use App\Domain\Reports\Average;
use App\Domain\Reports\CoursesTable;
use App\Infrastructure\CrudSystem\PeriodInfrastructure as PeriodInfra;

class ReportsController{
    private Container $container;
    private Validator $validator;
    private Infrastructure $infrastructure;
    private LoginInfra $LoginInfra;
    private Average $average;
    private PeriodInfra $periodInfra;
    private CoursesTable $coursesTable;
    
    public function __construct(Container $container, Infrastructure $infrastructure, LoginInfra $LoginInfra, Average $average, PeriodInfra $periodInfra, CoursesTable $coursesTable)
    {
        $this->container = $container;
        $this->infrastructure = $infrastructure;
        $this->loginInfra = $LoginInfra;
        $this->average = $average;
        $this->periodInfra = $periodInfra;
        $this->coursesTable = $coursesTable;
    }

    public function showDepartments(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $departmentData = $this->infrastructure->showByDepartments();
        $permissions = $this->loginInfra->userPermissions((array) $data);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Reporte/reportTable.latte', [
                'all_departments_information' => $departmentData,
                'data' => $data,
                'permissions' => $permissions
            ]);
    }

    public function showTeachers(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $teacherData = $this->infrastructure->showByTeachers((int) $data['clave_departamento']);
        $averageDepartment = $this->average->receiver($this->infrastructure->departmentResponses((int) $data['clave_departamento']));
        $permissions = $this->loginInfra->userPermissions((array) $data);
        $departmentData = $this->infrastructure->showByDepartments();
        
        return $this->container->get(LatteView::class)->render(
            $response,
            'Reporte/reportTable.latte', [
                'all_departments_information' => $departmentData,
                'all_teachers_information' => $teacherData,
                'data' => $data,
                'permissions' => $permissions,
                'average_department' => $averageDepartment,
                
            ]);
    }

    public function teacherResponses(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $permissions = $this->loginInfra->userPermissions((array) $data);
        $periodData = $this->periodInfra->report();
        $averageTeacher = $this->average->receiver($this->infrastructure->teacherResponses((int) $data['folio']));
        $courses = $this->infrastructure->courses((int) $data['folio']);
        $courseStudents = $this->coursesTable->receiver($courses);
        $departmentData = $this->infrastructure->showByDepartments();

        return $this->container->get(LatteView::class)->render(
            $response,
            'Reporte/printReport.latte', [
                'all_departments_information' => $departmentData,
                'data' => $data,
                'permissions' => $permissions,
                'period_information' => $periodData,
                'average_teacher' => $averageTeacher,
                'students' => $courseStudents,
                'courses' => $courses
            ]);
    }
}