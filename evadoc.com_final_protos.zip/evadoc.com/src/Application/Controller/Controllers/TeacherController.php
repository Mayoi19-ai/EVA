<?php
namespace App\Controller\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use App\Validator\TeacherValidator as Validator;
use Ujpef\LatteView;
use App\Infrastructure\CrudSystem\TeacherInfrastructure as Infrastructure;
use App\Infrastructure\CrudSystem\DepartmentInfrastructure as DepartmentInfra;
use App\Infrastructure\Login\Login as LoginInfra;

class TeacherController {
    private Container $container;
    private Validator $validator;
    private Infrastructure $infrastructure;
    private DepartmentInfra $departmentInfra;
    private LoginInfra $LoginInfra;
    
    public function __construct(Container $container, Validator $validator, Infrastructure $infrastructure, DepartmentInfra $departmentInfra, LoginInfra $LoginInfra)
    {
        $this->container = $container;
        $this->validator = $validator;
        $this->infrastructure = $infrastructure;
        $this->departmentInfra = $departmentInfra;
        $this->loginInfra = $LoginInfra;
    }

    public function saveForm(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $permissions = $this->loginInfra->userPermissions((array) $data);
        $departmentData = $this->departmentInfra->readAll();
        $sthResult = $this->infrastructure->readAll();

        return $this->container->get(LatteView::class)->render($response,
         'Docente/teacherForm.latte', [
            'all_departments_information' => $departmentData,
            'permissions' => $permissions,
            'query' => $sthResult,
            'data' => $data
         ]);
    }

    public function register(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $permissions = $this->loginInfra->userPermissions((array) $data);
        $departmentData = $this->departmentInfra->readAll();
        $validationResult = $this->validator->validateSaveTeacher((array) $data);
        
        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->create((array) $data);
        } else {
            $sthResult = false;
        }

        return $this->container->get(LatteView::class)->render(
            $response,
            'Docente/teacherForm.latte', [
                'all_departments_information' => $departmentData,
                'validation' => $validationResult, 
                'permissions' => $permissions,
                'query' => $sthResult,
                'data' => $data
            ]);
    }

    public function searchByTeacher(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $validationResult = $this->validator->validateFindTeacher((array) $data);
        $permissions = $this->loginInfra->userPermissions((array) $data);
        
        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->read((string) $data['nombre']);
        } else {
            $sthResult = false;
        }

        return $this->container->get(LatteView::class)->render(
            $response,
            'Docente/teacherTable.latte', [
                'validation' => $validationResult, 
                'query' => $sthResult,
                'data' => $data,
                'permissions' => $permissions,
            ]);
    }

    public function show(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $sthResult = $this->infrastructure->readAll();
        $permissions = $this->loginInfra->userPermissions((array) $data);
        $departmentData = $this->departmentInfra->readAll();

        return $this->container->get(LatteView::class)->render(
            $response,
            'Docente/teacherTable.latte', [
                'query' => $sthResult,
                'data' => $data,
                'permissions' => $permissions,
                'all_departments_information' => $departmentData,
            ]);
    }

    public function showByDepartment(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $permissions = $this->loginInfra->userPermissions((array) $data);
        $sthResult = $this->infrastructure->orderByDepartment((int) $data['clave_departamento']);
        $departmentData = $this->departmentInfra->readAll();

        return $this->container->get(LatteView::class)->render(
            $response,
            'Docente/teacherTable.latte', [
                'query' => $sthResult,
                'data' => $data,
                'permissions' => $permissions,
                'all_departments_information' => $departmentData,
            ]);

    }

    public function updateForm(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $permissions = $this->loginInfra->userPermissions((array) $data);
        $departmentData = $this->departmentInfra->readAll();
        $sthResult = $this->infrastructure->readAll();

        return $this->container->get(LatteView::class)->render($response,
         'Docente/teacherUpdate.latte', [
            'query' => $sthResult,
            'data' => $data,
            'permissions' => $permissions,
            'all_departments_information' => $departmentData,
         ]);
    }

    public function update(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $validationResult = $this->validator->validateSaveTeacher((array) $data);
        $permissions = $this->loginInfra->userPermissions((array) $data);
        $departmentData = $this->departmentInfra->readAll();

        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->update((array) $data);
        } else {
            $sthResult = false;
        }

        return $this->container->get(LatteView::class)->render(
            $response,
            'Docente/teacherUpdate.latte', [
                'validation' => $validationResult, 
                'query' => $sthResult,
                'data' => $data,
                'permissions' => $permissions,
                'all_departments_information' => $departmentData,
            ]);
    }

    public function delete(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $this->infrastructure->delete((array) $data);
        $permissions = $this->loginInfra->userPermissions((array) $data);
        $departmentData = $this->departmentInfra->readAll();
        $sthResult = $this->infrastructure->readAll();

        return $this->container->get(LatteView::class)->render(
            $response,
            'Docente/teacherTable.latte', [
                'query' => $sthResult,
                'data' => $data,
                'permissions' => $permissions,
                'all_departments_information' => $departmentData,
            ]);
    }
}