<?php
namespace App\Infrastructure\Rbac;

use Medoo\Medoo;
use App\Infrastructure\Exceptions\CustomException as Exception;
use App\Infrastructure\Binnacle\Binnacle;

class RolePermissions {
    private Medoo $db;
    private Exception $exception;
    private Binnacle $binnacle;

    public function __construct(Medoo $db, Exception $exception, Binnacle $binnacle)
    {
        $this->db = $db;
        $this->exception = $exception;
        $this->binnacle = $binnacle;
    }

    public function create(array $data): bool
    {
        $this->db->pdo->beginTransaction();
        $this->db->insert('roles_permisos',[
            'id_roles' => $data['id_roles'],
            'id_permisos' => $data['id_permisos'],
            'activar' => 1
        ]);

        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Registrar',
        'tabla_afectada' => 'Roles permisos'));

        return $this->exception->save((array) $this->db->error());
    }

    public function readAll(): ?array
    {
        $sql = <<<'EOP'
        SELECT
        roles.id AS 'id_roles',
        roles.nombre AS 'rol',
        permisos.id AS 'id_permisos',
        categoria.nombre as 'categoria',
        permisos.nombre AS 'permiso',
        roles_permisos.activar AS 'activar'
        FROM
        roles,
        permisos,
        roles_permisos,
        categoria 
        WHERE
        roles.id = roles_permisos.id_roles
        AND 
        permisos.id = roles_permisos.id_permisos
        AND 
        categoria.id = permisos.categoria_id 
        ORDER BY roles_permisos.id_roles ASC;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->execute();
        $records = $sth->fetchAll();

        return $this->exception->read((array) $this->db->error(), (array) $records);
    }

    public function groupByRole(string $roleName): ?array
    {
        $sql = <<<'EOP'
        SELECT
        roles.id AS 'id_roles',
        roles.nombre AS 'rol',
        permisos.id AS 'id_permisos',
        categoria.nombre as 'categoria',
        permisos.nombre AS 'permiso',
        roles_permisos.activar AS 'activar'
        FROM
        roles,
        permisos,
        roles_permisos,
        categoria 
        WHERE
        roles.id = roles_permisos.id_roles
        AND permisos.id = roles_permisos.id_permisos
        AND roles.nombre = :nombre_roles 
        AND permisos.categoria_id = categoria.id 
        ORDER BY roles.nombre ASC;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':nombre_roles', $roleName);
        $sth->execute();
        $records = $sth->fetchAll();
        
        return $this->exception->read((array) $this->db->error(), (array) $records);
    }

    /*public function readAll(): ?array
    {
        $sql = <<<'EOP'
        SELECT
        roles.id AS 'id_roles',
        roles.nombre AS 'rol',
        permisos.id AS 'id_permisos',
        permisos.categoria AS 'categoria',
        permisos.nombre AS 'permiso',
        roles_permisos.activar AS 'activar'
        FROM
        roles,
        permisos,
        roles_permisos
        WHERE
        roles.id = roles_permisos.id_roles
        AND 
        permisos.id = roles_permisos.id_permisos
        ORDER BY roles_permisos.id_roles ASC;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->execute();
        $records = $sth->fetchAll();

        return $this->exception->read((array) $this->db->error(), (array) $records);
    }

    public function groupByRole(string $roleName): ?array
    {
        $sql = <<<'EOP'
        SELECT
        roles.id AS 'id_roles',
        roles.nombre AS 'rol',
        permisos.id AS 'id_permisos',
        permisos.categoria AS 'categoria',
        permisos.nombre AS 'permiso',
        roles_permisos.activar AS 'activar'
        FROM
        roles,
        permisos,
        roles_permisos
        WHERE
        roles.id = roles_permisos.id_roles
        AND permisos.id = roles_permisos.id_permisos
        AND roles.nombre = :nombre_roles
        ORDER BY roles.nombre ASC;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':nombre_roles', $roleName);
        $sth->execute();
        $records = $sth->fetchAll();
        
        return $this->exception->read((array) $this->db->error(), (array) $records);
    }*/

    public function update(array $data): bool
    {
        $this->db->pdo->beginTransaction();
        $this->db->update('roles_permisos',[
            'id_roles' => $data['id_roles'],
            'id_permisos' => $data['id_permisos'], 
            'activar' => $data['activar']], [
                'AND' => [
                    'id_roles' => $data['id_roles_antiguo'],
                    'id_permisos' => $data['id_permisos_antiguo']
                ]
            ]);

        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Actualizar',
        'tabla_afectada' => 'Roles permisos'));

        return $this->exception->save((array) $this->db->error());
    }

    public function delete(array $data): bool
    {
        $this->db->pdo->beginTransaction();
        $this->db->delete('roles_permisos', [
            'AND' => [
                'id_roles' => $data['id_roles'],
                'id_permisos' => $data['id_permisos']
            ]
        ]);

        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Eliminar',
        'tabla_afectada' => 'Roles permisos'));
        
        return $this->exception->delete((array) $this->db->error());
    }
}