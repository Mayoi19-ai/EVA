<?php
namespace App\Infrastructure\Rbac;

use Medoo\Medoo;
use App\Infrastructure\Exceptions\CustomException as Exception;

class Permission {
    private Medoo $db;
    private Exception $exception;
    
    public function __construct(Medoo $db, Exception $exception) {
        $this->db = $db;
        $this->exception = $exception;
    }

    public function readAll(): ?array
    {
        $sql = <<<'EOP'
        SELECT permisos.id as 'id',
        categoria.nombre as 'categoria',
        permisos.nombre as 'nombre',
        permisos.enlace as 'enlace'
        FROM permisos 
        INNER JOIN categoria 
        ON permisos.categoria_id = categoria.id 
        ORDER BY categoria.nombre ASC;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->execute();
        $records = $sth->fetchAll();

        return $this->exception->read((array) $this->db->error(), (array) $records);
    }

    public function readByCategory(string $category): array
    {
        $sql = <<<'EOP'
        SELECT permisos.id as 'id',
        categoria.nombre as 'categoria',
        permisos.nombre as 'nombre',
        permisos.enlace as 'enlace'
        FROM permisos 
        INNER JOIN categoria 
        ON permisos.categoria_id = categoria.id 
        WHERE categoria.nombre = :categoria 
        ORDER BY categoria.nombre ASC;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':categoria', $category);
        $sth->execute();
        $records = $sth->fetchAll();

        return $this->exception->read((array) $this->db->error(), (array) $sql);
    }

    /*public function readAll(): array
    {
        $sql = $this->db->select('permisos',[
            'id',
            'categoria',
            'nombre',
            'enlace'],[
                'ORDER' => ['categoria' => 'ASC']
            ]);

        return $this->exception->read((array) $this->db->error(), (array) $sql);
    }

    public function readByCategory(string $category): array
    {
        $sql = $this->db->select('permisos',[
            'id',
            'categoria',
            'nombre',
            'enlace'],[
                'categoria' => $category
            ]);

        return $this->exception->read((array) $this->db->error(), (array) $sql);
    }*/
}