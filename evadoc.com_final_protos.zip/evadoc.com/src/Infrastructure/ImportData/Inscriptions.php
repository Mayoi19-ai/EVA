<?php

namespace App\Infrastructure\ImportData;

use App\Infrastructure\CrudSystem\InscriptionInfrastructure;
use Medoo\Medoo;


class Inscriptions {
    private Medoo $db;
    private InscriptionInfrastructure $inscriptionInfrastructure;

    public function __construct(Medoo $db, InscriptionInfrastructure $inscriptionInfrastructure){
        $this->db = $db;
        $this->inscriptionInfrastructure = $inscriptionInfrastructure;
    }

    public function inscriptions (): ?array
    {
        $inscriptions = $this->importInscriptions();
        return $this->inscriptionInfrastructure->readAll();
        /*if (empty($this->inscriptionInfrastructure->readAll())) {
            $result = ['message' => 'Error al importar registros en Inscripción',
                'success' => false];
        }
        
        return null;*/
    }

    private function importInscriptions()
    {
        $sql = <<<'EOP'
        DROP TABLE IF EXISTS `temp_inscripcion`;
        CREATE TEMPORARY TABLE `temp_inscripcion` (
        `ctr_alumno` char(12) CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci NOT NULL,
        `grupo` char(6) NOT NULL,
        `id_periodo` int(10) NOT NULL,
        `id_carrera` int(10) NOT NULL,
        `clave_asginatura` char(10) NOT NULL,
        `folio_docente` int(10) NOT NULL,
        UNIQUE KEY `inscription_UNIQUE` (`ctr_alumno`,`grupo`,`id_periodo`,`id_carrera`,`clave_asginatura`,`folio_docente`) USING BTREE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
        
        INSERT IGNORE INTO temp_inscripcion 
        SELECT temp_dlis.ctr, temp_grupo.nombre, periodo.id, diccionario_especialidad.id_carrera, temp_dret2.clave_asignatura, temp_dgau.cat
        FROM periodo,
        temp_grupo
        INNER JOIN 
        temp_dlis
        ON temp_grupo.cve = temp_dlis.gpo
        INNER JOIN 
        temp_dgau
        ON temp_dlis.gpo = temp_dgau.gpo AND temp_dlis.mat = temp_dgau.mat
        INNER JOIN 
        temp_dcat
        ON temp_dcat.cve =  temp_dgau.cat
        INNER JOIN
        temp_dret
        ON temp_dgau.mat = temp_dret.cve
        INNER JOIN 
        temp_dret2
        ON temp_dret.cve = temp_dret2.mat
        INNER JOIN 
        diccionario_especialidad
        ON temp_dret2.esp =  diccionario_especialidad.cve
        WHERE
        periodo.id = (SELECT periodo.id FROM periodo WHERE periodo.activar = 1);
        
        INSERT INTO inscripcion (id_curso, alumno_control, activar)
        SELECT curso.id, temp_inscripcion.ctr_alumno, 1 FROM curso
        INNER JOIN 
        temp_inscripcion
        ON curso.nombre_grupo = temp_inscripcion.grupo 
        AND 
        curso.id_periodo = temp_inscripcion.id_periodo
        AND 
        curso.id_carrera = temp_inscripcion.id_carrera
        AND 
        curso.clave_asignatura = temp_inscripcion.clave_asginatura
        AND 
        curso.folio_docente = temp_inscripcion.folio_docente;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->execute();
    }
}
