<?php
namespace App\Infrastructure\CrudSystem;

use Medoo\Medoo;
use App\Infrastructure\Exceptions\CustomException as Exception;
use App\Infrastructure\Binnacle\Binnacle;

class LessonInfrastructure{
    private Medoo $db;
    private Exception $exception;
    private Binnacle $binnacle;

    public function __construct(Medoo $db, Exception $exception, Binnacle $binnacle) 
    {
        $this->db = $db;
        $this->exception = $exception;
        $this->binnacle = $binnacle;
    }

    public function create(array $data): bool
    {
        $this->db->pdo->beginTransaction();
        $this->db->insert('asignatura',[
            'clave' => strtoupper($data['clave']), 
            'nombre'=> strtoupper($data['nombre'])
        ]);
        
        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Registrar',
        'tabla_afectada' => 'Asignatura'));

        return $this->exception->save((array) $this->db->error());
    }

    public function readAll(): ?array
    {
        $sql = $this->db->select('asignatura',[
           'clave', 
            'nombre'
        ]);
        
        return $this->exception->read((array) $this->db->error(), (array) $sql);
    }

    public function read(string $name): ?array
    {
        $sql = $this->db->select('asignatura', [
            'clave', 
            'nombre'],[
                'nombre[~]' => strtoupper($name)
        ]);

        return $this->exception->read((array) $this->db->error(), (array) $sql);
    }

    public function update(array $data): bool
    {
        $this->db->pdo->beginTransaction();

        $this->db->update('asignatura', [
            'clave'  => strtoupper($data['clave']), 
            'nombre' => strtoupper($data['nombre'])], [
                'clave' => strtoupper($data['clave_antigua'])
        ]);

        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Actualizar',
        'tabla_afectada' => 'Asignatura'));

        return $this->exception->save((array) $this->db->error());
    }
    
    public function delete (array $data): bool
    {
        $this->db->pdo->beginTransaction();
        $this->db->delete('asignatura', [
            'clave' => $data['clave']
        ]);

        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Eliminar',
        'tabla_afectada' => 'Asignatura'));
        
        return $this->exception->delete((array) $this->db->error());
    }
}