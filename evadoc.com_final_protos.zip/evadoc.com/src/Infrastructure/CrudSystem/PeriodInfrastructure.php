<?php
namespace App\Infrastructure\CrudSystem;

use Medoo\Medoo;
use App\Infrastructure\Exceptions\CustomException as Exception;
use App\Infrastructure\Binnacle\Binnacle;

class PeriodInfrastructure {
    private Medoo $db;
    private Exception $exception;
    private Binnacle $binnacle;

    public function __construct(Medoo $db, Exception $exception, Binnacle $binnacle) 
    {
        $this->db = $db;
        $this->exception = $exception;
        $this->binnacle = $binnacle;
    }

    public function create(array $data): bool
    {
        $this->db->pdo->beginTransaction();
        
        $this->db->update('periodo',[
            'activar' => 0
        ]);

        $result = $this->exception->save((array) $this->db->error());

        if(empty($result)) {
            return $result;
        }
        $this->db->pdo->beginTransaction();

        $this->db->insert('periodo',[
            'nombre' => strtoupper($data['nombre']), 
            'inicia' => $data['inicia'], 
            'termina' => $data['termina'],
            'activar' => 1,
        ]);
        
        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Registrar',
        'tabla_afectada' => 'Periodo'));

        return $this->exception->save((array) $this->db->error());
    }

    public function readAll(): ?array
    {
        $sql = $this->db->select('periodo',[
            'id',
            'nombre',
            'inicia',
            'termina',
            'activar'
        ]);
        
        return $this->exception->read((array) $this->db->error(), (array) $sql);
    }

    public function report(): ?array
    {
        $sql = $this->db->select('periodo',[
            'inicia',
            'termina'], [
                'activar' => 1
            ]);

        return $this->exception->read((array) $this->db->error(), (array) $sql);
    }

    public function evaluationState(): ?array
    {
        $sql = $this->db->get('activar_evaluacion', [
            'activar'
        ]);

        return $this->exception->read((array) $this->db->error(), (array) $sql);
    }

    public function activateEvaluation(array $data): bool
    {
        $this->db->pdo->beginTransaction();

        $this->db->update('activar_evaluacion',[
            'activar' => $data['activar_evaluacion']
        ]);

        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Habilitar o inhabilitar evaluacion',
        'tabla_afectada' => 'Activar evaluacion'));

        return $this->exception->save((array) $this->db->error());
    }

    public function update(array $data): bool
    {
        $this->db->pdo->beginTransaction();

        $this->db->update('periodo',[
            'activar' => 0
        ]);

        $result = $this->exception->save((array) $this->db->error());

        if(empty($result)) {
            return $result;
        }

        $this->db->pdo->beginTransaction();
        
        $this->db->update('periodo',[
            'nombre'  => strtoupper($data['nombre']), 
            'inicia'  => $data['inicia'], 
            'termina' => $data['termina'],
            'activar' => $data['activar']], [
            'id'      => $data['id']
        ]);

        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Actualizar',
        'tabla_afectada' => 'Periodo'));

        return $this->exception->save((array) $this->db->error());
    }
    
    public function delete(array $data): bool
    {
        $this->db->pdo->beginTransaction();
        $this->db->delete('periodo', [
            'id' => $data['id']
        ]);

        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Eliminar',
        'tabla_afectada' => 'Periodo'));
        
        $result = $this->exception->delete((array) $this->db->error());
        return $result;
    }
}