<?php
namespace App\Infrastructure\Code;

use Medoo\Medoo;
use App\Infrastructure\Exceptions\CustomException as Exception;

class Code {
    private Medoo $db;
    private Exception $exception;
    
    public function __construct(Medoo $db, Exception $exception) {
        $this->db = $db;
        $this->exception = $exception;
    }

    public function readAll(): array
    {
        $sql = <<<'EOP'
        SELECT evaluo.clave
        FROM evaluo
        INNER JOIN inscripcion
        ON evaluo.id = inscripcion.id
        INNER JOIN curso
        ON inscripcion.id_curso = curso.id
        WHERE curso.id_periodo = (SELECT periodo.id FROM periodo WHERE periodo.activar = 1)
        AND inscripcion.activar = 1
        ORDER BY evaluo.id DESC;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->execute();
        $records = $sth->fetchAll();

        return $this->exception->read((array) $this->db->error(), (array) $records);
    }
}