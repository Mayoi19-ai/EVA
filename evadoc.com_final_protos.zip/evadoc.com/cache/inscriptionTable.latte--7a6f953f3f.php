<?php
// source: Inscripcion/inscriptionTable.latte

use Latte\Runtime as LR;

class Template7a6f953f3f extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<!DOCTYPE html>
  <html>
    <head>
      <meta charset="utf-8">
      <title><?php echo LR\Filters::escapeHtmlText($title) /* line 5 */ ?></title>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
      <script type="text/javascript" src="/materialize/js/jquery.min.js"></script>
      <script type="text/javascript" src="/materialize/js/jquery-qrcode-0.18.0.js"></script>
      <script src="/materialize/js/materialize.min.js"></script>
      <link type="text/css" rel="stylesheet" href="/materialize/css/naver.css"  media="screen,projection">
      <script src="/materialize/validations/delete.js"></script>
      <script src="/materialize/validations/sellect.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    </head>
    <body>
<?php
		/* line 18 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
?>
        <div class="container section">
          <ul id="nav-mobile">
            <div class="row">
              <div class="col s12 m6 l3">
                <form name="showAllStudent" method="post" action="<?php
		echo $router->relativeUrlFor("inscriptionSearchByStudent");
?>">
                  <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 24 */ ?>">
                  <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 25 */ ?>">
                  <label for="control">Buscar número de control</label>
                  <input type="text" name="control">
                  <button id="buscar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee">Buscar<i class="material-icons left">search</i></button>
                </form>
              </div>
              <div class="col s12 m6 l3">
                <form action="<?php
		echo $router->relativeUrlFor("inscriptionShowByGroup");
?>" method="post">
                  <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 33 */ ?>">
                  <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 34 */ ?>">
<?php
		$iterations = 0;
		foreach ($permissions as $permissionInfor) {
			$permisos  = explode(" - ", $permissionInfor['enlace']);
			;
			if ($permisos[0] == "inscriptionShowByGroup") {
?>
                    <button id="buscar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee">Actualizar grupo</button>
<?php
			}
			$iterations++;
		}
?>
              </div>
            </form>
            <div class="col s12 m6 l3">
              <form action="<?php
		echo $router->relativeUrlFor("inscriptionShowByCareer");
?>" method="post">
                <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 45 */ ?>">
                <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 46 */ ?>">
<?php
		$iterations = 0;
		foreach ($permissions as $permissionInfor) {
			$permisos  = explode(" - ", $permissionInfor['enlace']);
			;
			if ($permisos[0] == "inscriptionShowByCareer") {
?>
                    <button id="buscar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee">Actualizar carrera</button>
<?php
			}
			$iterations++;
		}
?>
              </div>
            </form>
          </div>
        </div>
<?php
		if (empty ($query)) {
?>
          <div class="container section">
            <div class="card center">
              <div class="card center">
                <img class="logo" src="/materialize/css/alerta3.png">
                  <p>NO SE CUENTA CON ALUMNOS REGISTRADOS</p>
                    <form action="<?php
			echo $router->relativeUrlFor("userMenu");
?>" method="post">
                      <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 64 */ ?>">
                      <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 65 */ ?>">
                      <input id="retorno" type="submit" class="btn btn-primary btn-sm" value='Retornar'>
                    </form>
                  </div>
               </div>
            </div>
<?php
		}
		else {
?>
            <div class="MiTabla" class="container setcion responsive-table" >
              <table name="showAllInscription" method="get" class="bordered striped hoverable centered responsive-table"> <!-- nombre de tabla-->
                <thead>
                  <tr>
                    <th>Numero de control</th>
                    <th>Alumno</th>
                    <th>Grupo</th>
                    <th>Carrera</th>
                    <th>Asignatura</th>
                    <th>Docente</th>
                    <th>Estado de inscripción</th>
                    <th></th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
<?php
			$iterations = 0;
			foreach ($query as $inscriptionShow) {
?>
                    <tr>
                      <td><?php echo LR\Filters::escapeHtmlText($inscriptionShow['control']) /* line 90 */ ?> </td>
                      <td><?php echo LR\Filters::escapeHtmlText($inscriptionShow['alumno']) /* line 91 */ ?> </td>
                      <td><?php echo LR\Filters::escapeHtmlText($inscriptionShow['grupo']) /* line 92 */ ?> </td>
                      <td><?php echo LR\Filters::escapeHtmlText($inscriptionShow['carrera']) /* line 93 */ ?> </td>
                      <td><?php echo LR\Filters::escapeHtmlText($inscriptionShow['asignatura']) /* line 94 */ ?> </td>
                      <td><?php echo LR\Filters::escapeHtmlText($inscriptionShow['docente']) /* line 95 */ ?> </td>
<?php
				if ($inscriptionShow['activar'] == 1) {
?>
                      <td>Activo </td>
<?php
				}
				else {
?>
                        <td>No activo</td>
<?php
				}
?>
                      <td>
                        <form action="<?php
				echo $router->relativeUrlFor("inscriptionUpdateForm");
?>" method="post">
                          <input type="hidden" name="id" value="<?php echo LR\Filters::escapeHtmlAttr($inscriptionShow['id']) /* line 103 */ ?>">
                          <input type="hidden" name="id_curso" value="<?php echo LR\Filters::escapeHtmlAttr($inscriptionShow['id_curso']) /* line 104 */ ?>">
                          <input type="hidden" name="control" value="<?php echo LR\Filters::escapeHtmlAttr($inscriptionShow['control']) /* line 105 */ ?>">
                          <input type="hidden" name="nombre" value="<?php echo LR\Filters::escapeHtmlAttr($inscriptionShow['alumno']) /* line 106 */ ?>">
                          <input type="hidden" name="grupo" value="<?php echo LR\Filters::escapeHtmlAttr($inscriptionShow['grupo']) /* line 107 */ ?>">
                          <input type="hidden" name="carrera" value="<?php echo LR\Filters::escapeHtmlAttr($inscriptionShow['carrera']) /* line 108 */ ?>">
                          <input type="hidden" name="asignatura" value="<?php echo LR\Filters::escapeHtmlAttr($inscriptionShow['asignatura']) /* line 109 */ ?>">
                          <input type="hidden" name="docente" value="<?php echo LR\Filters::escapeHtmlAttr($inscriptionShow['docente']) /* line 110 */ ?>">
                          <input type="hidden" name="activar" value="<?php echo LR\Filters::escapeHtmlAttr($inscriptionShow['activar']) /* line 111 */ ?>">
                          <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 112 */ ?>">
                          <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 113 */ ?>">
<?php
				$iterations = 0;
				foreach ($permissions as $permissionInfor) {
					$permisos  = explode(" - ", $permissionInfor['enlace']);
					;
					if ($permisos[1] == "inscriptionUpdateForm") {
?>
                            <button id="actualizar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Editar<i class="material-icons left">edit</i></button>
<?php
					}
					$iterations++;
				}
?>
                      </form>
                    </td>
                      <td>
                        <form action="<?php
				echo $router->relativeUrlFor("inscriptionDelete");
?>" method="post" onsubmit="return confirmation()">
                        <input type="hidden" name="id" value="<?php echo LR\Filters::escapeHtmlAttr($inscriptionShow['id']) /* line 124 */ ?>">
                        <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 125 */ ?>">
                        <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 126 */ ?>">
<?php
				$iterations = 0;
				foreach ($permissions as $permissionInfor) {
					$permisos  = explode(" - ", $permissionInfor['enlace']);
					;
					if ($permisos[1] == "inscriptionDelete") {
?>
                              <button type="submit" id="eliminar" style="background-color: #f44336" class="btn btn-primary btn-sm #f44336" value='Eliminar'>Eliminar<i class="material-icons left">delete</i></button>
<?php
					}
					$iterations++;
				}
?>
                        </form>
                      </td>
                    </tr>
<?php
				$iterations++;
			}
?>
                </tbody>
                <form action="<?php
			echo $router->relativeUrlFor("inscriptionSaveForm");
?>" method="post">
                  <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 139 */ ?>">
                  <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 140 */ ?>">
                    <div class="fixed-action-btn">
<?php
			$iterations = 0;
			foreach ($permissions as $permissionInfor) {
				$permisos  = explode(" - ", $permissionInfor['enlace']);
				;
				if ($permisos[1] == "inscriptionSaveForm") {
?>
                          <button id="agrerar" type="submit" class="btn btn-primary btn-sm float-2" style="background-color: #22DD22" >Agregar<i class="material-icons left">add</i></button>
<?php
				}
				$iterations++;
			}
		}
?>
                      </form>
                    </table>
                  </div>
                </div>
 <!--footer -->
              <div class="content"></div>
              <div class="footer-copyright blue-grey lighten-3" >
                <div class="container">
                  <img class="header container section" src="/materialize/css/pie.jpg">
                </div>
              </div>
            </footer>
          </body>
         <script src="/materialize/validations/resources.js" type="text/javascript"></script>
        </html><?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['permissionInfor'])) trigger_error('Variable $permissionInfor overwritten in foreach on line 35, 47, 114, 127, 142');
		if (isset($this->params['inscriptionShow'])) trigger_error('Variable $inscriptionShow overwritten in foreach on line 88');
		
	}

}
