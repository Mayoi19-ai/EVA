<?php
// source: Materia/subjectTable.latte

use Latte\Runtime as LR;

class Template18c2fe172c extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 5 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
    <script type="text/javascript" src="/materialize/js/jquery.min.js"></script>
    <script type="text/javascript" src="/materialize/js/jquery-qrcode-0.18.0.js"></script>
    <script src="/materialize/js/materialize.min.js"></script>
    <link type="text/css" rel="stylesheet" href="/materialize/css/naver.css"  media="screen,projection">
    <script src="/materialize/validations/delete.js"></script>
    <script src="/materialize/validations/sellect.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js%22%3E"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js%22%3E"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.6/js/standalone/selectize.min.js" integrity="sha256-+C0A5Ilqmu4QcSPxrlGpaZxJ04VjsRjKu+G82kl5UJk=" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.6/css/selectize.bootstrap3.min.css" integrity="sha256-ze/OEYGcFbPRmvCnrSeKbRTtjG4vGLHXgOqsyLFTRjg=" crossorigin="anonymous">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
</head>
<body>
<?php
		/* line 21 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
?>
  <div class="container section">
  <ul id="nav-mobile">
    <div class="row">
      <div class="col s12 m6 l3">
      <form name="SearchForm" method="post" action="<?php
		echo $router->relativeUrlFor("subjectSearchByLesson");
?>">
        <label for="asignatura">Busqueda por asignatura<label>
        <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 28 */ ?>">
        <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 29 */ ?>">
        <input type="text" name="asignatura">
        <button id="buscar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee">Buscar<i class="material-icons left">search</i></button>
      </div>
    </form>
    <div class="col s12 m6 l3">
      <form name="SearchForm" method="post" action="<?php
		echo $router->relativeUrlFor("lessonShowByCareer");
?>">
        <label for="nombre">Busqueda por carrera<label>
        <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 37 */ ?>">
        <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 38 */ ?>">
        <select class="browser-default" name="id_career">
        <option value="<?php echo LR\Filters::escapeHtmlAttr($data['id']) /* line 40 */ ?>" name="id_career"></option>
<?php
		$iterations = 0;
		foreach ($all_careers_information as $searchOption) {
			?>        <option  value="<?php echo LR\Filters::escapeHtmlAttr($searchOption['id']) /* line 42 */ ?>" ><?php
			echo LR\Filters::escapeHtmlText($searchOption['nombre']) /* line 42 */ ?> </option>
<?php
			$iterations++;
		}
?>
        </select>
        <button id="buscar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee">Buscar<i class="material-icons left">search</i></button>
      </form>
    </div>
  </div>
</div>
<!-- -->
<?php
		if (empty ($query)) {
?>
  <div class="container section">
    <div class="card center">
      <div class="card center">
        <img class="logo" src="/materialize/css/alerta3.png">
          <h5>NO HAY MATERIA DISPONIBLE</h5>
            <form action="<?php
			echo $router->relativeUrlFor("userMenu");
?>" method="post">
              <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 58 */ ?>">
              <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 59 */ ?>">
              <input id="retorno" type="submit" class="btn btn-primary btn-sm" value='Retornar'>
            </form>                   
          </div>
        </div>
      </div>
<?php
		}
		else {
?>
        <table name="showAllDepartment" method="get" class="bordered striped hoverable centered responsive-table"> <!-- nombre de tabla-->
          <thead>
            <tr>
              <th>Carrera</th>
              <th>Asignatura</th>
              <th></th>
              <th></th>
            </tr>
          </thead>
          <tbody>
<?php
			$iterations = 0;
			foreach ($query as $subjecttShow) {
?>
            <tr>
              <td><?php echo LR\Filters::escapeHtmlText($subjecttShow['carrera']) /* line 78 */ ?> </td>    
              <td><?php echo LR\Filters::escapeHtmlText($subjecttShow['asignatura']) /* line 79 */ ?> </td>
              <td>
                <form action="<?php
				echo $router->relativeUrlFor("subjectUpdateForm");
?>" method="post">
                  <input type="hidden" name="id_carrera" value="<?php echo LR\Filters::escapeHtmlAttr($subjecttShow['id_carrera']) /* line 82 */ ?>">
                   <input type="hidden" name="clave_asignatura" value="<?php echo LR\Filters::escapeHtmlAttr($subjecttShow['clave_asignatura']) /* line 83 */ ?>">
                  <input type="hidden" name="carrera" value="<?php echo LR\Filters::escapeHtmlAttr($subjecttShow['carrera']) /* line 84 */ ?>">
                  <input type="hidden" name="asignatura" value="<?php echo LR\Filters::escapeHtmlAttr($subjecttShow['asignatura']) /* line 85 */ ?>">
             <!--No borrar -->
                  <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 87 */ ?>">
                  <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 88 */ ?>">
            <!--No borrar -->
<?php
				$iterations = 0;
				foreach ($permissions as $permissionInfor) {
					$permisos  = explode(" - ", $permissionInfor['enlace']);
					;
					if ($permisos[1] == "subjectUpdateForm") {
?>
                    <button id="actualizar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Editar<i class="material-icons left">edit</i></button>
<?php
					}
					$iterations++;
				}
?>
                  </form>
                </td>
                <td>
                  <form action="<?php
				echo $router->relativeUrlFor("subjectDelete");
?>" method="post" onsubmit="return confirmation()">
                    <input type="hidden" name="id_carrera" value="<?php echo LR\Filters::escapeHtmlAttr($subjecttShow['id_carrera']) /* line 100 */ ?>">
                    <input type="hidden" name="clave_asignatura" value="<?php echo LR\Filters::escapeHtmlAttr($subjecttShow['clave_asignatura']) /* line 101 */ ?>">
            <!-- No tocar lo de abajo-->
                    <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 103 */ ?>">
                    <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 104 */ ?>">
            <!--No tocar lo de arriba -->
<?php
				$iterations = 0;
				foreach ($permissions as $permissionInfor) {
					$permisos  = explode(" - ", $permissionInfor['enlace']);
					;
					if ($permisos[1] == "subjectDelete") {
?>
                        <button type="submit" id="eliminar" style="background-color: #f44336" class="btn btn-primary btn-sm #f44336" value='Eliminar'>Eliminar<i class="material-icons left">delete</i></button>
<?php
					}
					$iterations++;
				}
?>
                  </form>
                </td>
              </tr>
<?php
				$iterations++;
			}
?>
          </tbody>
            <form action="<?php
			echo $router->relativeUrlFor("subjectSaveForm");
?>" method="post">
              <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 118 */ ?>">
              <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 119 */ ?>">
                <div class="fixed-action-btn">
<?php
			$iterations = 0;
			foreach ($permissions as $permissionInfor) {
				$permisos  = explode(" - ", $permissionInfor['enlace']);
				;
				if ($permisos[1] == "subjectSaveForm") {
?>
                    <button id="agrerar" type="submit" class="btn btn-primary btn-sm float-2" style="background-color: #22DD22" >Agregar<i class="material-icons left">add</i></button>
<?php
				}
				$iterations++;
			}
		}
?>
            </form>
          </table>
        </div>
<!--footer -->
        <div class="content"></div>
        <div class="footer-copyright blue-grey lighten-3" >
          <div class="container">
            <img class="header container section" src="/materialize/css/pie.jpg">
          </div>
        </div>
      </footer>
    </body>
 <script src="/materialize/validations/resources.js" type="text/javascript"></script>
</html>
<?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['searchOption'])) trigger_error('Variable $searchOption overwritten in foreach on line 41');
		if (isset($this->params['permissionInfor'])) trigger_error('Variable $permissionInfor overwritten in foreach on line 90, 106, 121');
		if (isset($this->params['subjecttShow'])) trigger_error('Variable $subjecttShow overwritten in foreach on line 76');
		
	}

}
