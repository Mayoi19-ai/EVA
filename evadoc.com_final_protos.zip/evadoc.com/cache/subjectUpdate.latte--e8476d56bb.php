<?php
// source: Materia/subjectUpdate.latte

use Latte\Runtime as LR;

class Templatee8476d56bb extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<!DOCTYPE html>
  <html>
    <head>
      <meta charset="utf-8">
        <title><?php echo LR\Filters::escapeHtmlText($title) /* line 5 */ ?></title>
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
        <script type="text/javascript" src="/materialize/js/jquery.min.js"></script>
        <script type="text/javascript" src="/materialize/js/jquery-qrcode-0.18.0.js"></script>
        <script src="/materialize/js/materialize.min.js"></script>
        <link type="text/css" rel="stylesheet" href="/materialize/css/naver.css"  media="screen,projection">
        <script src="/materialize/validations/sellect.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js%22%3E"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js%22%3E"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.6/js/standalone/selectize.min.js" integrity="sha256-+C0A5Ilqmu4QcSPxrlGpaZxJ04VjsRjKu+G82kl5UJk=" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.6/css/selectize.bootstrap3.min.css" integrity="sha256-ze/OEYGcFbPRmvCnrSeKbRTtjG4vGLHXgOqsyLFTRjg=" crossorigin="anonymous">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
        <link type="text/css" rel="stylesheet" href="/materialize/css/formularios.css"  media="screen,projection">
<?php
		/* line 19 */
		$this->createTemplate('../validationUpdate.latte', $this->params, "include")->renderToContentType('html');
?>
    </head>
    <body>
<?php
		/* line 22 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
?>
       <ul id="nav-mobile">
        <div class="container section">
          <form name="subjectUpdateForm" method="post" action="<?php
		echo $router->relativeUrlFor("subjectUpdate");
?>">
            <input type="hidden" name="id_carrera" value="<?php echo LR\Filters::escapeHtmlAttr($data['id_carrera']) /* line 26 */ ?>">
            <input type="hidden" name="clave_asignatura" value="<?php echo LR\Filters::escapeHtmlAttr($data['clave_asignatura']) /* line 27 */ ?>">
            <input type="hidden" name="carrera" value="<?php echo LR\Filters::escapeHtmlAttr($data['carrera']) /* line 28 */ ?>">
            <input type="hidden" name="asignatura" value="<?php echo LR\Filters::escapeHtmlAttr($data['asignatura']) /* line 29 */ ?>">
            <!-- -->
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 31 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 32 */ ?>">
            <!-- -->
              <div class="container section">
                <li>
                  <label><input type="hidden" id="id_carrera_antiguo" name="id_carrera_antiguo" value="<?php
		echo LR\Filters::escapeHtmlAttr($data['id_carrera']) /* line 36 */ ?>" class="validate"></label>
                </li>
                <li>
                  <label><input type="hidden" id="id_asignatura_antiguo" name="clave_asignatura_antiguo" value="<?php
		echo LR\Filters::escapeHtmlAttr($data['clave_asignatura']) /* line 39 */ ?>" class="validate"></label>
                </li>
                <li>
                  <label for="id_carrera">Selecciona una Carrera:</label>
                  <select class="browser-default" name="id_carrera">
                  <option value="<?php echo LR\Filters::escapeHtmlAttr($data['id_carrera']) /* line 44 */ ?>" name="id_carrera"><?php
		echo LR\Filters::escapeHtmlText($data['carrera']) /* line 44 */ ?></option>
<?php
		$iterations = 0;
		foreach ($all_careers_information as $careerOption) {
			?>                  <option  value="<?php echo LR\Filters::escapeHtmlAttr($careerOption['id']) /* line 46 */ ?>" ><?php
			echo LR\Filters::escapeHtmlText($careerOption['nombre']) /* line 46 */ ?></option>
<?php
			$iterations++;
		}
?>
                  </select>
                </li>
                <li>
                  <label for="clave asignatura">Selecciona una modalidad:</label>
                  <select class="browser-default" name="clave_asignatura">
                  <option value="<?php echo LR\Filters::escapeHtmlAttr($data['clave_asignatura']) /* line 53 */ ?>" name="clave_asignatura"><?php
		echo LR\Filters::escapeHtmlText($data['asignatura']) /* line 53 */ ?></option>
<?php
		$iterations = 0;
		foreach ($all_lessons_information as $subjecttyOption) {
			?>                  <option  value="<?php echo LR\Filters::escapeHtmlAttr($subjecttyOption['clave']) /* line 55 */ ?>" ><?php
			echo LR\Filters::escapeHtmlText($subjecttyOption['nombre']) /* line 55 */ ?></option>
<?php
			$iterations++;
		}
?>
                </select>
              </li>
              <button id="guardar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Guardar<i class="material-icons left">send</i></button>
              </div>
              </form>
              <form action="<?php
		echo $router->relativeUrlFor("showAllSubjects");
?>" method="post">
              <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 63 */ ?>">
              <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 64 */ ?>">
              <button id="retornar" type="submit" class="btn btn-primary btn-sm float-1" style="background-color: #10c2ee" >Retornar<i class="material-icons left">arrow_back</i></button>
              </form>
            </div>
    <!--footer -->
            <div class="content"></div>
            <div class="footer-copyright blue-grey lighten-3" >
              <div class="container">
                <img class="header container section" src="/materialize/css/pie.jpg">
              </div>
          </div>
        </footer>
</body>
 <script src="/materialize/validations/resources.js" type="text/javascript"></script>
</html><?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['careerOption'])) trigger_error('Variable $careerOption overwritten in foreach on line 45');
		if (isset($this->params['subjecttyOption'])) trigger_error('Variable $subjecttyOption overwritten in foreach on line 54');
		
	}

}
