<?php
// source: RolesPermisos/permissionsRTable.latte

use Latte\Runtime as LR;

class Template679cc06666 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<!DOCTYPE html>
  <html>
    <head>
      <meta charset="utf-8">
      <title><?php echo LR\Filters::escapeHtmlText($title) /* line 5 */ ?></title>
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
      <script type="text/javascript" src="/materialize/js/jquery.min.js"></script>
      <script type="text/javascript" src="/materialize/js/jquery-qrcode-0.18.0.js"></script>
      <script src="/materialize/js/materialize.min.js"></script>
      <link type="text/css" rel="stylesheet" href="/materialize/css/naver.css"  media="screen,projection">
      <script src="/materialize/validations/delete.js"></script>
      <script src="/materialize/validations/sellect.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script> 
    </head>
    <body>
<?php
		/* line 17 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
		if (empty ($query)) {
?>
          <div class="container section">
            <div class="card center">
              <div class="card center">
                <img class="logo" src="/materialize/css/alerta3.png">
                  <p>NO SE CUENTA CON ROLES Y PERMISOS REGISTRADOS</p>
                  <form action="<?php
			echo $router->relativeUrlFor("userMenu");
?>" method="post">
                    <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 25 */ ?>">
                    <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 26 */ ?>">
                    <input id="retorno" type="submit" class="btn btn-primary btn-sm" value='Retornar'>
                  </form>
                </div>
              </div>
            </div>
<?php
		}
		else {
?>
            <ul id="nav-mobile">
              <div class="row">
                <div class="col s12 m6 l3">
                  <form name="showAllRolePermissions" method="post" action="<?php
			echo $router->relativeUrlFor("rolePermissionsSearchByRole");
?>">
                  <label for="nombre">Busqueda por rol<label>
                  <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 38 */ ?>">
                  <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 39 */ ?>">
                  <select class="browser-default" name="nombre">
                  <option value="<?php echo LR\Filters::escapeHtmlAttr($data['nombre']) /* line 41 */ ?>" name="nombre"></option>
<?php
			$iterations = 0;
			foreach ($roles as $permisosOption) {
				?>                  <option  value="<?php echo LR\Filters::escapeHtmlAttr($permisosOption['nombre']) /* line 43 */ ?>" ><?php
				echo LR\Filters::escapeHtmlText($permisosOption['nombre']) /* line 43 */ ?> </option>
<?php
				$iterations++;
			}
?>
                  </select>
                  <button id="buscar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee">Buscar<i class="material-icons left">search</i></button>
                </form>
              </div>
            </div>
<!-- -->
<?php
			if (empty ($query)) {
?>
              <div class="container section">
                <div class="card center">
                <div class="card center">
                  <p>El rol seleccionado no tiene permisos asignados</p>
                </div>
              </div>
            </div>
<?php
			}
			else {
?>
            <div class="MiTabla" class="container setcion responsive-table" >
              <table name="showAllRolePermissions" method="get" class="bordered striped hoverable centered responsive-table">
                <thead>
                  <tr>
                    <th>Rol</th>
                    <th>Categoria</th>
                    <th>Permiso</th>
                    <th>Estado</th>
                    <th></th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
<?php
				$iterations = 0;
				foreach ($query as $rolesPermisos) {
?>
                    <tr>
                      <td><?php echo LR\Filters::escapeHtmlText($rolesPermisos['rol']) /* line 75 */ ?> </td>
                      <td><?php echo LR\Filters::escapeHtmlText($rolesPermisos['categoria']) /* line 76 */ ?> </td>
                      <td><?php echo LR\Filters::escapeHtmlText($rolesPermisos['permiso']) /* line 77 */ ?> </td>     
<?php
					if ($rolesPermisos['activar'] == 1) {
?>
                      <td>Activo </td>
<?php
					}
					else {
?>
                      <td>No activo</td>
<?php
					}
?>
                     <td>
                        <form action="<?php
					echo $router->relativeUrlFor("rolePermissionsUpdateForm");
?>" method="post">
                          <input type="hidden" name="rol" value="<?php echo LR\Filters::escapeHtmlAttr($rolesPermisos['rol']) /* line 85 */ ?>">
                          <input type="hidden" name="categoria" value="<?php echo LR\Filters::escapeHtmlAttr($rolesPermisos['categoria']) /* line 86 */ ?>">
                          <input type="hidden" name="permiso" value="<?php echo LR\Filters::escapeHtmlAttr($rolesPermisos['permiso']) /* line 87 */ ?>">
                          <input type="hidden" name="id_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($rolesPermisos['id_permisos']) /* line 88 */ ?>">
                          <input type="hidden" name="id_roles" value="<?php echo LR\Filters::escapeHtmlAttr($rolesPermisos['id_roles']) /* line 89 */ ?>">
                          <input type="hidden" name="activar" value="<?php echo LR\Filters::escapeHtmlAttr($rolesPermisos['activar']) /* line 90 */ ?>">
                          <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 91 */ ?>">
                          <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 92 */ ?>">
<?php
					$iterations = 0;
					foreach ($permissions as $permissionInfor) {
						$permisos  = explode(" - ", $permissionInfor['enlace']);
						;
						if ($permisos[1] == "rolePermissionsUpdateForm") {
?>
                            <button id="actualizar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Editar<i class="material-icons left">edit</i></button>
<?php
						}
						$iterations++;
					}
?>
                        </form>
                      </td>
                      <td>
                        <form action="<?php
					echo $router->relativeUrlFor("rolePermissionsDelete");
?>" method="post" onsubmit="return confirmation()">
                          <input type="hidden" name="id_roles" value="<?php echo LR\Filters::escapeHtmlAttr($rolesPermisos['id_roles']) /* line 103 */ ?>">
                          <input type="hidden" name="id_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($rolesPermisos['id_permisos']) /* line 104 */ ?>">
                          <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 105 */ ?>">
                          <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 106 */ ?>">
<?php
					$iterations = 0;
					foreach ($permissions as $permissionInfor) {
						$permisos  = explode(" - ", $permissionInfor['enlace']);
						;
						if ($permisos[1] == "rolePermissionsDelete") {
?>
                                <button type="submit" id="eliminar" style="background-color: #f44336" class="btn btn-primary btn-sm #f44336" value='Eliminar'>Eliminar<i class="material-icons left">delete</i></button>
<?php
						}
						$iterations++;
					}
?>
                        </form>
                      </td>
                    </tr>
<?php
					$iterations++;
				}
?>
                </tbody>
                  <form action="<?php
				echo $router->relativeUrlFor("rolePermissionsSaveForm");
?>" method="post">
                    <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 119 */ ?>">
                    <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 120 */ ?>">
                    <div class="fixed-action-btn">
<?php
				$iterations = 0;
				foreach ($permissions as $permissionInfor) {
					$permisos  = explode(" - ", $permissionInfor['enlace']);
					;
					if ($permisos[1] == "rolePermissionsSaveForm") {
?>
                    <button id="agrerar" type="submit" class="btn btn-primary btn-sm float-2" style="background-color: #22DD22" >Agregar<i class="material-icons left">add</i></button>
<?php
					}
					$iterations++;
				}
			}
?>
                  </form>
                </table>
<?php
		}
?>
            </div>
 <!--footer -->
            <div class="content"></div>
            <div class="footer-copyright blue-grey lighten-3" >
              <div class="container">
                <img class="header container section" src="/materialize/css/pie.jpg">
            </div>
          </div>
        </footer>
</body>
 <script src="/materialize/validations/resources.js" type="text/javascript"></script>
</html>
<?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['permisosOption'])) trigger_error('Variable $permisosOption overwritten in foreach on line 42');
		if (isset($this->params['permissionInfor'])) trigger_error('Variable $permissionInfor overwritten in foreach on line 93, 107, 122');
		if (isset($this->params['rolesPermisos'])) trigger_error('Variable $rolesPermisos overwritten in foreach on line 73');
		
	}

}
