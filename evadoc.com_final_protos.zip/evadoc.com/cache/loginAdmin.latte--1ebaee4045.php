<?php
// source: Sesion/loginAdmin.latte

use Latte\Runtime as LR;

class Template1ebaee4045 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<!DOCTYPE html>
  <html>
    <head>
      <meta charset="utf-8">
        <title><?php echo LR\Filters::escapeHtmlText($title) /* line 5 */ ?></title>
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
        <script src="/materialize/js/materialize.min.js"></script>
        <link type="text/css" rel="stylesheet" href="/materialize/css/Logeo.css"  media="screen,projection">
        <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
        <script href="/materialize/validations/cookie.js" type="text/javascript"></script>
        <script href="/materialize/validations/resources.js" type="text/javascript"></script> 
    </head>
      <body>
        <img class="header container section" src="/materialize/css/cabeza.jpg">
          <!-- form sesion start -->
          <div class="row container section">
            <div class="col s12 ">
              <div class="card horizontal ">
                <img class="inicio" src="/materialize/css/tec.jpg"> 
                  <div class="card-stacked">
                    <div class="card-content">
                      <!-- sesion -->
                      <form name="usersLogin" method="post" action="<?php
		echo $router->relativeUrlFor("userMenu");
?>" > 
                        <div class="container section">
                          <label for="usuario_activo">Nombre de usuario</label>
                          <input type="text" id="usuario_activo" name="usuario_activo" class="validate">
                          <label for="contrasenia">Contraseña:</label>
                          <input type="password" id="contrasenia" name="contrasenia" class="validate" >
                          <input class="sesion file-path btn " type="submit"  value="Iniciar sesion" onclick ="return Logeo();">
                        </div>
                      </form>
                    <div id="error"></div> 
                  </div>
                    <div class="container section">
                      <div id="overbox3">
                        <div id="infobox3">
                          <p>Las 'Cookies' deben estar habilitadas en su navegador
                          <a onclick="aceptar_cookies();" style="cursor:pointer;">X Cerrar</a>
                          <a class="galletas  modal-trigger" href="#modal2"><i class="material-icons">help_outline</i></a> 
                          <!-- Modal Structure -->
                          <div id="modal2" class="modal">
                          <div class="modal-content">
                            <h4>Politica de 'Cookies'</h4>
                            <p>Utilizamos cookies para mejorar la experiencia de su navegador, recordando que ha iniciado sesión. Si completa un formulario de contacto, utilizamos cookies para recordar sus datos para la próxima vez.</p>
                              <div class="modal-footer">
                                <a href="#!" class="modal-close waves-effect waves-green btn-flat">Cerrar</a>
                              </div>
                            </div>
                          </div>
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- form sesion end --> 
          <!--footer-->
          <div class="content"></div>
            <div class="footer-copyright blue-grey lighten-3" >
              <div class="container">
                <img class="header container section" src="/materialize/css/pie.jpg">
              </div>
            </div>
          </footer>
      </body>
    </html><?php
		return get_defined_vars();
	}

}
