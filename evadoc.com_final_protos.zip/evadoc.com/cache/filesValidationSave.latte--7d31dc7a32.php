<?php
// source: Archivos/filesValidationSave.latte

use Latte\Runtime as LR;

class Template7d31dc7a32 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<!DOCTYPE html>
  <html>
    <head>
      <meta charset="utf-8">
      <title><?php echo LR\Filters::escapeHtmlText($title) /* line 5 */ ?></title>
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
      <script src="/materialize/js/materialize.min.js"></script>
      <link type="text/css" rel="stylesheet" href="/materialize/css/studentNaver.css"  media="screen,projection">
    </head>
    <body>
    <img class="header container section" src="/materialize/css/cabeza.jpg">
    <nav>
      <div class="nav-wrapper blue-grey lighten-3">
        <img class="logo" src="https://www.itshuatusco.edu.mx/inicio/images/Logo%20ITSH%20300x312%20negritas.png"></a>
        <ul id="nav-mobile" class="right hide-on-med-and-down">
          <ul class="right hide-on-med-and-down">
            <li><a class="dropdown-trigger" href="#!" data-target="dropdown1"><i class="material-icons right">arrow_drop_down</i></a></li>
            <ul id='dropdown1' class='dropdown-content'>
            <li><a href="<?php
		echo $router->relativeUrlFor("loginStudent");
?>">Cerrar sesion</a></li>
          </ul>
        </ul>
        <a href="#" data-target="slide-out" class="sidenav-trigger"><i class="material-icons">menu</i></a>
      </ul>
    </div>
  </nav>
<?php
		if (!empty ($query)) {
?>
      <div class="container section">
        <div class="card center">
          <div class="card center">
            <p>IMPORTADO CORRECTAMENTE</p>
            <form action="<?php
			echo $router->relativeUrlFor("userMenu");
?>" method="post">
              <i><input type="hidden" id="usuario_activo" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 33 */ ?>">
              <input type="hidden" id="categoria_permisos" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 34 */ ?>">
              <button id="retornar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Retornar<i class="material-icons left">arrow_back</i></button>
            </div>
          </div>
        </form>
      </div>
<?php
		}
		else {
?>
        <div class="container section">
          <div class="card center">
            <div class="card center">
              <p>ERROR NO SE LOGRO IMPORTAR LA INFORMACION</p>
                <form action="<?php
			echo $router->relativeUrlFor("userMenu");
?>" method="post">
                  <i><input type="hidden" id="usuario_activo" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 46 */ ?>">
                  <input type="hidden" id="categoria_permisos" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 47 */ ?>">
                  <button id="retornar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Retornar<i class="material-icons left">arrow_back</i></button>
                </div>
              </div>
            </form>
          </div>
<?php
		}
?>
        <div class="content"></div>
          <div class="footer-copyright blue-grey lighten-3" >
            <div class="container">
              <img class="header container section" src="/materialize/css/pie.jpg">
            </div>
          </div>
        </footer>
      </body>
    <script src="/materialize/validations/resources.js" type="text/javascript"></script>
  </html>
<?php
		return get_defined_vars();
	}

}
