<?php
// source: Preguntas/@layout.latte

use Latte\Runtime as LR;

class Templatebd4b2b9aed extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<!DOCTYPE html>
  <html>
    <head>
      <meta charset="utf-8">
      <title><?php echo LR\Filters::escapeHtmlText($title) /* line 5 */ ?></title>
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
      <script type="text/javascript" src="/materialize/js/jquery.min.js"></script>
      <script type="text/javascript" src="/materialize/js/jquery-qrcode-0.18.0.js"></script>
      <script src="/materialize/js/materialize.min.js"></script>
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/studentNaver.css"  media="screen,projection">
      <script src="/materialize/validations/resources.js"></script>
      <script src="/materialize/validations/validation.js"></script>
    </head>
    <body>
      <img class="header container section" src="/materialize/css/cabeza.jpg">  
      <nav>
        <div class="nav-wrapper blue-grey lighten-3">
          <img class="logo" src="https://www.itshuatusco.edu.mx/inicio/images/Logo%20ITSH%20300x312%20negritas.png"></a>
          <!--Mobile -->
          <a href="#" class="sidenav-trigger" data-target="mobile-nav">
			      <i class="material-icons">menu</i>
		      </a>
          <ul class="right hide-on-med-and-down "  >
            <li><a href="<?php
		echo $router->relativeUrlFor("loginStudent");
?>">Cerrar sesion</a></li>
          </ul>
          <!-- -->
        </div>
      </nav>
      <!-- -->
      <ul class="sidenav" id="mobile-nav">
        <li><a href="<?php
		echo $router->relativeUrlFor("loginStudent");
?>" id="actualizar" class="btn btn-primary btn-sm" style="background-color:#b0bec5">Cerrar sesion</a></li>
      </ul>
      <!--nav end -->
      <div class="container section">
        <div class="card center">
          <a><span class="black-text"><?php echo LR\Filters::escapeHtmlText($courseData['docente']) /* line 38 */ ?></span></a>
          <p><span class="black-text"><?php echo LR\Filters::escapeHtmlText($courseData['asignatura']) /* line 39 */ ?></span></p>
        </div>
        <div class="card">
          <form name="questionSaveForm" id="questionSaveForm" method="post" action="<?php
		echo $router->relativeUrlFor("studentCoursesSaveQuiz");
?>" onsubmit="return validation()">
            <input type="hidden" id="id" name="id" value="<?php echo LR\Filters::escapeHtmlAttr($courseData['id']) /* line 43 */ ?>" class="validate">
            <input type="hidden" id="control" name="control" value="<?php echo LR\Filters::escapeHtmlAttr($courseData['control']) /* line 44 */ ?>" class="validate">
            <input type="hidden" id=" alumno" name="  alumno" value="<?php echo LR\Filters::escapeHtmlAttr($courseData['alumno']) /* line 45 */ ?>" class="validate">
            <input type="hidden" id="curso" name="curso" value="<?php echo LR\Filters::escapeHtmlAttr($courseData['grupo']) /* line 46 */ ?>" class="validate">
            <input type="hidden" id="carrera" name="carrera" value="<?php echo LR\Filters::escapeHtmlAttr($courseData['carrera']) /* line 47 */ ?>" class="validate">
            <input type="hidden" id="asignatura" name="asignatura" value="<?php echo LR\Filters::escapeHtmlAttr($courseData['asignatura']) /* line 48 */ ?>" class="validate">
            <input type="hidden" id="clave_asignatura" name="clave_asignatura" value="<?php echo LR\Filters::escapeHtmlAttr($courseData['clave_asignatura']) /* line 49 */ ?>" class="validate">
            <input type="hidden" id=" docente" name=" docente" value="<?php echo LR\Filters::escapeHtmlAttr($courseData['docente']) /* line 50 */ ?>" class="validate">
            <input type="hidden" id=" periodo" name=" periodo" value="<?php echo LR\Filters::escapeHtmlAttr($courseData['periodo']) /* line 51 */ ?>" class="validate">
            <input type="hidden" id="id_curso" name="id_curso" value="<?php echo LR\Filters::escapeHtmlAttr($courseData['curso']) /* line 52 */ ?>" class="validate">
              <div class="questionTabla"> 
                <table class="bordered striped hoverable centered" >
                  <thead>
                    <tr>
                      <th>Número de pregunta</th>
                      <th>Preguntas</th>
                      <th>Totalmente desacuerdo</th>
                      <th>Desacuerdo</th>
                      <th>Indeciso</th>
                      <th>De acuerdo</th>
                      <th>Totalmente de acuerdo</th>
                    </tr>
                  </thead>
                  <tbody>  
                    <tr>
            <td>1</td>
            <td>Explica de manera clara los contenidos de la asignatura.</td>
            <td><label><input class="with-gap" name="group1" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group1" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group1" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group1" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group1" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>

          <tr>
            <td>2</td>
            <td>Relaciona los contenidos de la asignatura con los contenidos de otras.</td>
            <td><label><input class="with-gap" name="group2" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group2" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group2" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group2" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group2" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>
          <tr>
            <td>3</td>
            <td>Resuelve las dudas relacionadas con los contenidos de la asignatura.</td>
            <td><label><input class="with-gap" name="group3" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group3" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group3" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group3" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group3" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>

          <tr>
            <td>4</td>
            <td>Propone ejemplos o ejercicios que vinculan la asignatura con la práctica profecional.</td>
            <td><label><input class="with-gap" name="group4" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group4" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group4" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group4" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group4" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>

          <tr>
            <td>5</td>
            <td>Explica la utilidad de los contenidos teóricos y prácticos para la actividad profesional.</td>
            <td><label><input class="with-gap" name="group5" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group5" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group5" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group5" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group5" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>
          <tr>
            <td>6</td>
            <td>Cumple con los acuerdos establecidos al inicio de la asignatura.</td>
            <td><label><input class="with-gap" name="group6" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group6" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group6" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group6" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group6" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>

          <tr>
            <td>7</td>
            <td>Durante el curso establece las estrategias adecuadas necesarias para lograr el aprendizaje deseado.</td>
            <td><label><input class="with-gap" name="group7" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group7" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group7" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group7" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group7" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>

          <tr>
            <td>8</td>
            <td>¿El programa presentado al principio de la asignatura se cubre totalmente?</td>
            <td><label><input class="with-gap" name="group8" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group8" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group8" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group8" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group8" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>
          <tr>
            <td>9</td>
            <td>¿Incluye experiencias de aprendizaje en lugares diferentes al aula (talleres, laboratorios, empresas, comunidad, etc.)?</td>
            <td><label><input class="with-gap" name="group9" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group9" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group9" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group9" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group9" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>
          <tr>
            <td>10</td>
            <td>Utiliza para el aprendizaje las herramientas de interacción de las tecnologías actuales de la información (correo electrónico, chats, plataformas, etc.).</td>
            <td><label><input class="with-gap" name="group10" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group10" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group10" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group10" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group10" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>

          <tr>
            <td>11</td>
            <td>¿Organiza actividades que me permiten ejercitar mi expresión oral y escrita?</td>
            <td><label><input class="with-gap" name="group11" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group11" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group11" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group11" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group11" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>
          <tr>
            <td>12</td>
            <td>¿Relaciona los contenidos de la asignatura con la industria y la sociedad a nivel local, regional, nacional e internacional?</td>
            <td><label><input class="with-gap" name="group12" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group12" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group12" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group12" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group12" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>
          <tr>
            <td>13</td>
            <td>Usa ejemplos y casos relacionados con la vida real.</td>
            <td><label><input class="with-gap" name="group13" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group13" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group13" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group13" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group13" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>

          <tr>
            <td>14</td>
            <td>¿Adapta las actividades para atender los diferentes estilos de aprendizaje de los estudiantes?</td>
            <td><label><input class="with-gap" name="group14" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group14" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group14" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group14" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group14" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>
          <tr>
            <td>15</td>
            <td>¿Promueve el autodidactismo y la investigación?</td>
            <td><label><input class="with-gap" name="group15" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group15" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group15" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group15" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group15" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>
          <tr>
            <td>16</td>
            <td>Promueve actividades participativas que me permiten colaborar con mis compañeros con una actividad positiva.</td>
            <td><label><input class="with-gap" name="group16" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group16" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group16" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group16" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group16" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>

          <tr>
            <td>17</td>
            <td>Promueve actividades participativas que me permiten colaborar con mis compañeros con una actividad positiva.</td>
            <td><label><input class="with-gap" name="group17" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group17" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group17" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group17" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group17" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>
          <tr>
            <td>18</td>
            <td>¿Se involucra en las actividades propuestas al grupo?</td>
            <td><label><input class="with-gap" name="group18" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group18" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group18" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group18" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group18" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>
          <tr>
            <td>19</td>
            <td>Presenta y expone las clases de manera organizada y estructurada.</td>
            <td><label><input class="with-gap" name="group19" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group19" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group19" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group19" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group19" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>

          <tr>
            <td>20</td>
            <td>¿Utiliza diversas estrategias, métodos, medios y materiales?</td>
            <td><label><input class="with-gap" name="group20" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group20" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group20" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group20" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group20" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>
          <tr>
            <td>21</td>
            <td>¿Muestra compromiso y entusiasmo en sus actividades docentes?</td>
            <td><label><input class="with-gap" name="group21" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group21" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group21" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group21" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group21" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>
          <tr>
            <td>22</td>
            <td>Toma en cuenta las necesidades, intereses y expectativas del grupo.</td>
            <td><label><input class="with-gap" name="group22" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group22" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group22" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group22" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group22" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>

          <tr>
            <td>23</td>
            <td>¿Propicia el desarrollo de un ambiente de respeto y confianza?</td>
            <td><label><input class="with-gap" name="group23" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group23" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group23" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group23" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group23" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>
          <tr>
            <td>24</td>
            <td>¿Propicia la curiosidad y el deseo de aprender?</td>
            <td><label><input class="with-gap" name="group24" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group24" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group24" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group24" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group24" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>
          <tr>
            <td>25</td>
            <td>Reconoce los éxitos y logros en las actividades de aprendizaje.</td>
            <td><label><input class="with-gap" name="group25" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group25" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group25" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group25" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group25" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>

          <tr>
            <td>26</td>
            <td style="color:#ef5350">¿Existe la impresión de que se toman represalias con algunos estudiantes?</td>
            <td><label><input class="with-gap" name="group26" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group26" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group26" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group26" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group26" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>
          <tr>
            <td>27</td>
            <td>¿Hace interesante la asignatura?</td>
            <td><label><input class="with-gap" name="group27" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group27" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group27" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group27" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group27" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>
          <tr>
            <td>28</td>
            <td>Identifica los conocimientos y habilidades de los estudiantes al inicio de la asignatura o de cada unidad.</td>
            <td><label><input class="with-gap" name="group28" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group28" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group28" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group28" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group28" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>

          <tr>
            <td>29</td>
            <td>¿Proporciona información para realizar adecuadamente las actividades de evaluación?</td>
            <td><label><input class="with-gap" name="group29" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group29" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group29" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group29" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group29" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>
          <tr>
            <td>30</td>
            <td>¿Toma en cuenta las actividades realizadas y los productos como evidencias para la calificación y acreditación de la asignatura?</td>
            <td><label><input class="with-gap" name="group30" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group30" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group30" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group30" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group30" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>
          <tr>
            <td>31</td>
            <td>Considera los resultados de la evaluación (asesorías, trabajos complementarios, búsqueda de información, etc.) para realizar mejoras en el aprendizaje.</td>
            <td><label><input class="with-gap" name="group31" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group31" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group31" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group31" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group31" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>

          <tr>
            <td>32</td>
            <td>¿Da a conocer las calificaciones en el plazo establecido?</td>
            <td><label><input class="with-gap" name="group32" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group32" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group32" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group32" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group32" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>
          <tr>
            <td>33</td>
            <td>¿Da oportunidad de mejorar los resultados de la evaluación del aprendizaje?</td>
            <td><label><input class="with-gap" name="group33" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group33" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group33" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group33" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group33" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>
          <tr>
            <td>34</td>
            <td>Muestra apertura para la corrección de errores de apreciación y evaluación.</td>
            <td><label><input class="with-gap" name="group34" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group34" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group34" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group34" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group34" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>

          <tr>
            <td>35</td>
            <td ¿style="color:#ef5350">Otorga calificaciones imparciales?</td>
            <td><label><input class="with-gap" name="group35" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group35" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group35" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group35" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group35" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>
          <tr>
            <td>36</td>
            <td>¿Desarrolla la clase en un clima de apertura y entendimiento?</td>
            <td><label><input class="with-gap" name="group36" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group36" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group36" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group36" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group36" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>
          <tr>
            <td>37</td>
            <td>Escucha y toma en cuenta las opiniones de los estudiantes.</td>
            <td><label><input class="with-gap" name="group37" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group37" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group37" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group37" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group37" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>

          <tr>
            <td>38</td>
            <td>¿Muestra congruencia entre lo que dice y lo que hace?</td>
            <td><label><input class="with-gap" name="group38" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group38" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group38" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group38" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group38" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>
          <tr>
            <td>39</td>
            <td>¿Asiste a clases regular y puntualmente?</td>
            <td><label><input class="with-gap" name="group39" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group39" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group39" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group39" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group39" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>
          <tr>
            <td>40</td>
            <td>Fomenta la importancia de contribuir a la conservación del medio ambiente.</td>
            <td><label><input class="with-gap" name="group40" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group40" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group40" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group40" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group40" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>

          <tr>
            <td>41</td>
            <td>¿Promueve mantener limpias y ordenadas las instalaciones?</td>
            <td><label><input class="with-gap" name="group41" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group41" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group41" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group41" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group41" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>
          <tr>
            <td>42</td>
            <td>¿Es accesible y está dispuesto a brindarte ayuda académica?</td>
            <td><label><input class="with-gap" name="group42" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group42" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group42" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group42" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group42" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>
          <tr>
            <td>43</td>
            <td>Emplea las tecnologías de la información y de la comunicación como un medio que facilite el aprendizaje de los estudiantes.</td>
            <td><label><input class="with-gap" name="group43" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group43" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group43" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group43" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group43" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>

          <tr>
            <td>44</td>
            <td>¿Promueve el uso de diversas herramientas, particularmente las digitales, para gestionar (recabar, procesar, evaluar y usar) información?</td>
            <td><label><input class="with-gap" name="group44" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group44" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group44" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group44" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group44" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>
          <tr>
            <td>45</td>
            <td>¿Promueve el uso seguro, legal y ético de la información digital?</td>
            <td><label><input class="with-gap" name="group45" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group45" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group45" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group45" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group45" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>
          <tr>
            <td>46</td>
            <td>En general, pienso que es un buen docente.</td>
            <td><label><input class="with-gap" name="group46" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group46" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group46" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group46" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group46" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>

          <tr>
            <td>47</td>
            <td>¿Estoy satisfecha o satisfecho por mi nivel de desempeño y aprendizaje logrado gracias a la labor del docente?</td>
            <td><label><input class="with-gap" name="group47" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group47" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group47" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group47" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group47" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>
          <tr>
            <td>48</td>
            <td>¿Yo recomendaría a este docente a otros compañeros?</td>
            <td><label><input class="with-gap" name="group48" id="preguntas" type="radio" value="1" ><span></span></label></td>
            <td><label><input class="with-gap" name="group48" id="preguntas" type="radio" value="2" ><span></span></label></td>
            <td><label><input class="with-gap" name="group48" id="preguntas" type="radio" value="3" ><span></span></label></td>
            <td><label><input class="with-gap" name="group48" id="preguntas" type="radio" value="4" ><span></span></label></td>
            <td><label><input class="with-gap" name="group48" id="preguntas" type="radio" value="5" ><span></span></label></td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
  <button id="guardar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" onsubmit="return validation()">Guardar<i class="material-icons left">send</i></button>
  </form>
</div>
  <div class="content"></div>
    <div class="footer-copyright blue-grey lighten-3" >
      <div class="container">
        <img class="header container section" src="/materialize/css/pie.jpg">
      </div>
    </div>
  </footer>
<script src="/materialize/validations/resources.js" type="text/javascript"></script>
</body>
</html>



<?php
		return get_defined_vars();
	}

}
