<?php
// source: Rol/rolUpdate.latte

use Latte\Runtime as LR;

class Template043e3f0839 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<!DOCTYPE html>
  <html>
    <head>
      <meta charset="utf-8">
      <title><?php echo LR\Filters::escapeHtmlText($title) /* line 5 */ ?></title>
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
      <script type="text/javascript" src="/materialize/js/jquery.min.js"></script>
      <script type="text/javascript" src="/materialize/js/jquery-qrcode-0.18.0.js"></script>
      <script src="/materialize/js/materialize.min.js"></script>
      <link type="text/css" rel="stylesheet" href="/materialize/css/naver.css"  media="screen,projection">
      <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
      <link type="text/css" rel="stylesheet" href="/materialize/css/formularios.css"  media="screen,projection">
<?php
		/* line 14 */
		$this->createTemplate('../validationUpdate.latte', $this->params, "include")->renderToContentType('html');
?>
    </head>
    <body>
<?php
		/* line 17 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
?>
        <ul id="nav-mobile">
          <div class="container section">
            <form name="rolUpdateForm" method="post" action="<?php
		echo $router->relativeUrlFor("roleUpdate");
?>">
              <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 21 */ ?>">
              <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 22 */ ?>">
                <ul>
                  <li>
                    <label><input type="hidden" id="id" name="id" value="<?php echo LR\Filters::escapeHtmlAttr($data['id']) /* line 25 */ ?>" class="validate"></label>
                  </li>
                  <li>
                    <label for="nombre">Rol:</label>
                  <label><input type="text" id="nombre" name="nombre" value="<?php echo LR\Filters::escapeHtmlAttr($data['nombre']) /* line 29 */ ?>" class="validate"></label>
                </ul>   
                <button id="guardar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Guardar<i class="material-icons left">send</i></button>
                </div>
              </form>
              <div>
                <form action="<?php
		echo $router->relativeUrlFor("showAllRoles");
?>" method="post">
                  <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 36 */ ?>">
                  <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 37 */ ?>">
                  <button id="retornar" type="submit" class="btn btn-primary btn-sm float-1" style="background-color: #10c2ee" >Retornar<i class="material-icons left">arrow_back</i></button>
                </form>
              </div>
     <!--footer -->
              <div class="content"></div>
              <div class="footer-copyright blue-grey lighten-3" >
                <div class="container">
                  <img class="header container section" src="/materialize/css/pie.jpg">
                </div>
              </div>
            </footer>
          </body>
        <script src="/materialize/validations/resources.js" type="text/javascript"></script>
      </html><?php
		return get_defined_vars();
	}

}
