<?php
// source: Menu\navegar.latte

use Latte\Runtime as LR;

class Template4b2c0ced05 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<!-- nav -->
                <img class="header container section" src="/materialize/css/cabeza.jpg">
                <nav>
                    <div class="nav-wrapper blue-grey lighten-3">
                        <img class="logo" src="/materialize/css/tec.jpg">
                        <ul id="nav-mobile" class="right hide-on-med-and-down">
                            <li>
                                <form action="/login" method="post">
                                    <input type="hidden" name="usuario_activo" value="Administrador">
                                    <input type="hidden" name="categoria_permisos" value="CAMPUS">
                                    <button id="menu" type="submit" class="btn btn-primary btn-sm" style="background-color:#b0bec5" >Menú</button>
                                </form>
                            </li>
                            <li>
                                <a href="/login">Cerrar sesión</a>
                            </li>                  
                        </ul>
                    </div>
                </nav>
                <!-- end nav -->
 <?php
		return get_defined_vars();
	}

}
