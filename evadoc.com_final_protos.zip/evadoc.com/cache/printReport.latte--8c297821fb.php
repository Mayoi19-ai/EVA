<?php
// source: Reporte/printReport.latte

use Latte\Runtime as LR;

class Template8c297821fb extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 5 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
       <script type="text/javascript" src="/materialize/js/d3.js"></script>
       <script type="text/javascript" src="/materialize/js/d3.min.js"></script>
       <link type="text/css" rel="stylesheet" href="/materialize/css/reporte.css"  media="screen,print">
       <script src="https://unpkg.com/jspdf@latest/dist/jspdf.umd.min.js"></script>
       <script type="text/javascript" src="/materialize/js/jquery.min.js"></script>
      <script type="text/javascript" src="/materialize/js/jquery-qrcode-0.18.0.js"></script>
<script type="text/javascript" src="/materialize/js/morris.js"></script>
<script type="text/javascript" src="/materialize/js/morris.min.js"></script>
<script type="text/javascript" src="/materialize/js/jquery.min.js"></script>
<script type="text/javascript" src="/materialize/js/raphael.js"></script>
<script type="text/javascript" src="/materialize/js/raphael.min.js"></script>
<style>
		@media print{
			.saltoDePagina{
				display:block;
				page-break-before:always;
			}
		}
	</style>
</head>
<body>

<div class="container section">
   <img class="imagen" src="/materialize/css/SEP.jpg">
    
      <div class="card centerd">
          <p>RESULTADOS DE LA EVALUACION DE LOS PROFESORES
          <span>
<?php
		$iterations = 0;
		foreach ($period_information as $periodo) {
			?>          <?php
			setlocale(LC_TIME, 'es_ES');
			echo strftime("AÑO %Y, APLICACION ", strtotime($periodo['inicia']));
			$mes = explode("-", $periodo['inicia']);

			switch($mes[2])
			{
				case "01":
				echo 'DE ENERO';
				break;

				case "02":
				echo 'DE FEBRERO';
				break;

				case "03":
				echo 'DE MARZO';
				break;

				case "04":
				echo 'DE ABRIL';
				break;

				case "05":
				echo 'DE MAYO';
				break;

				case "06":
				echo 'DE JUNIO';
				break;

				case "07":
				echo 'DE JULIO';
				break;

				case "08":
				echo 'DE AGOSTO';
				break;

				case "09":
				echo 'DE SEPTIEMBRE';
				break;

				case "10":
				echo 'DE OCTUBRE';
				break;

				case "11":
				echo 'DE NOVIEMBRE';
				break;

				case "12":
				echo 'DE DICIEMBRE';
				break;

			};
?>

          <?php
			$iterations++;
		}
?></span></p>
           <p>CUESTIONARIO PARA ALUMNOS<p>
          <p><h5>REPORTE POR PROFESOR</h5></p>
          <p>NOMBRE DEL PROFESOR: <span class="black-text"><?php echo LR\Filters::escapeHtmlText($data['docente']) /* line 98 */ ?></span></p>
          <P>NOMBRE DEL FOLIO: <span class="black-text"><?php echo LR\Filters::escapeHtmlText($data['folio']) /* line 99 */ ?></span></P>
          <p>DEPARTAMENTO: <span class="black-text"><?php echo LR\Filters::escapeHtmlText($data['clave_departamento']) /* line 100 */ ?></span></p>
      </div>
      <p></p>
        <div>
        <table class="centered">
          <thead>
            <tr>
            <th>Clave</th>
            <th>Grupo</th>
            <th>Nombre de la materia</th>
            <th>Inscritos</th>
            <th>Evaluados</th>
            </tr>
          </thead>
          <tbody>
<?php
		$iterations = 0;
		foreach ($courses as $teacherShow) {
?>
              <tr>
              <td><?php echo LR\Filters::escapeHtmlText($teacherShow['clave']) /* line 117 */ ?></td>
              <td><?php echo LR\Filters::escapeHtmlText($teacherShow['nombre_grupo']) /* line 118 */ ?></td>
              <td><?php echo LR\Filters::escapeHtmlText($teacherShow['asignatura']) /* line 119 */ ?></td>
              <td><?php echo LR\Filters::escapeHtmlText($teacherShow['COUNT(inscripcion.id)']) /* line 120 */ ?></td>
              <td><?php echo LR\Filters::escapeHtmlText($teacherShow['COUNT(evaluo.id)']) /* line 121 */ ?></td>
<?php
			$iterations++;
		}
?>
          </tbody>
          <tbody>
            <td></td>
             <td></td>
              <td>TOTAL</td>
              <td><?php echo LR\Filters::escapeHtmlText($students['inscribed']) /* line 128 */ ?></td>
              <td><?php echo LR\Filters::escapeHtmlText($students['evaluated']) /* line 129 */ ?></td>
          </tbody>
          <tbody>
            <td></td>
             <td></td>
              <td>PORCENTAJE DE ALUMNOS EVALUADOS</td>
              <td></td>
              <td><?php echo LR\Filters::escapeHtmlText($students['percentage']) /* line 136 */ ?>%</td>
          </tbody>
        </table>
        </div>
 <p></p>
        <div>
        <table  class="centered">
          <thead>
            <tr>
            <th>ASPECTO</th>
            <th>PUNTAJE</th>
            <th>DESEMPEÑO</th>
            </tr>
          </thead>
          <tbody>
<?php
		$iterations = 0;
		foreach ($average_teacher as $teacherResult) {
?>
              <tr>

              <td><?php echo LR\Filters::escapeHtmlText($teacherResult['dimension']) /* line 154 */ ?></td>
              <td><?php echo LR\Filters::escapeHtmlText($teacherResult['average']) /* line 155 */ ?></td>
              <td><?php echo LR\Filters::escapeHtmlText($teacherResult['status']) /* line 156 */ ?></td>
<?php
			$iterations++;
		}
?>
          </tbody>
        </table>
        </div>
      </div>


<div class="container section">
<script>
let dimension = [];
let status = [];
let average = [];
</script>

<?php
		$iterations = 0;
		foreach ($average_teacher as $datos) {
?>
  <script>
    dimension.push(<?php echo LR\Filters::escapeJs($datos['dimension']) /* line 173 */ ?>);
    status.push(<?php echo LR\Filters::escapeJs($datos['status']) /* line 174 */ ?>);
    average.push(<?php echo LR\Filters::escapeJs($datos['average']) /* line 175 */ ?>);
  </script>  
<?php
			$iterations++;
		}
?>

<div class="dona" id="dona"></div>
<script>
new Morris.Bar({
  element: 'dona',
  data: [

    { label: "A", value: average[0]},
    { label: "B", value: average[1]}, 
    { label: "C", value: average[2]}, 
    { label: "D", value: average[3]}, 
    { label: "E", value: average[4]}, 
    { label: "F", value: average[5]}, 
    { label: "G", value: average[6]}, 
    { label: "H", value: average[7]}, 
    { label: "I", value: average[8]}, 
    { label: "J", value: average[9]}, 
    { label: "K", value: average[10]}
  ],
  colors: [
    '#E0F7FA',
    '#B2EBF2',
    '#80DEEA',
    '#4DD0E1',
    '#26C6DA',
    '#00BCD4',
    '#00ACC1',
    '#0097A7',
    '#00838F',
    '#006064'
  ],
  // The name of the data record attribute that contains x-values.
  xkey: 'label',
  // A list of names of data record attributes that contain y-values.
  ykeys: ['value'],
  // Labels for the ykeys -- will be displayed when you hover over the
  // chart.
  labels: ['Resultado']
});
</script>

</div>
<form action="<?php
		echo $router->relativeUrlFor("teachersShowList");
?>" method="post">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 221 */ ?>">
            <input type="hidden" name="clave_departamento" value="<?php echo LR\Filters::escapeHtmlAttr($data['clave_departamento']) /* line 222 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 223 */ ?>">
 <input class="oculto-impresion" id="retorno" type="submit" class="btn btn-primary btn-sm" value='Retornar'>
            </form>
            </div>
<?php
		if ($students['percentage'] < 60) {
?>
              <script>
              alert("EL DOCENTE NO CUENTA CON 60% DE EVALUACION");
              </script>
<?php
		}
		else {
?>
  <button class="oculto-impresion" onclick="imprimir()">Imprimir pantalla</button>
<?php
		}
?>
<div class="saltoDePagina"></div>
 <div class="card centerd">
          <p>RESULTADOS DE LA EVALUACION DE LOS PROFESORES
          PERIODO  DEL <span><?php
		$iterations = 0;
		foreach ($period_information as $periodo) {
			echo LR\Filters::escapeHtmlText($periodo['inicia']) /* line 237 */;
			$iterations++;
		}
		?></span> A <span><?php
		$iterations = 0;
		foreach ($period_information as $periodo) {
			echo LR\Filters::escapeHtmlText($periodo['inicia']) /* line 237 */;
			$iterations++;
		}
?></span>.</p>
           <p>CUESTIONARIO PARA ALUMNOS<p>
          <p><h5>REPORTE POR PROFESOR</h5></p>
          <p>NOMBRE DEL PROFESOR: <span class="black-text"><?php echo LR\Filters::escapeHtmlText($data['docente']) /* line 240 */ ?></span></p>
          <P>NOMBRE DEL FOLIO: <span class="black-text"><?php echo LR\Filters::escapeHtmlText($data['folio']) /* line 241 */ ?></span></P>
          <p>DEPARTAMENTO: <span class="black-text"><?php echo LR\Filters::escapeHtmlText($data['clave_departamento']) /* line 242 */ ?></span></p>
      </div>


<?php
		$iterations = 0;
		foreach ($average_teacher as $teacherResult) {
			if ($teacherResult['average'] <= 3.25) {
				if ($teacherResult['dimension'] !=="RESULTADO GLOBAL") {
					?>              <p>Docente requiere capacitacion <?php echo LR\Filters::escapeHtmlText($teacherResult['dimension']) /* line 249 */ ?> </p>
<?php
				}
			}
			$iterations++;
		}
?>
            <div class="container section">
<script>
let dimension = [];
let status = [];
let average = [];
</script>

<?php
		$iterations = 0;
		foreach ($average_teacher as $datos) {
?>
  <script>
    dimension.push(<?php echo LR\Filters::escapeJs($datos['dimension']) /* line 262 */ ?>);
    status.push(<?php echo LR\Filters::escapeJs($datos['status']) /* line 263 */ ?>);
    average.push(<?php echo LR\Filters::escapeJs($datos['average']) /* line 264 */ ?>);
  </script>  
<?php
			$iterations++;
		}
?>

<div class="dona" id="dona2"></div>
<script>
new Morris.Bar({
  element: 'dona2',
  data: [

    { label: "A", value: average[0]},
    { label: "B", value: average[1]}, 
    { label: "C", value: average[2]}, 
    { label: "D", value: average[3]}, 
    { label: "E", value: average[4]}, 
    { label: "F", value: average[5]}, 
    { label: "G", value: average[6]}, 
    { label: "H", value: average[7]}, 
    { label: "I", value: average[8]}, 
    { label: "J", value: average[9]}, 
    { label: "K", value: average[10]}
  ],
  colors: [
    '#E0F7FA',
    '#B2EBF2',
    '#80DEEA',
    '#4DD0E1',
    '#26C6DA',
    '#00BCD4',
    '#00ACC1',
    '#0097A7',
    '#00838F',
    '#006064'
  ],
  // The name of the data record attribute that contains x-values.
  xkey: 'label',
  // A list of names of data record attributes that contain y-values.
  ykeys: ['value'],
  // Labels for the ykeys -- will be displayed when you hover over the
  // chart.
  labels: ['Resultado']
});
</script>

</div>
  

</body>
<script>
function imprimir() {
	window.print();
}
</script>
</html>
<?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['periodo'])) trigger_error('Variable $periodo overwritten in foreach on line 37, 237, 237');
		if (isset($this->params['teacherShow'])) trigger_error('Variable $teacherShow overwritten in foreach on line 115');
		if (isset($this->params['teacherResult'])) trigger_error('Variable $teacherResult overwritten in foreach on line 151, 246');
		if (isset($this->params['datos'])) trigger_error('Variable $datos overwritten in foreach on line 171, 260');
		
	}

}
