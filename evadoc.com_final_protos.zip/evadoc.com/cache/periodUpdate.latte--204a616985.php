<?php
// source: Periodo/periodUpdate.latte

use Latte\Runtime as LR;

class Template204a616985 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<!DOCTYPE html>
  <html>
    <head>
      <meta charset="utf-8">
      <title><?php echo LR\Filters::escapeHtmlText($title) /* line 5 */ ?></title>
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
      <script type="text/javascript" src="/materialize/js/jquery.min.js"></script>
      <script type="text/javascript" src="/materialize/js/jquery-qrcode-0.18.0.js"></script>
      <script src="/materialize/js/materialize.min.js"></script>
      <link type="text/css" rel="stylesheet" href="/materialize/css/naver.css"  media="screen,projection">
      <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
      <link type="text/css" rel="stylesheet" href="/materialize/css/formularios.css"  media="screen,projection">
<?php
		/* line 14 */
		$this->createTemplate('../validationUpdate.latte', $this->params, "include")->renderToContentType('html');
?>
    </head>
    <body>
<?php
		/* line 17 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
?>
      <ul id="nav-mobile">
      <div class="container section">
        <form name="periodUpdateForm" method="post" action="<?php
		echo $router->relativeUrlFor("periodUpdate");
?>">
          <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 21 */ ?>">
          <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 22 */ ?>">
          <input type="hidden" name="activar" value="<?php echo LR\Filters::escapeHtmlAttr($data['activar']) /* line 23 */ ?>"> 
          <ul>
            <li>
              <label><input type="hidden" id="id" name="id" value="<?php echo LR\Filters::escapeHtmlAttr($data['id']) /* line 26 */ ?>" class="validate"></label>
            </li>
            <li>
              <label for="nombre">Nombre:</label>
              <label><input type="text" id="nombre" name="nombre" value="<?php echo LR\Filters::escapeHtmlAttr($data['nombre']) /* line 30 */ ?>" class="validate"></label>
            </li>
            <li>
              <label for="inicia">Inicia:</label>
              <input type="date" id="inicia" name="inicia" value="<?php echo LR\Filters::escapeHtmlAttr($data['inicia']) /* line 34 */ ?>" class="validate" min="2021-01-01" max="2100-01-01">
            </li>
            <li>
              <label for="termina">Termina:</label>
              <input type="date" id="termina" name="termina" value="<?php echo LR\Filters::escapeHtmlAttr($data['termina']) /* line 38 */ ?>" class="validate" min="2021-01-01" max="2100-01-01">
            </li>
          </ul>
          <label for="activar">Estado del periodo</label>
          <select class="browser-default" name="activar">
          <option value="" name="activar"><?php
		if ($data['activar'] == 1) {
?>Activo
            <?php
		}
		else {
?>No activo
<?php
		}
?>
         </option>
        <option value=1>Activo</option>
        <option value=0>No activo</option>
        </select>
        <button id="guardar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Guardar<i class="material-icons left">send</i></button>
      </div>
    </form>
    <div>
    <form action="<?php
		echo $router->relativeUrlFor("showAllPeriods");
?>" method="post">
      <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 55 */ ?>">
      <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 56 */ ?>">
      <button id="retornar" type="submit" class="btn btn-primary btn-sm float-1" style="background-color: #10c2ee" >Retornar<i class="material-icons left">arrow_back</i></button>
      </form>
    </div>
  </div>
   <!--footer -->
  <div class="content"></div>
  <div class="footer-copyright blue-grey lighten-3" >
    <div class="container">
      <img class="header container section" src="/materialize/css/pie.jpg">
    </div>
  </div>
</footer>
</body>
 <script src="/materialize/validations/resources.js" type="text/javascript"></script>
</html>
<?php
		return get_defined_vars();
	}

}
