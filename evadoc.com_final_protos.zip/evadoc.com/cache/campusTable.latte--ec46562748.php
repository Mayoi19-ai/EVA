<?php
// source: Campus/campusTable.latte

use Latte\Runtime as LR;

class Templateec46562748 extends Latte\Runtime\Template
{
	public $blocks = [
		'content' => 'blockContent',
	];

	public $blockTypes = [
		'content' => 'html',
	];


	function main()
	{
		extract($this->params);
		/* line 1 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
		/* line 2 */
		$this->createTemplate('../validationDelete.latte', $this->params, "include")->renderToContentType('html');
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('content', get_defined_vars());
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['permissionInfor'])) trigger_error('Variable $permissionInfor overwritten in foreach on line 51, 66, 81');
		if (isset($this->params['campusShow'])) trigger_error('Variable $campusShow overwritten in foreach on line 40');
		
	}


	function blockContent($_args)
	{
		extract($_args);
?>
            <!DOCTYPE html>
                <html>
                    <head>
                        <meta charset="utf-8">
                            <title><?php echo LR\Filters::escapeHtmlText($title) /* line 8 */ ?></title>
                            <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
                            <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
                            <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
                        </head>
                        <body>
                        <!-- -->
<?php
		if (empty ($query)) {
?>
                            <div class="container section">
                                <div class="card center">
                                    <div class="card center">
                                    <img class="logo" src="/materialize/css/alerta3.png">
                                        <h5>NO HAY CAMPUS DISPONIBLES</h5>
                                          <form action="<?php
			echo $router->relativeUrlFor("userMenu");
?>" method="post">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 22 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 23 */ ?>">
 <input id="retorno" type="submit" class="btn btn-primary btn-sm" value='Retornar'>
            </form>
                                    </div>
                                </div>
                            </div>
<?php
		}
		else {
?>
                            <div class=" responsive-table" >
                                <table name="showAllModalities" method="get" class="bordered striped hoverable centered responsive-table">
                                    <thead>
                                        <tr>
                                            <th>Campus</th>
                                            <th></th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                        <tbody>
<?php
			$iterations = 0;
			foreach ($query as $campusShow) {
?>
                                                <tr>
                                                    <td><?php echo LR\Filters::escapeHtmlText($campusShow['nombre']) /* line 42 */ ?> </td>
                                                    <td>
                                                        <form action="<?php
				echo $router->relativeUrlFor("campusUpdateForm");
?>" method="post">
                                                            <input type="hidden" name="nombre" value="<?php
				echo LR\Filters::escapeHtmlAttr($campusShow['nombre']) /* line 45 */ ?>">
                                                            <input type="hidden" name="id" value="<?php echo LR\Filters::escapeHtmlAttr($campusShow['id']) /* line 46 */ ?>">
                                                            <!--No borrar -->
                                                            <input type="hidden" name="usuario_activo" value="<?php
				echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 48 */ ?>">
                                                            <input type="hidden" name="categoria_permisos" value="<?php
				echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 49 */ ?>">
                                                            <!--No borrar -->
<?php
				$iterations = 0;
				foreach ($permissions as $permissionInfor) {
					$permisos  = explode(" - ", $permissionInfor['enlace']);
					;
					if ($permisos[1] == "campusUpdateForm") {
?>
                                                                           <button id="actualizar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Editar<i class="material-icons left">edit</i></button>
<?php
					}
					$iterations++;
				}
?>
                                                        </form>
                                                    </td>
                                                    <td>
                                                        <form action="<?php
				echo $router->relativeUrlFor("campusDelete");
?>" method="post" onsubmit="return confirmation()">
                                                            <input type="hidden" name="id" value="<?php echo LR\Filters::escapeHtmlAttr($campusShow['id']) /* line 61 */ ?>">
                                                            <!-- No tocar lo de abajo-->
                                                            <input type="hidden" name="usuario_activo" value="<?php
				echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 63 */ ?>">
                                                            <input type="hidden" name="categoria_permisos" value="<?php
				echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 64 */ ?>">
                                                            <!--No tocar lo de arriba -->
<?php
				$iterations = 0;
				foreach ($permissions as $permissionInfor) {
					$permisos  = explode(" - ", $permissionInfor['enlace']);
					;
					if ($permisos[1] == "campusDelete") {
?>
                                                                          <button type="submit" id="eliminar" style="background-color: #f44336" class="btn btn-primary btn-sm #f44336" >Eliminar<i class="material-icons left">delete</i></button>
<?php
					}
					$iterations++;
				}
?>
                                                            </form>
                                                        </td>
                                                </tr>
<?php
				$iterations++;
			}
?>
                                        </tbody>
                                            <form action="<?php
			echo $router->relativeUrlFor("campusSaveForm");
?>" method="post">
                                                <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 78 */ ?>">
                                                <input type="hidden" name="categoria_permisos" value="<?php
			echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 79 */ ?>">
                                                    <div class="fixed-action-btn">
<?php
			$iterations = 0;
			foreach ($permissions as $permissionInfor) {
				$permisos  = explode(" - ", $permissionInfor['enlace']);
				;
				if ($permisos[1] == "campusSaveForm") {
?>
                                                                    <button type="submit" class="float" ><i class="material-icons center">add</i></button>
<?php
				}
				$iterations++;
			}
		}
?>
                                                </form>
                                            </table>
                                        </div>
                                    <!--footer -->
                                        <div class="content"></div>
            <div class="footer-copyright blue-grey lighten-3" >
            <div class="container">
           <img class="header container section" src="/materialize/css/pie.jpg">
            </div>
          </div>
        </footer>
                                        </body>
                                    <script> M.AutoInit(); </script>
                                </html>
<?php
	}

}
