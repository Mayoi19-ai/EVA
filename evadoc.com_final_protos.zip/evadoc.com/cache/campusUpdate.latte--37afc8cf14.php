<?php
// source: Campus/campusUpdate.latte

use Latte\Runtime as LR;

class Template37afc8cf14 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		/* line 1 */
		$this->createTemplate('../validationUpdate.latte', $this->params, "include")->renderToContentType('html');
		/* line 2 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
?>
    <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <title><?php echo LR\Filters::escapeHtmlText($title) /* line 7 */ ?></title>
          <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
          <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
          <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
          <link type="text/css" rel="stylesheet" href="/materialize/css/formularios.css"  media="screen,projection">
        </head>
        <body>
          <div class="container section">
            <form name="campusUpdateForm" method="post" action="<?php
		echo $router->relativeUrlFor("campusUpdate");
?>">
              <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 16 */ ?>">
              <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 17 */ ?>">
              <input type="hidden" id="id" name="id" value="<?php echo LR\Filters::escapeHtmlAttr($data['id']) /* line 18 */ ?>" class="validate">
              <label for="name">Nombre:</label>
              <input type="text" id="nombre" name="nombre" value="<?php echo LR\Filters::escapeHtmlAttr($data['nombre']) /* line 20 */ ?>" class="validate">
             <button id="guardar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Guardar<i class="material-icons left">send</i></button>
          </div>
            </form>
            <form action="<?php
		echo $router->relativeUrlFor("showAllCampuses");
?>" method="post">
              <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 25 */ ?>">
              <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 26 */ ?>">
              <button id="retornar" type="submit" class="btn btn-primary btn-sm float-1" style="background-color: #10c2ee" >Retornar<i class="material-icons left">arrow_back</i></button>
            </form>
         
            <!--footer -->
             <div class="content"></div>
            <div class="footer-copyright blue-grey lighten-3" >
            <div class="container">
           <img class="header container section" src="/materialize/css/pie.jpg">
            </div>
          </div>
        </footer>
            </body>
          <script> M.AutoInit(); </script>
        </html><?php
		return get_defined_vars();
	}

}
