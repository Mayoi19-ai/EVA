<?php
// source: Inscripcion/inscriptionUpdate.latte

use Latte\Runtime as LR;

class Templatedd5222b479 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<!DOCTYPE html>
  <html>
    <head>
      <meta charset="utf-8">
       <title><?php echo LR\Filters::escapeHtmlText($title) /* line 5 */ ?></title>
       <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
       <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script type="text/javascript" src="/materialize/js/jquery.min.js"></script>
       <script type="text/javascript" src="/materialize/js/jquery-qrcode-0.18.0.js"></script>
       <script src="/materialize/js/materialize.min.js"></script>
       <link type="text/css" rel="stylesheet" href="/materialize/css/naver.css"  media="screen,projection">
       <script src="/materialize/validations/delete.js"></script>
       <script src="/materialize/validations/sellect.js"></script>
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js%22%3E"></script>
       <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js%22%3E"></script>
       <script src="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.6/js/standalone/selectize.min.js" integrity="sha256-+C0A5Ilqmu4QcSPxrlGpaZxJ04VjsRjKu+G82kl5UJk=" crossorigin="anonymous"></script>
       <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.6/css/selectize.bootstrap3.min.css" integrity="sha256-ze/OEYGcFbPRmvCnrSeKbRTtjG4vGLHXgOqsyLFTRjg=" crossorigin="anonymous">
       <link type="text/css" rel="stylesheet" href="/materialize/css/selectize.bootstrap3.min.css"  media="screen,projection">
       <link type="text/css" rel="stylesheet" href="/materialize/css/formularios.css"  media="screen,projection">
<?php
		/* line 20 */
		$this->createTemplate('../validationUpdate.latte', $this->params, "include")->renderToContentType('html');
?>
    </head>
    <body>
<?php
		/* line 23 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
?>
       <ul id="nav-mobile">
        <div class="container section">
          <form name="inscriptionUpdateForm" method="post" action="<?php
		echo $router->relativeUrlFor("inscriptionUpdate");
?>">
            <input type="hidden" name="id" value="<?php echo LR\Filters::escapeHtmlAttr($data['id']) /* line 27 */ ?>">
            <input type="hidden" name="id_curso" value="<?php echo LR\Filters::escapeHtmlAttr($data['id_curso']) /* line 28 */ ?>">
            <input type="hidden" name="control" value="<?php echo LR\Filters::escapeHtmlAttr($data['control']) /* line 29 */ ?>">
            <input type="hidden" name="nombre" value="<?php echo LR\Filters::escapeHtmlAttr($data['nombre']) /* line 30 */ ?>">
            <input type="hidden" name="grupo" value="<?php echo LR\Filters::escapeHtmlAttr($data['grupo']) /* line 31 */ ?>">
            <input type="hidden" name="carrera" value="<?php echo LR\Filters::escapeHtmlAttr($data['carrera']) /* line 32 */ ?>">
            <input type="hidden" name="asignatura" value="<?php echo LR\Filters::escapeHtmlAttr($data['asignatura']) /* line 33 */ ?>">
            <input type="hidden" name="docente" value="<?php echo LR\Filters::escapeHtmlAttr($data['docente']) /* line 34 */ ?>">
            <input type="hidden" name="activar" value="<?php echo LR\Filters::escapeHtmlAttr($data['activar']) /* line 35 */ ?>">
            <!-- -->
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 37 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 38 */ ?>">
            <!-- -->
            <ul>
              <li>
                <label><input type="hidden" id="id" name="id" value="<?php echo LR\Filters::escapeHtmlAttr($data['id']) /* line 42 */ ?>" class="validate"></label>
              </li>
              <li>
                <label for="id_curso">Selecciona un curso:</label>
                <select  class="browser-default"  name="id_curso" >
                <option value="<?php echo LR\Filters::escapeHtmlAttr($data['id_curso']) /* line 47 */ ?>" name="id_curso"><?php
		echo LR\Filters::escapeHtmlText($data['grupo']) /* line 47 */ ?> - <?php echo LR\Filters::escapeHtmlText($data['carrera']) /* line 47 */ ?> - <?php
		echo LR\Filters::escapeHtmlText($data['asignatura']) /* line 47 */ ?> - <?php echo LR\Filters::escapeHtmlText($data['docente']) /* line 47 */ ?></option>
<?php
		$iterations = 0;
		foreach ($all_courses_information as $cursoOption) {
			?>                <option  value="<?php echo LR\Filters::escapeHtmlAttr($cursoOption['id_curso']) /* line 49 */ ?>"><?php
			echo LR\Filters::escapeHtmlText($cursoOption['grupo']) /* line 49 */ ?> - <?php echo LR\Filters::escapeHtmlText($cursoOption['carrera']) /* line 49 */ ?> - <?php
			echo LR\Filters::escapeHtmlText($cursoOption['asignatura']) /* line 49 */ ?> - <?php echo LR\Filters::escapeHtmlText($cursoOption['docente']) /* line 49 */ ?></option>
<?php
			$iterations++;
		}
?>
                </select>
              </li>
              <li>
                <label for="id_curso">Selecciona un alumno:</label>
                <select name="control" class="browser-default">
                <option value="<?php echo LR\Filters::escapeHtmlAttr($data['control']) /* line 56 */ ?>" name="control"><?php
		echo LR\Filters::escapeHtmlText($data['control']) /* line 56 */ ?> - <?php echo LR\Filters::escapeHtmlText($data['nombre']) /* line 56 */ ?></option>
<?php
		$iterations = 0;
		foreach ($all_students_information as $controlOption) {
			?>                <option  value="<?php echo LR\Filters::escapeHtmlAttr($controlOption['control']) /* line 58 */ ?>" ><?php
			echo LR\Filters::escapeHtmlText($controlOption['control']) /* line 58 */ ?> - <?php echo LR\Filters::escapeHtmlText($controlOption['nombre']) /* line 58 */ ?></option> 
<?php
			$iterations++;
		}
?>
                </select>
              </li>
                <label for="activar">Estado de inscripcion</label>
                <select name="activar"  class="browser-default">
                <option value="<?php echo LR\Filters::escapeHtmlAttr($data['activar']) /* line 64 */ ?>" name="activar"><?php
		if ($data['activar'] == 1) {
?>Activo
                  <?php
		}
		else {
?>No activo
<?php
		}
?>
               </option>
              <option value=1>Activo</option>
              <option value=0>No activo</option>
              </select>   
              <button id="guardar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Guardar<i class="material-icons left">send</i></button>
            </div>
          </form>
          <div>
            <form action="<?php
		echo $router->relativeUrlFor("showAllInscriptions");
?>" method="post">
              <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 76 */ ?>">
              <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 77 */ ?>">
              <button id="retornar" type="submit" class="btn btn-primary btn-sm float-1" style="background-color: #10c2ee" >Retornar<i class="material-icons left">arrow_back</i></button>
            </form>
          </div>

    <!--footer -->
          <div class="content"></div>
          <div class="footer-copyright blue-grey lighten-3" >
           <div class="container">
             <img class="header container section" src="/materialize/css/pie.jpg">
            </div>
          </div>
        </footer>
</body>

 <script src="/materialize/validations/resources.js" type="text/javascript"></script>
</html>
<?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['cursoOption'])) trigger_error('Variable $cursoOption overwritten in foreach on line 48');
		if (isset($this->params['controlOption'])) trigger_error('Variable $controlOption overwritten in foreach on line 57');
		
	}

}
