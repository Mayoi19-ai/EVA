<?php
// source: RolesPermisos/permissionsRForm.latte

use Latte\Runtime as LR;

class Template82efa83e5e extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		/* line 1 */
		$this->createTemplate('../validationCreate.latte', $this->params, "include")->renderToContentType('html');
		/* line 2 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 7 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
       <link type="text/css" rel="stylesheet" href="/materialize/css/formularios.css"  media="screen,projection">
</head>
<body>
 <ul id="nav-mobile">
<form name="rolePermissionsSaveForm" method="post" action="<?php
		echo $router->relativeUrlFor("rolePermissionsRegister");
?>">
  <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 16 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 17 */ ?>">

  <div class="container section">
  <label>Selecciona un rol</label>
 <select class="browser-default" name="id_roles">
      <option value="" name="id">Seleccionar un rol</option>
<?php
		$iterations = 0;
		foreach ($roles as $rolesOption) {
			?>      <option  value="<?php echo LR\Filters::escapeHtmlAttr($rolesOption['id']) /* line 24 */ ?>"><?php
			echo LR\Filters::escapeHtmlText($rolesOption['nombre']) /* line 24 */ ?></option>
<?php
			$iterations++;
		}
?>
    </select>

<label>Selecciona un permiso</label>
  <select class="browser-default" name="id_permisos">
  <option value="" name="id" >Selecciona permiso</option>
<?php
		$iterations = 0;
		foreach ($permissions as $permisosOption) {
			?>      <option  value="<?php echo LR\Filters::escapeHtmlAttr($permisosOption['id']) /* line 32 */ ?>" ><?php
			echo LR\Filters::escapeHtmlText($permisosOption['categoria']) /* line 32 */ ?> - <?php echo LR\Filters::escapeHtmlText($permisosOption['nombre']) /* line 32 */ ?></option>
<?php
			$iterations++;
		}
?>
  </select>
  
<button id="guardar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Guardar<i class="material-icons left">send</i></button>
</div>
</form>
<div>
<form action="<?php
		echo $router->relativeUrlFor("showAllRolePermissions");
?>" method="post">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 41 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 42 */ ?>">
 <button id="retornar" type="submit" class="btn btn-primary btn-sm float-1" style="background-color: #10c2ee" >Retornar<i class="material-icons left">arrow_back</i></button>
            </form>
            </div>
     <!--footer -->
                   <div class="content"></div>
            <div class="footer-copyright blue-grey lighten-3" >
            <div class="container">
           <img class="header container section" src="/materialize/css/pie.jpg">
            </div>
          </div>
        </footer>
</body>
 <script>M.AutoInit();</script>
</html><?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['rolesOption'])) trigger_error('Variable $rolesOption overwritten in foreach on line 23');
		if (isset($this->params['permisosOption'])) trigger_error('Variable $permisosOption overwritten in foreach on line 31');
		
	}

}
