<?php
// source: Materia/subjectTable.latte

use Latte\Runtime as LR;

class Templateb11e5c6f9a extends Latte\Runtime\Template
{
	public $blocks = [
		'content' => 'blockContent',
	];

	public $blockTypes = [
		'content' => 'html',
	];


	function main()
	{
		extract($this->params);
		/* line 1 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
		/* line 2 */
		$this->createTemplate('../validationDelete.latte', $this->params, "include")->renderToContentType('html');
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('content', get_defined_vars());
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['searchOption'])) trigger_error('Variable $searchOption overwritten in foreach on line 36');
		if (isset($this->params['permissionInfor'])) trigger_error('Variable $permissionInfor overwritten in foreach on line 89, 105, 122');
		if (isset($this->params['subjecttShow'])) trigger_error('Variable $subjecttShow overwritten in foreach on line 75');
		
	}


	function blockContent($_args)
	{
		extract($_args);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 9 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
      <link type="text/css" rel="stylesheet" href="/materialize/css/formularios.css"  media="screen,projection">
</head>
<body>
<div class="container section">
<ul id="nav-mobile">
                <div class="row">
                <div class="col s12 m6 l3">
<form name="SearchForm" method="post" action="<?php
		echo $router->relativeUrlFor("subjectSearchByLesson");
?>">
<label for="asignatura">Busqueda por asignatura<label>
          <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 22 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 23 */ ?>">
             <input type="text" name="asignatura">
 <button id="buscar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee">Buscar<i class="material-icons left">search</i></button>
</div>
</form>
    <div class="col s12 m6 l3">
<form name="SearchForm" method="post" action="<?php
		echo $router->relativeUrlFor("lessonShowByCareer");
?>">
<label for="nombre">Busqueda por carrera<label>
          <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 31 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 32 */ ?>">

      <select class="browser-default" name="id_career">
      <option value="<?php echo LR\Filters::escapeHtmlAttr($data['id']) /* line 35 */ ?>" name="id_career"></option>
<?php
		$iterations = 0;
		foreach ($all_careers_information as $searchOption) {
			?>      <option  value="<?php echo LR\Filters::escapeHtmlAttr($searchOption['id']) /* line 37 */ ?>" ><?php
			echo LR\Filters::escapeHtmlText($searchOption['nombre']) /* line 37 */ ?> </option>
<?php
			$iterations++;
		}
?>
    </select>
 
  <button id="buscar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee">Buscar<i class="material-icons left">search</i></button>
</form>
</div>
</div>
</div>
<!-- -->
<?php
		if (empty ($query)) {
?>
       <div class="container section">
       <div class="card center">
              <div class="card center">
                  <img class="logo" src="/materialize/css/alerta3.png">
                     <h5>NO HAY MATERIA DISPONIBLE</h5>
                     <form action="<?php
			echo $router->relativeUrlFor("userMenu");
?>" method="post">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 54 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 55 */ ?>">
 <input id="retorno" type="submit" class="btn btn-primary btn-sm" value='Retornar'>
            </form>
                    
              </div>
       </div>
</div>

<?php
		}
		else {
?>
<table name="showAllDepartment" method="get" class="bordered striped hoverable centered responsive-table"> <!-- nombre de tabla-->
 <thead>
</tr>
<tr>
<th>Carrera</th>
<th>Asignatura</th>
<th></th>
<th></th>
</tr>
</thead>
<tbody>
<?php
			$iterations = 0;
			foreach ($query as $subjecttShow) {
?>
<tr>
    <td><?php echo LR\Filters::escapeHtmlText($subjecttShow['carrera']) /* line 77 */ ?> </td>
    <td><?php echo LR\Filters::escapeHtmlText($subjecttShow['asignatura']) /* line 78 */ ?> </td>
    <td>
<form action="<?php
				echo $router->relativeUrlFor("subjectUpdateForm");
?>" method="post">
            <input type="hidden" name="id_carrera" value="<?php echo LR\Filters::escapeHtmlAttr($subjecttShow['id_carrera']) /* line 81 */ ?>">
             <input type="hidden" name="clave_asignatura" value="<?php echo LR\Filters::escapeHtmlAttr($subjecttShow['clave_asignatura']) /* line 82 */ ?>">
             <input type="hidden" name="carrera" value="<?php echo LR\Filters::escapeHtmlAttr($subjecttShow['carrera']) /* line 83 */ ?>">
             <input type="hidden" name="asignatura" value="<?php echo LR\Filters::escapeHtmlAttr($subjecttShow['asignatura']) /* line 84 */ ?>">
             <!--No borrar -->
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 86 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 87 */ ?>">
            <!--No borrar -->
<?php
				$iterations = 0;
				foreach ($permissions as $permissionInfor) {
					$permisos  = explode(" - ", $permissionInfor['enlace']);
					;
					if ($permisos[1] == "subjectUpdateForm") {
?>
       <button id="actualizar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Editar<i class="material-icons left">edit</i></button>
<?php
					}
					$iterations++;
				}
?>
</form>
</td>
<td>
    <form action="<?php
				echo $router->relativeUrlFor("subjectDelete");
?>" method="post" onsubmit="return confirmation()">
            <input type="hidden" name="id_carrera" value="<?php echo LR\Filters::escapeHtmlAttr($subjecttShow['id_carrera']) /* line 99 */ ?>">
             <input type="hidden" name="clave_asignatura" value="<?php echo LR\Filters::escapeHtmlAttr($subjecttShow['clave_asignatura']) /* line 100 */ ?>">
            <!-- No tocar lo de abajo-->
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 102 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 103 */ ?>">
            <!--No tocar lo de arriba -->
<?php
				$iterations = 0;
				foreach ($permissions as $permissionInfor) {
					$permisos  = explode(" - ", $permissionInfor['enlace']);
					;
					if ($permisos[1] == "subjectDelete") {
?>
    <button type="submit" id="eliminar" style="background-color: #f44336" class="btn btn-primary btn-sm #f44336" value='Eliminar'>Eliminar<i class="material-icons left">delete</i></button>
<?php
					}
					$iterations++;
				}
?>
    </form>
</td>

</tr>
<?php
				$iterations++;
			}
?>

</tbody>
 <form action="<?php
			echo $router->relativeUrlFor("subjectSaveForm");
?>" method="post">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 119 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 120 */ ?>">
   <div class="fixed-action-btn">
<?php
			$iterations = 0;
			foreach ($permissions as $permissionInfor) {
				$permisos  = explode(" - ", $permissionInfor['enlace']);
				;
				if ($permisos[1] == "subjectSaveForm") {
?>
<button type="submit" class="float" ><i class="material-icons center">add</i></button>
<?php
				}
				$iterations++;
			}
		}
?>
</form>
</table>
</div>
<!--footer -->
                   <div class="content"></div>
            <div class="footer-copyright blue-grey lighten-3" >
            <div class="container">
           <img class="header container section" src="/materialize/css/pie.jpg">
            </div>
          </div>
        </footer>
</body>
<script> M.AutoInit(); </script>
</html>
<?php
	}

}
