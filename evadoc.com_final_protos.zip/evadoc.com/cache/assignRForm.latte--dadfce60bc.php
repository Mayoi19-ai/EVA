<?php
// source: AsignarR/assignRForm.latte

use Latte\Runtime as LR;

class Templatedadfce60bc extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<!DOCTYPE html>
  <html>
    <head>
      <meta charset="utf-8">
      <title><?php echo LR\Filters::escapeHtmlText($title) /* line 5 */ ?></title>
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
      <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
      <link type="text/css" rel="stylesheet" href="/materialize/css/formularios.css"  media="screen,projection">
      <script type="text/javascript" src="/materialize/js/jquery.min.js"></script>
      <script type="text/javascript" src="/materialize/js/jquery-qrcode-0.18.0.js"></script>
      <script src="/materialize/js/materialize.min.js"></script>
      <link type="text/css" rel="stylesheet" href="/materialize/css/naver.css"  media="screen,projection">
      <script src="/materialize/validations/sellect.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js%22%3E"></script>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js%22%3E"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.6/js/standalone/selectize.min.js" integrity="sha256-+C0A5Ilqmu4QcSPxrlGpaZxJ04VjsRjKu+G82kl5UJk=" crossorigin="anonymous"></script>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.6/css/selectize.bootstrap3.min.css" integrity="sha256-ze/OEYGcFbPRmvCnrSeKbRTtjG4vGLHXgOqsyLFTRjg=" crossorigin="anonymous">
      <link type="text/css" rel="stylesheet" href="/materialize/css/formularios.css"  media="screen,projection">
<?php
		/* line 20 */
		$this->createTemplate('../validationCreate.latte', $this->params, "include")->renderToContentType('html');
?>
    </head>
    <body>
<?php
		/* line 23 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
?>
        <ul id="nav-mobile">
          <div class="container section">
            <form name="userRolesSaveForm" method="post" action="<?php
		echo $router->relativeUrlFor("userRolesRegister");
?>">
              <input type="hidden" name="nombre"  id="nombre">
                <label>Usuario: </label>
                <select class="browser-default" name="id_usuario">
                <option class="browser-default" value="" name="id" >Selecciona usuario</option>
<?php
		$iterations = 0;
		foreach ($users as $usuario) {
			?>                <option  value="<?php echo LR\Filters::escapeHtmlAttr($usuario['id']) /* line 32 */ ?>" ><?php
			echo LR\Filters::escapeHtmlText($usuario['nombre']) /* line 32 */ ?></option>
<?php
			$iterations++;
		}
?>
              </select>
              <label>Roles: </label>
                <select class="browser-default" name="id_roles" id="id">
                <option value="" name="id" >Selecciona rol</option>
<?php
		$iterations = 0;
		foreach ($roles as $rol) {
			?>                  <option  value="<?php echo LR\Filters::escapeHtmlAttr($rol['id']) /* line 39 */ ?>" ><?php
			echo LR\Filters::escapeHtmlText($rol['nombre']) /* line 39 */ ?></option>
<?php
			$iterations++;
		}
?>
              </select>
                <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 42 */ ?>">
                <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 43 */ ?>">
                <button id="guardar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Guardar<i class="material-icons left">send</i></button>
              </div>
            </form>
            <div>
              <form action="<?php
		echo $router->relativeUrlFor("showAllUserRoles");
?>" method="post">
                <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 49 */ ?>">
                <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 50 */ ?>">
                <button id="retornar" type="submit" class="btn btn-primary btn-sm float-1" style="background-color: #10c2ee" >Retornar<i class="material-icons left">arrow_back</i></button>
              </form>
            </div>
            <div class="content"></div>
            <div class="footer-copyright blue-grey lighten-3" >
              <div class="container">
                <img class="header container section" src="/materialize/css/pie.jpg">
              </div>
          </div>
        </footer>
</body>
 <script src="/materialize/validations/resources.js" type="text/javascript"></script>
</html><?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['usuario'])) trigger_error('Variable $usuario overwritten in foreach on line 31');
		if (isset($this->params['rol'])) trigger_error('Variable $rol overwritten in foreach on line 38');
		
	}

}
