<?php
// source: Inscripcion/inscriptionTableCareer.latte

use Latte\Runtime as LR;

class Template494fc18c8e extends Latte\Runtime\Template
{
	public $blocks = [
		'content' => 'blockContent',
	];

	public $blockTypes = [
		'content' => 'html',
	];


	function main()
	{
		extract($this->params);
		/* line 1 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
		/* line 2 */
		$this->createTemplate('../validationDelete.latte', $this->params, "include")->renderToContentType('html');
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('content', get_defined_vars());
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['permissionInfor'])) trigger_error('Variable $permissionInfor overwritten in foreach on line 65');
		if (isset($this->params['inscriptionShow'])) trigger_error('Variable $inscriptionShow overwritten in foreach on line 45');
		
	}


	function blockContent($_args)
	{
		extract($_args);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 9 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
      
</head>

<body>

<!-- -->
<?php
		if (empty ($query)) {
?>
       <div class="container section">
       <div class="card center">
              <div class="card center">
              <img class="logo" src="/materialize/css/alerta3.png">
                     <H5>NO HAY CARRERA DISPONIBLE</H5>
                    
              </div>
       </div>
</div>

<?php
		}
		else {
?>

<div class="MiTabla" class="container setcion responsive-table" >
<table name="showAllInscription" method="get" class="bordered striped hoverable centered responsive-table"> <!-- nombre de tabla-->
<thead>
<tr>
<th>Carrera</th>
<th>Estado de la carrera</th>


<th></th>
<th></th>
</tr>
</thead>
<tbody>
<?php
			$iterations = 0;
			foreach ($query as $inscriptionShow) {
?>
<tr>
    
     <td><?php echo LR\Filters::escapeHtmlText($inscriptionShow['carrera']) /* line 48 */ ?> </td>

        
    
<td>
    <form action="<?php
				echo $router->relativeUrlFor("inscriptionUpdateByCareer");
?>" method="post">
             <input type="hidden" name="id_carrera" value="<?php echo LR\Filters::escapeHtmlAttr($inscriptionShow['id_carrera']) /* line 54 */ ?>">

<?php
				if ($inscriptionShow['activar'] == 1) {
?>
                        <input type="hidden" name="activar" value=0>
<?php
				}
				else {
?>
                        <input type="hidden" name="activar" value=1>
<?php
				}
?>
            <!-- No tocar lo de abajo-->
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 62 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 63 */ ?>">
            <!--No tocar lo de arriba -->
<?php
				$iterations = 0;
				foreach ($permissions as $permissionInfor) {
					$permisos  = explode(" - ", $permissionInfor['enlace']);
					;
					if ($permisos[1] == "inscriptionUpdateByCareer") {
						if ($inscriptionShow['activar'] == 1) {
?>
                        <input type="submit"  class="btn btn-primary btn-sm #f44336" value='Activo'>
<?php
						}
						else {
?>
                        <input type="submit"  style="background-color: #f44336" class="btn btn-primary btn-sm #f44336" value='No activo'>
<?php
						}
					}
					$iterations++;
				}
?>
    </form>
</td>

</tr>
<?php
				$iterations++;
			}
?>

</tbody>

<?php
		}
?>
</form>
</table>
</div>
 <div class="content"></div>
            <div class="footer-copyright blue-grey lighten-3" >
            <div class="container">
           <img class="header container section" src="/materialize/css/pie.jpg">
            </div>
          </div>
        </footer>
</body>
<script> M.AutoInit(); </script>
</html>
<?php
	}

}
