<?php
// source: Inscripcion/inscriptionTable.latte

use Latte\Runtime as LR;

class Templated28e472438 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 6 */ ?></title>
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
      <script type="text/javascript" src="/materialize/js/jquery.min.js"></script>
      <script type="text/javascript" src="/materialize/js/jquery-qrcode-0.18.0.js"></script>
      <script src="/materialize/js/materialize.min.js"></script>
      <link type="text/css" rel="stylesheet" href="/materialize/css/naver.css"  media="screen,projection">
      <script src="/materialize/validations/delete.js"></script>
       <script src="/materialize/validations/sellect.js"></script>
         <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
</head>

<body>
<?php
		/* line 20 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
?>
<div class="container section">
<ul id="nav-mobile">
                <div class="row">
                <div class="col s12 m6 l3">
<form name="showAllStudent" method="post" action="<?php
		echo $router->relativeUrlFor("inscriptionSearchByStudent");
?>">
          <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 26 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 27 */ ?>">
  <label for="control">Buscar número de control</label>
            <input type="text" name="control">

  <button id="buscar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee">Buscar<i class="material-icons left">search</i></button>
</div>
</form> 
<div class="col s12 m6 l3">
<form action="<?php
		echo $router->relativeUrlFor("inscriptionShowByGroup");
?>" method="post">
            <!-- No tocar lo de abajo-->
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 37 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 38 */ ?>">
            <!--No tocar lo de arriba -->
<?php
		$iterations = 0;
		foreach ($permissions as $permissionInfor) {
			$permisos  = explode(" - ", $permissionInfor['enlace']);
			;
			if ($permisos[0] == "inscriptionShowByGroup") {
?>
    <button id="buscar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee">Actualizar grupo</button>
<?php
			}
			$iterations++;
		}
?>
</div>
    </form>
     <div class="col s12 m6 l3">
    <form action="<?php
		echo $router->relativeUrlFor("inscriptionShowByCareer");
?>" method="post">
            <!-- No tocar lo de abajo-->
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 51 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 52 */ ?>">
            <!--No tocar lo de arriba -->
<?php
		$iterations = 0;
		foreach ($permissions as $permissionInfor) {
			$permisos  = explode(" - ", $permissionInfor['enlace']);
			;
			if ($permisos[0] == "inscriptionShowByCareer") {
?>
   <button id="buscar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee">Actualizar carrera</button>
<?php
			}
			$iterations++;
		}
?>
</div>
    </form>
  </div>
</div>
<!-- -->
<?php
		if (empty ($query)) {
?>
       <div class="container section">
       <div class="card center">
              <div class="card center">
                    <img class="logo" src="/materialize/css/alerta3.png">
                        <p>NO SE CUENTA CON ALUMNOS REGISTRADOS</p>
                          <form action="<?php
			echo $router->relativeUrlFor("userMenu");
?>" method="post">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 72 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 73 */ ?>">
 <input id="retorno" type="submit" class="btn btn-primary btn-sm" value='Retornar'>
            </form>
              </div>
       </div>
</div>

<?php
		}
		else {
?>

<div class="MiTabla" class="container setcion responsive-table" >
<table name="showAllInscription" method="get" class="bordered striped hoverable centered responsive-table"> <!-- nombre de tabla-->
<thead>
<tr>
<th>Numero de control</th>
<th>Alumno</th>
<th>Grupo</th>
<th>Carrera</th>
<th>Asignatura</th>
<th>Docente</th>
<th>Estado de inscripción</th>


<th></th>
<th></th>
</tr>
</thead>
<tbody>
<?php
			$iterations = 0;
			foreach ($query as $inscriptionShow) {
?>
<tr>
    <td><?php echo LR\Filters::escapeHtmlText($inscriptionShow['control']) /* line 102 */ ?> </td>
     <td><?php echo LR\Filters::escapeHtmlText($inscriptionShow['alumno']) /* line 103 */ ?> </td>
     <td><?php echo LR\Filters::escapeHtmlText($inscriptionShow['grupo']) /* line 104 */ ?> </td>
     <td><?php echo LR\Filters::escapeHtmlText($inscriptionShow['carrera']) /* line 105 */ ?> </td>
     <td><?php echo LR\Filters::escapeHtmlText($inscriptionShow['asignatura']) /* line 106 */ ?> </td>
     <td><?php echo LR\Filters::escapeHtmlText($inscriptionShow['docente']) /* line 107 */ ?> </td>



    
<?php
				if ($inscriptionShow['activar'] == 1) {
?>
     <td>Activo </td>
<?php
				}
				else {
?>
        <td>No activo</td>
<?php
				}
?>
     <td>

<form action="<?php
				echo $router->relativeUrlFor("inscriptionUpdateForm");
?>" method="post">

            <input type="hidden" name="id" value="<?php echo LR\Filters::escapeHtmlAttr($inscriptionShow['id']) /* line 121 */ ?>">
             <input type="hidden" name="id_curso" value="<?php echo LR\Filters::escapeHtmlAttr($inscriptionShow['id_curso']) /* line 122 */ ?>">
              <input type="hidden" name="control" value="<?php echo LR\Filters::escapeHtmlAttr($inscriptionShow['control']) /* line 123 */ ?>">
               <input type="hidden" name="nombre" value="<?php echo LR\Filters::escapeHtmlAttr($inscriptionShow['alumno']) /* line 124 */ ?>">
              <input type="hidden" name="grupo" value="<?php echo LR\Filters::escapeHtmlAttr($inscriptionShow['grupo']) /* line 125 */ ?>">
              <input type="hidden" name="carrera" value="<?php echo LR\Filters::escapeHtmlAttr($inscriptionShow['carrera']) /* line 126 */ ?>">
              <input type="hidden" name="asignatura" value="<?php echo LR\Filters::escapeHtmlAttr($inscriptionShow['asignatura']) /* line 127 */ ?>">
              <input type="hidden" name="docente" value="<?php echo LR\Filters::escapeHtmlAttr($inscriptionShow['docente']) /* line 128 */ ?>">
             <input type="hidden" name="activar" value="<?php echo LR\Filters::escapeHtmlAttr($inscriptionShow['activar']) /* line 129 */ ?>">
             <!-- -->
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 131 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 132 */ ?>">
            <!-- -->
<?php
				$iterations = 0;
				foreach ($permissions as $permissionInfor) {
					$permisos  = explode(" - ", $permissionInfor['enlace']);
					;
					if ($permisos[1] == "inscriptionUpdateForm") {
?>
       <button id="actualizar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Editar<i class="material-icons left">edit</i></button>
<?php
					}
					$iterations++;
				}
?>
</form>
</td>
<td>
    <form action="<?php
				echo $router->relativeUrlFor("inscriptionDelete");
?>" method="post" onsubmit="return confirmation()">
             <input type="hidden" name="id" value="<?php echo LR\Filters::escapeHtmlAttr($inscriptionShow['id']) /* line 144 */ ?>">

            <!-- No tocar lo de abajo-->
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 147 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 148 */ ?>">
            <!--No tocar lo de arriba -->
             <form action="<?php
				echo $router->relativeUrlFor("rolePermissionsDelete");
?>" method="post" onsubmit="return confirmation()">
<?php
				$iterations = 0;
				foreach ($permissions as $permissionInfor) {
					$permisos  = explode(" - ", $permissionInfor['enlace']);
					;
					if ($permisos[1] == "inscriptionDelete") {
?>
    <button type="submit" id="eliminar" style="background-color: #f44336" class="btn btn-primary btn-sm #f44336" value='Eliminar'>Eliminar<i class="material-icons left">delete</i></button>
<?php
					}
					$iterations++;
				}
?>
    </form>
</td>

</tr>
<?php
				$iterations++;
			}
?>

</tbody>
 <form action="<?php
			echo $router->relativeUrlFor("inscriptionSaveForm");
?>" method="post">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 165 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 166 */ ?>">
   <div class="fixed-action-btn">
<?php
			$iterations = 0;
			foreach ($permissions as $permissionInfor) {
				$permisos  = explode(" - ", $permissionInfor['enlace']);
				;
				if ($permisos[1] == "inscriptionSaveForm") {
?>
<button id="agrerar" type="submit" class="btn btn-primary btn-sm float-1" style="background-color: #22DD22" >Agregar<i class="material-icons left">add</i></button>
<?php
				}
				$iterations++;
			}
		}
?>
</form>
</table>
</div>
</div>
 <!--footer -->
                   <div class="content"></div>
            <div class="footer-copyright blue-grey lighten-3" >
            <div class="container">
           <img class="header container section" src="/materialize/css/pie.jpg">
            </div>
          </div>
        </footer>
</body>
<script> M.AutoInit(); </script>
</html><?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['permissionInfor'])) trigger_error('Variable $permissionInfor overwritten in foreach on line 40, 54, 134, 151, 168');
		if (isset($this->params['inscriptionShow'])) trigger_error('Variable $inscriptionShow overwritten in foreach on line 100');
		
	}

}
