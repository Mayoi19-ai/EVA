$(document).ready(function(){
    $('#demo1').MultiFile({ 
        list: '#demo1-list'
       }); 
});
function fileValidation(){
    var fileInput = document.getElementById('demo1');
    var filePath = fileInput.value;
    var allowedExtensions = (".DBF", ".xlsx");
    if(!allowedExtensions.exec(filePath)){
        alert('Extencion no valida');
        fileInput.value = '';
        return false;
    }else{
        //Image preview
        if (fileInput.files && fileInput.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                document.getElementById('imagePreview').innerHTML = '<img src="'+e.target.result+'"/>';
            };
            reader.readAsDataURL(fileInput.files[0]);
        }
    }
}
