var $contrasenia = document.getElementById('contrasenia');
var $contrasenia_same = document.getElementById('contrasenia_same');
var $error = document.getElementById('error');
error.style.color ="red";
function Logeo(){

    var mensajesError =[];
    
    if(contrasenia.value === null || contrasenia_same.value === null){
         mensajesError.push('Datos erróneos. Por favor, inténtelo otra vez. ');
           error.innerHTML = mensajesError.join(', '); 
         return false;
    }
    if(contrasenia.value === "" || contrasenia_same.value === ""){
         mensajesError.push('Datos erróneos. Por favor, inténtelo otra vez. ');
           error.innerHTML = mensajesError.join(', '); 
         return false;
    }

    if(contrasenia.value === null && contrasenia_same.value === null){
        mensajesError.push('Datos erróneos. Por favor, inténtelo otra vez. ');
          error.innerHTML = mensajesError.join(', '); 
        return false;
    }
     if(contrasenia.value === "" && contrasenia_same.value === ""){
        mensajesError.push('Datos erróneos. Por favor, inténtelo otra vez.');
          error.innerHTML = mensajesError.join(', '); 
        return false;
    }
 
     if(contrasenia.value.length < 8 || contrasenia.value.length > 12 ){
        mensajesError.push('Datos erróneos. Se permite un minimo de 8 caracteres y maximo 12 caracteres');
          error.innerHTML = mensajesError.join(', '); 
        return false;
    }
      if(contrasenia.value != contrasenia_same.value){
        mensajesError.push('Datos erróneos. Contraseñas no coinciden');
          error.innerHTML = mensajesError.join(', '); 
        return false;
    }

 
}

