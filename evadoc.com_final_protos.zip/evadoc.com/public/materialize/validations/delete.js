function confirmation() 
{
   if(confirm("¿DESEA ELIMINAR?"))
{
  return true;
}
else
{
  return false;
}
}
