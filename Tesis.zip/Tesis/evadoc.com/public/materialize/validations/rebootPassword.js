function validarCambio() 
{
   if(confirm("¿DESEA RESTABLECER CONTRASEÑA?"))
{
  return true;
}
else
{
  return false;
}
}
