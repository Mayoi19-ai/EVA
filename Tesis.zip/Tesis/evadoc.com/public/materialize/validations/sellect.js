$(document).ready(function () {
    $('select').selectize({
      sortField: 'text'
    });
  });