M.AutoInit();
$(document).ready(function(){
 		$('.sidenav').sidenav();
 	});