<?php
// source: Reporte/printReport.latte

use Latte\Runtime as LR;

class Templateb06f8931ae extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 5 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
       <script type="text/javascript" src="/materialize/js/d3.js"></script>
       <script type="text/javascript" src="/materialize/js/d3.min.js"></script>
       <link type="text/css" rel="stylesheet" href="/materialize/css/reporte.css"  media="screen,print">
       <script src="https://unpkg.com/jspdf@latest/dist/jspdf.umd.min.js"></script>

  
       <!--graficos-->
<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>
<!-- -->
<style>
		/* cuando vayamos a imprimir ... */
		@media print{
			/* indicamos el salto de pagina */
			.saltoDePagina{
				display:block;
				page-break-before:always;
			}
		}
	</style>
</head>
<body>

<div class="container section">
   <img class="imagen" src="/materialize/css/SEP.jpg">
    
      <div class="card centerd">
          <p>RESULTADOS DE LA EVALUACION DE LOS PROFESORES
          PERIODO  DEL <span><?php
		$iterations = 0;
		foreach ($period_information as $periodo) {
			echo LR\Filters::escapeHtmlText($periodo['inicia']) /* line 39 */;
			$iterations++;
		}
		?></span> A <span><?php
		$iterations = 0;
		foreach ($period_information as $periodo) {
			echo LR\Filters::escapeHtmlText($periodo['inicia']) /* line 39 */;
			$iterations++;
		}
?></span>.</p>
           <p>CUESTIONARIO PARA ALUMNOS<p>
          <p><h5>REPORTE POR PROFESOR</h5></p>
          <p>NOMBRE DEL PROFESOR: <span class="black-text"><?php echo LR\Filters::escapeHtmlText($data['docente']) /* line 42 */ ?></span></p>
          <P>NOMBRE DEL FOLIO: <span class="black-text"><?php echo LR\Filters::escapeHtmlText($data['folio']) /* line 43 */ ?></span></P>
          <p>DEPARTAMENTO: <span class="black-text"><?php echo LR\Filters::escapeHtmlText($data['clave_departamento']) /* line 44 */ ?></span></p>
      </div>
      <p></p>
        <div>
        <table class="centered">
          <thead>
            <tr>
            <th>Clave</th>
            <th>Grupo</th>
            <th>Nombre de la materia</th>
            <th>Inscritos</th>
            <th>Evaluados</th>
            </tr>
          </thead>
          <tbody>
<?php
		$iterations = 0;
		foreach ($courses as $teacherShow) {
?>
              <tr>
              <td><?php echo LR\Filters::escapeHtmlText($teacherShow['clave']) /* line 61 */ ?></td>
              <td><?php echo LR\Filters::escapeHtmlText($teacherShow['nombre_grupo']) /* line 62 */ ?></td>
              <td><?php echo LR\Filters::escapeHtmlText($teacherShow['nombre']) /* line 63 */ ?></td>
              <td><?php echo LR\Filters::escapeHtmlText($teacherShow['COUNT(inscripcion.id)']) /* line 64 */ ?></td>
              <td><?php echo LR\Filters::escapeHtmlText($teacherShow['COUNT(evaluo.id)']) /* line 65 */ ?></td>
<?php
			$iterations++;
		}
?>
          </tbody>
          <tbody>
            <td></td>
             <td></td>
              <td>TOTAL</td>
              <td><?php echo LR\Filters::escapeHtmlText($students['inscribed']) /* line 72 */ ?></td>
              <td><?php echo LR\Filters::escapeHtmlText($students['evaluated']) /* line 73 */ ?></td>
          </tbody>
          <tbody>
            <td></td>
             <td></td>
              <td>PORCENTAJE DE ALUMNOS EVALUADOS</td>
              <td></td>
              <td><?php echo LR\Filters::escapeHtmlText($students['percentage']) /* line 80 */ ?>%</td>
          </tbody>
        </table>
        </div>
 <p></p>
        <div>
        <table  class="centered">
          <thead>
            <tr>
            <th>ASPECTO</th>
            <th>PUNTAJE</th>
            <th>DESEMPEÑO</th>
            </tr>
          </thead>
          <tbody>
<?php
		$iterations = 0;
		foreach ($average_teacher as $teacherResult) {
?>
              <tr>

              <td><?php echo LR\Filters::escapeHtmlText($teacherResult['dimension']) /* line 98 */ ?></td>
              <td><?php echo LR\Filters::escapeHtmlText($teacherResult['average']) /* line 99 */ ?></td>
              <td><?php echo LR\Filters::escapeHtmlText($teacherResult['status']) /* line 100 */ ?></td>
<?php
			$iterations++;
		}
?>
          </tbody>
        </table>
        </div>
      </div>


<div class="container section">
<script>
let dimension = [];
let status = [];
let average = [];
</script>

<?php
		$iterations = 0;
		foreach ($average_teacher as $datos) {
?>
  <script>
    dimension.push(<?php echo LR\Filters::escapeJs($datos['dimension']) /* line 117 */ ?>);
    status.push(<?php echo LR\Filters::escapeJs($datos['status']) /* line 118 */ ?>);
    average.push(<?php echo LR\Filters::escapeJs($datos['average']) /* line 119 */ ?>);
  </script>  
<?php
			$iterations++;
		}
?>

<div class="dona" id="dona"></div>
<script>
new Morris.Bar({
  element: 'dona',
  data: [

    { label: dimension[0], value: average[0]},
    { label: dimension[1], value: average[1]}, 
    { label: dimension[2], value: average[2]}, 
    { label: dimension[3], value: average[3]}, 
    { label: dimension[4], value: average[4]}, 
    { label: dimension[5], value: average[5]}, 
    { label: dimension[6], value: average[6]}, 
    { label: dimension[7], value: average[7]}, 
    { label: dimension[8], value: average[8]}, 
    { label: dimension[9], value: average[9]}, 
    { label: dimension[10], value: average[10]}
  ],
  colors: [
    '#E0F7FA',
    '#B2EBF2',
    '#80DEEA',
    '#4DD0E1',
    '#26C6DA',
    '#00BCD4',
    '#00ACC1',
    '#0097A7',
    '#00838F',
    '#006064'
  ],
  // The name of the data record attribute that contains x-values.
  xkey: 'label',
  // A list of names of data record attributes that contain y-values.
  ykeys: ['value'],
  // Labels for the ykeys -- will be displayed when you hover over the
  // chart.
  labels: ['Resultado']
});
</script>

</div>
<form action="<?php
		echo $router->relativeUrlFor("teachersShowList");
?>" method="post">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 165 */ ?>">
            <input type="hidden" name="clave_departamento" value="<?php echo LR\Filters::escapeHtmlAttr($data['clave_departamento']) /* line 166 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 167 */ ?>">
 <input class="oculto-impresion" id="retorno" type="submit" class="btn btn-primary btn-sm" value='Retornar'>
            </form>
            </div>
<?php
		if ($students['percentage'] < 60) {
?>
              <script>
              alert("EL DOCENTE NO CUENTA CON 60% DE EVALUACION");
              </script>
<?php
		}
		else {
?>
  <button class="oculto-impresion" onclick="imprimir()">Imprimir pantalla</button>
<?php
		}
?>
<div class="saltoDePagina"></div>
 <div class="card centerd">
          <p>RESULTADOS DE LA EVALUACION DE LOS PROFESORES
          PERIODO  DEL <span><?php
		$iterations = 0;
		foreach ($period_information as $periodo) {
			echo LR\Filters::escapeHtmlText($periodo['inicia']) /* line 181 */;
			$iterations++;
		}
		?></span> A <span><?php
		$iterations = 0;
		foreach ($period_information as $periodo) {
			echo LR\Filters::escapeHtmlText($periodo['inicia']) /* line 181 */;
			$iterations++;
		}
?></span>.</p>
           <p>CUESTIONARIO PARA ALUMNOS<p>
          <p><h5>REPORTE POR PROFESOR</h5></p>
          <p>NOMBRE DEL PROFESOR: <span class="black-text"><?php echo LR\Filters::escapeHtmlText($data['docente']) /* line 184 */ ?></span></p>
          <P>NOMBRE DEL FOLIO: <span class="black-text"><?php echo LR\Filters::escapeHtmlText($data['folio']) /* line 185 */ ?></span></P>
          <p>DEPARTAMENTO: <span class="black-text"><?php echo LR\Filters::escapeHtmlText($data['clave_departamento']) /* line 186 */ ?></span></p>
      </div>


<?php
		$iterations = 0;
		foreach ($average_teacher as $teacherResult) {
			if ($teacherResult['average'] <= 3.25) {
				if ($teacherResult['dimension'] !=="RESULTADO GLOBAL") {
					?>              <p>Docente requiere capacitacion <?php echo LR\Filters::escapeHtmlText($teacherResult['dimension']) /* line 193 */ ?> </p>
<?php
				}
			}
			$iterations++;
		}
?>
            <div class="container section">
<script>
let dimension = [];
let status = [];
let average = [];
</script>

<?php
		$iterations = 0;
		foreach ($average_teacher as $datos) {
?>
  <script>
    dimension.push(<?php echo LR\Filters::escapeJs($datos['dimension']) /* line 206 */ ?>);
    status.push(<?php echo LR\Filters::escapeJs($datos['status']) /* line 207 */ ?>);
    average.push(<?php echo LR\Filters::escapeJs($datos['average']) /* line 208 */ ?>);
  </script>  
<?php
			$iterations++;
		}
?>

<div class="dona" id="dona2"></div>
<script>
new Morris.Bar({
  element: 'dona2',
  data: [

    { label: dimension[0], value: average[0]},
    { label: dimension[1], value: average[1]}, 
    { label: dimension[2], value: average[2]}, 
    { label: dimension[3], value: average[3]}, 
    { label: dimension[4], value: average[4]}, 
    { label: dimension[5], value: average[5]}, 
    { label: dimension[6], value: average[6]}, 
    { label: dimension[7], value: average[7]}, 
    { label: dimension[8], value: average[8]}, 
    { label: dimension[9], value: average[9]}, 
    { label: dimension[10], value: average[10]}
  ],
  colors: [
    '#E0F7FA',
    '#B2EBF2',
    '#80DEEA',
    '#4DD0E1',
    '#26C6DA',
    '#00BCD4',
    '#00ACC1',
    '#0097A7',
    '#00838F',
    '#006064'
  ],
  // The name of the data record attribute that contains x-values.
  xkey: 'label',
  // A list of names of data record attributes that contain y-values.
  ykeys: ['value'],
  // Labels for the ykeys -- will be displayed when you hover over the
  // chart.
  labels: ['Resultado']
});
</script>

</div>
  

</body>
<script>
function imprimir() {
	window.print();
}
</script>
</html><?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['periodo'])) trigger_error('Variable $periodo overwritten in foreach on line 39, 39, 181, 181');
		if (isset($this->params['teacherShow'])) trigger_error('Variable $teacherShow overwritten in foreach on line 59');
		if (isset($this->params['teacherResult'])) trigger_error('Variable $teacherResult overwritten in foreach on line 95, 190');
		if (isset($this->params['datos'])) trigger_error('Variable $datos overwritten in foreach on line 115, 204');
		
	}

}
