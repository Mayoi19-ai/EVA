<?php
// source: Curso/coursesTable.latte

use Latte\Runtime as LR;

class Templatec64dbd5fa8 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<!DOCTYPE html>
  <html>
    <head>
      <meta charset="utf-8">
      <title><?php echo LR\Filters::escapeHtmlText($title) /* line 5 */ ?></title>
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
      <script type="text/javascript" src="/materialize/js/jquery.min.js"></script>
      <script type="text/javascript" src="/materialize/js/jquery-qrcode-0.18.0.js"></script>
      <script src="/materialize/js/materialize.min.js"></script>
      <link type="text/css" rel="stylesheet" href="/materialize/css/naver.css"  media="screen,projection">
      <script src="/materialize/validations/delete.js"></script>
      <script src="/materialize/validations/sellect.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>        
    </head>
    <body>
<?php
		/* line 17 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
?>
    <div class="container section">
    <ul id="nav-mobile">
      <div class="row">
        <div class="col s12 m6 l3">
          <form name="grupo" method="post" action="<?php
		echo $router->relativeUrlFor("courseSearchByGroup");
?>">
            <label for="autocomplete-input">Busqueda por Grupo</label>
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 24 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 25 */ ?>">
            <input type="text" name="grupo" id="grupo">
            <button id="buscar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee">Buscar<i class="material-icons left">search</i></button>
          </form>
        </div>
        <div class="col s12 m6 l3">
          <form name="SearchForm" method="post" action="<?php
		echo $router->relativeUrlFor("courseSearchByLesson");
?>">
            <label for="asignatura">Busqueda por materia</label>
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 33 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 34 */ ?>">
            <input type="text" name="asignatura" id="asignatura">
            <button id="buscar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee">Buscar<i class="material-icons left">search</i></button>
          </form>
        </div>
      </div>
    </div>
<?php
		if (empty ($query)) {
?>
      <div class="container section">
       <div class="card center">
          <div class="card center">
            <img class="logo" src="/materialize/css/alerta3.png">
              <h5>NO HAY GRUPOS REGISTRADOS</h5>
                <form action="<?php
			echo $router->relativeUrlFor("userMenu");
?>" method="post">
                  <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 48 */ ?>">
                  <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 49 */ ?>">
                  <input id="retorno" type="submit" class="btn btn-primary btn-sm" value='Retornar'>
                </form>    
              </div>
            </div>
          </div>
<?php
		}
		else {
?>
            <table name="showAllGroup" method="get" class="bordered striped hoverable centered responsive-table"> <!-- nombre de tabla-->
              <thead>
                <tr>
                  <th>Grupo</th>
                  <th>Carrera</th>
                  <th>Asignatura</th>
                  <th>Docente</th>
                  <th></th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
<?php
			$iterations = 0;
			foreach ($query as $courseShow) {
?>
              <tr>
                  <td><?php echo LR\Filters::escapeHtmlText($courseShow['grupo']) /* line 70 */ ?> </td>
                  <td><?php echo LR\Filters::escapeHtmlText($courseShow['carrera']) /* line 71 */ ?> </td>
                  <td><?php echo LR\Filters::escapeHtmlText($courseShow['asignatura']) /* line 72 */ ?> </td>
                  <td><?php echo LR\Filters::escapeHtmlText($courseShow['docente']) /* line 73 */ ?> </td>
                  <td>
                    <form action="<?php
				echo $router->relativeUrlFor("courseUpdateForm");
?>" method="post">
                      <input type="hidden" name="grupo" value="<?php echo LR\Filters::escapeHtmlAttr($courseShow['grupo']) /* line 76 */ ?>">
                      <input type="hidden" name="id_curso" value="<?php echo LR\Filters::escapeHtmlAttr($courseShow['id_curso']) /* line 77 */ ?>">
                      <input type="hidden" name="clave_asignatura" value="<?php echo LR\Filters::escapeHtmlAttr($courseShow['clave_asignatura']) /* line 78 */ ?>">
                      <input type="hidden" name="folio_docente" value="<?php echo LR\Filters::escapeHtmlAttr($courseShow['folio_docente']) /* line 79 */ ?>">
                      <input type="hidden" name="carrera" value="<?php echo LR\Filters::escapeHtmlAttr($courseShow['carrera']) /* line 80 */ ?>">
                      <input type="hidden" name="id_carrera" value="<?php echo LR\Filters::escapeHtmlAttr($courseShow['id_carrera']) /* line 81 */ ?>">
                      <input type="hidden" name="asignatura" value="<?php echo LR\Filters::escapeHtmlAttr($courseShow['asignatura']) /* line 82 */ ?>">
                      <input type="hidden" name="docente" value="<?php echo LR\Filters::escapeHtmlAttr($courseShow['docente']) /* line 83 */ ?>">
                      <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 84 */ ?>">
                      <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 85 */ ?>">
<?php
				$iterations = 0;
				foreach ($permissions as $permissionInfor) {
					$permisos  = explode(" - ", $permissionInfor['enlace']);
					;
					if ($permisos[1] == "courseUpdateForm") {
?>
                          <button id="actualizar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Editar<i class="material-icons left">edit</i></button>
<?php
					}
					$iterations++;
				}
?>
                    </form>
                  </td>
                  <td>
                    <form action="<?php
				echo $router->relativeUrlFor("courseDelete");
?>" method="post" onsubmit="return confirmation()">
                      <input type="hidden" name="id_curso" value="<?php echo LR\Filters::escapeHtmlAttr($courseShow['id_curso']) /* line 96 */ ?>">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 97 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 98 */ ?>">
<?php
				$iterations = 0;
				foreach ($permissions as $permissionInfor) {
					$permisos  = explode(" - ", $permissionInfor['enlace']);
					;
					if ($permisos[1] == "courseDelete") {
?>
                  <button type="submit" id="eliminar" style="background-color: #f44336" class="btn btn-primary btn-sm #f44336" value='Eliminar'>Eliminar<i class="material-icons left">delete</i></button>
<?php
					}
					$iterations++;
				}
?>
            </form>
          </td>
        </tr>
<?php
				$iterations++;
			}
?>
    </tbody>
    <form action="<?php
			echo $router->relativeUrlFor("courseSaveForm");
?>" method="post">
      <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 111 */ ?>">
      <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 112 */ ?>">
      <div class="fixed-action-btn">
<?php
			$iterations = 0;
			foreach ($permissions as $permissionInfor) {
				$permisos  = explode(" - ", $permissionInfor['enlace']);
				;
				if ($permisos[1] == "courseSaveForm") {
?>
          <button id="agrerar" type="submit" class="btn btn-primary btn-sm float-2" style="background-color: #22DD22" >Agregar<i class="material-icons left">add</i></button>
<?php
				}
				$iterations++;
			}
		}
?>
  </form>
</table>
</div>
</div>
<div class="content"></div>
<div class="footer-copyright blue-grey lighten-3" >
  <div class="container">
    <img class="header container section" src="/materialize/css/pie.jpg">
  </div>
</div>
</footer>
</body>
 <script src="/materialize/validations/resources.js" type="text/javascript"></script>
</html>
<?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['permissionInfor'])) trigger_error('Variable $permissionInfor overwritten in foreach on line 86, 99, 114');
		if (isset($this->params['courseShow'])) trigger_error('Variable $courseShow overwritten in foreach on line 68');
		
	}

}
