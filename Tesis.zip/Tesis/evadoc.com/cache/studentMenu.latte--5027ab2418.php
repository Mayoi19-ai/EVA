<?php
// source: Menu/studentMenu.latte

use Latte\Runtime as LR;

class Template5027ab2418 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<!DOCTYPE html>
  <html>
    <head>
      <meta charset="utf-8">
      <title><?php echo LR\Filters::escapeHtmlText($title) /* line 5 */ ?></title>
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
      <script type="text/javascript" src="/materialize/js/jquery.min.js"></script>
      <script type="text/javascript" src="/materialize/js/jquery-qrcode-0.18.0.js"></script>
      <script src="/materialize/js/materialize.min.js"></script>
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/studentNaver.css"  media="screen,projection">
      <link type="text/css" rel="stylesheet" href="/materialize/css/botones.css"  media="screen,projection">
      <script src="/materialize/validations/resources.js" type="text/javascript"></script>
    </head>
    <body>
      <img class="header container section" src="/materialize/css/cabeza.jpg">
      <!-- nav -->
      <nav>
        <div class="nav-wrapper blue-grey lighten-3">
          <img class="logo" src="/materialize/css/tec.jpg"></a>
          <!--Mobile -->
          <a href="#" class="sidenav-trigger" data-target="mobile-nav">
			      <i class="material-icons">menu</i>
		      </a>
          <ul class="right hide-on-med-and-down "  >
            <li>
              <form method="post" action="<?php
		echo $router->relativeUrlFor("studentPasswordUpdateForm");
?>">
<?php
		$iterations = 0;
		foreach ($student_information as $studentInformationControl) {
			?>                  <input type="hidden" name="control" value="<?php echo LR\Filters::escapeHtmlAttr($studentInformationControl['control']) /* line 30 */ ?>">
                  <input type="hidden" name="nombre" value="<?php echo LR\Filters::escapeHtmlAttr($studentInformationControl['nombre']) /* line 31 */ ?>">
<?php
			$iterations++;
		}
?>
                <button id="actualizar" type="submit" class="btn btn-primary btn-sm" style="background-color:#b0bec5" >Cambiar contraseña</button>
              </form> 
            </li> 
            <li><a href="<?php
		echo $router->relativeUrlFor("loginStudent");
?>">Cerrar sesión</a></li>
          </ul>
          <!-- -->
        </div>
      </nav>
      <!-- -->
        <ul class="sidenav" id="mobile-nav">
            <form method="post" action="<?php
		echo $router->relativeUrlFor("studentPasswordUpdateForm");
?>">
<?php
		$iterations = 0;
		foreach ($student_information as $studentInformationControl) {
			?>                <input type="hidden" name="control" value="<?php echo LR\Filters::escapeHtmlAttr($studentInformationControl['control']) /* line 45 */ ?>">
                <input type="hidden" name="nombre" value="<?php echo LR\Filters::escapeHtmlAttr($studentInformationControl['nombre']) /* line 46 */ ?>">
<?php
			$iterations++;
		}
?>
              <div class="container section">
              <li><button type="submit" id="actualizar" class="btn btn-primary btn-sm menuBotones" style="background-color:#b0bec5">Cambiar contraseña</button>
            </form>
            <p>
          <a href="<?php
		echo $router->relativeUrlFor("loginStudent");
?>" id="actualizar" class="btn btn-primary btn-sm menuBotones" style="background-color:#b0bec5">Cerrar sesion</a></li></p>
          </div>
        </ul>

        <!-- -->
        <!--Nav end-->
        <div class="container section">
          <div class="card center">
<?php
		$iterations = 0;
		foreach ($student_information as $studentInformation) {
			?>              <span class="black-text center"><?php echo LR\Filters::escapeHtmlText($studentInformation['nombre']) /* line 61 */ ?> </span></a>
<?php
			$iterations++;
		}
?>
          </div>
          <div class="card">
            <table class="highlight">
            <thead>
              <tr>
              </tr>
            </thead>
            <tbody>
            <!-- -->
<?php
		if (empty ($query)) {
?>
              <div class="container section">
                <div class="card center">
                  <div class="card center">
                    <img class="logo" src="/materialize/css/alerta3.png">
                     <h5>NO HAY EVALUACIONES DISPONIBLES</h5>
<?php
			if (empty ($code)) {
?>
                        <p>NO HAY CURSO DISPONIBLES.</p>
<?php
			}
			else {
?>
                            <p>CODIGO DE VERIFICACION:</p>
                            <!-- code qr start -->
                            <div id="qrcode"></div>
                              <script type="text/javascript">
                                var options = {
                                  render: 'canvas',
                                  minVersion: 1,
                                  maxVersion: 40,
                                  ecLevel: 'L',
                                  left: 0,
                                  top: 0,
                                  size: 200,
                                  fill: '#000',
                                  background: null,
                                  text: <?php echo LR\Filters::escapeJs($code) /* line 95 */ ?>,
                                  radius: 0,
                                  quiet: 0,
                                  mode: 0,
                                  mSize: 0.1,
                                  mPosX: 0.5,
                                  mPosY: 0.5,
                                  label: 'no label',
                                  fontname: 'sans',
                                  fontcolor: '#000',
                                  image: null
                                }
                                $('#qrcode').qrcode(options);
                              </script>
                              <!-- code  qr end -->   
                            </div>
                          </div>
                        </div>
<?php
			}
		}
		else {
?>
                      <!-- -->
<?php
			$iterations = 0;
			foreach ($query as $studentCourses) {
?>
                          <tr>
                            <td>
                              <p>MATERIA: <?php echo LR\Filters::escapeHtmlText($studentCourses['asignatura']) /* line 119 */ ?></p>
                              <p>DOCENTE: <?php echo LR\Filters::escapeHtmlText($studentCourses['docente']) /* line 120 */ ?> </p>
                            </td>
                          <td>
                            <form action="<?php
				echo $router->relativeUrlFor("studentCoursesShowQuiz");
?>" method="post">
                              <input type="hidden" name="id" value="<?php echo LR\Filters::escapeHtmlAttr($studentCourses['id']) /* line 124 */ ?>">
                              <input type="hidden" name="control" value="<?php echo LR\Filters::escapeHtmlAttr($studentCourses['control']) /* line 125 */ ?>">
                              <input type="hidden" name="alumno" value="<?php echo LR\Filters::escapeHtmlAttr($studentCourses['alumno']) /* line 126 */ ?>">
                              <input type="hidden" name="grupo" value="<?php echo LR\Filters::escapeHtmlAttr($studentCourses['grupo']) /* line 127 */ ?>">
                              <input type="hidden" name="carrera" value="<?php echo LR\Filters::escapeHtmlAttr($studentCourses['carrera']) /* line 128 */ ?>">
                              <input type="hidden" name="asignatura" value="<?php echo LR\Filters::escapeHtmlAttr($studentCourses['asignatura']) /* line 129 */ ?>">
                              <input type="hidden" name="clave_asignatura" value="<?php echo LR\Filters::escapeHtmlAttr($studentCourses['clave_asignatura']) /* line 130 */ ?>">
                              <input type="hidden" name="docente" value="<?php echo LR\Filters::escapeHtmlAttr($studentCourses['docente']) /* line 131 */ ?>">
                              <input type="hidden" name="periodo" value="<?php echo LR\Filters::escapeHtmlAttr($studentCourses['periodo']) /* line 132 */ ?>">
                              <input type="hidden" name="curso" value="<?php echo LR\Filters::escapeHtmlAttr($studentCourses['curso']) /* line 133 */ ?>">
                              <input type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" value='Iniciar evaluación'>
                            </form>
                          </div> 
                        </div>
                      </td>
                    </tr>
<?php
				$iterations++;
			}
		}
?>
              </tbody>
            </table>
          </div>
        </div>
        <!--footer-->
        <div class="content"></div>
	      <div class="content"></div>
        <div class="content"></div>
          <div class="footer-copyright blue-grey lighten-3" >
           <img class="header container section" src="/materialize/css/pie.jpg">
          </div>
        </div>
      </footer>
    </body>
  <script src="/materialize/validations/resources.js" type="text/javascript"></script>
</html>
<?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['studentInformationControl'])) trigger_error('Variable $studentInformationControl overwritten in foreach on line 29, 44');
		if (isset($this->params['studentInformation'])) trigger_error('Variable $studentInformation overwritten in foreach on line 60');
		if (isset($this->params['studentCourses'])) trigger_error('Variable $studentCourses overwritten in foreach on line 116');
		
	}

}
