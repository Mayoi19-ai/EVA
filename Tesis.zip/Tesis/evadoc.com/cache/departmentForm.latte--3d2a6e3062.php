<?php
// source: Departamento/departmentForm.latte

use Latte\Runtime as LR;

class Template3d2a6e3062 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<!DOCTYPE html>
  <html>
    <head>
      <meta charset="utf-8">
      <title><?php echo LR\Filters::escapeHtmlText($title) /* line 5 */ ?></title>
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
      <script type="text/javascript" src="/materialize/js/jquery.min.js"></script>
      <script type="text/javascript" src="/materialize/js/jquery-qrcode-0.18.0.js"></script>
      <script src="/materialize/js/materialize.min.js"></script>
      <link type="text/css" rel="stylesheet" href="/materialize/css/naver.css"  media="screen,projection">
      <script src="/materialize/validations/sellect.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
      <link type="text/css" rel="stylesheet" href="/materialize/css/formularios.css"  media="screen,projection">
<?php
		/* line 15 */
		$this->createTemplate('../validationCreate.latte', $this->params, "include")->renderToContentType('html');
?>
    </head>
    <body>
<?php
		/* line 18 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
?>
        <ul id="nav-mobile">
          <div class="container section">
            <form name="departmentSaveForm" method="post" action="<?php
		echo $router->relativeUrlFor("departmentRegister");
?>">
              Codigo <input type="text" name="clave" id="clave">
              Nombre <input type="text" name="nombre" id="nombre">
              <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 24 */ ?>">
              <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 25 */ ?>">
              <button id="guardar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Guardar<i class="material-icons left">send</i></button>
            </form>
          </div>
          <div>
            <form action="<?php
		echo $router->relativeUrlFor("showAllDepartments");
?>" method="post">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 31 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 32 */ ?>">
            <button id="retornar" type="submit" class="btn btn-primary btn-sm float-1" style="background-color: #10c2ee" >Retornar<i class="material-icons left">arrow_back</i></button>
            </form>
            </div>
                 <div class="content"></div>
            <div class="footer-copyright blue-grey lighten-3" >
            <div class="container">
           <img class="header container section" src="/materialize/css/pie.jpg">
            </div>
          </div>
        </footer>
      </body>
    <script src="/materialize/validations/resources.js" type="text/javascript"></script>
  </html><?php
		return get_defined_vars();
	}

}
