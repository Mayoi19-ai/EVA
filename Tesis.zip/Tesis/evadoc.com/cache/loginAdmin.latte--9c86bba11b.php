<?php
// source: Sesion/loginAdmin.latte

use Latte\Runtime as LR;

class Template9c86bba11b extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		?><!--<?php
		/* line 1 */
		$this->createTemplate('validationSesion.latte', $this->params, "include")->renderToContentType('htmlComment');
?>-->
<!DOCTYPE html>
  <html>
    <head>
      <meta charset="utf-8">
        <title><?php echo LR\Filters::escapeHtmlText($title) /* line 6 */ ?></title>
          <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
          <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
          <script src="/materialize/js/materialize.min.js"></script>
          <link type="text/css" rel="stylesheet" href="/materialize/css/Logeo.css"  media="screen,projection">
      </head>
      <body>
      <img class="header container section" src="/materialize/css/cabeza.jpg">
      <!-- form sesion start -->
        <div class="row container section">
          <div class="col s12 ">
            <div class="card horizontal ">
              <img class="inicio" src="https://www.itshuatusco.edu.mx/inicio/images/Logo%20ITSH%20300x312%20negritas.png">
                <div class="card-stacked">
                  <div class="card-content">
                    <!-- sesion -->
                    <form name="usersLogin" method="post" action="<?php
		echo $router->relativeUrlFor("userMenu");
?>" > 
                    <div class="container section">
                      <label for="usuario_activo">Nombre de usuario</label>
                      <input type="text" id="usuario_activo" name="usuario_activo" class="validate">
                      <label for="contrasenia">Contraseña:</label>
                      <input type="password" id="contrasenia" name="contrasenia" class="validate" >
                      <input class="sesion file-path btn " type="submit"  value="Iniciar sesion" onclick ="return Logeo();">
                    </div>
                    </form>
                    <div id="error"></div> 
                  </div>
                  </div>
                </div>
              </div>
            </div>
    <!-- form sesion end --> 
    <!--footer-->
      <footer class="page-footer blue-grey lighten-3">

                 <img class="header container section" src="/materialize/css/pie.jpg"> 
              
            
        </footer>   
     
      </body>
    <script> M.AutoInit(); </script>
</html><?php
		return get_defined_vars();
	}

}
