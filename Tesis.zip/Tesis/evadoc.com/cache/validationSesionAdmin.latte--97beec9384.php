<?php
// source: Sesion\validationSesionAdmin.latte

use Latte\Runtime as LR;

class Template97beec9384 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<script>

var $usuario_activo = document.getElementById('usuario_activo');
var $contrasenia = document.getElementById('contrasenia');
var $error = document.getElementById('error');
error.style.color ="red";
function Logeo(){

    var mensajesError =[];

     if(usuario_activo.value === null || contrasenia.value === null){
         mensajesError.push('Datos erróneos. Por favor, inténtelo otra vez. ');
           error.innerHTML = mensajesError.join(', '); 
         return false;
    }
    if(usuario_activo.value === "" || contrasenia.value === ""){
         mensajesError.push('Datos erróneos. Por favor, inténtelo otra vez. ');
           error.innerHTML = mensajesError.join(', '); 
         return false;
    }

    if(usuario_activo.value === null && contrasenia.value === null){
        mensajesError.push('Datos erróneos. Por favor, inténtelo otra vez. ');
          error.innerHTML = mensajesError.join(', '); 
        return false;
    }
     if(usuario_activo.value === "" && contrasenia.value === ""){
        mensajesError.push('Datos erróneos. Por favor, inténtelo otra vez.');
          error.innerHTML = mensajesError.join(', '); 
        return false;
    }



</script>
<?php
		return get_defined_vars();
	}

}
