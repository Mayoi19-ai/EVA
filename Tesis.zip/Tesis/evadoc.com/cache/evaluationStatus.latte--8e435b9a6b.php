<?php
// source: Estado/evaluationStatus.latte

use Latte\Runtime as LR;

class Template8e435b9a6b extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<!DOCTYPE html>
                <html>
                    <head>
                        <meta charset="utf-8">
                            <title><?php echo LR\Filters::escapeHtmlText($title) /* line 5 */ ?></title>
                            <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
                            <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
                            <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
                            <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
      <script type="text/javascript" src="/materialize/js/jquery.min.js"></script>
      <script type="text/javascript" src="/materialize/js/jquery-qrcode-0.18.0.js"></script>
      <script src="/materialize/js/materialize.min.js"></script>
      <link type="text/css" rel="stylesheet" href="/materialize/css/naver.css"  media="screen,projection">
      <script src="/materialize/validations/delete.js"></script>
       <script src="/materialize/validations/sellect.js"></script>
       <link type="text/css" rel="stylesheet" href="/materialize/css/naver.css"  media="screen,projection">
                            </head>
                        <body>
<?php
		/* line 20 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
		if (empty ($query)) {
?>
       <div class="container section">
       <div class="card center">
              <div class="card center">
                    <img class="logo" src="/materialize/css/alerta3.png">
                        <p>NO HAY ALUMNOS REGISTRADOS</p>
                          <form action="<?php
			echo $router->relativeUrlFor("userMenu");
?>" method="post">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 28 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 29 */ ?>">
 <input id="retorno" type="submit" class="btn btn-primary btn-sm" value='Retornar'>
            </form>
              </div>
       </div>
</div>
<?php
		}
		else {
?>
<div class="MiTabla" class="container setcion responsive-table" >
<table name="showAllInscription" method="get" class="bordered striped hoverable centered responsive-table"> <!-- nombre de tabla-->
<thead>
<tr>
<th>Numero de control</th>
<th>Alumno</th>
<th>Grupo</th>
<th>Carrera</th>
<th>Asignatura</th>
<th>Clave asignatura</th>
<th>Docente</th>
</tr>
</thead>
<tbody>
<?php
			$iterations = 0;
			foreach ($query as $evaluationShow) {
?>
<tr>
    <td><?php echo LR\Filters::escapeHtmlText($evaluationShow['control']) /* line 52 */ ?> </td>
     <td><?php echo LR\Filters::escapeHtmlText($evaluationShow['alumno']) /* line 53 */ ?> </td>
     <td><?php echo LR\Filters::escapeHtmlText($evaluationShow['grupo']) /* line 54 */ ?> </td>
     <td><?php echo LR\Filters::escapeHtmlText($evaluationShow['carrera']) /* line 55 */ ?> </td>
     <td><?php echo LR\Filters::escapeHtmlText($evaluationShow['asignatura']) /* line 56 */ ?> </td>
      <td><?php echo LR\Filters::escapeHtmlText($evaluationShow['clave_asignatura']) /* line 57 */ ?> </td>
     <td><?php echo LR\Filters::escapeHtmlText($evaluationShow['docente']) /* line 58 */ ?> </td>
<?php
				$iterations++;
			}
?>
</tbody>
</table>
<?php
		}
?>
                                </div>
                                    <!--footer -->
                                      
            <div class="footer-copyright blue-grey lighten-3" >
            <div class="container">
           <img class="header container section" src="/materialize/css/pie.jpg">
            </div>
          </div>
        </footer>
                                        </body>
                                    
 <script src="/materialize/validations/resources.js" type="text/javascript"></script>
                                </html>
                          <?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['evaluationShow'])) trigger_error('Variable $evaluationShow overwritten in foreach on line 50');
		
	}

}
