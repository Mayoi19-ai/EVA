<?php
// source: Curso/coursesUpdate.latte

use Latte\Runtime as LR;

class Template23dbbb01f2 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<!DOCTYPE html>
  <html>
    <head>
      <meta charset="utf-8">
      <title><?php echo LR\Filters::escapeHtmlText($title) /* line 5 */ ?></title>
     <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
      <script type="text/javascript" src="/materialize/js/jquery.min.js"></script>
      <script type="text/javascript" src="/materialize/js/jquery-qrcode-0.18.0.js"></script>
      <script src="/materialize/js/materialize.min.js"></script>
      <link type="text/css" rel="stylesheet" href="/materialize/css/naver.css"  media="screen,projection">
      <script src="/materialize/validations/delete.js"></script>
      <script src="/materialize/validations/sellect.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
      <link type="text/css" rel="stylesheet" href="/materialize/css/formularios.css"  media="screen,projection">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js%22%3E"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.6/js/standalone/selectize.min.js" integrity="sha256-+C0A5Ilqmu4QcSPxrlGpaZxJ04VjsRjKu+G82kl5UJk=" crossorigin="anonymous"></script>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.6/css/selectize.bootstrap3.min.css" integrity="sha256-ze/OEYGcFbPRmvCnrSeKbRTtjG4vGLHXgOqsyLFTRjg=" crossorigin="anonymous">
      <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
<?php
		/* line 20 */
		$this->createTemplate('../validationUpdate.latte', $this->params, "include")->renderToContentType('html');
?>
    </head>
    <body>
<?php
		/* line 23 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
?>
      <div class="container section">
        <form name="courseUpdateForm" method="post" action="<?php
		echo $router->relativeUrlFor("courseUpdate");
?>">
          <input type="hidden" name="grupo" value="<?php echo LR\Filters::escapeHtmlAttr($data['grupo']) /* line 26 */ ?>">
          <input type="hidden" name="id_curso" value="<?php echo LR\Filters::escapeHtmlAttr($data['id_curso']) /* line 27 */ ?>">
          <input type="hidden" name="id_carrera" value="<?php echo LR\Filters::escapeHtmlAttr($data['id_carrera']) /* line 28 */ ?>">
          <input type="hidden" name="clave_asignatura" value="<?php echo LR\Filters::escapeHtmlAttr($data['clave_asignatura']) /* line 29 */ ?>">
          <input type="hidden" name="folio_docente" value="<?php echo LR\Filters::escapeHtmlAttr($data['folio_docente']) /* line 30 */ ?>">
          <input type="hidden" name="carrera" value="<?php echo LR\Filters::escapeHtmlAttr($data['carrera']) /* line 31 */ ?>">
          <input type="hidden" name="asignatura" value="<?php echo LR\Filters::escapeHtmlAttr($data['asignatura']) /* line 32 */ ?>">              <input type="hidden" name="docente" value="<?php
		echo LR\Filters::escapeHtmlAttr($data['docente']) /* line 32 */ ?>">
          <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 33 */ ?>">
          <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 34 */ ?>">
            <div class="container section">
              <input type="hidden" name="id_curso" id="id_curso" value="<?php echo LR\Filters::escapeHtmlAttr($data['id_curso']) /* line 36 */ ?>">
                <ul>
                  <li>
                    <label for="grupo">seleccione un grupo:</label>
                      <select class="browser-default" name="grupo">
                      <option value="<?php echo LR\Filters::escapeHtmlAttr($data['grupo']) /* line 41 */ ?>" name="grupo"><?php
		echo LR\Filters::escapeHtmlText($data['grupo']) /* line 41 */ ?> - <?php echo LR\Filters::escapeHtmlText($data['carrera']) /* line 41 */ ?></option>
<?php
		$iterations = 0;
		foreach ($all_groups_information as $groupOption) {
			?>                      <option  value="<?php echo LR\Filters::escapeHtmlAttr($groupOption['grupo']) /* line 43 */ ?>" ><?php
			echo LR\Filters::escapeHtmlText($groupOption['grupo']) /* line 43 */ ?> - <?php echo LR\Filters::escapeHtmlText($groupOption['carrera']) /* line 43 */ ?></option>
<?php
			$iterations++;
		}
?>
                    </select>
                  </li>
                  <li>
                    <label for="clave_asignatura_id_carrera">seleccione una asignatura:</label>
                      <select class="browser-default" name="clave_asignatura_id_carrera" id="clave_asignatura_id_carrera">
                      <option value="<?php echo LR\Filters::escapeHtmlAttr($data['clave_asignatura']) /* line 50 */ ?> <?php
		echo LR\Filters::escapeHtmlAttr($data['id_carrera']) /* line 50 */ ?>" name="clave_asignatura_id_carrera"><?php
		echo LR\Filters::escapeHtmlText($data['asignatura']) /* line 50 */ ?> - <?php echo LR\Filters::escapeHtmlText($data['carrera']) /* line 50 */ ?></option>
<?php
		$iterations = 0;
		foreach ($all_subjects_information as $subjectOption) {
			?>                      <option  value="<?php echo LR\Filters::escapeHtmlAttr($subjectOption['clave_asignatura']) /* line 52 */ ?> <?php
			echo LR\Filters::escapeHtmlAttr($subjectOption['id_carrera']) /* line 52 */ ?>" ><?php echo LR\Filters::escapeHtmlText($subjectOption['asignatura']) /* line 52 */ ?> - <?php
			echo LR\Filters::escapeHtmlText($subjectOption['carrera']) /* line 52 */ ?></option>
<?php
			$iterations++;
		}
?>
                      </select>
                    </li>
                    <li>
                      <label for="folio_docente">Seleccione un docente:</label>
                      <select class="browser-default" name="folio_docente">
                      <option value="<?php echo LR\Filters::escapeHtmlAttr($data['folio_docente']) /* line 59 */ ?>" name="folio_docente"><?php
		echo LR\Filters::escapeHtmlText($data['docente']) /* line 59 */ ?></option>
<?php
		$iterations = 0;
		foreach ($all_teachers_information as $teachersOption) {
			?>                      <option  value="<?php echo LR\Filters::escapeHtmlAttr($teachersOption['folio']) /* line 61 */ ?>" ><?php
			echo LR\Filters::escapeHtmlText($teachersOption['nombre']) /* line 61 */ ?></option>
<?php
			$iterations++;
		}
?>
                    </select>
                  </li>
                </ul>
                <button id="guardar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Guardar<i class="material-icons left">send</i></button>
              </div>
            </form>
          </div>
            <form action="<?php
		echo $router->relativeUrlFor("showAllCourses");
?>" method="post">
              <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 71 */ ?>">
              <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 72 */ ?>">
              <button id="retornar" type="submit" class="btn btn-primary btn-sm float-1" style="background-color: #10c2ee" >Retornar<i class="material-icons left">arrow_back</i></button>
            </form>
          </div>
          <div class="content"></div>
          <div class="footer-copyright blue-grey lighten-3" >
            <div class="container">
              <img class="header container section" src="/materialize/css/pie.jpg">
            </div>
          </div>
        </footer>
      </body>
  <script src="/materialize/validations/resources.js" type="text/javascript"></script>
</html>
<?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['groupOption'])) trigger_error('Variable $groupOption overwritten in foreach on line 42');
		if (isset($this->params['subjectOption'])) trigger_error('Variable $subjectOption overwritten in foreach on line 51');
		if (isset($this->params['teachersOption'])) trigger_error('Variable $teachersOption overwritten in foreach on line 60');
		
	}

}
