<?php
// source: AsignarR/assignRTable.latte

use Latte\Runtime as LR;

class Templateb3c2ba8f21 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<!DOCTYPE html>
    <html>
        <head>
            <meta charset="utf-8">
            <title><?php echo LR\Filters::escapeHtmlText($title) /* line 5 */ ?></title>
            <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
            <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
            <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
            <script type="text/javascript" src="/materialize/js/jquery.min.js"></script>
            <script type="text/javascript" src="/materialize/js/jquery-qrcode-0.18.0.js"></script>
            <script src="/materialize/js/materialize.min.js"></script>
            <link type="text/css" rel="stylesheet" href="/materialize/css/naver.css"  media="screen,projection">
            <script src="/materialize/validations/delete.js"></script>
            <script src="/materialize/validations/sellect.js"></script>
        </head>
        <body>
<?php
		/* line 17 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
		if (empty ($query)) {
?>
                    <div class="container section">
                        <div class="card center">
                            <img class="logo" src="/materialize/css/alerta3.png">
                            <h5>NO SE CUENTA CON ROLES REGISTRADOS</h5>
                        </div>
                    </div>
                </div>
<?php
		}
		else {
?>
                    <ul id="nav-mobile">
                        <div class="MiTabla">
                            <table name="showAllroles" method="get" class="bordered striped hoverable centered responsive-table">
                                <thead>
                                    <tr>
                                        <th>Usuario</th>
                                        <th>Rol</th>
                                        <th></th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
<?php
			$iterations = 0;
			foreach ($query as $asignR) {
?>
                                        <tr>
                                            <td><?php echo LR\Filters::escapeHtmlText($asignR['usuario']) /* line 41 */ ?> </td>
                                            <td><?php echo LR\Filters::escapeHtmlText($asignR['rol']) /* line 42 */ ?> </td>
                                            <td>
                                                <form action="<?php
				echo $router->relativeUrlFor("userRolesUpdateForm");
?>" method="post">
                                                    <input type="hidden" name="id_usuario" value="<?php echo LR\Filters::escapeHtmlAttr($asignR['id_usuario']) /* line 45 */ ?>">
                                                    <input type="hidden" name="usuario" value="<?php echo LR\Filters::escapeHtmlAttr($asignR['usuario']) /* line 46 */ ?>">
                                                    <input type="hidden" name="id_roles" value="<?php echo LR\Filters::escapeHtmlAttr($asignR['id_roles']) /* line 47 */ ?>">
                                                    <input type="hidden" name="rol" value="<?php echo LR\Filters::escapeHtmlAttr($asignR['rol']) /* line 48 */ ?>">
                                                    <input type="hidden" name="usuario_activo" value="<?php
				echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 49 */ ?>">
                                                    <input type="hidden" name="categoria_permisos" value="<?php
				echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 50 */ ?>">
<?php
				$iterations = 0;
				foreach ($permissions as $permissionInfor) {
					$permisos  = explode(" - ", $permissionInfor['enlace']);
					;
					if ($permisos[1] == "userRolesUpdateForm") {
?>
                                                                <button id="actualizar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Editar<i class="material-icons left">edit</i></button>
<?php
					}
					$iterations++;
				}
?>
                                                    </form>
                                                </td>
                                                <td>
                                                    <form action="<?php
				echo $router->relativeUrlFor("userRolesDelete");
?>" method="post" onsubmit="return confirmation()">
                                                        <input type="hidden" name="id_usuario" value="<?php
				echo LR\Filters::escapeHtmlAttr($asignR['id_usuario']) /* line 61 */ ?>">
                                                        <input type="hidden" name="id_roles" value="<?php
				echo LR\Filters::escapeHtmlAttr($asignR['id_roles']) /* line 62 */ ?>">
                                                        <input type="hidden" name="usuario_activo" value="<?php
				echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 63 */ ?>">
                                                        <input type="hidden" name="categoria_permisos" value="<?php
				echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 64 */ ?>">
<?php
				$iterations = 0;
				foreach ($permissions as $permissionInfor) {
					$permisos  = explode(" - ", $permissionInfor['enlace']);
					;
					if ($permisos[1] == "userRolesDelete") {
?>
                                                                    <button type="submit" id="eliminar" style="background-color: #f44336" class="btn btn-primary btn-sm #f44336" value='Eliminar'>Eliminar<i class="material-icons left">delete</i></button>
<?php
					}
					$iterations++;
				}
?>
                                                        </form>
                                                    </td>
                                                </tr>
<?php
				$iterations++;
			}
?>
                                        </tbody>
                                        <form action="<?php
			echo $router->relativeUrlFor("userRolesSaveForm");
?>" method="post">
                                            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 77 */ ?>">
                                            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 78 */ ?>">
                                                <div class="fixed-action-btn">
<?php
			$iterations = 0;
			foreach ($permissions as $permissionInfor) {
				$permisos  = explode(" - ", $permissionInfor['enlace']);
				;
				if ($permisos[1] == "userRolesSaveForm") {
?>
                                                            <button id="agrerar" type="submit" class="btn btn-primary btn-sm float-2" style="background-color: #22DD22" >Agregar<i class="material-icons left">add</i></button>
<?php
				}
				$iterations++;
			}
?>
                                                </form>
                                            </table>
<?php
		}
?>
                                    </div>
                                    <div class="content"></div>
                                    <div class="footer-copyright blue-grey lighten-3" >
                                        <div class="container">
                                            <img class="header container section" src="/materialize/css/pie.jpg">
                                        </div>
                                    </div>
                                </footer>
                            </body>
                        <script src="/materialize/validations/resources.js" type="text/javascript"></script>
                    </html>
<?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['permissionInfor'])) trigger_error('Variable $permissionInfor overwritten in foreach on line 51, 65, 80');
		if (isset($this->params['asignR'])) trigger_error('Variable $asignR overwritten in foreach on line 39');
		
	}

}
