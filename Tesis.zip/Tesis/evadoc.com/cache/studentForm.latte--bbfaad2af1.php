<?php
// source: Alumno/studentForm.latte

use Latte\Runtime as LR;

class Templatebbfaad2af1 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		/* line 1 */
		$this->createTemplate('../validationCreate.latte', $this->params, "include")->renderToContentType('html');
		/* line 2 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
?>
    <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <title><?php echo LR\Filters::escapeHtmlText($title) /* line 7 */ ?></title>
          <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
          <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
          <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
          <link type="text/css" rel="stylesheet" href="/materialize/css/formularios.css"  media="screen,projection">
        </head>
        <body>
          <form name="studentSaveForm" method="post" action="<?php
		echo $router->relativeUrlFor("studentRegister");
?>">
            <!-- -->
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 16 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 17 */ ?>">
            <!-- -->
            <div class="container section">
              Control <input type="text" name="control" id="control">
              Nombre <input type="text" name="nombre"  id="nombre">
             <button id="actualizar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Guardar<i class="material-icons left">send</i></button>
            </div>
          </form>
          <form action="<?php
		echo $router->relativeUrlFor("showAllStudents");
?>" method="post">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 26 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 27 */ ?>">
           <button id="retornar" type="submit" class="btn btn-primary btn-sm float-1" style="background-color: #10c2ee" >Retornar<i class="material-icons left">arrow_back</i></button>
            </form>
              <!--footer -->
               <div class="content"></div>
            <div class="footer-copyright blue-grey lighten-3" >
            <div class="container">
           <img class="header container section" src="/materialize/css/pie.jpg">
            </div>
          </div>
        </footer>
                </body>
 <script>M.AutoInit();</script>
</html><?php
		return get_defined_vars();
	}

}
