<?php
// source: validationPassword.latte

use Latte\Runtime as LR;

class Template55bc2fee15 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<script type="text/javascript">
 var contrasenia = document.getElementById('contrasenia').value;
 var contrasenia_same = document.getElementById('contrasenia_same').value;
     function validarCambio(){
      if (contrasenia.value === null || contrasenia_same.value === null) {
  		alert("Los campos de la password no pueden quedar vacios");
  		return false;
		}
     }
    </script><?php
		return get_defined_vars();
	}

}
