<?php
// source: Usuario/userForm.latte

use Latte\Runtime as LR;

class Template12b1b0ea15 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<!DOCTYPE html>
  <html>
    <head>
      <meta charset="utf-8">
      <title><?php echo LR\Filters::escapeHtmlText($title) /* line 5 */ ?></title>
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
      <script type="text/javascript" src="/materialize/js/jquery.min.js"></script>
      <script type="text/javascript" src="/materialize/js/jquery-qrcode-0.18.0.js"></script>
      <script src="/materialize/js/materialize.min.js"></script>
      <link type="text/css" rel="stylesheet" href="/materialize/css/naver.css"  media="screen,projection">
      <script src="/materialize/validations/delete.js"></script>
      <script src="/materialize/validations/sellect.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
      <link type="text/css" rel="stylesheet" href="/materialize/css/formularios.css"  media="screen,projection">
<?php
		/* line 16 */
		$this->createTemplate('../validationCreate.latte', $this->params, "include")->renderToContentType('html');
?>
    </head>
    <body>
<?php
		/* line 19 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
		?>        <form name="studentSaveForm" method="post" action="<?php
		echo $router->relativeUrlFor("userRegister");
?>">
          <div class="container section">
            Nombre <input type="text" name="usuario"  id="usuario">
            Contraseña <input type="password" name="contrasenia" id=contrasenia>
            Verificacion <input type="password" name="contrasenia_same" id=contrasenia_same>
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 25 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 26 */ ?>">
            <button id="guardar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Guardar<i class="material-icons left">send</i></button>
          </div>
        </form>
      <div>
      <form action="<?php
		echo $router->relativeUrlFor("showAllUsers");
?>" method="post">
        <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 32 */ ?>">
        <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 33 */ ?>">
        <button id="retornar" type="submit" class="btn btn-primary btn-sm float-1" style="background-color: #10c2ee" >Retornar<i class="material-icons left">arrow_back</i></button>
      </form>
    </div>
    <div class="content"></div>
    <div class="footer-copyright blue-grey lighten-3" >
      <div class="container">
        <img class="header container section" src="/materialize/css/pie.jpg">
      </div>
    </div>
  </footer>
</body>
</html><?php
		return get_defined_vars();
	}

}
