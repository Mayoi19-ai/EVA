<?php
// source: Departamento/departmentUpdate.latte

use Latte\Runtime as LR;

class Template207b30e7d9 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<!DOCTYPE html>
  <html>
    <head>
      <meta charset="utf-8">
      <title><?php echo LR\Filters::escapeHtmlText($title) /* line 5 */ ?></title>
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
      <script type="text/javascript" src="/materialize/js/jquery.min.js"></script>
      <script type="text/javascript" src="/materialize/js/jquery-qrcode-0.18.0.js"></script>
      <script src="/materialize/js/materialize.min.js"></script>
      <link type="text/css" rel="stylesheet" href="/materialize/css/naver.css"  media="screen,projection">
      <script src="/materialize/validations/sellect.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
      <link type="text/css" rel="stylesheet" href="/materialize/css/formularios.css"  media="screen,projection">
<?php
		/* line 15 */
		$this->createTemplate('../validationUpdate.latte', $this->params, "include")->renderToContentType('html');
?>
    </head>
    <body>
<?php
		/* line 18 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
?>
      <ul id="nav-mobile">
        <div class="container section">
          <form name="departmentUpdateForm" method="post" action="<?php
		echo $router->relativeUrlFor("departmentUpdate");
?>">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 22 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 23 */ ?>">
            <div class="container section">
              <li>
                <label><input type="hidden" id="clave_antigua" name="clave_antigua" value="<?php echo LR\Filters::escapeHtmlAttr($data['clave']) /* line 26 */ ?>" class="validate"></label>
              </li>
              <li>
                <label for="clave">Clave:</label>
                <label><input type="text" id="clave" name="clave" value="<?php echo LR\Filters::escapeHtmlAttr($data['clave']) /* line 30 */ ?>" class="validate"></label>
              </li>
              <li>
                <label for="nombre">Nombre:</label>
                <input type="text" id="nombre" name="nombre" value="<?php echo LR\Filters::escapeHtmlAttr($data['nombre']) /* line 34 */ ?>" class="validate"></label>
              </li>
              <button id="guardar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Guardar<i class="material-icons left">send</i></button>
              </div>
            </form>
              <form action="<?php
		echo $router->relativeUrlFor("showAllDepartments");
?>" method="post">
                <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 40 */ ?>">
                <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 41 */ ?>">
                <button id="retornar" type="submit" class="btn btn-primary btn-sm float-1" style="background-color: #10c2ee" >Retornar<i class="material-icons left">arrow_back</i></button>
            </form>
          </div>
          <div class="content"></div>
          <div class="footer-copyright blue-grey lighten-3" >
            <div class="container">
              <img class="header container section" src="/materialize/css/pie.jpg">
            </div>
          </div>
        </footer>
      </body>
    <script src="/materialize/validations/resources.js" type="text/javascript"></script>
  </html><?php
		return get_defined_vars();
	}

}
