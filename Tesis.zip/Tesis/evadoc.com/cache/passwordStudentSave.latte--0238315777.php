<?php
// source: Contraseñas/passwordStudentSave.latte

use Latte\Runtime as LR;

class Template0238315777 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 5 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="/materialize/js/materialize.min.js"></script>
   <link type="text/css" rel="stylesheet" href="/materialize/css/student-naver.css"  media="screen,projection">

</head>
<nav>
    <div class="nav-wrapper blue-grey lighten-3">
    <img class="logo" src="https://www.itshuatusco.edu.mx/inicio/images/Logo%20ITSH%20300x312%20negritas.png"></a>
      <ul id="nav-mobile" class="right hide-on-med-and-down">

    <!--DropDown start -->
        <ul class="right hide-on-med-and-down">
      <li><a class="dropdown-trigger" href="#!" data-target="dropdown1"><i class="material-icons right">arrow_drop_down</i></a></li>
      <ul id='dropdown1' class='dropdown-content'>
        <li><a href="<?php
		echo $router->relativeUrlFor("loginStudent");
?>">Cerrar sesion</a></li>
      </ul>
    </ul>
    <a href="#" data-target="slide-out" class="sidenav-trigger"><i class="material-icons">menu</i></a>
          <!--dropdpen end -->
          <span class="white-text"><?php echo LR\Filters::escapeHtmlText($student_information['nombre']) /* line 26 */ ?></span></a>
           
      </ul>
    </div>
  </nav>
<!--nav end -->

<body>
<?php
		if (!empty ($query)) {
?>

       <div class="container section">
       <div class="card center">
              <div class="card center">
                     <p>Contraseña actualizada</p>
                     <form action="<?php
			echo $router->relativeUrlFor("studentCoursesMenu");
?>" method="post">
                     <i><input type="hidden" id="control" name="control" value="<?php echo LR\Filters::escapeHtmlAttr($student_information['control']) /* line 41 */ ?>">
                     <input type="submit" class="btn btn-primary btn-sm" value='Regresar a menu'>
              </div>
       </div>
                     </form>
</div>

 
     
	    <!--<span><?php echo LR\Filters::escapeHtmlComment($error) /* line 50 */ ?></span>-->
<?php
		}
		else {
?>
<div class="container section">
       <div class="card center">
              <div class="card center">
                     <p>Error al acompletar el registro</p>
                     <form action="<?php
			echo $router->relativeUrlFor("studentCoursesMenu");
?>" method="post">
                     <i><input type="hidden" id="control" name="control" value="<?php echo LR\Filters::escapeHtmlAttr($control) /* line 57 */ ?>">
                     <input type="submit" class="btn btn-primary btn-sm" value='Regresar a menu'>
              </div>
       </div>
                     </form>
</div>

 
<?php
		}
?>

    <!--footer -->
                  <div class="content"></div>
                    <footer class="page-footer blue-grey lighten-3">
                      <div class="footer-copyright">
                         <div class="row">
                           <div class="s12 m4 l8">
                              <p>© 2021 Copyright Todos los derechos reservados, Gerardo y Raul 2020</p>
                          </div>
                       </div>
                     </div>
                   </footer>
</body><?php
		return get_defined_vars();
	}

}
