<?php
// source: AsignarR/assignRUpdate.latte

use Latte\Runtime as LR;

class Template00d32aacac extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<!DOCTYPE html>
  <html>
    <head>
      <meta charset="utf-8">
      <title><?php echo LR\Filters::escapeHtmlText($title) /* line 5 */ ?></title>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
      <link type="text/css" rel="stylesheet" href="/materialize/css/formularios.css"  media="screen,projection">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
      <script type="text/javascript" src="/materialize/js/jquery.min.js"></script>
      <script type="text/javascript" src="/materialize/js/jquery-qrcode-0.18.0.js"></script>
      <script src="/materialize/js/materialize.min.js"></script>
      <link type="text/css" rel="stylesheet" href="/materialize/css/naver.css"  media="screen,projection">
      <link type="text/css" rel="stylesheet" href="/materialize/css/formularios.css"  media="screen,projection">
      <script src="/materialize/validations/sellect.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js%22%3E"></script>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js%22%3E"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.6/js/standalone/selectize.min.js" integrity="sha256-+C0A5Ilqmu4QcSPxrlGpaZxJ04VjsRjKu+G82kl5UJk=" crossorigin="anonymous"></script>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.6/css/selectize.bootstrap3.min.css" integrity="sha256-ze/OEYGcFbPRmvCnrSeKbRTtjG4vGLHXgOqsyLFTRjg=" crossorigin="anonymous">
<?php
		/* line 20 */
		$this->createTemplate('../validationUpdate.latte', $this->params, "include")->renderToContentType('html');
?>
    </head>
    <body>
<?php
		/* line 23 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
?>
        <ul id="nav-mobile">
          <div class="container section">
            <form name="rolUpdateForm" method="post" action="<?php
		echo $router->relativeUrlFor("userRolesUpdate");
?>">
              <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 27 */ ?>">
              <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 28 */ ?>">
              <input type="hidden" name="usuario" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario']) /* line 29 */ ?>">
              <input type="hidden" name="rol" value="<?php echo LR\Filters::escapeHtmlAttr($data['rol']) /* line 30 */ ?>">
                <ul>
                  <li>
                    <label><input type="hidden" id="id_usuario_antiguo" name="id_usuario_antiguo" value="<?php
		echo LR\Filters::escapeHtmlAttr($data['id_usuario']) /* line 33 */ ?>" class="validate"></label>
                  </li>
                  <li>
                    <label for="id_usuario">Selecciona un usuario:</label>
                    <select class="browser-default" name="id_usuario">
                    <option value="<?php echo LR\Filters::escapeHtmlAttr($data['id_usuario']) /* line 38 */ ?>" name="id_usuario"><?php
		echo LR\Filters::escapeHtmlText($data['usuario']) /* line 38 */ ?></option>
<?php
		$iterations = 0;
		foreach ($users as $usuarioOption) {
			?>                    <option  value="<?php echo LR\Filters::escapeHtmlAttr($usuarioOption['id']) /* line 40 */ ?>" ><?php
			echo LR\Filters::escapeHtmlText($usuarioOption['nombre']) /* line 40 */ ?></option>
<?php
			$iterations++;
		}
?>
                    </select>
                  </li>
                  <li>
                    <label><input type="hidden" id="id_roles_antiguo" name="id_roles_antiguo" value="<?php
		echo LR\Filters::escapeHtmlAttr($data['id_roles']) /* line 45 */ ?>" class="validate"></label>
                  </li>
                  <li>
                    <label for="id_roles">Selecciona un rol:</label>
                    <select class="browser-default" name="id_roles">
                    <option value="<?php echo LR\Filters::escapeHtmlAttr($data['id_roles']) /* line 50 */ ?>" name="id_roles"><?php
		echo LR\Filters::escapeHtmlText($data['rol']) /* line 50 */ ?></option>
<?php
		$iterations = 0;
		foreach ($roles as $rolesOption) {
			?>                    <option  value="<?php echo LR\Filters::escapeHtmlAttr($rolesOption['id']) /* line 52 */ ?>" ><?php
			echo LR\Filters::escapeHtmlText($rolesOption['nombre']) /* line 52 */ ?></option>
<?php
			$iterations++;
		}
?>
                    </select>
                  </li>
                    <button id="guardar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Guardar<i class="material-icons left">send</i></button>
                  </div>
              </form>
              <div>
                <form action="<?php
		echo $router->relativeUrlFor("showAllUserRoles");
?>" method="post">
                  <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 61 */ ?>">
                  <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 62 */ ?>">
                  <button id="retornar" type="submit" class="btn btn-primary btn-sm float-1" style="background-color: #10c2ee" >Retornar<i class="material-icons left">arrow_back</i></button>
                </form>
              </div>
              <div class="content"></div>
              <div class="footer-copyright blue-grey lighten-3" >
                <div class="container">
                  <img class="header container section" src="/materialize/css/pie.jpg">
                </div>
              </div>
            </footer>
          </body>
        <script src="/materialize/validations/resources.js" type="text/javascript"></script>
      </html><?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['usuarioOption'])) trigger_error('Variable $usuarioOption overwritten in foreach on line 39');
		if (isset($this->params['rolesOption'])) trigger_error('Variable $rolesOption overwritten in foreach on line 51');
		
	}

}
