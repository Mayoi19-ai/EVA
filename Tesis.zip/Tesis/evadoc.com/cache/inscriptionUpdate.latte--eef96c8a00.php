<?php
// source: Inscripcion/inscriptionUpdate.latte

use Latte\Runtime as LR;

class Templateeef96c8a00 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>


<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 7 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
      <script type="text/javascript" src="/materialize/js/jquery.min.js"></script>
      <script type="text/javascript" src="/materialize/js/jquery-qrcode-0.18.0.js"></script>
      <script src="/materialize/js/materialize.min.js"></script>
      <link type="text/css" rel="stylesheet" href="/materialize/css/naver.css"  media="screen,projection">
      <script src="/materialize/validations/delete.js"></script>
       <script src="/materialize/validations/sellect.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js%22%3E"></script>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js%22%3E"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.6/js/standalone/selectize.min.js" integrity="sha256-+C0A5Ilqmu4QcSPxrlGpaZxJ04VjsRjKu+G82kl5UJk=" crossorigin="anonymous"></script>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.6/css/selectize.bootstrap3.min.css" integrity="sha256-ze/OEYGcFbPRmvCnrSeKbRTtjG4vGLHXgOqsyLFTRjg=" crossorigin="anonymous">
         <link type="text/css" rel="stylesheet" href="/materialize/css/selectize.bootstrap3.min.css"  media="screen,projection">
 <link type="text/css" rel="stylesheet" href="/materialize/css/formularios.css"  media="screen,projection">
<?php
		/* line 22 */
		$this->createTemplate('../validationUpdate.latte', $this->params, "include")->renderToContentType('html');
?>
</head>
<body>
<?php
		/* line 25 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
?>
 <ul id="nav-mobile">
<div class="container section">
<form name="inscriptionUpdateForm" method="post" action="<?php
		echo $router->relativeUrlFor("inscriptionUpdate");
?>">
              <input type="hidden" name="id" value="<?php echo LR\Filters::escapeHtmlAttr($data['id']) /* line 29 */ ?>">
             <input type="hidden" name="id_curso" value="<?php echo LR\Filters::escapeHtmlAttr($data['id_curso']) /* line 30 */ ?>">
             <input type="hidden" name="control" value="<?php echo LR\Filters::escapeHtmlAttr($data['control']) /* line 31 */ ?>">
               <input type="hidden" name="nombre" value="<?php echo LR\Filters::escapeHtmlAttr($data['nombre']) /* line 32 */ ?>">
              <input type="hidden" name="grupo" value="<?php echo LR\Filters::escapeHtmlAttr($data['grupo']) /* line 33 */ ?>">
              <input type="hidden" name="carrera" value="<?php echo LR\Filters::escapeHtmlAttr($data['carrera']) /* line 34 */ ?>">
              <input type="hidden" name="asignatura" value="<?php echo LR\Filters::escapeHtmlAttr($data['asignatura']) /* line 35 */ ?>">
              <input type="hidden" name="docente" value="<?php echo LR\Filters::escapeHtmlAttr($data['docente']) /* line 36 */ ?>">
             <input type="hidden" name="activar" value="<?php echo LR\Filters::escapeHtmlAttr($data['activar']) /* line 37 */ ?>">
            <!-- -->
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 39 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 40 */ ?>">
            <!-- -->
             


            
<ul>
  <li>
    <label><input type="hidden" id="id" name="id" value="<?php echo LR\Filters::escapeHtmlAttr($data['id']) /* line 48 */ ?>" class="validate"></label>
  </li>
  <li>
    <label for="id_curso">Selecciona un curso:</label>
      <select  class="browser-default"  name="id_curso" >
      <option value="<?php echo LR\Filters::escapeHtmlAttr($data['id_curso']) /* line 53 */ ?>" name="id_curso"><?php
		echo LR\Filters::escapeHtmlText($data['grupo']) /* line 53 */ ?> - <?php echo LR\Filters::escapeHtmlText($data['carrera']) /* line 53 */ ?> - <?php
		echo LR\Filters::escapeHtmlText($data['asignatura']) /* line 53 */ ?> - <?php echo LR\Filters::escapeHtmlText($data['docente']) /* line 53 */ ?></option>
<?php
		$iterations = 0;
		foreach ($all_courses_information as $cursoOption) {
			?>      <option  value="<?php echo LR\Filters::escapeHtmlAttr($cursoOption['id_curso']) /* line 55 */ ?>"><?php
			echo LR\Filters::escapeHtmlText($cursoOption['grupo']) /* line 55 */ ?> - <?php echo LR\Filters::escapeHtmlText($cursoOption['carrera']) /* line 55 */ ?> - <?php
			echo LR\Filters::escapeHtmlText($cursoOption['asignatura']) /* line 55 */ ?> - <?php echo LR\Filters::escapeHtmlText($cursoOption['docente']) /* line 55 */ ?></option>
<?php
			$iterations++;
		}
?>
    </select>
  </li>


  <li>
   <label for="id_curso">Selecciona un alumno:</label>
      <select name="control" class="browser-default">
      <option value="<?php echo LR\Filters::escapeHtmlAttr($data['control']) /* line 64 */ ?>" name="control"><?php
		echo LR\Filters::escapeHtmlText($data['control']) /* line 64 */ ?> - <?php echo LR\Filters::escapeHtmlText($data['nombre']) /* line 64 */ ?></option>
<?php
		$iterations = 0;
		foreach ($all_students_information as $controlOption) {
			?>      <option  value="<?php echo LR\Filters::escapeHtmlAttr($controlOption['control']) /* line 66 */ ?>" ><?php
			echo LR\Filters::escapeHtmlText($controlOption['control']) /* line 66 */ ?> - <?php echo LR\Filters::escapeHtmlText($controlOption['nombre']) /* line 66 */ ?></option>
<?php
			$iterations++;
		}
?>
    </select>
  </li>

 <label for="activar">Estado de inscripcion</label>
      <select name="activar"  class="browser-default">
      <option value="<?php echo LR\Filters::escapeHtmlAttr($data['activar']) /* line 73 */ ?>" name="activar"><?php
		if ($data['activar'] == 1) {
?>Activo
                                          <?php
		}
		else {
?>No activo
<?php
		}
?>
     </option>
      <option value=1>Activo</option>
      <option value=0>No activo</option>
    </select>


   
<button id="guardar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Guardar<i class="material-icons left">send</i></button>
</div>
</form>
<div>
<form action="<?php
		echo $router->relativeUrlFor("showAllInscriptions");
?>" method="post">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 88 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 89 */ ?>">
 <button id="retornar" type="submit" class="btn btn-primary btn-sm float-1" style="background-color: #10c2ee" >Retornar<i class="material-icons left">arrow_back</i></button>
            </form>

</div>

    <!--footer -->
                  <div class="content"></div>
            <div class="footer-copyright blue-grey lighten-3" >
            <div class="container">
           <img class="header container section" src="/materialize/css/pie.jpg">
            </div>
          </div>
        </footer>
</body>

 <script src="/materialize/validations/resources.js" type="text/javascript"></script>
</html><?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['cursoOption'])) trigger_error('Variable $cursoOption overwritten in foreach on line 54');
		if (isset($this->params['controlOption'])) trigger_error('Variable $controlOption overwritten in foreach on line 65');
		
	}

}
