<?php
// source: Contrasenas/passwordStudentSave.latte

use Latte\Runtime as LR;

class Template41d85a68a2 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 5 */ ?></title>
   <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
 <script type="text/javascript" src="/materialize/js/jquery.min.js"></script>
    <script type="text/javascript" src="/materialize/js/jquery-qrcode-0.18.0.js"></script>
       <script src="/materialize/js/materialize.min.js"></script>
       <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
       <link type="text/css" rel="stylesheet" href="/materialize/css/studentNaver.css"  media="screen,projection">

</head>
 
           <img class="header container section" src="/materialize/css/cabeza.jpg">
      
<nav>
    <div class="nav-wrapper blue-grey lighten-3">
      <img class="logo" src="https://www.itshuatusco.edu.mx/inicio/images/Logo%20ITSH%20300x312%20negritas.png"></a>

        <!--Mobile -->
          <a href="#" class="sidenav-trigger" data-target="mobile-nav">
			    <i class="material-icons">menu</i>
		      </a>
            <ul class="right hide-on-med-and-down "  >
              <li><a href="<?php
		echo $router->relativeUrlFor("loginStudent");
?>">Cerrar sesion</a></li>
            </ul>
        <!-- -->
    </div>
</nav>
  <!-- -->
    <ul class="sidenav" id="mobile-nav">
         <li><a href="<?php
		echo $router->relativeUrlFor("loginStudent");
?>" id="actualizar" class="btn btn-primary btn-sm" style="background-color:#b0bec5">Cerrar sesion</a></li>
    </ul>
<!--nav end -->

<body>
<?php
		if (!empty ($query)) {
?>

       <div class="container section">
       <div class="card center">
              <div class="card center">
                     <p>Contraseña actualizada</p>
                     <form action="<?php
			echo $router->relativeUrlFor("studentCoursesMenu");
?>" method="post">
                     <i><input type="hidden" id="control" name="control" value="<?php echo LR\Filters::escapeHtmlAttr($student_information['control']) /* line 46 */ ?>">
                     <button id="retornar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Retornar<i class="material-icons left">arrow_back</i></button>
                      </form>
                  </div>
                </div>               
              </div>

 
     
	    <!--<span><?php echo LR\Filters::escapeHtmlComment($error) /* line 55 */ ?></span>-->
<?php
		}
		else {
?>
<div class="container section">
       <div class="card center">
              <div class="card center">
                     <p>Error al acompletar el registro</p>
                     <form action="<?php
			echo $router->relativeUrlFor("studentCoursesMenu");
?>" method="post">
                     <i><input type="hidden" id="control" name="control" value="<?php echo LR\Filters::escapeHtmlAttr($control) /* line 62 */ ?>">
                     <button id="retornar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Retornar<i class="material-icons left">arrow_back</i></button>
              </form>
              </div>
            </div>                 
          </div>

 
<?php
		}
?>

    <!--footer -->
                  <div class="content"></div>
            <div class="footer-copyright blue-grey lighten-3" >
            <div class="container">
           <img class="header container section" src="/materialize/css/pie.jpg">
            </div>
          </div>
        </footer>
</body>
<script> M.AutoInit(); </script>
<script>$(document).ready(function(){
 		$('.sidenav').sidenav();
 	});</script>
   </html><?php
		return get_defined_vars();
	}

}
