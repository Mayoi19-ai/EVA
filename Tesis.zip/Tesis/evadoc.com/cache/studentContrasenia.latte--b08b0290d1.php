<?php
// source: Contrasenas/studentContrasenia.latte

use Latte\Runtime as LR;

class Templateb08b0290d1 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
      <title><?php echo LR\Filters::escapeHtmlText($title) /* line 5 */ ?></title>
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
      <script type="text/javascript" src="/materialize/js/jquery.min.js"></script>
      <script type="text/javascript" src="/materialize/js/jquery-qrcode-0.18.0.js"></script>
      <script src="/materialize/js/materialize.min.js"></script>
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/studentNaver.css"  media="screen,projection">
      <script src="/materialize/validations/contrasenia.js" type="text/javascript"></script>
      <script src="/materialize/validations/resources.js" type="text/javascript"></script>
    </head>
    <body>
      <img class="header container section" src="/materialize/css/cabeza.jpg">
        <nav>
          <div class="nav-wrapper blue-grey lighten-3">
            <img class="logo" src="https://www.itshuatusco.edu.mx/inicio/images/Logo%20ITSH%20300x312%20negritas.png"></a>
            <a href="#" class="sidenav-trigger" data-target="mobile-nav">
			        <i class="material-icons">menu</i>
		        </a>
            <ul class="right hide-on-med-and-down "  >
              <li><a href="<?php
		echo $router->relativeUrlFor("loginStudent");
?>">Cerrar sesion</a></li>
            </ul>
          </div>
        </nav>
        <ul class="sidenav" id="mobile-nav">
          <li><a href="<?php
		echo $router->relativeUrlFor("loginStudent");
?>" id="actualizar" class="btn btn-primary btn-sm" style="background-color:#b0bec5">Cerrar sesion</a></li>
        </ul>
        <ul id="nav-mobile">
          <div class="container section">
            <form method="post" action="<?php
		echo $router->relativeUrlFor("studenPasswordUpdate");
?>">
              <ul>
                <li>
                  <label><input type="hidden" id="control" name="control" value="<?php echo LR\Filters::escapeHtmlAttr($student_information['control']) /* line 37 */ ?>" class="validate"></label>
                </li>
                <li>
                  <label><input type="hidden" id="nombre" name="nombre" value="<?php echo LR\Filters::escapeHtmlAttr($student_information['nombre']) /* line 40 */ ?>" class="validate"></label>
                </li>
                <li>
                  <input type="password" placeholder="Nueva contraseña" type="text" id="contrasenia" name="contrasenia" class="validate"></label>
                </li>
                <li>
                  <input type="password" placeholder="Confirmar nueva contraseña" type="text" id="contrasenia_same" name="contrasenia_same" class="validate"></label>
                </li>
                <div id="error"></div>
              </ul>
              <button id="guardar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" onclick ="return Logeo();" >Guardar<i class="material-icons left">send</i></button>
              </div>
            </form>
            <div>
            </div>
            <form action="<?php
		echo $router->relativeUrlFor("studentCoursesMenu");
?>" method="post">
              <i><input type="hidden" id="control" name="control" value="<?php echo LR\Filters::escapeHtmlAttr($student_information['control']) /* line 56 */ ?>">
                <button id="retornar" type="submit" class="btn btn-primary btn-sm float-2" style="background-color: #10c2ee" >Retornar<i class="material-icons left">arrow_back</i></button>
              </form>
                <div class="content"></div>
                  <div class="footer-copyright blue-grey lighten-3" >
                    <div class="container">
                      <img class="header container section" src="/materialize/css/pie.jpg">
                    </div>
                  </div>
                </footer>
              </body>
            </html><?php
		return get_defined_vars();
	}

}
