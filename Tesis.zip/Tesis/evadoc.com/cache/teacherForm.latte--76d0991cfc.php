<?php
// source: Docente/teacherForm.latte

use Latte\Runtime as LR;

class Template76d0991cfc extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<!DOCTYPE html>
  <html>
    <head>
      <meta charset="utf-8">
      <title><?php echo LR\Filters::escapeHtmlText($title) /* line 5 */ ?></title>
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
      <script type="text/javascript" src="/materialize/js/jquery.min.js"></script>
      <script type="text/javascript" src="/materialize/js/jquery-qrcode-0.18.0.js"></script>
      <script src="/materialize/js/materialize.min.js"></script>
      <link type="text/css" rel="stylesheet" href="/materialize/css/naver.css"  media="screen,projection">
      <script src="/materialize/validations/sellect.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
      <link type="text/css" rel="stylesheet" href="/materialize/css/formularios.css"  media="screen,projection">
<?php
		/* line 15 */
		$this->createTemplate('../validationCreate.latte', $this->params, "include")->renderToContentType('html');
?>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js%22%3E"></script>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js%22%3E"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.6/js/standalone/selectize.min.js" integrity="sha256-+C0A5Ilqmu4QcSPxrlGpaZxJ04VjsRjKu+G82kl5UJk=" crossorigin="anonymous"></script>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.6/css/selectize.bootstrap3.min.css" integrity="sha256-ze/OEYGcFbPRmvCnrSeKbRTtjG4vGLHXgOqsyLFTRjg=" crossorigin="anonymous">
    </head>
    <body>
<?php
		/* line 22 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
		?>      <form name="teacherSaveForm" method="post" action="<?php
		echo $router->relativeUrlFor("teacherRegister");
?>">
        <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 24 */ ?>">
        <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 25 */ ?>">
        <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 26 */ ?>">    
          <div class="container section">
            Folio <input type="text" name="folio" id="folio">
            Nombre docente <input type="text" name="nombre" id="nombre">
              <label for="clave_departamento">Selecciona un departamento:</label>
              <select class="browser-default" name="clave_departamento" id="clave_departamento">
              <option value="" name="clave_departamento" >Selecciona un departamento</option>
<?php
		$iterations = 0;
		foreach ($all_departments_information as $option) {
			?>              <option  value="<?php echo LR\Filters::escapeHtmlAttr($option['clave']) /* line 34 */ ?>" ><?php
			echo LR\Filters::escapeHtmlText($option['nombre']) /* line 34 */ ?></option>
<?php
			$iterations++;
		}
?>
              </select>
              <button id="guardar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee">Guardar<i class="material-icons left">send</i></button>
            </div>
          </form>
        <div>
          <form action="<?php
		echo $router->relativeUrlFor("showAllTeachers");
?>" method="post">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 42 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 43 */ ?>">
            <button id="retornar" type="submit" class="btn btn-primary btn-sm float-1" style="background-color: #10c2ee" >Retornar<i class="material-icons left">arrow_back</i></button>
          </form>
        </div>
        <div class="content"></div>
        <div class="footer-copyright blue-grey lighten-3" >
          <div class="container">
            <img class="header container section" src="/materialize/css/pie.jpg">
          </div>
        </div>
      </footer>
    </body>
  <script src="/materialize/validations/resources.js" type="text/javascript"></script>
</html><?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['option'])) trigger_error('Variable $option overwritten in foreach on line 33');
		
	}

}
