<?php
// source: Grupo/groupForm.latte

use Latte\Runtime as LR;

class Template02ea4c0bbe extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<!DOCTYPE html>
  <html>
    <head>
      <meta charset="utf-8">
      <title><?php echo LR\Filters::escapeHtmlText($title) /* line 5 */ ?></title>
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
      <script type="text/javascript" src="/materialize/js/jquery.min.js"></script>
      <script type="text/javascript" src="/materialize/js/jquery-qrcode-0.18.0.js"></script>
      <script src="/materialize/js/materialize.min.js"></script>
      <link type="text/css" rel="stylesheet" href="/materialize/css/naver.css"  media="screen,projection">
      <script src="/materialize/validations/sellect.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js%22%3E"></script>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js%22%3E"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.6/js/standalone/selectize.min.js" integrity="sha256-+C0A5Ilqmu4QcSPxrlGpaZxJ04VjsRjKu+G82kl5UJk=" crossorigin="anonymous"></script>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.6/css/selectize.bootstrap3.min.css" integrity="sha256-ze/OEYGcFbPRmvCnrSeKbRTtjG4vGLHXgOqsyLFTRjg=" crossorigin="anonymous">
      <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
      <link type="text/css" rel="stylesheet" href="/materialize/css/formularios.css"  media="screen,projection">
<?php
		/* line 19 */
		$this->createTemplate('../validationCreate.latte', $this->params, "include")->renderToContentType('html');
?>
    </head>
    <body>
<?php
		/* line 22 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
?>
      <ul id="nav-mobile">
        <div class="container section">
          <form name="groupSaveForm" method="post" action="<?php
		echo $router->relativeUrlFor("groupRegister");
?>">
            Nombre del grupo <input type="text" name="grupo" >
            <label for="id_carrera">Selecciona una carrera:</label>
            <select class="browser-default" name="id_carrera">
            <option value="" name="id_carrera">Selecciona una carrera</option>
<?php
		$iterations = 0;
		foreach ($all_careers_information as $idCarrera) {
			?>            <option  value="<?php echo LR\Filters::escapeHtmlAttr($idCarrera['id']) /* line 31 */ ?>" ><?php
			echo LR\Filters::escapeHtmlText($idCarrera['nombre']) /* line 31 */ ?></option>
<?php
			$iterations++;
		}
?>
            </select>
            <label for="id_modalidad">Selecciona una modalidad:</label>
            <select class="browser-default" name="id_modalidad" id="id_modalidad">
            <option value="" name="id_modalidad">Selecciona una modalidad </option>
<?php
		$iterations = 0;
		foreach ($all_modalities_information as $idModalidad) {
			?>            <option  value="<?php echo LR\Filters::escapeHtmlAttr($idModalidad['id']) /* line 38 */ ?>" ><?php
			echo LR\Filters::escapeHtmlText($idModalidad['nombre']) /* line 38 */ ?></option>
<?php
			$iterations++;
		}
?>
            </select>
            <label for="id_campus">Selecciona un campus:</label>
            <select class="browser-default" name="id_campus" id="id_campus">
            <option value="" name="id_campus">Selecciona un campus </option>
<?php
		$iterations = 0;
		foreach ($all_campus_information as $idCampus) {
			?>            <option  value="<?php echo LR\Filters::escapeHtmlAttr($idCampus['id']) /* line 45 */ ?>" ><?php
			echo LR\Filters::escapeHtmlText($idCampus['nombre']) /* line 45 */ ?></option>
<?php
			$iterations++;
		}
?>
            </select>
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 48 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 49 */ ?>">
            <button id="guardar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Guardar<i class="material-icons left">send</i></button>
          </form>
        </div>
        <div>
          <form action="<?php
		echo $router->relativeUrlFor("showAllGroups");
?>" method="post">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 55 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 56 */ ?>">
            <button id="retornar" type="submit" class="btn btn-primary btn-sm float-1" style="background-color: #10c2ee" >Retornar<i class="material-icons left">arrow_back</i></button>
          </form>
        </div>
        <div class="content"></div>
          <div class="footer-copyright blue-grey lighten-3" >
            <div class="container">
              <img class="header container section" src="/materialize/css/pie.jpg">
            </div>
          </div>
        </footer>
      </body>
    <script src="/materialize/validations/resources.js" type="text/javascript"></script>
  </html><?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['idCarrera'])) trigger_error('Variable $idCarrera overwritten in foreach on line 30');
		if (isset($this->params['idModalidad'])) trigger_error('Variable $idModalidad overwritten in foreach on line 37');
		if (isset($this->params['idCampus'])) trigger_error('Variable $idCampus overwritten in foreach on line 44');
		
	}

}
