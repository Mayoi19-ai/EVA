<?php
// source: validationDelete.latte

use Latte\Runtime as LR;

class Template961437ef73 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
 <script type="text/javascript">
     function confirmation() 
     {
        if(confirm("Desea eliminar"))
	{
	   return true;
	}
	else
	{
	   return false;
	}
     }
    </script><?php
		return get_defined_vars();
	}

}
