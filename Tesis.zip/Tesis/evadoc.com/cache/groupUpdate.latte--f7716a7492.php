<?php
// source: Grupo/groupUpdate.latte

use Latte\Runtime as LR;

class Templatef7716a7492 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<!DOCTYPE html>
  <html>
    <head>
      <meta charset="utf-8">
      <title><?php echo LR\Filters::escapeHtmlText($title) /* line 5 */ ?></title>
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
      <script type="text/javascript" src="/materialize/js/jquery.min.js"></script>
      <script type="text/javascript" src="/materialize/js/jquery-qrcode-0.18.0.js"></script>
      <script src="/materialize/js/materialize.min.js"></script>
      <link type="text/css" rel="stylesheet" href="/materialize/css/naver.css"  media="screen,projection">
      <script src="/materialize/validations/sellect.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js%22%3E"></script>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js%22%3E"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.6/js/standalone/selectize.min.js" integrity="sha256-+C0A5Ilqmu4QcSPxrlGpaZxJ04VjsRjKu+G82kl5UJk=" crossorigin="anonymous"></script>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.6/css/selectize.bootstrap3.min.css" integrity="sha256-ze/OEYGcFbPRmvCnrSeKbRTtjG4vGLHXgOqsyLFTRjg=" crossorigin="anonymous">
      <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
      <link type="text/css" rel="stylesheet" href="/materialize/css/formularios.css"  media="screen,projection">
<?php
		/* line 19 */
		$this->createTemplate('../validationUpdate.latte', $this->params, "include")->renderToContentType('html');
?>
    </head>
    <body>
<?php
		/* line 22 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
?>
        <ul id="nav-mobile">
          <div class="container section">
            <form name="groupUpdateForm" method="post" action="<?php
		echo $router->relativeUrlFor("groupUpdate");
?>">
              <input type="hidden" name="nombre_carrera" value="<?php echo LR\Filters::escapeHtmlAttr($data['nombre_carrera']) /* line 26 */ ?>">
              <input type="hidden" name="nombre_modalidad" value="<?php echo LR\Filters::escapeHtmlAttr($data['nombre_modalidad']) /* line 27 */ ?>">
              <input type="hidden" name="nombre_campus" value="<?php echo LR\Filters::escapeHtmlAttr($data['nombre_campus']) /* line 28 */ ?>">
              <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 29 */ ?>">
              <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 30 */ ?>">
                <div class="container section">
                  <li>
                    <label><input type="hidden" id="grupo_antiguo" name="grupo_antiguo" value="<?php echo LR\Filters::escapeHtmlAttr($data['grupo']) /* line 33 */ ?>" class="validate"></label>
                  <li>
                    <label><input type="hidden" id="id_carrera_antiguo" name="id_carrera_antiguo" value="<?php
		echo LR\Filters::escapeHtmlAttr($data['id_carrera']) /* line 35 */ ?>" class="validate"></label>
                  </li>
                  <li>
                    <label><input type="hidden" id="id_modalidad_antiguo" name="id_modalidad_antiguo" value="<?php
		echo LR\Filters::escapeHtmlAttr($data['id_modalidad']) /* line 38 */ ?>" class="validate"></label>
                  </li>
                  <li>
                    <label><input type="hidden" id="id_campus_antiguo" name="id_campus_antiguo" value="<?php
		echo LR\Filters::escapeHtmlAttr($data['id_campus']) /* line 41 */ ?>" class="validate"></label>
                  </li>
                  <li>
                    <label for="nombre">Nombre del grupo:</label>
                    <label><input id="nombre" name="grupo" value="<?php echo LR\Filters::escapeHtmlAttr($data['grupo']) /* line 45 */ ?>" class="validate"></label>
                  </li>
                  <li>
                    <label for="id_carrera">Carrera:</label>
                    <select class="browser-default" name="id_carrera">
                    <option value="<?php echo LR\Filters::escapeHtmlAttr($data['id_carrera']) /* line 50 */ ?>" name="id_carrera"><?php
		echo LR\Filters::escapeHtmlText($data['nombre_carrera']) /* line 50 */ ?></option>
<?php
		$iterations = 0;
		foreach ($all_careers_information as $careerOption) {
			?>                    <option  value="<?php echo LR\Filters::escapeHtmlAttr($careerOption['id']) /* line 52 */ ?>" ><?php
			echo LR\Filters::escapeHtmlText($careerOption['nombre']) /* line 52 */ ?></option>
<?php
			$iterations++;
		}
?>
                    </select>
                  </li>
                  <li>
                    <label for="id_modalidad">Modalidad:</label>
                    <select class="browser-default" name="id_modalidad">
                    <option value="<?php echo LR\Filters::escapeHtmlAttr($data['id_modalidad']) /* line 59 */ ?>" name="id_modalidad"><?php
		echo LR\Filters::escapeHtmlText($data['nombre_modalidad']) /* line 59 */ ?></option>
<?php
		$iterations = 0;
		foreach ($all_modalities_information as $modalityOption) {
			?>                    <option  value="<?php echo LR\Filters::escapeHtmlAttr($modalityOption['id']) /* line 61 */ ?>" ><?php
			echo LR\Filters::escapeHtmlText($modalityOption['nombre']) /* line 61 */ ?></option>
<?php
			$iterations++;
		}
?>
                    </select>
                  </li>
                  <li>
                    <label for="id_campus">Campus:</label>
                    <select class="browser-default" name="id_campus">
                    <option value="<?php echo LR\Filters::escapeHtmlAttr($data['id_campus']) /* line 68 */ ?>" name="id_campus"><?php
		echo LR\Filters::escapeHtmlText($data['nombre_campus']) /* line 68 */ ?></option>
<?php
		$iterations = 0;
		foreach ($all_campus_information as $campusOption) {
			?>                    <option  value="<?php echo LR\Filters::escapeHtmlAttr($campusOption['id']) /* line 70 */ ?>" ><?php
			echo LR\Filters::escapeHtmlText($campusOption['nombre']) /* line 70 */ ?></option>
<?php
			$iterations++;
		}
?>
                    </select>
                  </li>
                  <button id="guardar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Guardar<i class="material-icons left">send</i></button>
                </div>
              </form>
              <form action="<?php
		echo $router->relativeUrlFor("showAllGroups");
?>" method="post">
                <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 78 */ ?>">
                <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 79 */ ?>">
                <button id="retornar" type="submit" class="btn btn-primary btn-sm float-1" style="background-color: #10c2ee" >Retornar<i class="material-icons left">arrow_back</i></button>
              </form>
            </div>
            <div class="content"></div>
            <div class="footer-copyright blue-grey lighten-3" >
              <div class="container">
               <img class="header container section" src="/materialize/css/pie.jpg">
              </div>
            </div>
          </footer>
        </body>
      <script src="/materialize/validations/resources.js" type="text/javascript"></script>
    </html><?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['careerOption'])) trigger_error('Variable $careerOption overwritten in foreach on line 51');
		if (isset($this->params['modalityOption'])) trigger_error('Variable $modalityOption overwritten in foreach on line 60');
		if (isset($this->params['campusOption'])) trigger_error('Variable $campusOption overwritten in foreach on line 69');
		
	}

}
