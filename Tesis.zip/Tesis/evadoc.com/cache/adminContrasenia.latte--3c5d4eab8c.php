<?php
// source: Contrasenas/adminContrasenia.latte

use Latte\Runtime as LR;

class Template3c5d4eab8c extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<!DOCTYPE html>
  <html>
    <head>
      <meta charset="utf-8">
      <title><?php echo LR\Filters::escapeHtmlText($title) /* line 5 */ ?></title>
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
      <script type="text/javascript" src="/materialize/js/jquery.min.js"></script>
      <script type="text/javascript" src="/materialize/js/jquery-qrcode-0.18.0.js"></script>
      <script src="/materialize/js/materialize.min.js"></script>
      <link type="text/css" rel="stylesheet" href="/materialize/css/studentNaver.css"  media="screen,projection">
      <script src="/materialize/validations/contrasenia.js" type="text/javascript"></script>
      <script src="/materialize/validations/resources.js" type="text/javascript"></script>
    </head>
    <body>
      <img class="header container section" src="/materialize/css/cabeza.jpg">    
        <nav>
          <div class="nav-wrapper blue-grey lighten-3">
            <img class="logo" src="https://www.itshuatusco.edu.mx/inicio/images/Logo%20ITSH%20300x312%20negritas.png">
              <ul id="nav-mobile" class="right hide-on-med-and-down">
                <li>
                  <a class="dropdown-trigger" href="#!" data-target="dropdown1">Opciones<i class="material-icons right">arrow_drop_down</i></a></li>
                    <ul id='dropdown1' class='dropdown-content'>
                      <li><a href="<?php
		echo $router->relativeUrlFor("usersLogin");
?>">Cerrar sesion</a></li>                  
                    </ul>
                  </ul>
                </li>
              </ul>
            </div>
          </nav>
          <ul id="nav-mobile">
            <div class="container section">
              <form method="post" action="<?php
		echo $router->relativeUrlFor("userPasswordUpdate");
?>">
                <ul>
                  <li>
                    <label><input type="hidden" id="usuario_activo" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 36 */ ?>" class="validate"></label>
                  </li>
                <li>
                  <label><input type="hidden" id="categoria_permisos" name="categoria_permisos" value="<?php
		echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 39 */ ?>" class="validate"></label>
                </li>
                <li>
                  <input type="password" placeholder="Nueva contraseña" type="text" id="contrasenia" name="contrasenia" class="validate"></label>
                </li>
                <li>
                  <input type="password" placeholder="Confirmar nueva contraseña" type="text" id="contrasenia_same" name="contrasenia_same" class="validate"></label>
                </li>
                  <div id="error"></div>
                </ul>
                  <button id="guardar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" onclick ="return Logeo();" >Guardar<i class="material-icons left">send</i></button></div>
                </form>
                <form action="<?php
		echo $router->relativeUrlFor("userMenu");
?>" method="post">
                  <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 52 */ ?>">
                  <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 53 */ ?>">
                  <button id="retornar" type="submit" class="btn btn-primary btn-sm float-2" style="background-color: #10c2ee" >Retornar<i class="material-icons left">arrow_back</i></button>
                  </form>
                <div>
              </div>
              <!--footer -->
              <div class="content"></div>
                <div class="footer-copyright blue-grey lighten-3" >
                  <div class="container">
                    <img class="header container section" src="/materialize/css/pie.jpg">
                  </div>
                </div>
              </footer>
            </body>



</html><?php
		return get_defined_vars();
	}

}
