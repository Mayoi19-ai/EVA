<?php
// source: Periodo/periodTable.latte

use Latte\Runtime as LR;

class Templatee5f999c9d0 extends Latte\Runtime\Template
{
	public $blocks = [
		'content' => 'blockContent',
	];

	public $blockTypes = [
		'content' => 'html',
	];


	function main()
	{
		extract($this->params);
		/* line 1 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
		/* line 2 */
		$this->createTemplate('../validationDelete.latte', $this->params, "include")->renderToContentType('html');
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('content', get_defined_vars());
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['permissionInfor'])) trigger_error('Variable $permissionInfor overwritten in foreach on line 51, 100, 116, 133');
		if (isset($this->params['periodShow'])) trigger_error('Variable $periodShow overwritten in foreach on line 79');
		
	}


	function blockContent($_args)
	{
		extract($_args);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 9 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
       
</head>

<body>
 <ul id="nav-mobile">
                <div class="row">
                <div class="col s12 m6 l3">
<!--Activar evaluacion -->
<form name="periodActivateEvaluation" method="post" action="<?php
		echo $router->relativeUrlFor("periodActivateEvaluation");
?>">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 22 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 23 */ ?>">

<label for="activar_evaluacion">Estado de la evaluación</label>
      <select class="browser-default" name="activar_evaluacion">
      <option value="" name="activar_evaluacion"><?php
		if ($evaluation['activar'] == 1) {
?>Activa
                                          <?php
		}
		else {
?>No activa
<?php
		}
?>
     </option>
      <option value=1>Activa</option>
      <option value=0>No activa</option>
    </select>
<button id="guardar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Guardar<i class="material-icons left">send</i></button>
</form>
</div>


<!-- -->
<?php
		if (empty ($query)) {
?>
       <div class="container section">
       <div class="card center">
              <div class="card center">
                 <img class="logo" src="/materialize/css/alerta3.png">
                     <h5>NO HAY PERIODO DISPONIBLE</h5>

                     <form action="<?php
			echo $router->relativeUrlFor("periodSaveForm");
?>" method="post">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 48 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 49 */ ?>">
   <div class="fixed-action-btn">
<?php
			$iterations = 0;
			foreach ($permissions as $permissionInfor) {
				$permisos  = explode(" - ", $permissionInfor['enlace']);
				;
				if ($permisos[1] == "periodSaveForm") {
?>
<button id="agrerar" type="submit" class="btn btn-primary btn-sm float-2" style="background-color: #22DD22" >Agregar<i class="material-icons left">add</i></button>

<?php
				}
				$iterations++;
			}
?>

</form>
                    
              </div>
       </div>
</div>

<?php
		}
		else {
?>
<div class="MiTabla">
 <table name="showAllPeriods" method="get" class="bordered striped hoverable centered responsive-table"> <!-- nombre de tabla-->
<thead>
<tr>
<th>Nombre</th>
<th>Inicio</th>
<th>Fin</th>
<th>Estado</th>
<th></th>
<th></th>
</tr>
</thead>
<tbody>
<?php
			$iterations = 0;
			foreach ($query as $periodShow) {
?>
<tr>
    <td><?php echo LR\Filters::escapeHtmlText($periodShow['nombre']) /* line 81 */ ?> </td>
    <td><?php echo LR\Filters::escapeHtmlText($periodShow['inicia']) /* line 82 */ ?> </td>
    <td><?php echo LR\Filters::escapeHtmlText($periodShow['termina']) /* line 83 */ ?> </td>
    
<?php
				if ($periodShow['activar'] == 1) {
?>
     <td>Activo</td>
<?php
				}
				else {
?>
        <td>No activo</td>
<?php
				}
?>
     
<td>
<form action="<?php
				echo $router->relativeUrlFor("periodUpdateForm");
?>" method="post">
            <input type="hidden" name="id" value="<?php echo LR\Filters::escapeHtmlAttr($periodShow['id']) /* line 93 */ ?>">
            <input type="hidden" name="nombre" value="<?php echo LR\Filters::escapeHtmlAttr($periodShow['nombre']) /* line 94 */ ?>">
            <input type="hidden" name="inicia" value="<?php echo LR\Filters::escapeHtmlAttr($periodShow['inicia']) /* line 95 */ ?>">
            <input type="hidden" name="termina" value="<?php echo LR\Filters::escapeHtmlAttr($periodShow['termina']) /* line 96 */ ?>">
             <input type="hidden" name="activar" value="<?php echo LR\Filters::escapeHtmlAttr($periodShow['activar']) /* line 97 */ ?>">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 98 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 99 */ ?>">
<?php
				$iterations = 0;
				foreach ($permissions as $permissionInfor) {
					$permisos  = explode(" - ", $permissionInfor['enlace']);
					;
					if ($permisos[1] == "periodUpdateForm") {
?>
        <button id="actualizar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Editar<i class="material-icons left">edit</i></button>
<?php
					}
					$iterations++;
				}
?>
</form>
</td>
<td>
    <form action="<?php
				echo $router->relativeUrlFor("periodDelete");
?>" method="post" onsubmit="return confirmation()">
            <input type="hidden" name="id" value="<?php echo LR\Filters::escapeHtmlAttr($periodShow['id']) /* line 110 */ ?>">
            <!-- No tocar lo de abajo-->
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 112 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 113 */ ?>">
            <!--No tocar lo de arriba -->
             <form action="<?php
				echo $router->relativeUrlFor("rolePermissionsDelete");
?>" method="post" onsubmit="return confirmation()">
<?php
				$iterations = 0;
				foreach ($permissions as $permissionInfor) {
					$permisos  = explode(" - ", $permissionInfor['enlace']);
					;
					if ($permisos[1] == "periodDelete") {
?>
    <button type="submit" id="eliminar" style="background-color: #f44336" class="btn btn-primary btn-sm #f44336" value='Eliminar'>Eliminar<i class="material-icons left">delete</i></button>
<?php
					}
					$iterations++;
				}
?>
    </form>
</td>

</tr>
<?php
				$iterations++;
			}
?>

</tbody>
 <form action="<?php
			echo $router->relativeUrlFor("periodSaveForm");
?>" method="post">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 130 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 131 */ ?>">
   <div class="fixed-action-btn">
<?php
			$iterations = 0;
			foreach ($permissions as $permissionInfor) {
				$permisos  = explode(" - ", $permissionInfor['enlace']);
				;
				if ($permisos[1] == "periodSaveForm") {
?>
<button id="agrerar" type="submit" class="btn btn-primary btn-sm float-2" style="background-color: #22DD22" >Agregar<i class="material-icons left">add</i></button>
<?php
				}
				$iterations++;
			}
		}
?>
</form>
</table>
</div>
<!--footer -->
                   <div class="content"></div>
            <div class="footer-copyright blue-grey lighten-3" >
            <div class="container">
           <img class="header container section" src="/materialize/css/pie.jpg">
            </div>
          </div>
        </footer>
</body>
<script> M.AutoInit(); </script>
</html>
<?php
	}

}
