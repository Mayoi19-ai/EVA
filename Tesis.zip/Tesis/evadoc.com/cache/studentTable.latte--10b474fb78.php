<?php
// source: Alumno/studentTable.latte

use Latte\Runtime as LR;

class Template10b474fb78 extends Latte\Runtime\Template
{
	public $blocks = [
		'content' => 'blockContent',
	];

	public $blockTypes = [
		'content' => 'html',
	];


	function main()
	{
		extract($this->params);
		/* line 1 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
		/* line 2 */
		$this->createTemplate('../validationDelete.latte', $this->params, "include")->renderToContentType('html');
		/* line 3 */
		$this->createTemplate('../validationPassword.latte', $this->params, "include")->renderToContentType('html');
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('content', get_defined_vars());
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['permissionInfor'])) trigger_error('Variable $permissionInfor overwritten in foreach on line 68, 84, 99, 118');
		if (isset($this->params['studentShow'])) trigger_error('Variable $studentShow overwritten in foreach on line 56');
		
	}


	function blockContent($_args)
	{
		extract($_args);
?>
    <!DOCTYPE html>
        <html>
            <head>
                <meta charset="utf-8">
                <title><?php echo LR\Filters::escapeHtmlText($title) /* line 9 */ ?></title>
                <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
                <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
                <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
            </head>
            <!-- -->
            <body>
             <ul id="nav-mobile">
                <div class="row">
                <div class="col s12 m6 l3">
                    <form name="showAllStudent" method="post" action="<?php
		echo $router->relativeUrlFor("studentSearch");
?>">
                        <label for="control">Busqueda por número de control<label>
                        <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 21 */ ?>">
                        <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 22 */ ?>">
                        <input type="text" name="control">
                        <button id="buscar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Buscar<i class="material-icons left">search</i></button>
                    </div>
                </div>
            </form>       
<!-- -->
<?php
		if (empty ($query)) {
?>
                <div class="container section">
                    <div class="card center">
                        <div class="card center">
                         <img class="logo" src="/materialize/css/alerta3.png">
                        <p>NO SE CUENTA CON ALUMNOS REGISTRADOS</p>
                          <form action="<?php
			echo $router->relativeUrlFor("userMenu");
?>" method="post">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 36 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 37 */ ?>">
 <input id="retorno" type="submit" class="btn btn-primary btn-sm" value='Retornar'>
            </form>
                    </div>
                 </div>
            </div>
<?php
		}
		else {
?>
<div class="responsive-table">
<table name="showAllStudent" method="get" class="bordered striped hoverable centered responsive-table">
<thead>
<tr>
<th>Numero de control</th>
<th>Nombre</th>
<th>Actualizar alumno</th>
<th>Eliminar alumno</th>
<th>Reestablecer contraseña</th>
</tr>
</thead>
<tbody>
<?php
			$iterations = 0;
			foreach ($query as $studentShow) {
?>
<tr>
    <td><?php echo LR\Filters::escapeHtmlText($studentShow['control']) /* line 58 */ ?> </td>
    <td><?php echo LR\Filters::escapeHtmlText($studentShow['nombre']) /* line 59 */ ?> </td>
    <td>
<form action="<?php
				echo $router->relativeUrlFor("studentUpdateForm");
?>" method="post">
            <input type="hidden" name="control" value="<?php echo LR\Filters::escapeHtmlAttr($studentShow['control']) /* line 62 */ ?>">
             <input type="hidden" name="nombre" value="<?php echo LR\Filters::escapeHtmlAttr($studentShow['nombre']) /* line 63 */ ?>">
             <!-- -->
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 65 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 66 */ ?>">
            <!-- -->
<?php
				$iterations = 0;
				foreach ($permissions as $permissionInfor) {
					$permisos  = explode(" - ", $permissionInfor['enlace']);
					;
					if ($permisos[1] == "studentUpdateForm") {
?>
        <button id="actualizar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Editar<i class="material-icons left">edit</i></button>
<?php
					}
					$iterations++;
				}
?>
</form>
</td>
<td>
    <form action="<?php
				echo $router->relativeUrlFor("studentDelete");
?>" method="post" onsubmit="return confirmation()">
            <input type="hidden" name="control" value="<?php echo LR\Filters::escapeHtmlAttr($studentShow['control']) /* line 78 */ ?>">
            <!-- No tocar lo de abajo-->
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 80 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 81 */ ?>">
            <!--No tocar lo de arriba -->
             <form action="<?php
				echo $router->relativeUrlFor("rolePermissionsDelete");
?>" method="post" onsubmit="return confirmation()">
<?php
				$iterations = 0;
				foreach ($permissions as $permissionInfor) {
					$permisos  = explode(" - ", $permissionInfor['enlace']);
					;
					if ($permisos[1] == "studentDelete") {
?>
   <button type="submit" id="eliminar" style="background-color: #f44336" class="btn btn-primary btn-sm #f44336" value='Eliminar'>Eliminar<i class="material-icons left">delete</i></button>
<?php
					}
					$iterations++;
				}
?>
    </form>
</td>
<td>
    <form action="<?php
				echo $router->relativeUrlFor("studentUpdatePassword");
?>" method="post" onsubmit="return confirmationContrasenia()">
            <input type="hidden" name="control" value="<?php echo LR\Filters::escapeHtmlAttr($studentShow['control']) /* line 94 */ ?>">
            <!-- No tocar lo de abajo-->
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 96 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 97 */ ?>">
            <!--No tocar lo de arriba -->
<?php
				$iterations = 0;
				foreach ($permissions as $permissionInfor) {
					$permisos  = explode(" - ", $permissionInfor['enlace']);
					;
					if ($permisos[1] == "studentUpdatePasswordShow") {
?>
    <input type="submit" id="eliminar" style="background-color: #f44336" class="btn btn-primary btn-sm #f44336" value='Restablecer contraseña'>
<?php
					}
					$iterations++;
				}
?>
    </form>
</td>



</tr>
<?php
				$iterations++;
			}
?>

</tbody>
 <form action="<?php
			echo $router->relativeUrlFor("studentSaveForm");
?>" method="post">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 115 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 116 */ ?>">
   <div class="fixed-action-btn">
<?php
			$iterations = 0;
			foreach ($permissions as $permissionInfor) {
				$permisos  = explode(" - ", $permissionInfor['enlace']);
				;
				if ($permisos[1] == "studentSaveForm") {
?>
 <button id="agrerar" type="submit" class="btn btn-primary btn-sm float-2" style="background-color: #22DD22" >Agregar<i class="material-icons left">add</i></button>
<?php
				}
				$iterations++;
			}
		}
?>
</form>
</table>
</div>
<!--footer -->
                  <div class="content"></div>
            <div class="footer-copyright blue-grey lighten-3" >
            <div class="container">
           <img class="header container section" src="/materialize/css/pie.jpg">
            </div>
          </div>
        </footer>
</body>
<script> M.AutoInit(); </script>
</html>
<?php
	}

}
