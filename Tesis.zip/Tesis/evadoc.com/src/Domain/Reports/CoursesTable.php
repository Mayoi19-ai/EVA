<?php
namespace App\Domain\Reports;

class CoursesTable {
    public function receiver(array $coursesArray): array
    {
        foreach ($coursesArray as $course) {
            $enrolledStudents[] = $course[4];
            $studentsEvaluated[] = $course[5];
        }

        return $this->operations((array) array('inscribed' => $enrolledStudents,
            'evaluated' => $studentsEvaluated));
    }

    private function operations(array $students): array
    { 
        $evaluated = array_sum($students['evaluated']);
        $inscribed = array_sum($students['inscribed']);
        $percentage = (float) ($evaluated * 100) / $inscribed;
        $percentage = round($percentage, 2);

        return array('inscribed' => $inscribed,
            'evaluated' => $evaluated,
            'percentage' => $percentage);
    }
}