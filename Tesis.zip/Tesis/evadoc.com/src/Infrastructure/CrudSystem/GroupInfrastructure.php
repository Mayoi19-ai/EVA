<?php
namespace App\Infrastructure\CrudSystem;

use Medoo\Medoo;
use App\Infrastructure\Exceptions\CustomException as Exception;
use App\Infrastructure\Binnacle\Binnacle;

class GroupInfrastructure {
    private Medoo $db;
    private Exception $exception;
    private Binnacle $binnacle;

    public function __construct(Medoo $db, Exception $exception, Binnacle $binnacle) 
    {
        $this->db = $db;
        $this->exception = $exception;
        $this->binnacle = $binnacle;
    }

    public function create(array $data): bool
    {
        $this->db->pdo->beginTransaction();
        $sql = <<<'EOP'
        INSERT INTO grupo (nombre, id_periodo, id_carrera, id_modalidad, id_campus) 
        SELECT :nombre, periodo.id, :id_carrera, :id_modalidad, :id_campus 
        FROM periodo WHERE periodo.activar = 1;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $group = strtoupper($data['grupo']);
        $sth->bindParam(':nombre', $group);
        $sth->bindParam(':id_carrera', $data['id_carrera']);
        $sth->bindParam(':id_modalidad', $data['id_modalidad']);
        $sth->bindParam(':id_campus', $data['id_campus']);
        $sth->execute();

        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Registrar',
        'tabla_afectada' => 'Grupo'));
        
        return $this->exception->save((array) $this->db->error());
    }

    public function readAll(): ?array
    {
        $sql = <<<'EOP'
        SELECT grupo.nombre AS 'grupo',
        carrera.nombre_corto AS 'carrera',
        grupo.id_carrera AS 'id_carrera',
        modalidad.nombre AS 'modalidad',    
        grupo.id_modalidad AS 'id_modalidad',
        campus.nombre AS 'campus',
        grupo.id_campus AS 'id_campus'
        FROM 
        grupo
        INNER JOIN carrera
        ON carrera.id = grupo.id_carrera
        INNER JOIN periodo
        ON grupo.id_periodo = (SELECT periodo.id FROM periodo WHERE periodo.activar = 1) AND periodo.id = grupo.id_periodo
        INNER JOIN campus
        ON campus.id = grupo.id_campus
        INNER JOIN modalidad
        ON grupo.id_modalidad = modalidad.id
        ORDER BY carrera.id, grupo.nombre ASC;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->execute();
        $records = $sth->fetchAll();
        
        return $this->exception->read((array) $this->db->error(), (array) $records);
    }

    public function readByGroup(string $group): ?array
    {
        $sql = <<<'EOP'
        SELECT grupo.nombre AS 'grupo',
        carrera.nombre_corto AS 'carrera',
        grupo.id_carrera AS 'id_carrera',
        modalidad.nombre AS 'modalidad',
        grupo.id_modalidad AS 'id_modalidad',
        campus.nombre AS 'campus',
        grupo.id_campus AS 'id_campus'
        FROM 
        grupo
        INNER JOIN carrera
        ON carrera.id = grupo.id_carrera
        INNER JOIN periodo
        ON grupo.id_periodo = (SELECT periodo.id FROM periodo WHERE periodo.activar = 1) AND periodo.id = grupo.id_periodo
        INNER JOIN campus
        ON campus.id = grupo.id_campus
        INNER JOIN modalidad
        ON grupo.id_modalidad = modalidad.id
        WHERE grupo.nombre LIKE '%' :grupo '%'
        ORDER BY carrera.nombre_corto, grupo.nombre ASC;
        EOP;

        $group = strtoupper($group);
        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':grupo', $group);
        $sth->execute();
        $records = $sth->fetchAll();
        
        return $this->exception->read((array) $this->db->error(), (array) $records);
    }

    public function update(array $data): bool
    {
        $this->db->pdo->beginTransaction();
        $sql = <<<'EOP'
        UPDATE grupo
        SET nombre = :nombre,
        id_carrera = :id_carrera,
        id_modalidad = :id_modalidad,
        id_campus = :id_campus
        WHERE grupo.nombre = :nombre_antiguo
        AND id_periodo = (SELECT periodo.id FROM periodo WHERE periodo.activar = 1) 
        AND id_carrera = :id_carrera_antiguo 
        AND id_modalidad = :id_modalidad_antiguo
        AND id_campus = :id_campus_antiguo;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $group = strtoupper($data['grupo']);
        $sth->bindParam(':nombre', $group);
        $sth->bindParam(':id_carrera', $data['id_carrera']);
        $sth->bindParam(':id_modalidad', $data['id_modalidad']);
        $sth->bindParam(':id_campus', $data['id_campus']);

        $sth->bindParam(':nombre_antiguo', $data['grupo_antiguo']);
        $sth->bindParam(':id_carrera_antiguo', $data['id_carrera_antiguo']);
        $sth->bindParam(':id_modalidad_antiguo', $data['id_modalidad_antiguo']);
        $sth->bindParam(':id_campus_antiguo', $data['id_campus_antiguo']);
        $sth->execute();

        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Actualizar',
        'tabla_afectada' => 'Curso'));

        return $this->exception->save((array) $this->db->error());
    }
    
    public function delete(array $data): bool
    {
        $this->db->pdo->beginTransaction();
        $sql = <<<'EOP'
        DELETE FROM grupo
        WHERE grupo.nombre = :nombre
        AND id_periodo = (SELECT periodo.id FROM periodo WHERE periodo.activar = 1) 
        AND id_carrera = :id_carrera
        AND id_modalidad = :id_modalidad
        AND id_campus = :id_campus;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':nombre', $data['grupo']);
        $sth->bindParam(':id_carrera', $data['id_carrera']);
        $sth->bindParam(':id_modalidad', $data['id_modalidad']);
        $sth->bindParam(':id_campus', $data['id_campus']);
        $sth->execute();

        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Eliminar',
        'tabla_afectada' => 'Curso'));

        return $this->exception->delete((array) $this->db->error());
    }
}