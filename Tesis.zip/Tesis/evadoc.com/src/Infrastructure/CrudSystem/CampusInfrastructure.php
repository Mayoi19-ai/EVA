<?php
namespace App\Infrastructure\CrudSystem;

use Medoo\Medoo;
use App\Infrastructure\Exceptions\CustomException as Exception;
use App\Infrastructure\Binnacle\Binnacle;

class CampusInfrastructure {
    private Medoo $db;
    private Exception $exception;
    private Binnacle $binnacle;

    public function __construct(Medoo $db, Exception $exception, Binnacle $binnacle) 
    {
        $this->db = $db;
        $this->exception = $exception;
        $this->binnacle = $binnacle;
    }

    public function create(array $data): bool
    {
        $this->db->pdo->beginTransaction();

        $sql = $this->db->insert('campus',[
            'nombre' => strtoupper($data['nombre'])
        ]);

        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Registrar',
        'tabla_afectada' => 'Campus'));

        return $this->exception->save((array) $this->db->error());
    }

    //is too auxiliary
    public function readAll(): ?array
    {
        $sql = $this->db->select('campus', [
            'id', 'nombre'
        ]);
        
        return $this->exception->read((array) $this->db->error(), (array) $sql);
    }

    public function update(array $data): bool
    {
        $this->db->pdo->beginTransaction();

        $this->db->update('campus', [
            'nombre' => strtoupper($data['nombre'])], [
                'id' => $data['id']]);

        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Actualizar',
        'tabla_afectada' => 'Campus'));
        
        return $this->exception->save((array) $this->db->error());
    }
    
    public function delete(array $data): bool
    {
        $this->db->pdo->beginTransaction();
        $this->db->delete('campus', [
            'id' => $data['id']
        ]);
        
        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Eliminar',
        'tabla_afectada' => 'Campus'));

        return $this->exception->delete((array) $this->db->error());
    }
}