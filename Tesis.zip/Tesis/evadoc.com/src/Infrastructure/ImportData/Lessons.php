<?php

namespace App\Infrastructure\ImportData;

use Medoo\Medoo;

class Lessons {
    private Medoo $db;
    public function __construct(Medoo $db){
        $this->db = $db;
    }

    public function lessons(): ?array
    {   
        $lessons = $this->importLessons();
        
        if(!empty($lessons[1])){
            $result = ['flag' => true, 
                        'error' => 'Error al importar Asignaturas'];
            return $result;
        }

        return null;
    }

    private function importLessons (): array
    {
        $sql = <<<'EOP'
        INSERT IGNORE  INTO asignatura  
        SELECT temp_dret2.clave_asignatura, temp_dret.nom
        FROM temp_dret2
        INNER JOIN temp_dret
        ON temp_dret2.mat = temp_dret.cve;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->execute();
        return $this->db->error();
    }

}