<?php

namespace App\Infrastructure\ImportData;

use App\Infrastructure\CrudSystem\GroupInfrastructure;
use Medoo\Medoo;

class Groups {
    private Medoo $db;
    private GroupInfrastructure $groupInfrastructure;

    public function __construct(Medoo $db, GroupInfrastructure $groupInfrastructure){
        $this->db = $db;
        $this->groupInfrastructure = $groupInfrastructure;
    }

    public function groups (): ?array
    {
        $groups = $this->importGroups();
        return $this->groupInfrastructure->readAll();
        /*if (empty($this->groupInfrastructure->readAll())) {
            $result = ['message' => 'Error al importar registros en Grupo',
                'success' => false];
        }
        
        return null;*/
    }

    private function importGroups ()
    {
        $sql = <<<'EOP'
        INSERT IGNORE INTO grupo (nombre, id_periodo, id_carrera, id_modalidad, id_campus) 
        SELECT temp_grupo.nombre, periodo.id, diccionario_especialidad.id_carrera, diccionario_especialidad.id_modalidad, diccionario_especialidad.id_campus 
        FROM periodo,
        temp_grupo 
        INNER JOIN 
        temp_dgau 
        ON temp_grupo.cve = temp_dgau.gpo 
        INNER JOIN 
        temp_dret 
        ON temp_dgau.mat = temp_dret.cve 
        INNER JOIN 
        temp_dret2 
        ON  temp_dret.cve = temp_dret2.mat 
        INNER JOIN 
        diccionario_especialidad
        ON temp_dret2.esp = diccionario_especialidad.cve 
        WHERE 
        periodo.id = (SELECT periodo.id FROM periodo WHERE periodo.activar = 1)
        GROUP BY temp_grupo.nombre, 
        diccionario_especialidad.id_carrera, 
        diccionario_especialidad.id_modalidad,
        diccionario_especialidad.id_campus;
        EOP;
        
        $sth = $this->db->pdo->prepare($sql);
        $sth->execute();
    }
}