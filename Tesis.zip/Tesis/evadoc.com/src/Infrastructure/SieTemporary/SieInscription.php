<?php
namespace App\Infrastructure\SieTemporary;

use org\majkel\dbase\Table;
use Medoo\Medoo;

class SieInscription {
    private Medoo $db;

    public function __construct(Medoo $db) {
        $this->db = $db;
    }

    public function loadSieInscription(string $dbfFileInscription): ?array
    {
        $create = $this->createSieInscription((string) $dbfFileInscription);
        if(!empty($create[1])){
            $result = ['flag' => true, 
                        'error' => 'No se pudo crear estructura Inscripción SIE'];
            return $result;
        }

        return null;
    }

    private function createSieInscription (string $dbfFileInscription): array
    {
        $sql = <<<'EOP'
        DROP TABLE IF EXISTS `temp_dlis`;
        CREATE TEMPORARY TABLE IF NOT EXISTS `temp_dlis` (
            `ctr` CHAR(12) NOT NULL,
            `gpo` CHAR(6) NOT NULL,
            `mat` CHAR(4) NOT NULL,
            UNIQUE INDEX `dlis_Unique` USING BTREE (`ctr`,`gpo`,`mat`));
        EOP;

        $this->db->query($sql);
        $file = Table::fromFile($dbfFileInscription);

        foreach ($file as $record) {
            $this->db->insert("temp_dlis", [
                "ctr" => $record['LIS_CTR'],
                "gpo" => $record['LIS_GPO'],
                "mat" => $record['LIS_MAT']
            ]);
        }

        return $this->db->error();
    }
}
