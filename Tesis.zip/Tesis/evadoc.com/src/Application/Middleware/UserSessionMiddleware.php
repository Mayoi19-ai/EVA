<?php declare(strict_types=1);
namespace App\Middleware;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Server\MiddlewareInterface as Middleware;
use Psr\Http\Server\RequestHandlerInterface as RequestHandler;
use Slim\Routing\RouteContext;
use Psr\Http\Message\ResponseFactoryInterface as Factory;
use App\Validator\LoginValidator as Validator;
use App\Infrastructure\Login\Login as Infrastructure;
use Odan\Session\PhpSession as Session;

class UserSessionMiddleware implements Middleware
{
    private Factory $responseFactory;
    private Validator $validator;
    private Infrastructure $infrastructure;
    private Session $session;

    public function __construct(Factory $responseFactory, Validator $validator, Infrastructure $infrastructure, Session $session)
    {
        $this->responseFactory = $responseFactory;
        $this->validator = $validator;
        $this->infrastructure = $infrastructure;
        $this->session = $session;
    }

    public function process(Request $request, RequestHandler $handler): Response
    {
        if($this->session->get('logged') && $this->session->get('user')) {
            $find = $this->infrastructure->logged((string) $this->session->get('session_id'));

            if($find['id_usuario'] == $this->session->get('id') && $find['ip'] == $this->session->get('ip') && $find['navegador'] == $this->session->get('userAgent')) {
                return $handler->handle($request);
            }
            
            $routeParser = RouteContext::fromRequest($request)->getRouteParser();
            $url = $routeParser->urlFor('usersLogin');
        
            $response = $this->responseFactory->createResponse();
            $response = $response->withStatus(302)->withHeader('Location', $url);
            return $response;

        } else {
            $data = $request->getParsedBody();
            $user = $this->user($data);
            
            if(empty($user)) {
                $routeParser = RouteContext::fromRequest($request)->getRouteParser();
                $url = $routeParser->urlFor('usersLogin');
                
                $response = $this->responseFactory->createResponse();
                return $response->withStatus(302)->withHeader('Location', $url);

            } else {

                if(password_verify($data['contrasenia'], $user['contrasenia']) && $user['nombre'] == $data['usuario_activo']) {
                    $this->session->replace(['session_id' => uniqid(bin2hex(random_bytes(5)), true),
                    'id' => $user['id'],
                    'logged' => true,
                    'user' => true,
                    'ip' => $this->getRealIP(),
                    'userAgent' => $_SERVER['HTTP_USER_AGENT']]);
                    $this->session->save();

                    if (!empty($this->infrastructure->saveSession($_SESSION))) {
                        return $handler->handle($request);

                    } else {

                        $routeParser = RouteContext::fromRequest($request)->getRouteParser();
                        $url = $routeParser->urlFor('usersLogin');
        
                        $response = $this->responseFactory->createResponse();
                        $response = $response->withStatus(302)->withHeader('Location', $url);
                        return $response;
                    }

                } else {
                    $routeParser = RouteContext::fromRequest($request)->getRouteParser();
                    $url = $routeParser->urlFor('usersLogin');
                    $response = $this->responseFactory->createResponse();
                    return $response->withStatus(302)->withHeader('Location', $url);
                }
            }

        }        
    }

    private function user(array $data): ?array
    {
        $validationResult = $this->validator->userValidator((array) $data);

        if(!empty($validationResult['flag'])) {
            return $this->infrastructure->findUser((array) $data);
        }

        return null;
    }

    private function getRealIP() {
        if (!empty($_SERVER['HTTP_CLIENT_IP']))
            return $_SERVER['HTTP_CLIENT_IP'];
           
        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))
            return $_SERVER['HTTP_X_FORWARDED_FOR'];
       
        return $_SERVER['REMOTE_ADDR'];
    }
}
