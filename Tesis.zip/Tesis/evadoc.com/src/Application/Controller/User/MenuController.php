<?php
namespace App\Controller\User;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use Ujpef\LatteView;
use App\Infrastructure\Login\Login;
use App\Validator\UserValidator as Validator;
use App\Infrastructure\Rbac\User as Infrastructure;

class MenuController{
    private Container $container;
    private Login $login;
    private Infrastructure $infrastructure;
    private Validator $validator;

    public function __construct(Container $container, Login $login, Infrastructure $infrastructure, Validator $validator){
        $this->container = $container;
        $this->login = $login;
        $this->infrastructure = $infrastructure;
        $this->validator = $validator;
    }

    public function menu(Request $request, Response $response, array $args){
        $data = $request->getParsedBody();
        $permissionsCategories = $this->login->userPermissionsCategories((string) $data['usuario_activo']);
        
        return $this->container->get(LatteView::class)->render(
            $response, 
            'Menu/adminMenu.latte', [
                'categories' => $permissionsCategories,
                'user' => $data['usuario_activo']
        ]);
    }

    public function updateForm(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        
        return $this->container->get(LatteView::class)->render(
            $response,
            'Contrasenas/adminContrasenia.latte', [
                'data' => $data,
            ]);
    }
    
    public function update(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $validationResult = $this->validator->validateUpdatePassword((array) $data);

        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->updatePassword((array) $data);
        } else {
            $sthResult = false;
        }

        return $this->container->get(LatteView::class)->render(
            $response,
            'Contrasenas/passwordAdminSave.latte', [
                'validation' => $validationResult,
                'query' => $sthResult,
                'data' => $data
            ]);
    }
}