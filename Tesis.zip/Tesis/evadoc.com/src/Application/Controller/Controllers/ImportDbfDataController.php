<?php
namespace App\Controller\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Ujpef\LatteView;
use App\Infrastructure\SieTemporary\DbfImport;
use App\Infrastructure\CrudSystem\PeriodInfrastructure as Infrastructure;
use Psr\Container\ContainerInterface as Container;
use App\UploadFiles\UploadFiles as Upload;

class ImportDbfDataController {
    private DbfImport $dbf;
    private Infrastructure $infrastructure;
    private Container $container;
    private Validator $validator;
    private Upload $upload;

    public function __construct(DbfImport $dbf, Infrastructure $infrastructure, Container $container, Upload $upload)
    {
        $this->dbf = $dbf;
        $this->infrastructure = $infrastructure;
        $this->container = $container;
        $this->upload = $upload;
    }

    public function importForm(Request $request, Response $response) {
        $data = (array)$request->getParsedBody();

        return $this->container->get(LatteView::class)->render($response, 
            'Archivos/layout.latte', [
                'data' => $data,
            ]);
    }

    public function importAll(Request $request, Response $response) {
        $data = (array)$request->getParsedBody();
        $success = $this->upload->upload($request->getUploadedFiles());
        $importResult = false;

        if(!empty($success)){
            $importResult = $this->dbf->importData();
            $this->upload->deleteFiles();
        }

        return $this->container->get(LatteView::class)->render($response, 
        'Archivos/filesValidationSave.latte', [
            'data' => $data,
            'query' => $importResult
        ]);
    }
}