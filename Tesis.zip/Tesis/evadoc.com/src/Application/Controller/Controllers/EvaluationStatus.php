<?php
namespace App\Controller\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use Ujpef\LatteView;
use App\Infrastructure\Login\Login as LoginInfra;
use App\Infrastructure\EvaluationStatus\EvaluationStatus as Infrastructure;

class EvaluationStatus {
    private Container $container;
    private Infrastructure $infrastructure;
    private LoginInfra $LoginInfra;

    public function __construct(Container $container, Infrastructure $infrastructure, LoginInfra $LoginInfra) 
    {
        $this->container = $container;
        $this->infrastructure = $infrastructure;
        $this->loginInfra = $LoginInfra;
    }

    public function show(Request $request, Response $response) {
        $data = (array)$request->getParsedBody();
        $sthResult = $this->infrastructure->readAll();
        $permissions = $this->loginInfra->userPermissions((array) $data);
        
        return $this->container->get(LatteView::class)->render(
            $response,
            'Estado/evaluationStatus.latte', [
                'query' => $sthResult,
                'data' => $data,
                'permissions' => $permissions,
            ]);
    }
}