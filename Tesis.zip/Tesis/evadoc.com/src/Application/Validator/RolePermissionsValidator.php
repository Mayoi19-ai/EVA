<?php
namespace App\Validator;
use Rakit\Validation\Validator;

class RolePermissionsValidator{
    private Validator $validator;

    public function __construct(Validator $validator) {
        $this->validator = $validator;
    }

    public function validateSaveRolePermissions(array $data): array {
        $validationRules = [
            'id_roles'         =>  'required|numeric|digits_between:1,10',
            'id_permisos'      =>  'required|numeric|digits_between:1,10',
        ];

        $errorMessages = [
            'id_roles:required'      => 'La clave de rol es obligatoria',
            'id_roles:numeric'       => 'La clave de rol solo acepta números',
            'id_roles:between'       => 'La clave de rol debe tener entre 1 y 10 caracteres',
            'id_permisos:required'   => 'La clave del permiso es obligatoria',
            'id_permisos:numeric'    => 'La clave del permiso solo acepta números',
            'id_permisos:between'    => 'La clave del permiso debe tener entre 1 y 10 caracteres',
        ];

        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data);
    }

    public function validateSaveUpdateRolePermissions(array $data): array {
        $validationRules = [
            'id_roles'         =>  'required|numeric|digits_between:1,10',
            'id_permisos'      =>  'required|numeric|digits_between:1,10',
            'activar'          =>  'required|numeric|digits_between:1,1'
        ];

        $errorMessages = [
            'id_roles:required'      => 'La clave de rol es obligatoria',
            'id_roles:numeric'       => 'La clave de rol solo acepta números',
            'id_roles:between'       => 'La clave de rol debe tener entre 1 y 10 caracteres',
            'id_permisos:required'   => 'La clave del permiso es obligatoria',
            'id_permisos:numeric'    => 'La clave del permiso solo acepta números',
            'id_permisos:between'    => 'La clave del permiso debe tener entre 1 y 10 caracteres',
            'activar:required'       => 'El campo activar es obligatorio',
            'activar:numeric'        => 'El campo activar solo acepta números',
            'activar:digits_between' => 'El campo activar debe tener 1 caracter'
        ];

        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data);
    }
}