<?php declare(strict_types=1);

use DI\ContainerBuilder;
use Psr\Container\ContainerInterface;
use Psr\Log\LoggerInterface;

use Monolog\Logger;
use Monolog\Handler\StreamHandler;
use Monolog\Handler\FirePHPHandler;

use Latte\Engine;
use Latte\MacroNode;
use Latte\PhpWriter;
use Latte\Loaders\FileLoader;
use Ujpef\LatteView;
use Medoo\Medoo;
use Slim\App;
use Rakit\Validation\Validator;

use Psr\Http\Message\ResponseFactoryInterface;
use Slim\Factory\AppFactory;

use Odan\Session\PhpSession;
use Odan\Session\SessionInterface;
use Odan\Session\Middleware\SessionMiddleware;

return function(ContainerBuilder $containerBuilder): void
{
    $containerBuilder->addDefinitions([
        LoggerInterface::class => function(ContainerInterface $container): LoggerInterface {
            $settings = $container->get('settings');
            $loggerSettings = $settings['logger'];

            $logger = new Logger($loggerSettings['name']);

            // Additional information in the log
            foreach([
                //new \Monolog\Processor\IntrospectionProcessor($loggerSettings['level']),
                new \Monolog\Processor\WebProcessor(),
                new \Monolog\Processor\HostnameProcessor(),
                //new \Monolog\Processor\UidProcessor(),
            ] as $processor) $logger->pushProcessor($processor);

            foreach([
                new StreamHandler($loggerSettings['path'], $loggerSettings['level']),
                new FirePHPHandler(),
            ] as $handler) $logger->pushHandler($handler);

            return $logger;
        },
        LatteView::class => function(ContainerInterface $container) {
            $settings = $container->get('settings');
            $viewSettings = $settings['view'];
            $app = $container->get(App::class);
            $routeParser = $app->getRouteCollector()->getRouteParser();

            $engine = new Engine();
            $engine->setLoader(new FileLoader($viewSettings['path']));
            $engine->setTempDirectory($viewSettings['cache']);

            $latteView = new LatteView($engine);
            $latteView->addParams($viewSettings['params']);
            $latteView->addParam('router', $routeParser);
            $latteView->addMacro('link', function (MacroNode $node, PhpWriter $writer) {
                if (strpos($node->args, ' ') !== false) {
                    return $writer->write("echo \$router->relativeUrlFor(%node.word, %node.args);");
                } else {
                    return $writer->write("echo \$router->relativeUrlFor(%node.word);");
                }
            });
            return $latteView;
        },
        Medoo::class => function(ContainerInterface $container) {
            $settings = $container->get('settings');
            $dbSettings = $settings['database'];

            $database = new Medoo([
                'database_type' => $dbSettings['type'],
                'database_name' => $dbSettings['name'],
                'server'        => $dbSettings['server'],
                'username'      => $dbSettings['username'],
                'password'      => $dbSettings['password'],
                'charset'       => $dbSettings['charset'],
                'collation'     => $dbSettings['collation'],
                'port'          => $dbSettings['port'],
                'prefix'        => $dbSettings['prefix'],
            ]);

            return $database;
        },
        Validator::class => function(ContainerInterface $container) {
            return new Validator;
        },
        ResponseFactoryInterface::class => function (ContainerInterface $container) {
            return $container->get(App::class)->getResponseFactory();
        },
        SessionInterface::class => function (ContainerInterface $container) {
            $settings = $container->get('settings');
            $session = new PhpSession();
            $session->setOptions((array)$settings['session']);
            return $session;
        },
    
        SessionMiddleware::class => function (ContainerInterface $container) {
            return new SessionMiddleware($container->get(SessionInterface::class));
        },
    ]);
};