<?php
// source: Archivos/layout.latte

use Latte\Runtime as LR;

class Template6c2c84787d extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		/* line 1 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 6 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
       <!-- -->
       <script type="text/javascript" src="/materialize/js/jquery.min.js"></script>
    <script type="text/javascript" src="/materialize/js/jquery.MultiFile.js"></script>
       <script src="/materialize/js/materialize.min.js"></script>
       <link type="text/css" rel="stylesheet" href="/materialize/css/archivos.css"  media="screen,projection">
    
     <script type="text/javascript">
$(document).ready(function(){
    $('#demo1').MultiFile({ 
        list: '#demo1-list'
       }); 
});
</script>

<script>
function fileValidation(){
    var fileInput = document.getElementById('demo1');
    var filePath = fileInput.value;
    var allowedExtensions = (".DBF", ".xlsx");
    if(!allowedExtensions.exec(filePath)){
        alert('Extencion no valida');
        fileInput.value = '';
        return false;
    }else{
        //Image preview
        if (fileInput.files && fileInput.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                document.getElementById('imagePreview').innerHTML = '<img src="'+e.target.result+'"/>';
            };
            reader.readAsDataURL(fileInput.files[0]);
        }
    }
}
</script>

</head>
 <body>
  <div class="container section">
 <div class="card">

  <form action="<?php
		echo $router->relativeUrlFor("importSieData");
?>" clas="dropzone" method="post" enctype="multipart/form-data" >
 <input class="file" id="demo1" name="files[]" type="file" accept=".xlsx|.DBF" onchange="return fileValidation()"  multiple>
 <input type="hidden" id="usuario_activo" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 53 */ ?>">
                    <input type="hidden" id="categoria_permisos" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 54 */ ?>">
 <div id="demo1-list"></div>
  <p><input type="submit" class="boton" value="Subir archivos"></p>
</form>
</div>
</div>
 <div class="content"></div>
            <div class="footer-copyright blue-grey lighten-3" >
            <div class="container">
           <img class="header container section" src="/materialize/css/pie.jpg">
            </div>
          </div>
        </footer>
</body>
</html>
        <?php
		return get_defined_vars();
	}

}
