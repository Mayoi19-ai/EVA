<?php
// source: RolesPermisos/permissionsRTable.latte

use Latte\Runtime as LR;

class Templatedd93bad88f extends Latte\Runtime\Template
{
	public $blocks = [
		'content' => 'blockContent',
	];

	public $blockTypes = [
		'content' => 'html',
	];


	function main()
	{
		extract($this->params);
		/* line 1 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
		/* line 2 */
		$this->createTemplate('../validationDelete.latte', $this->params, "include")->renderToContentType('html');
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('content', get_defined_vars());
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['permisosOption'])) trigger_error('Variable $permisosOption overwritten in foreach on line 45');
		if (isset($this->params['permissionInfor'])) trigger_error('Variable $permissionInfor overwritten in foreach on line 103, 122, 139');
		if (isset($this->params['rolesPermisos'])) trigger_error('Variable $rolesPermisos overwritten in foreach on line 81');
		
	}


	function blockContent($_args)
	{
		extract($_args);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 9 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
       
</head>
<!-- -->


<!-- -->

<body>
<?php
		if (empty ($query)) {
?>
                <div class="container section">
                    <div class="card center">
                        <div class="card center">
                         <img class="logo" src="/materialize/css/alerta3.png">
                        <p>NO SE CUENTA CON ROLES Y PERMISOS REGISTRADOS</p>
                        <form action="<?php
			echo $router->relativeUrlFor("userMenu");
?>" method="post">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 28 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 29 */ ?>">
 <input id="retorno" type="submit" class="btn btn-primary btn-sm" value='Retornar'>
            </form>
                    </div>
                 </div>
            </div>
<?php
		}
		else {
?>
<ul id="nav-mobile">
                <div class="row">
                <div class="col s12 m6 l3">
<form name="showAllRolePermissions" method="post" action="<?php
			echo $router->relativeUrlFor("rolePermissionsSearchByRole");
?>">
<label for="nombre">Busqueda por rol<label>
          <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 41 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 42 */ ?>">
      <select class="browser-default" name="nombre">
      <option value="<?php echo LR\Filters::escapeHtmlAttr($data['nombre']) /* line 44 */ ?>" name="nombre"></option>
<?php
			$iterations = 0;
			foreach ($roles as $permisosOption) {
				?>      <option  value="<?php echo LR\Filters::escapeHtmlAttr($permisosOption['nombre']) /* line 46 */ ?>" ><?php
				echo LR\Filters::escapeHtmlText($permisosOption['nombre']) /* line 46 */ ?> </option>
<?php
				$iterations++;
			}
?>
    </select>
  
<button id="buscar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee">Buscar<i class="material-icons left">search</i></button>
</form>
</div>
</div>
<!-- -->
<?php
			if (empty ($query)) {
?>
       <div class="container section">
       <div class="card center">
              <div class="card center">
                     <p>El rol seleccionado no tiene permisos asignados</p>
                    
              </div>
       </div>
</div>

<?php
			}
			else {
?>

<div class="MiTabla" class="container setcion responsive-table" >
<table name="showAllRolePermissions" method="get" class="bordered striped hoverable centered responsive-table">
<thead>
<tr>
<th>Rol</th>
<th>Categoria</th>
<th>Permiso</th>
<th>Estado</th>
<th></th>
<th></th>
</tr>
</thead>
<tbody>

<?php
				$iterations = 0;
				foreach ($query as $rolesPermisos) {
?>
<tr>
    <td><?php echo LR\Filters::escapeHtmlText($rolesPermisos['rol']) /* line 83 */ ?> </td>
    <td><?php echo LR\Filters::escapeHtmlText($rolesPermisos['categoria']) /* line 84 */ ?> </td>
     <td><?php echo LR\Filters::escapeHtmlText($rolesPermisos['permiso']) /* line 85 */ ?> </td>
     
<?php
					if ($rolesPermisos['activar'] == 1) {
?>
     <td>Activo </td>
<?php
					}
					else {
?>
        <td>No activo</td>
<?php
					}
?>
     <td>

<form action="<?php
					echo $router->relativeUrlFor("rolePermissionsUpdateForm");
?>" method="post">
            <input type="hidden" name="rol" value="<?php echo LR\Filters::escapeHtmlAttr($rolesPermisos['rol']) /* line 95 */ ?>">
            <input type="hidden" name="categoria" value="<?php echo LR\Filters::escapeHtmlAttr($rolesPermisos['categoria']) /* line 96 */ ?>">
             <input type="hidden" name="permiso" value="<?php echo LR\Filters::escapeHtmlAttr($rolesPermisos['permiso']) /* line 97 */ ?>">
             <input type="hidden" name="id_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($rolesPermisos['id_permisos']) /* line 98 */ ?>">
            <input type="hidden" name="id_roles" value="<?php echo LR\Filters::escapeHtmlAttr($rolesPermisos['id_roles']) /* line 99 */ ?>">
             <input type="hidden" name="activar" value="<?php echo LR\Filters::escapeHtmlAttr($rolesPermisos['activar']) /* line 100 */ ?>">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 101 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 102 */ ?>">
<?php
					$iterations = 0;
					foreach ($permissions as $permissionInfor) {
						$permisos  = explode(" - ", $permissionInfor['enlace']);
						;
						if ($permisos[1] == "rolePermissionsUpdateForm") {
?>
        <button id="actualizar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Editar<i class="material-icons left">edit</i></button>
<?php
						}
						$iterations++;
					}
?>
</form>
</td>
<td>
    <form action="<?php
					echo $router->relativeUrlFor("rolePermissionsDelete");
?>" method="post" onsubmit="return confirmation()">
            <input type="hidden" name="id_usuario" value="<?php echo LR\Filters::escapeHtmlAttr($rolesPermisos['id_usuario']) /* line 113 */ ?>">
            <input type="hidden" name="id_roles" value="<?php echo LR\Filters::escapeHtmlAttr($rolesPermisos['id_roles']) /* line 114 */ ?>">
            <input type="hidden" name="id_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($rolesPermisos['id_permisos']) /* line 115 */ ?>">

            <!-- No tocar lo de abajo-->
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 118 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 119 */ ?>">
            <!--No tocar lo de arriba -->
             <form action="<?php
					echo $router->relativeUrlFor("rolePermissionsDelete");
?>" method="post" onsubmit="return confirmation()">
<?php
					$iterations = 0;
					foreach ($permissions as $permissionInfor) {
						$permisos  = explode(" - ", $permissionInfor['enlace']);
						;
						if ($permisos[1] == "rolePermissionsDelete") {
?>
   <button type="submit" id="eliminar" style="background-color: #f44336" class="btn btn-primary btn-sm #f44336" value='Eliminar'>Eliminar<i class="material-icons left">delete</i></button>
<?php
						}
						$iterations++;
					}
?>
    </form>
</td>

</tr>
<?php
					$iterations++;
				}
?>

</tbody>
 <form action="<?php
				echo $router->relativeUrlFor("rolePermissionsSaveForm");
?>" method="post">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 136 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 137 */ ?>">
   <div class="fixed-action-btn">
<?php
				$iterations = 0;
				foreach ($permissions as $permissionInfor) {
					$permisos  = explode(" - ", $permissionInfor['enlace']);
					;
					if ($permisos[1] == "rolePermissionsSaveForm") {
?>
<button type="submit" class="float" ><i class="material-icons center">add</i></button>
<?php
					}
					$iterations++;
				}
			}
?>
</form>
</table>
<?php
		}
?>
</div>
 <!--footer -->
                   <div class="content"></div>
            <div class="footer-copyright blue-grey lighten-3" >
            <div class="container">
           <img class="header container section" src="/materialize/css/pie.jpg">
            </div>
          </div>
        </footer>
</body>
<script> M.AutoInit(); </script>
</html>
<?php
	}

}
