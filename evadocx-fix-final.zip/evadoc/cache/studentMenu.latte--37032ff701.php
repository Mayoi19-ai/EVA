<?php
// source: Menu/studentMenu.latte

use Latte\Runtime as LR;

class Template37032ff701 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 5 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
 <script type="text/javascript" src="/materialize/js/jquery.min.js"></script>
    <script type="text/javascript" src="/materialize/js/jquery-qrcode-0.18.0.js"></script>
       <script src="/materialize/js/materialize.min.js"></script>
       <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
       <link type="text/css" rel="stylesheet" href="/materialize/css/studentNaver.css"  media="screen,projection">

    
</head>
<body>
 <img class="header container section" src="/materialize/css/cabeza.jpg">
<!-- nav -->
<nav>
    <div class="nav-wrapper blue-grey lighten-3">
      <img class="logo" src="https://www.itshuatusco.edu.mx/inicio/images/Logo%20ITSH%20300x312%20negritas.png"></a>

        <!--Mobile -->
          <a href="#" class="sidenav-trigger" data-target="mobile-nav">
			    <i class="material-icons">menu</i>
		      </a>
            <ul class="right hide-on-med-and-down "  >
              <li>
                  <form method="post" action="<?php
		echo $router->relativeUrlFor("studentPasswordUpdateForm");
?>">
<?php
		$iterations = 0;
		foreach ($student_information as $studentInformationControl) {
			?>                      <input type="hidden" name="control" value="<?php echo LR\Filters::escapeHtmlAttr($studentInformationControl['control']) /* line 31 */ ?>">
                      <input type="hidden" name="nombre" value="<?php echo LR\Filters::escapeHtmlAttr($studentInformationControl['nombre']) /* line 32 */ ?>">
<?php
			$iterations++;
		}
?>
                 <button id="actualizar" type="submit" class="btn btn-primary btn-sm" style="background-color:#b0bec5" >Cambiar contraseña</button>
                  </form> 
              </li> 
              <li><a href="<?php
		echo $router->relativeUrlFor("loginStudent");
?>">Cerrar sesion</a></li>
            </ul>
        <!-- -->
    </div>
</nav>
  <!-- -->
    <ul class="sidenav" id="mobile-nav">
        <li>
         <form method="post" action="<?php
		echo $router->relativeUrlFor("studentPasswordUpdateForm");
?>">
<?php
		$iterations = 0;
		foreach ($student_information as $studentInformationControl) {
			?>        <input type="hidden" name="control" value="<?php echo LR\Filters::escapeHtmlAttr($studentInformationControl['control']) /* line 47 */ ?>">
         <input type="hidden" name="nombre" value="<?php echo LR\Filters::escapeHtmlAttr($studentInformationControl['nombre']) /* line 48 */ ?>">
<?php
			$iterations++;
		}
?>
           <li><a type="submit" id="actualizar" class="btn btn-primary btn-sm" style="background-color:#b0bec5">Cambiar contraseña</a></li>
        </form> 
        </li> 
         <li><a href="<?php
		echo $router->relativeUrlFor("loginStudent");
?>" id="actualizar" class="btn btn-primary btn-sm" style="background-color:#b0bec5">Cerrar sesion</a></li>
    </ul>
  <!-- -->
<!--Nav end-->

<div class="container section">
<div class="card center">
<?php
		$iterations = 0;
		foreach ($student_information as $studentInformation) {
			?>          <span class="black-text center"><?php echo LR\Filters::escapeHtmlText($studentInformation['nombre']) /* line 61 */ ?> </span></a>
<?php
			$iterations++;
		}
?>
          </div>
<div class="card">
 <table class="highlight responsive-table ">
        <thead>
          <tr>
            
              
          </tr>
        </thead>

        <tbody>

<!-- -->

<?php
		if (empty ($query)) {
?>
       <div class="container section">
       <div class="card center">
              <div class="card center">
              <img class="logo" src="/materialize/css/alerta3.png">

                     <h5>NO HAY EVALUACIONES DISPONIBLES</h5>
                       

<?php
			if (empty ($code)) {
?>
                           <p>NO HAY CURSO DISPONIBLES.</p>
<?php
			}
			else {
?>
                     <p>CODIGO DE VERIFICACION:</p>
                    <!-- code qr start -->


         <div id="qrcode"></div>
    <script type="text/javascript">
    var options = {
        // render method: 'canvas', 'image' or 'div'
        render: 'canvas',

        // version range somewhere in 1 .. 40
        minVersion: 1,
        maxVersion: 40,

        // error correction level: 'L', 'M', 'Q' or 'H'
        ecLevel: 'L',

        // offset in pixel if drawn onto existing canvas
        left: 0,
        top: 0,

        // size in pixel
        size: 200,

        // code color or image element
        fill: '#000',

        // background color or image element, null for transparent background
        background: null,

        // content
        text: <?php echo LR\Filters::escapeJs($code) /* line 120 */ ?>,

        // corner radius relative to module width: 0.0 .. 0.5
        radius: 0,

        // quiet zone in modules
        quiet: 0,

        // modes
        // 0: normal
        // 1: label strip
        // 2: label box
        // 3: image strip
        // 4: image box
        mode: 0,

        mSize: 0.1,
        mPosX: 0.5,
        mPosY: 0.5,

        label: 'no label',
        fontname: 'sans',
        fontcolor: '#000',

        image: null
    }
    $('#qrcode').qrcode(options);
    </script>


                    <!-- code  qr end -->
                     
              </div>
       </div>
</div>
<?php
			}
?>

 
     
	    <!--<span><?php echo LR\Filters::escapeHtmlComment($error) /* line 159 */ ?></span>-->
<?php
		}
		else {
?>
 


<!-- -->


<?php
			$iterations = 0;
			foreach ($query as $studentCourses) {
?>
          <tr>
            <td>
             <p>MATERIA: <?php echo LR\Filters::escapeHtmlText($studentCourses['asignatura']) /* line 170 */ ?></p>
             <p>DOCENTE: <?php echo LR\Filters::escapeHtmlText($studentCourses['docente']) /* line 171 */ ?> </p>
            </td>
            <td>

            <form action="<?php
				echo $router->relativeUrlFor("studentCoursesShowQuiz");
?>" method="post">
            <input type="hidden" name="id" value="<?php echo LR\Filters::escapeHtmlAttr($studentCourses['id']) /* line 176 */ ?>">
             <input type="hidden" name="control" value="<?php echo LR\Filters::escapeHtmlAttr($studentCourses['control']) /* line 177 */ ?>">
             <input type="hidden" name="alumno" value="<?php echo LR\Filters::escapeHtmlAttr($studentCourses['alumno']) /* line 178 */ ?>">
             <input type="hidden" name="grupo" value="<?php echo LR\Filters::escapeHtmlAttr($studentCourses['grupo']) /* line 179 */ ?>">
             <input type="hidden" name="carrera" value="<?php echo LR\Filters::escapeHtmlAttr($studentCourses['carrera']) /* line 180 */ ?>">
             <input type="hidden" name="asignatura" value="<?php echo LR\Filters::escapeHtmlAttr($studentCourses['asignatura']) /* line 181 */ ?>">
             <input type="hidden" name="clave_asignatura" value="<?php echo LR\Filters::escapeHtmlAttr($studentCourses['clave_asignatura']) /* line 182 */ ?>">
             <input type="hidden" name="docente" value="<?php echo LR\Filters::escapeHtmlAttr($studentCourses['docente']) /* line 183 */ ?>">
             <input type="hidden" name="periodo" value="<?php echo LR\Filters::escapeHtmlAttr($studentCourses['periodo']) /* line 184 */ ?>">
             <input type="hidden" name="curso" value="<?php echo LR\Filters::escapeHtmlAttr($studentCourses['curso']) /* line 185 */ ?>">
             <div class="submit">
             <input type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" value='Iniciar evaluación'>
            </form>
        </div> 
        </div>

            </td>

          </tr>
<?php
				$iterations++;
			}
		}
?>
        </tbody>
      </table>
</div>
</div>
 <!--footer-->

                   <div class="content"></div>
            <div class="footer-copyright blue-grey lighten-3" >
            <div class="container">
           <img class="header container section" src="/materialize/css/pie.jpg">
            </div>
          </div>
        </footer>
</body>
<script> M.AutoInit(); </script>
<script>$(document).ready(function(){
 		$('.sidenav').sidenav();
 	});</script>
</html>
<?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['studentInformationControl'])) trigger_error('Variable $studentInformationControl overwritten in foreach on line 30, 46');
		if (isset($this->params['studentInformation'])) trigger_error('Variable $studentInformation overwritten in foreach on line 60');
		if (isset($this->params['studentCourses'])) trigger_error('Variable $studentCourses overwritten in foreach on line 167');
		
	}

}
