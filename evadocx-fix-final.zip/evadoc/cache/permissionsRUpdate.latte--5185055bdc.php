<?php
// source: RolesPermisos/permissionsRUpdate.latte

use Latte\Runtime as LR;

class Template5185055bdc extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		/* line 1 */
		$this->createTemplate('../validationUpdate.latte', $this->params, "include")->renderToContentType('html');
		/* line 2 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 7 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
 <link type="text/css" rel="stylesheet" href="/materialize/css/formularios.css"  media="screen,projection">
</head>
<body>
 <ul id="nav-mobile">
<div class="container section">
<form name="rolePermissionsUpdateForm" method="post" action="<?php
		echo $router->relativeUrlFor("rolePermissionsUpdate");
?>">
<input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 17 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 18 */ ?>">
            <input type="hidden" name="categoria" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria']) /* line 19 */ ?>">
            <input type="hidden" name="rol" value="<?php echo LR\Filters::escapeHtmlAttr($data['rol']) /* line 20 */ ?>"> 
             <input type="hidden" name="permiso" value="<?php echo LR\Filters::escapeHtmlAttr($data['permiso']) /* line 21 */ ?>"> 
             <input type="hidden" name="activar" value="<?php echo LR\Filters::escapeHtmlAttr($data['activar']) /* line 22 */ ?>"> 


            
<ul>
  <li>
    <label><input type="hidden" id="id_roles_antiguo" name="id_roles_antiguo" value="<?php echo LR\Filters::escapeHtmlAttr($data['id_roles']) /* line 28 */ ?>" class="validate"></label>
  </li>
  <li>
    <label><input type="hidden" id="id_permisos_antiguo" name="id_permisos_antiguo" value="<?php echo LR\Filters::escapeHtmlAttr($data['id_permisos']) /* line 31 */ ?>" class="validate"></label>
  </li>
  <li>
    <label for="id_roles">Selecciona un rol:</label>
      <select class="browser-default" name="id_roles">
      <option value="<?php echo LR\Filters::escapeHtmlAttr($data['id_roles']) /* line 36 */ ?>" name="id_roles"><?php
		echo LR\Filters::escapeHtmlText($data['rol']) /* line 36 */ ?></option>
<?php
		$iterations = 0;
		foreach ($roles as $rolesOption) {
			?>      <option  value="<?php echo LR\Filters::escapeHtmlAttr($rolesOption['id_roles']) /* line 38 */ ?>"><?php
			echo LR\Filters::escapeHtmlText($rolesOption['nombre']) /* line 38 */ ?></option>
<?php
			$iterations++;
		}
?>
    </select>
  </li>



  <li>
    <label for="id_permisos">Selecciona un permiso:</label>
      <select class="browser-default"  name="id_permisos">
      <option value="<?php echo LR\Filters::escapeHtmlAttr($data['id_permisos']) /* line 48 */ ?>" name="id_permisos"><?php
		echo LR\Filters::escapeHtmlText($data['categoria']) /* line 48 */ ?> - <?php echo LR\Filters::escapeHtmlText($data['permiso']) /* line 48 */ ?>  </option>
<?php
		$iterations = 0;
		foreach ($permissions as $permisosOption) {
			?>      <option  value="<?php echo LR\Filters::escapeHtmlAttr($permisosOption['id']) /* line 50 */ ?>" ><?php
			echo LR\Filters::escapeHtmlText($permisosOption['categoria']) /* line 50 */ ?> - <?php echo LR\Filters::escapeHtmlText($permisosOption['nombre']) /* line 50 */ ?></option>
<?php
			$iterations++;
		}
?>
    </select>
  </li>

 <label for="activar">Estado del rol</label>
      <select class="browser-default" name="activar">
      <option value="" name="activar"><?php
		if ($data['activar'] == 1) {
?>Activo
                                          <?php
		}
		else {
?>No activo
<?php
		}
?>
     </option>
      <option value=1>Activo</option>
      <option value=0>No activo</option>
    </select>
<button id="guardar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Guardar<i class="material-icons left">send</i></button>
</div>
</form>
<div>
<form action="<?php
		echo $router->relativeUrlFor("showAllRolePermissions");
?>" method="post">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 69 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 70 */ ?>">
 <button id="retornar" type="submit" class="btn btn-primary btn-sm float-1" style="background-color: #10c2ee" >Retornar<i class="material-icons left">arrow_back</i></button>
            </form>

</div>

    <!--footer -->
                   <div class="content"></div>
            <div class="footer-copyright blue-grey lighten-3" >
            <div class="container">
           <img class="header container section" src="/materialize/css/pie.jpg">
            </div>
          </div>
        </footer>
</body>
<script> M.AutoInit(); </script>
</html><?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['rolesOption'])) trigger_error('Variable $rolesOption overwritten in foreach on line 37');
		if (isset($this->params['permisosOption'])) trigger_error('Variable $permisosOption overwritten in foreach on line 49');
		
	}

}
