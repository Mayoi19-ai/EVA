<?php
// source: AsignarR/assignRForm.latte

use Latte\Runtime as LR;

class Templatedadfce60bc extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		/* line 1 */
		$this->createTemplate('../validationCreate.latte', $this->params, "include")->renderToContentType('html');
		/* line 2 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 7 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
       <link type="text/css" rel="stylesheet" href="/materialize/css/formularios.css"  media="screen,projection">
</head>
<body>
 <ul id="nav-mobile">
<form name="userRolesSaveForm" method="post" action="<?php
		echo $router->relativeUrlFor("userRolesRegister");
?>">
  <!-- Datos del formulario -->
  <div class="container section">
  <!--Control <input type="text" name="control" id="control" /> -->
   <input type="hidden" name="nombre"  id="nombre">

<label>Usuario: </label>
<select class="browser-default" name="id_usuario">
  <option class="browser-default" value="" name="id" >Selecciona usuario</option>
<?php
		$iterations = 0;
		foreach ($users as $usuario) {
			?>      <option  value="<?php echo LR\Filters::escapeHtmlAttr($usuario['id']) /* line 25 */ ?>" ><?php
			echo LR\Filters::escapeHtmlText($usuario['nombre']) /* line 25 */ ?></option>
<?php
			$iterations++;
		}
?>
  </select>

  <label>Roles: </label>
  <select class="browser-default" name="id_roles" id="id">
  <option value="" name="id" >Selecciona rol</option>
<?php
		$iterations = 0;
		foreach ($roles as $rol) {
			?>      <option  value="<?php echo LR\Filters::escapeHtmlAttr($rol['id']) /* line 33 */ ?>" ><?php echo LR\Filters::escapeHtmlText($rol['nombre']) /* line 33 */ ?></option>
<?php
			$iterations++;
		}
?>
  </select>

      <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 37 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 38 */ ?>">
  <!-- Botón de envío de formulario -->
  
  <button id="guardar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Guardar<i class="material-icons left">send</i></button>
</div>
</form>
<div>
<form action="<?php
		echo $router->relativeUrlFor("showAllUserRoles");
?>" method="post">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 46 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 47 */ ?>">
<button id="retornar" type="submit" class="btn btn-primary btn-sm float-1" style="background-color: #10c2ee" >Retornar<i class="material-icons left">arrow_back</i></button>
            </form>
            </div>
     <div class="content"></div>
            <div class="footer-copyright blue-grey lighten-3" >
            <div class="container">
           <img class="header container section" src="/materialize/css/pie.jpg">
            </div>
          </div>
        </footer>
</body>
 <script>M.AutoInit();</script>
</html><?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['usuario'])) trigger_error('Variable $usuario overwritten in foreach on line 24');
		if (isset($this->params['rol'])) trigger_error('Variable $rol overwritten in foreach on line 32');
		
	}

}
