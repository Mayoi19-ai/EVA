<?php
// source: Materia/subjectUpdate.latte

use Latte\Runtime as LR;

class Templateb335a1db88 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		/* line 1 */
		$this->createTemplate('../validationUpdate.latte', $this->params, "include")->renderToContentType('html');
		/* line 2 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 7 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
<link type="text/css" rel="stylesheet" href="/materialize/css/formularios.css"  media="screen,projection">
</head>
<body>
 <ul id="nav-mobile">
<div class="container section">
<form name="subjectUpdateForm" method="post" action="<?php
		echo $router->relativeUrlFor("subjectUpdate");
?>">
            <input type="hidden" name="id_carrera" value="<?php echo LR\Filters::escapeHtmlAttr($data['id_carrera']) /* line 17 */ ?>">
             <input type="hidden" name="clave_asignatura" value="<?php echo LR\Filters::escapeHtmlAttr($data['clave_asignatura']) /* line 18 */ ?>">
             <input type="hidden" name="carrera" value="<?php echo LR\Filters::escapeHtmlAttr($data['carrera']) /* line 19 */ ?>">
             <input type="hidden" name="asignatura" value="<?php echo LR\Filters::escapeHtmlAttr($data['asignatura']) /* line 20 */ ?>">
            <!-- -->
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 22 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 23 */ ?>">
            <!-- -->

<div class="container section">
     <li>
    <label><input type="hidden" id="id_carrera_antiguo" name="id_carrera_antiguo" value="<?php echo LR\Filters::escapeHtmlAttr($data['id_carrera']) /* line 28 */ ?>" class="validate"></label>
  </li>
   <li>
    <label><input type="hidden" id="id_asignatura_antiguo" name="clave_asignatura_antiguo" value="<?php echo LR\Filters::escapeHtmlAttr($data['clave_asignatura']) /* line 31 */ ?>" class="validate"></label>
  </li>
  <li>
    <label for="id_carrera">Selecciona una Carrera:</label>
      <select class="browser-default" name="id_carrera">
      <option value="<?php echo LR\Filters::escapeHtmlAttr($data['id_carrera']) /* line 36 */ ?>" name="id_carrera"><?php
		echo LR\Filters::escapeHtmlText($data['carrera']) /* line 36 */ ?></option>
<?php
		$iterations = 0;
		foreach ($all_careers_information as $careerOption) {
			?>      <option  value="<?php echo LR\Filters::escapeHtmlAttr($careerOption['id']) /* line 38 */ ?>" ><?php
			echo LR\Filters::escapeHtmlText($careerOption['nombre']) /* line 38 */ ?></option>
<?php
			$iterations++;
		}
?>
    </select>
  </li>

 <li>
    <label for="clave asignatura">Selecciona una modalidad:</label>
      <select class="browser-default" name="clave_asignatura">
      <option value="<?php echo LR\Filters::escapeHtmlAttr($data['clave_asignatura']) /* line 46 */ ?>" name="clave_asignatura"><?php
		echo LR\Filters::escapeHtmlText($data['asignatura']) /* line 46 */ ?></option>
<?php
		$iterations = 0;
		foreach ($all_lessons_information as $subjecttyOption) {
			?>      <option  value="<?php echo LR\Filters::escapeHtmlAttr($subjecttyOption['clave']) /* line 48 */ ?>" ><?php
			echo LR\Filters::escapeHtmlText($subjecttyOption['nombre']) /* line 48 */ ?></option>
<?php
			$iterations++;
		}
?>
    </select>
  </li>
<button id="guardar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Guardar<i class="material-icons left">send</i></button>

</div>
</form>
<form action="<?php
		echo $router->relativeUrlFor("showAllSubjects");
?>" method="post">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 57 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 58 */ ?>">
 <button id="retornar" type="submit" class="btn btn-primary btn-sm float-1" style="background-color: #10c2ee" >Retornar<i class="material-icons left">arrow_back</i></button>
            </form>

</div>

    <!--footer -->
                   <div class="content"></div>
            <div class="footer-copyright blue-grey lighten-3" >
            <div class="container">
           <img class="header container section" src="/materialize/css/pie.jpg">
            </div>
          </div>
        </footer>
</body>
<script> M.AutoInit(); </script>
</html><?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['careerOption'])) trigger_error('Variable $careerOption overwritten in foreach on line 37');
		if (isset($this->params['subjecttyOption'])) trigger_error('Variable $subjecttyOption overwritten in foreach on line 47');
		
	}

}
