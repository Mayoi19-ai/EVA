<?php
// source: validationCreate.latte

use Latte\Runtime as LR;

class Templatecf470ad0f9 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		if (!empty($validation)) {
			if ($validation['flag'] === false) {
				$iterations = 0;
				foreach ($validation['errorMessages'] as $error) {
?>
      <script type='text/javascript'>
        alert(<?php echo LR\Filters::escapeJs($error) /* line 5 */ ?>);
      </script>
	    <!--<span><?php echo LR\Filters::escapeHtmlComment($error) /* line 7 */ ?></span>-->
<?php
					$iterations++;
				}
			}
			else {
?>
  <script>
    alert("Registro almacenado");
  </script> 
<?php
			}
		}
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['error'])) trigger_error('Variable $error overwritten in foreach on line 3');
		
	}

}
