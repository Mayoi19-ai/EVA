<?php
// source: AsignarR/assignRUpdate.latte

use Latte\Runtime as LR;

class Template1aafe28e88 extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		/* line 1 */
		$this->createTemplate('../validationUpdate.latte', $this->params, "include")->renderToContentType('html');
		/* line 2 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 7 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
      <link type="text/css" rel="stylesheet" href="/materialize/css/formularios.css"  media="screen,projection">
</head>
<body>
 <ul id="nav-mobile">
<div class="container section">
<form name="rolUpdateForm" method="post" action="<?php
		echo $router->relativeUrlFor("userRolesUpdate");
?>">
<input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 17 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 18 */ ?>">
            <input type="hidden" name="usuario" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario']) /* line 19 */ ?>">
            <input type="hidden" name="rol" value="<?php echo LR\Filters::escapeHtmlAttr($data['rol']) /* line 20 */ ?>">
            
<ul>
  <li>
    <label><input type="hidden" id="id_usuario_antiguo" name="id_usuario_antiguo" value="<?php echo LR\Filters::escapeHtmlAttr($data['id_usuario']) /* line 24 */ ?>" class="validate"></label>
  </li>
  <li>
    <label for="id_usuario">Selecciona un usuario:</label>
      <select class="browser-default" name="id_usuario">
      <option value="<?php echo LR\Filters::escapeHtmlAttr($data['id_usuario']) /* line 29 */ ?>" name="id_usuario"><?php
		echo LR\Filters::escapeHtmlText($data['usuario']) /* line 29 */ ?></option>
<?php
		$iterations = 0;
		foreach ($users as $usuarioOption) {
			?>      <option  value="<?php echo LR\Filters::escapeHtmlAttr($usuarioOption['id']) /* line 31 */ ?>" ><?php
			echo LR\Filters::escapeHtmlText($usuarioOption['nombre']) /* line 31 */ ?></option>
<?php
			$iterations++;
		}
?>
    </select>
  </li>

<li>
    <label><input type="hidden" id="id_roles_antiguo" name="id_roles_antiguo" value="<?php echo LR\Filters::escapeHtmlAttr($data['id_roles']) /* line 37 */ ?>" class="validate"></label>
  </li>
  <li>

  <li>
    <label for="id_roles">Selecciona un rol:</label>
      <select class="browser-default" name="id_roles">
      <option value="<?php echo LR\Filters::escapeHtmlAttr($data['id']) /* line 44 */ ?>" name="id_roles"><?php
		echo LR\Filters::escapeHtmlText($data['rol']) /* line 44 */ ?></option>
<?php
		$iterations = 0;
		foreach ($roles as $rolesOption) {
			?>      <option  value="<?php echo LR\Filters::escapeHtmlAttr($rolesOption['id']) /* line 46 */ ?>" ><?php
			echo LR\Filters::escapeHtmlText($rolesOption['nombre']) /* line 46 */ ?></option>
<?php
			$iterations++;
		}
?>
    </select>
  </li>
   
<button id="guardar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Guardar<i class="material-icons left">send</i></button>
</div>
</form>
<div>
<form action="<?php
		echo $router->relativeUrlFor("showAllUserRoles");
?>" method="post">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 56 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 57 */ ?>">
 <button id="retornar" type="submit" class="btn btn-primary btn-sm float-1" style="background-color: #10c2ee" >Retornar<i class="material-icons left">arrow_back</i></button>
            </form>

</div>

    <div class="content"></div>
            <div class="footer-copyright blue-grey lighten-3" >
            <div class="container">
           <img class="header container section" src="/materialize/css/pie.jpg">
            </div>
          </div>
        </footer>
</body>
<script> M.AutoInit(); </script>
</html><?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['usuarioOption'])) trigger_error('Variable $usuarioOption overwritten in foreach on line 30');
		if (isset($this->params['rolesOption'])) trigger_error('Variable $rolesOption overwritten in foreach on line 45');
		
	}

}
