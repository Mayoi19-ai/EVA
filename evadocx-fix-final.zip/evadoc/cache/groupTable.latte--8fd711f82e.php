<?php
// source: Grupo/groupTable.latte

use Latte\Runtime as LR;

class Template8fd711f82e extends Latte\Runtime\Template
{
	public $blocks = [
		'content' => 'blockContent',
	];

	public $blockTypes = [
		'content' => 'html',
	];


	function main()
	{
		extract($this->params);
		/* line 1 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
		/* line 2 */
		$this->createTemplate('../validationDelete.latte', $this->params, "include")->renderToContentType('html');
		if ($this->getParentName()) return get_defined_vars();
		$this->renderBlock('content', get_defined_vars());
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['permissionInfor'])) trigger_error('Variable $permissionInfor overwritten in foreach on line 78, 96, 113');
		if (isset($this->params['groupShow'])) trigger_error('Variable $groupShow overwritten in foreach on line 59');
		
	}


	function blockContent($_args)
	{
		extract($_args);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 9 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
      
</head>
<body>
<!-- -->
<div class="container section">
<ul id="nav-mobile">
                <div class="row">
                <div class="col s12 m6 l3">
<form name="SearchForm" method="post" action="<?php
		echo $router->relativeUrlFor("groupSearch");
?>">
<label for="grupo">Busqueda por grupo<label>
          <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 23 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 24 */ ?>">
             <input type="text" name="grupo">
 <button id="buscar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee">Buscar<i class="material-icons left">search</i></button>
</div>
</div>
</div>
</form>
<!-- -->
<?php
		if (empty ($query)) {
?>
       
       <div class="card center">
              <div class="card center">
              <img class="logo" src="/materialize/css/alerta3.png">
                     <h5>NO HAY GRUPOS REGISTRADOS</h5>
                       <form action="<?php
			echo $router->relativeUrlFor("userMenu");
?>" method="post">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 39 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 40 */ ?>">
 <input id="retorno" type="submit" class="btn btn-primary btn-sm" value='Retornar'>
            </form>
       </div>
</div>

<?php
		}
		else {
?>
<table name="showAllGroups" method="get" class="bordered striped hoverable centered responsive-table"> <!-- nombre de tabla-->
<thead>
<tr>
<th>Grupo</th>
<th>Carrera</th>
<th>Modalidad</th>
<th>Campus</th>
<th></th>
<th></th>
</tr>
</thead>
<tbody>
<?php
			$iterations = 0;
			foreach ($query as $groupShow) {
?>
<tr>
    <td><?php echo LR\Filters::escapeHtmlText($groupShow['grupo']) /* line 61 */ ?> </td>
    <td><?php echo LR\Filters::escapeHtmlText($groupShow['carrera']) /* line 62 */ ?> </td>
    <td><?php echo LR\Filters::escapeHtmlText($groupShow['modalidad']) /* line 63 */ ?> </td>
    <td><?php echo LR\Filters::escapeHtmlText($groupShow['campus']) /* line 64 */ ?> </td>
    <td>
<form action="<?php
				echo $router->relativeUrlFor("groupUpdateForm");
?>" method="post">
            <input type="hidden" name="grupo" value="<?php echo LR\Filters::escapeHtmlAttr($groupShow['grupo']) /* line 67 */ ?>">
              <input type="hidden" name="id_carrera" value="<?php echo LR\Filters::escapeHtmlAttr($groupShow['id_carrera']) /* line 68 */ ?>">
              <input type="hidden" name="id_modalidad" value="<?php echo LR\Filters::escapeHtmlAttr($groupShow['id_modalidad']) /* line 69 */ ?>">
              <input type="hidden" name="id_campus" value="<?php echo LR\Filters::escapeHtmlAttr($groupShow['id_campus']) /* line 70 */ ?>">
               <input type="hidden" name="nombre_carrera" value="<?php echo LR\Filters::escapeHtmlAttr($groupShow['carrera']) /* line 71 */ ?>">
              <input type="hidden" name="nombre_modalidad" value="<?php echo LR\Filters::escapeHtmlAttr($groupShow['modalidad']) /* line 72 */ ?>">
              <input type="hidden" name="nombre_campus" value="<?php echo LR\Filters::escapeHtmlAttr($groupShow['campus']) /* line 73 */ ?>">
             <!--No borrar -->
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 75 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 76 */ ?>">
            <!--No borrar -->
<?php
				$iterations = 0;
				foreach ($permissions as $permissionInfor) {
					$permisos  = explode(" - ", $permissionInfor['enlace']);
					;
					if ($permisos[1] == "groupUpdateForm") {
?>
       <button id="actualizar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Editar<i class="material-icons left">edit</i></button>
<?php
					}
					$iterations++;
				}
?>
</form>
</td>
<td>
    <form action="<?php
				echo $router->relativeUrlFor("groupDelete");
?>" method="post" onsubmit="return confirmation()">
            <input type="hidden" name="grupo" value="<?php echo LR\Filters::escapeHtmlAttr($groupShow['grupo']) /* line 88 */ ?>">
             <input type="hidden" name="id_carrera" value="<?php echo LR\Filters::escapeHtmlAttr($groupShow['id_carrera']) /* line 89 */ ?>">
             <input type="hidden" name="id_modalidad" value="<?php echo LR\Filters::escapeHtmlAttr($groupShow['id_modalidad']) /* line 90 */ ?>">
             <input type="hidden" name="id_campus" value="<?php echo LR\Filters::escapeHtmlAttr($groupShow['id_campus']) /* line 91 */ ?>">
            <!-- No tocar lo de abajo-->
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 93 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 94 */ ?>">
            <!--No tocar lo de arriba -->
<?php
				$iterations = 0;
				foreach ($permissions as $permissionInfor) {
					$permisos  = explode(" - ", $permissionInfor['enlace']);
					;
					if ($permisos[1] == "groupDelete") {
?>
    <button type="submit" id="eliminar" style="background-color: #f44336" class="btn btn-primary btn-sm #f44336" value='Eliminar'>Eliminar<i class="material-icons left">delete</i></button>
<?php
					}
					$iterations++;
				}
?>
    </form>
</td>

</tr>
<?php
				$iterations++;
			}
?>

</tbody>
 <form action="<?php
			echo $router->relativeUrlFor("groupSaveForm");
?>" method="post">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 110 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 111 */ ?>">
   <div class="fixed-action-btn">
<?php
			$iterations = 0;
			foreach ($permissions as $permissionInfor) {
				$permisos  = explode(" - ", $permissionInfor['enlace']);
				;
				if ($permisos[1] == "groupSaveForm") {
?>
<button id="agrerar" type="submit" class="btn btn-primary btn-sm float-2" style="background-color: #22DD22" >Agregar<i class="material-icons left">add</i></button>
<?php
				}
				$iterations++;
			}
		}
?>
</form>
</div>
</table>
</div>
<!--footer -->
                  <div class="content"></div>
            <div class="footer-copyright blue-grey lighten-3" >
            <div class="container">
           <img class="header container section" src="/materialize/css/pie.jpg">
            </div>
          </div>
        </footer>
</body>
<script> M.AutoInit(); </script>
</html>
<?php
	}

}
