<?php
// source: Docente/teacherUpdate.latte

use Latte\Runtime as LR;

class Template438b857f8e extends Latte\Runtime\Template
{

	function main()
	{
		extract($this->params);
		/* line 1 */
		$this->createTemplate('../validationUpdate.latte', $this->params, "include")->renderToContentType('html');
		/* line 2 */
		$this->createTemplate('../Menu/navegar.latte', $this->params, "include")->renderToContentType('html');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo LR\Filters::escapeHtmlText($title) /* line 7 */ ?></title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <link type="text/css" rel="stylesheet" href="/materialize/css/materialize.min.css"  media="screen,projection">
       <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
<link type="text/css" rel="stylesheet" href="/materialize/css/formularios.css"  media="screen,projection">
</head>
<body>
<ul id="nav-mobile">
<div class="container section">
<form name="teacherUpdateForm" method="post" action="<?php
		echo $router->relativeUrlFor("teacherUpdate");
?>">
<input type="hidden" name="nombre_departamento" value="<?php echo LR\Filters::escapeHtmlAttr($data['nombre_departamento']) /* line 17 */ ?>">
<!-- -->
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 19 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 20 */ ?>">
            <!-- -->
       
<li>
    <label><input type="hidden" id="folio_antiguo" name="folio_antiguo" value="<?php echo LR\Filters::escapeHtmlAttr($data['folio']) /* line 24 */ ?>" class="validate"></label>
  </li>
  <li>
    <label for="folio">Folio docente:</label>
    <label><input id="folio" name="folio" value="<?php echo LR\Filters::escapeHtmlAttr($data['folio']) /* line 28 */ ?>" class="validate"></label>
  </li>
  <li>
    <label for="clave">Nombre:</label>
    <label><input type="text" id="nombre" name="nombre" value="<?php echo LR\Filters::escapeHtmlAttr($data['nombre']) /* line 32 */ ?>" class="validate"></label>
  </li>
  <li>
    <label for="clave">Departamento:</label>
      <select class="browser-default" name="clave_departamento" id="clave_departamento">
      <option value="<?php echo LR\Filters::escapeHtmlAttr($data['clave_departamento']) /* line 37 */ ?>" name="clave_departamento"><?php
		echo LR\Filters::escapeHtmlText($data['nombre_departamento']) /* line 37 */ ?></option>
<?php
		$iterations = 0;
		foreach ($all_departments_information as $option) {
			?>      <option  value="<?php echo LR\Filters::escapeHtmlAttr($option['clave']) /* line 39 */ ?>" ><?php
			echo LR\Filters::escapeHtmlText($option['nombre']) /* line 39 */ ?></option>
<?php
			$iterations++;
		}
?>
    </select>
  </li>
 
<button id="guardar" type="submit" class="btn btn-primary btn-sm" style="background-color: #10c2ee" >Guardar<i class="material-icons left">send</i></button>
</div>
</form>
<div>
<form action="<?php
		echo $router->relativeUrlFor("showAllTeachers");
?>" method="post">
            <input type="hidden" name="usuario_activo" value="<?php echo LR\Filters::escapeHtmlAttr($data['usuario_activo']) /* line 49 */ ?>">
            <input type="hidden" name="categoria_permisos" value="<?php echo LR\Filters::escapeHtmlAttr($data['categoria_permisos']) /* line 50 */ ?>">
 <button id="retornar" type="submit" class="btn btn-primary btn-sm float-1" style="background-color: #10c2ee" >Retornar<i class="material-icons left">arrow_back</i></button>
            </form>

</div>
   <!--footer -->
                 <div class="content"></div>
            <div class="footer-copyright blue-grey lighten-3" >
            <div class="container">
           <img class="header container section" src="/materialize/css/pie.jpg">
            </div>
          </div>
        </footer>
</body>
<script> M.AutoInit(); </script>
</html><?php
		return get_defined_vars();
	}


	function prepare()
	{
		extract($this->params);
		if (isset($this->params['option'])) trigger_error('Variable $option overwritten in foreach on line 38');
		
	}

}
