<?php
namespace App\Validator;
use Rakit\Validation\Validator;

class CourseValidator{
    private Validator $validator;

    public function __construct(Validator $validator) {
        $this->validator = $validator;
    }

    public function validateSaveCourse(array $data): array {
        $validationRules = [
            'grupo'                          =>  'required|alpha_dash|between:5,5',
            'clave_asignatura_id_carrera'    =>  'required',
            'folio_docente'                  =>  'required|numeric|digits_between:1,3',
        ];

        $errorMessages = [
            'grupo:required'                        => 'El grupo es obligatorio',
            'grupo:alpha_dash'                      => 'El grupo no acepta espacios ni caracteres especiales',
            'grupo:between'                         => 'El grupo debe tener 5 caracteres',
            'clave_asignatura_id_carrera:required'  => 'La clave de asignatura es obligatoria',
            'folio_docente:required'                =>  'El folio del docente es obligatorio',
            'folio_docente:digits_between'          =>  'El folio del docente debe tener 1 a 3 digitos',
            'folio_docente:numeric'                 =>  'El folio del docente solo acepta números',
        ];

        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data);
    }
}