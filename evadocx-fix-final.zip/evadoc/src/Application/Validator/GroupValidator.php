<?php
namespace App\Validator;
use Rakit\Validation\Validator;

class GroupValidator{
    private Validator $validator;

    public function __construct(Validator $validator) {
        $this->validator = $validator;
    }

    public function validateSaveGroup(array $data): array {
        $validationRules = [
            'grupo'        =>  'required|alpha_dash|between:5,5',
            'id_carrera'    =>  'required|numeric|digits_between:1,10',
            'id_modalidad'  =>  'required|numeric|digits_between:1,10',
            'id_campus'     =>  'required|numeric|digits_between:1,10',
        ];

        $errorMessages = [
            'grupo:required'               => 'El nombre es obligatorio',
            'grupo:alpha_dash'             => 'El nombre no acepta espacios ni caracteres especiales',
            'grupo:between'                => 'El nombre debe tener 5 caracteres',
            'id_carrera:required'          => 'La clave de carrera es obligatoria',
            'id_carrera:numeric'           => 'La clave de carrera es numerica',
            'id_carrera:between'           => 'La clave de carrera debe tener entre 1 a 10 caracteres',
            'id_modalidad:required'        => 'La clave de modalidad es obligatoria',
            'id_modalidad:numeric'         => 'La clave de modalidad solo acepta números',
            'id_modalidad:digits_between'  => 'La clave de modadalidad debe tener entre 1 a 10 caracteres',
            'id_campus:required'           => 'La clave de campus es obligatoria',
            'id_campus:numeric'            => 'La clave de campus solo acepta números',
            'id_campus:digits_between'     => 'La clave de campus debe tener entre 1 a 10 caracteres',
        ];

        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data);
    }

    public function validateFindGroup(array $data): array {
        $validationRules = [
            'grupo'        =>  'required|alpha_dash|between:1,5',
        ];

        $errorMessages = [
            'grupo:required'              => 'El grupo es obligatorio',
            'grupo:alpha_dash'            => 'El grupo no acepta espacios ni caracteres especiales',
            'grupo:between'               => 'El grupo debe tener 3 a 5 caracteres',
        ];

        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data);
    }
}