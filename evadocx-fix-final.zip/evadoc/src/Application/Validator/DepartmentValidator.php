<?php
namespace App\Validator;
use Rakit\Validation\Validator;

class DepartmentValidator{
    private Validator $validator;

    public function __construct(Validator $validator) {
        $this->validator = $validator;
    }

    public function validateSaveDepartment(array $data): array {
        $validationRules = [
            'clave'          =>  'required|numeric|digits_between:3,3',
            'nombre'         =>  'required|alpha_spaces',
        ];

        $errorMessages = [
            'clave:required'        => 'La clave es obligatoria',
            'clave:numeric'         => 'La clave solo acepta números',
            'clave:digits_between'  => 'La clave debe tener 3 digitos',
            'nombre:required'       => 'El nombre es obligatorio',
            'nombre:alpha_spaces'   => 'El nombre no es válido',
        ];

        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data);
    }

    public function validateFindDepartment(array $data): array {
        $validationRules = [
            'nombre'         =>  'required|alpha_spaces',
        ];

        $errorMessages = [
            'nombre:required'       => 'El nombre es obligatorio',
            'nombre:alpha_spaces'   => 'El nombre no es válido',
        ];

        $validator = new CustomValidator($this->validator, $validationRules, $errorMessages);
        return $validator->validate($data);
    }
}