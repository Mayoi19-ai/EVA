<?php
namespace App\Controller\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use App\Validator\InscriptionValidator as Validator;
use App\Validator\StudentValidator as StudentVal;
use App\Validator\GroupValidator as GroupVal;
use Ujpef\LatteView;
use App\Infrastructure\CrudSystem\InscriptionInfrastructure as Infrastructure;
use App\Infrastructure\CrudSystem\CourseInfrastructure as CourseInfra;
use App\Infrastructure\CrudSystem\StudentInfrastructure as StudentInfra;
use App\Infrastructure\Login\Login as LoginInfra;

class InscriptionController{
    private Container $container;
    private Infrastructure $infrastructure;
    private CourseInfra $courseInfra;
    private StudentInfra $studentInfra;
    private StudentVal $studentVal;
    private LoginInfra $LoginInfra;
    private GroupVal $groupVal;
    private Validator $validator;
    
    public function __construct(Container $container, Infrastructure $infrastructure, CourseInfra $courseInfra, StudentInfra $studentInfra, StudentVal $studentVal, LoginInfra $LoginInfra, GroupVal $groupVal, Validator $validator)
    {
        $this->container = $container;
        $this->infrastructure = $infrastructure;
        $this->validator = $validator;
        $this->courseInfra = $courseInfra;
        $this->studentInfra = $studentInfra;
        $this->studentVal = $studentVal;
        $this->loginInfra = $LoginInfra;
        $this->groupVal = $groupVal;
    }

    public function saveForm(Request $request, Response $response){
        $courseData = $this->courseInfra->readAll();
        $studentData = $this->studentInfra->readAll();
        $data = (array)$request->getParsedBody();
        $permissions = $this->loginInfra->userPermissions((array) $data);
        $sthResult = $this->infrastructure->readAll();

        return $this->container->get(LatteView::class)->render($response, 
            'Inscripcion/inscriptionForm.latte', [
                'all_courses_information' => $courseData,
                'all_students_information' => $studentData,
                'permissions' => $permissions,
                'query' => $sthResult,
                'data' => $data
            ]);
    }

    public function register(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $courseData = $this->courseInfra->readAll();
        $studentData = $this->studentInfra->readAll();
        $permissions = $this->loginInfra->userPermissions((array) $data);
        $validationResult = $this->validator->validateSaveInscription((array) $data);

        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->create((array) $data);
        } else {
            $sthResult = false;
        }

        return $this->container->get(LatteView::class)->render($response, 
            'Inscripcion/inscriptionForm.latte', [
                'all_courses_information' => $courseData,
                'all_students_information' => $studentData,
                'permissions' => $permissions,
                'query' => $sthResult,
                'data' => $data,
                'validation' => $validationResult,
            ]);
    }

    public function show(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $sthResult = $this->infrastructure->readAll();
        $permissions = $this->loginInfra->userPermissions((array) $data);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Inscripcion/inscriptionTable.latte', [
                'query' => $sthResult,
                'data' => $data,
                'permissions' => $permissions
            ]);
    }

    public function showByCareer(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $permissions = $this->loginInfra->userPermissions((array) $data);
        $sthResult = $this->infrastructure->groupByCareer();

        return $this->container->get(LatteView::class)->render(
            $response,
            'Inscripcion/inscriptionTableCareer.latte', [
                'query' => $sthResult,
                'data' => $data,
                'permissions' => $permissions
            ]);
    }

    public function showByGroup(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $permissions = $this->loginInfra->userPermissions((array) $data);
        $sthResult = $this->infrastructure->groupByGroups();

        return $this->container->get(LatteView::class)->render(
            $response,
            'Inscripcion/inscriptionTableGroup.latte', [
                'query' => $sthResult,
                'data' => $data,
                'permissions' => $permissions
            ]);
    }

    public function searchByStudent(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $validationResult = $this->studentVal->validateFindStudent((array) $data);
        $permissions = $this->loginInfra->userPermissions((array) $data);

        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->readByStudent((string) $data['control']);
        } else {
            $sthResult = false;
        }

        return $this->container->get(LatteView::class)->render(
            $response,
            'Inscripcion/inscriptionTable.latte', [
                'validation' => $validationResult, 
                'query' => $sthResult,
                'data' => $data,
                'permissions' => $permissions
            ]);
    }

    public function searchByGroup(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $validationResult = $this->groupVal->validateFindGroup((array) $data);
        $permissions = $this->loginInfra->userPermissions((array) $data);

        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->searchByGroup((string) $data['grupo']);
        } else {
            $sthResult = false;
        }

        return $this->container->get(LatteView::class)->render(
            $response,
            'Inscripcion/inscriptionTableGroup.latte', [
                'validation' => $validationResult, 
                'query' => $sthResult,
                'data' => $data,
                'permissions' => $permissions
            ]);
    }

    public function updateForm(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $sthResult = $this->infrastructure->readAll();
        $permissions = $this->loginInfra->userPermissions((array) $data);
        $courseData = $this->courseInfra->readAll();
        $studentData = $this->studentInfra->readAll();

        return $this->container->get(LatteView::class)->render(
            $response,
            'Inscripcion/inscriptionUpdate.latte', [
                'query' => $sthResult,
                'all_courses_information'=> $courseData,
                'all_students_information'=> $studentData,
                'data' => $data,
                'permissions' => $permissions
            ]);
    }

    public function update(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $permissions = $this->loginInfra->userPermissions((array) $data);
        $validationResult = $this->validator->validateSaveInscription((array) $data);
        $courseData = $this->courseInfra->readAll();
        $studentData = $this->studentInfra->readAll();

        if(!empty($validationResult['flag'])) {
            $sthResult = $this->infrastructure->update((array) $data);
        } else {
            $sthResult = false;
        }

        return $this->container->get(LatteView::class)->render(
            $response,
            'Inscripcion/inscriptionUpdate.latte', [
                'validation' => $validationResult, 
                'query' => $sthResult,
                'all_courses_information'=> $courseData,
                'all_students_information'=> $studentData,
                'data' => $data,
                'permissions' => $permissions
            ]);
    }

    public function updateByCareer(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $permissions = $this->loginInfra->userPermissions((array) $data);
        $this->infrastructure->updateByCareer((array) $data);
        $sthResult = $this->infrastructure->groupByCareer();

        return $this->container->get(LatteView::class)->render(
            $response,
            'Inscripcion/inscriptionTableCareer.latte', [
                'query' => $sthResult,
                'data' => $data,
                'permissions' => $permissions
            ]);
    }

    public function updateByGroup(Request $request, Response $response){
        $data = (array)$request->getParsedBody();
        $this->infrastructure->updateByGroup((array) $data);
        $sthResult = $this->infrastructure->groupByGroups();
        $permissions = $this->loginInfra->userPermissions((array) $data);

        return $this->container->get(LatteView::class)->render(
            $response,
            'Inscripcion/inscriptionTableGroup.latte', [
                'query' => $sthResult,
                'data' => $data,
                'permissions' => $permissions
            ]);
    }

    public function delete(Request $request, Response $response, array $args){
        $data = (array)$request->getParsedBody();
        $this->infrastructure->delete((array) $data);
        $permissions = $this->loginInfra->userPermissions((array) $data);
        $sthResult = $this->infrastructure->readAll();

        return $this->container->get(LatteView::class)->render(
            $response,
            'Inscripcion/inscriptionTable.latte', [
                'query' => $sthResult,
                'data' => $data,
                'permissions' => $permissions
            ]);
    }
}