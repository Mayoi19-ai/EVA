<?php
namespace App\Controller\Student;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Container\ContainerInterface as Container;
use Ujpef\LatteView;

class LoginStudentController{
    private Container $container;

    public function __construct(Container $container){
        $this->container = $container;
    }

    public function login(Request $request, Response $response){
        return $this->container->get(LatteView::class)->render($response, 'Sesion/loginStudent.latte');
    }

    public function loginStudent(Request $request, Response $response){
        return $this->container->get(LatteView::class)->render($response, 'Sesion/loginStudent.latte');
    }
}