<?php
namespace App\Infrastructure\CrudSystem;

use Medoo\Medoo;
use App\Infrastructure\Exceptions\CustomException as Exception;
use App\Infrastructure\Binnacle\Binnacle;

class InscriptionInfrastructure 
{
    private Medoo $db;
    private Exception $exception;
    private Binnacle $binnacle;

    public function __construct(Medoo $db, Exception $exception, Binnacle $binnacle) 
    {
        $this->db = $db;
        $this->exception = $exception;
        $this->binnacle = $binnacle;
    }

    public function create(array $data): bool
    {
        $this->db->pdo->beginTransaction();
        $this->db->insert('inscripcion',[
            'id_curso' => $data['id_curso'], 
            'alumno_control' => $data['control'], 
            'activar' => $data['activar']
        ]);

        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Registrar',
        'tabla_afectada' => 'Inscripcion'));

        return $result = $this->exception->save((array) $this->db->error());
    }

    public function readAll(): ?array
    {
        $sql = <<<'EOP'
        SELECT 
        inscripcion.id AS 'id',
        inscripcion.activar AS 'activar',
        inscripcion.alumno_control AS 'control',
        alumno.nombre AS 'alumno',
        curso.id AS 'id_curso',
        curso.nombre_grupo AS 'grupo',
        carrera.nombre AS 'carrera',
        curso.id_carrera AS 'id_carrera',
        asignatura.nombre AS 'asignatura',
        curso.clave_asignatura AS 'clave_asignatura',
        docente.nombre AS 'docente',
        curso.folio_docente AS 'folio_docente'
        FROM 
        inscripcion
        INNER JOIN alumno
        ON alumno.control = inscripcion.alumno_control
        INNER JOIN curso
        ON inscripcion.id_curso = curso.id
        INNER JOIN docente
        ON docente.folio = curso.folio_docente
        INNER JOIN materia
        ON curso.id_carrera = materia.id_carrera AND curso.clave_asignatura = materia.clave_asignatura
        INNER JOIN carrera
        ON carrera.id = materia.id_carrera
        INNER JOIN asignatura 
        ON asignatura.clave = materia.clave_asignatura
        WHERE curso.id_periodo = (SELECT periodo.id FROM periodo WHERE periodo.activar = 1)
        ORDER BY carrera.id, curso.nombre_grupo ASC
        LIMIT 20;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->execute();
        $records = $sth->fetchAll();

        return $this->exception->read((array) $this->db->error(), (array) $records);
    }

    public function readByStudent(string $control): ?array
    {
        $sql = <<<'EOP'
        SELECT 
        inscripcion.id AS 'id',
        inscripcion.activar AS 'activar',
        inscripcion.alumno_control AS 'control',
        alumno.nombre AS 'alumno',
        curso.id AS 'id_curso',
        curso.nombre_grupo AS 'grupo',
        carrera.nombre AS 'carrera',
        curso.id_carrera AS 'id_carrera',
        asignatura.nombre AS 'asignatura',
        curso.clave_asignatura AS 'clave_asignatura',
        docente.nombre AS 'docente',
        curso.folio_docente AS 'folio_docente'
        FROM 
        inscripcion
        INNER JOIN alumno
        ON alumno.control = inscripcion.alumno_control
        INNER JOIN curso
        ON inscripcion.id_curso = curso.id
        INNER JOIN docente
        ON docente.folio = curso.folio_docente
        INNER JOIN materia
        ON curso.id_carrera = materia.id_carrera AND curso.clave_asignatura = materia.clave_asignatura
        INNER JOIN carrera
        ON carrera.id = materia.id_carrera
        INNER JOIN asignatura 
        ON asignatura.clave = materia.clave_asignatura
        WHERE curso.id_periodo = (SELECT periodo.id FROM periodo WHERE periodo.activar = 1)
        AND inscripcion.alumno_control LIKE '%' :control '%'
        ORDER BY carrera.id, curso.nombre_grupo ASC;
        EOP;

        $student = strtoupper($control);
        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':control', $student);
        $sth->execute();
        $records = $sth->fetchAll();
        
        return $this->exception->read((array) $this->db->error(), (array) $records);
    }

    public function groupByCareer(): ?array
    {
        $sql = <<<'EOP'
        SELECT 
        inscripcion.id AS 'id',
        inscripcion.activar AS 'activar',
        carrera.nombre AS 'carrera',
        curso.id_carrera AS 'id_carrera'
        FROM 
        inscripcion,
        alumno,
        curso,
        asignatura,
        carrera, 
        docente
        WHERE inscripcion.alumno_control = alumno.control
        AND inscripcion.id_curso = curso.id
        AND curso.id_carrera = carrera.id
        AND curso.clave_asignatura = asignatura.clave
        AND curso.folio_docente = docente.folio 
        AND curso.id_periodo = (SELECT periodo.id FROM periodo WHERE periodo.activar = 1) 
        GROUP BY curso.id_carrera
        ORDER BY carrera.id, curso.nombre_grupo ASC;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->execute();
        $records = $sth->fetchAll();
        
        return $this->exception->read((array) $this->db->error(), (array) $records);
    }

    public function groupByGroups(): ?array
    {
        $sql = <<<'EOP'
        SELECT 
        inscripcion.id AS 'id',
        inscripcion.activar AS 'activar',
        curso.nombre_grupo AS 'grupo',
        carrera.nombre AS 'carrera',
        curso.id_carrera AS 'id_carrera'
        FROM 
        inscripcion,
        alumno,
        curso,
        asignatura,
        carrera, 
        docente
        WHERE inscripcion.alumno_control = alumno.control
        AND inscripcion.id_curso = curso.id
        AND curso.id_carrera = carrera.id
        AND curso.clave_asignatura = asignatura.clave
        AND curso.folio_docente = docente.folio 
        AND curso.id_periodo = (SELECT periodo.id FROM periodo WHERE periodo.activar = 1)
        AND curso.nombre_grupo 
        GROUP BY curso.nombre_grupo
        ORDER BY carrera.id, curso.nombre_grupo ASC;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->execute();
        $records = $sth->fetchAll();
        
        return $this->exception->read((array) $this->db->error(), (array) $records);
    }

    public function searchByGroup(string $group): ?array
    {
        $sql = <<<'EOP'
        SELECT
        inscripcion.id AS 'id',
        inscripcion.activar AS 'activar',
        curso.nombre_grupo AS 'grupo',
        carrera.nombre AS 'carrera',
        curso.id_carrera AS 'id_carrera'
        FROM alumno
        INNER JOIN inscripcion 
        ON alumno.control = inscripcion.alumno_control
        INNER JOIN curso
        ON inscripcion.id_curso = curso.id
        INNER JOIN docente 
        ON docente.folio = curso.folio_docente
        INNER JOIN materia
        ON curso.id_carrera = materia.id_carrera AND curso.clave_asignatura = materia.clave_asignatura
        INNER JOIN carrera
        ON carrera.id = materia.id_carrera
        INNER JOIN asignatura 
        ON asignatura.clave = materia.clave_asignatura
        WHERE curso.id_periodo = (SELECT periodo.id FROM periodo WHERE periodo.activar = 1)
        AND curso.nombre_grupo LIKE '%' :grupo '%'
        GROUP BY curso.nombre_grupo
        ORDER BY carrera.nombre, curso.nombre_grupo ASC;
        EOP;

        $groupName = strtoupper($group);
        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':grupo', $groupName);
        $sth->execute();
        $records = $sth->fetchAll();
        
        return $this->exception->read((array) $this->db->error(), (array) $records);
    }

    public function updateByCareer(array $data): bool
    {
        $this->db->pdo->beginTransaction();
        $sql = <<<'EOP'
        UPDATE 
        inscripcion 
        SET inscripcion.activar = :activar
        WHERE
        inscripcion.id IN 
        (SELECT 
        inscripcion.id
        FROM 
        inscripcion
        INNER JOIN curso
        ON inscripcion.id_curso = curso.id
        WHERE curso.id_carrera = :id_carrera
        AND curso.id_periodo = (SELECT periodo.id FROM periodo WHERE periodo.activar = 1));
        EOP;
        
        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':activar', $data['activar']);
        $sth->bindParam(':id_carrera', $data['id_carrera']);
        $sth->execute();

        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Activar o desactivar carrera',
        'tabla_afectada' => 'Inscripcion'));

        return $this->exception->save((array) $this->db->error());
    }

    public function updateByGroup(array $data): bool
    {
        $this->db->pdo->beginTransaction();
        $sql = <<<'EOP'
        UPDATE 
        inscripcion 
        SET inscripcion.activar = :activar
        WHERE
        inscripcion.id IN 
        (SELECT 
        inscripcion.id
        FROM 
        inscripcion
        INNER JOIN curso
        ON inscripcion.id_curso = curso.id
        WHERE curso.nombre_grupo = :grupo 
        AND curso.id_periodo = (SELECT periodo.id FROM periodo WHERE periodo.activar = 1));
        EOP;
        
        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':activar', $data['activar']);
        $sth->bindParam(':grupo', $data['grupo']);
        $sth->execute();

        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Activar o desactivar grupo',
        'tabla_afectada' => 'Inscripcion'));

        return $this->exception->save((array) $this->db->error());
    }

    public function update(array $data): bool
    {
        $this->db->pdo->beginTransaction();
        $this->db->update('inscripcion', [
            'id_curso' => $data['id_curso'], 
            'alumno_control' => $data['control'],
            'activar' => $data['activar']], [
                'id' => $data['id']
        ]);

        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Actualizar',
        'tabla_afectada' => 'Inscripcion'));

        return $this->exception->save((array) $this->db->error());
    }
    
    public function delete(array $data): bool
    {
        $this->db->pdo->beginTransaction();
        $this->db->delete('inscripcion', [
            'id' => $data['id']
        ]);
        
        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Eliminar',
        'tabla_afectada' => 'Inscripcion'));

        return $this->exception->delete((array) $this->db->error());
    }
}