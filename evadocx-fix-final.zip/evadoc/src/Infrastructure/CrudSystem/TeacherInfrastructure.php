<?php
namespace App\Infrastructure\CrudSystem;

use Medoo\Medoo;
use App\Infrastructure\Exceptions\CustomException as Exception;
use App\Infrastructure\Binnacle\Binnacle;

class TeacherInfrastructure {
    private Medoo $db;
    private Exception $exception;
    private Binnacle $binnacle;

    public function __construct(Medoo $db, Exception $exception, Binnacle $binnacle) 
    {
        $this->db = $db;
        $this->exception = $exception;
        $this->binnacle = $binnacle;
    }

    public function create(array $data): bool
    {
        $this->db->pdo->beginTransaction();
        $this->db->insert('docente',[
            'folio' => $data['folio'], 
            'nombre' => strtoupper($data['nombre']),
            'clave_departamento' => $data['clave_departamento']
        ]);
        
        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Registrar',
        'tabla_afectada' => 'Docente'));
        
        return $this->exception->save((array) $this->db->error());
    }

    public function readAll(): ?array
    {
        $sql = <<<'EOP'
        SELECT docente.folio AS 'folio', 
        docente.nombre AS 'nombre',
        departamento.clave AS 'clave_departamento',
        departamento.nombre  AS 'departamento'
        FROM 
        docente,
        departamento 
        where docente.clave_departamento =  departamento.clave
        ORDER BY docente.nombre ASC;
        EOP;
        $sth = $this->db->pdo->prepare($sql);
        $sth->execute();
        $records = $sth->fetchAll();

        return $this->exception->read((array) $this->db->error(), (array) $records);
    }

    public function read(string $name): ?array
    {
        $sql = <<<'EOP'
        SELECT docente.folio AS 'folio', 
        docente.nombre AS 'nombre',
        departamento.clave AS 'clave_departamento',
        departamento.nombre  AS 'departamento'
        FROM 
        docente,
        departamento 
        where docente.clave_departamento = departamento.clave
        AND docente.nombre LIKE '%' :nombre '%'
        ORDER BY docente.nombre ASC;;
        EOP;
        $teacher = strtoupper($name);
        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':nombre', $teacher);
        $sth->execute();
        $records = $sth->fetchAll();

        return $this->exception->read((array) $this->db->error(), (array) $records);
    }

    public function orderByDepartment(int $codeDepartment): ?array
    {
        $sql = <<<'EOP'
        SELECT docente.folio AS 'folio', 
        docente.nombre AS 'nombre',
        departamento.clave AS 'clave_departamento',
        departamento.nombre  AS 'departamento'
        FROM 
        docente,
        departamento 
        WHERE docente.clave_departamento = departamento.clave
        AND departamento.clave = :clave_departamento
        ORDER BY docente.nombre ASC;
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':clave_departamento', $codeDepartment);
        $sth->execute();
        $records = $sth->fetchAll();

        return $this->exception->read((array) $this->db->error(), (array) $records);
    }

    public function update(array $data): bool
    {
        $this->db->pdo->beginTransaction();

        $this->db->update('docente', [
            'folio' => $data['folio'], 
            'nombre' => strtoupper($data['nombre']),
            'clave_departamento' => $data['clave_departamento']], [
                'folio' => $data['folio_antiguo']
            ]);

        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Actualizar',
        'tabla_afectada' => 'Docente'));

        return $this->exception->save((array) $this->db->error());
    }
    
    public function delete(array $data): bool
    {
        $this->db->pdo->beginTransaction();
        $this->db->delete('docente', [
            'folio' => $data['folio']
        ]);

        $this->binnacle->binnacle(array('usuario' => $data['usuario_activo'],
        'actividad' => 'Eliminar',
        'tabla_afectada' => 'Docente'));
        
        return $this->exception->delete((array) $this->db->error());
    }
}