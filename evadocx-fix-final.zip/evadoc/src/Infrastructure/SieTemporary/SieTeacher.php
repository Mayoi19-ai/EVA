<?php
namespace App\Infrastructure\SieTemporary;

use org\majkel\dbase\Table;
use Medoo\Medoo;

class SieTeacher {
    private Medoo $db;

    public function __construct(Medoo $db) {
        $this->db = $db;
    }

    public function loadSieTeacher (string $dbfFileTeacher) {
        $create = $this->createSieTeacher((string) $dbfFileTeacher);
        if(!empty($create[1])){
            $result = ['flag' => true, 
                        'error' => 'No se pudo crear estructura Docente SIE'];
            return $result;
        }

        return null;
    }

    private function createSieTeacher (string $dbfFileTeacher): array
    {
        $sql = <<<'EOP'
        DROP TABLE IF EXISTS `temp_dcat`;
        CREATE TEMPORARY TABLE IF NOT EXISTS `temp_dcat` (
            `cve` INT(3) UNSIGNED NOT NULL,
            `dep` INT(3) NOT NULL,
            `nom` VARCHAR(255) NOT NULL,
            PRIMARY KEY (`cve`));
        EOP;

        $this->db->query($sql);

        $file = Table::fromFile($dbfFileTeacher);

        foreach ($file as $record) {
            $this->db->insert("temp_dcat", [
                "cve" => $record['CAT_CVE'],
                "dep" => $record['CAT_DEP'],
                "nom" => utf8_encode($record['CAT_NOM'])
            ]);
        }

        return $this->db->error();
    }
}