<?php
namespace App\Infrastructure\Binnacle;

use Medoo\Medoo;

class Binnacle {
    private Medoo $db;
    
    public function __construct(Medoo $db) {
        $this->db = $db;
    }

    public function binnacle(array $binnacle)
    {
        $sql = <<<'EOP'
        CALL bitacoras(:usuario, :actividad, :tabla_afectada);
        EOP;

        $sth = $this->db->pdo->prepare($sql);
        $sth->bindParam(':usuario', $binnacle['usuario']);
        $sth->bindParam(':actividad', $binnacle['actividad']);
        $sth->bindParam(':tabla_afectada', $binnacle['tabla_afectada']);
        $sth->execute();
    }
}